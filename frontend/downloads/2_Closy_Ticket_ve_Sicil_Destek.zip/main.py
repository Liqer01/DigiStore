import os
import sys
import json
import asyncio
import html
import re
from datetime import datetime, timezone
from typing import Optional, Any, Union, Dict, List, Tuple
from collections import defaultdict

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import io
import secrets
import time
import subprocess
import atexit
import aiohttp
from aiohttp import web
import discord
from discord import app_commands
from discord.ext import commands, tasks
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# ─────────────────────────────────────────────
# DİZİNLER & AYARLAR (CONFIG)
# ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
TICKETS_PATH = os.path.join(BASE_DIR, "tickets.json")
TRANSCRIPTS_DIR = os.path.join(BASE_DIR, "transcripts")
TRANSCRIPT_INDEX_PATH = os.path.join(TRANSCRIPTS_DIR, "index.json")
SESSIONS_PATH = os.path.join(BASE_DIR, "staff_sessions.json")
os.makedirs(TRANSCRIPTS_DIR, exist_ok=True)
ticket_sse_listeners = defaultdict(list)

DEFAULT_CONFIG = {
    "bot_token": "BOT_TOKENINI_BURAYA_YAZIN",
    "bot_adi": "ɨ̇ ʍ ʐ ǟ",
    "embed_renk": "0x111216",
    "ticket_kategori_id": None,
    "ticket_log_kanal_id": None,
    "ticket_yetkili_rol_id": 0,
    "ticket_panel_kanal_id": None,
    "ticket_panel_mesaj_id": None,
    "dm_bildirim": False,
    "logo_url": None,
    "sabit_ses_kanal_id": 0,
    "stream_url": "https://www.twitch.tv/imzapriw",
    "web_host": "0.0.0.0",
    "web_port": 8080,
    "web_base_url": "http://188.119.11.236:8080"
}

def load_config() -> dict:
    if not os.path.exists(CONFIG_PATH):
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8-sig") as f:
            return {**DEFAULT_CONFIG, **json.load(f)}
    except Exception as e:
        print(f"[Config Okuma Hatası]: {e}")
        return DEFAULT_CONFIG.copy()

def save_config(cfg: dict):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=4)

def load_tickets() -> dict:
    if not os.path.exists(TICKETS_PATH):
        return {"counter": 0, "active": {}}
    try:
        with open(TICKETS_PATH, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        return {"counter": 0, "active": {}}

def save_tickets(data: dict):
    with open(TICKETS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

config = load_config()

# Yetkili Web Transkript ve Doğrulama Durumları
staff_pins = {}        # pin -> {"user_id": int, "expires_at": float}

def load_staff_sessions() -> dict:
    """Session'ları diskten yükle (bot restart'ta kaybolmasın)."""
    if not os.path.exists(SESSIONS_PATH):
        return {}
    try:
        with open(SESSIONS_PATH, "r", encoding="utf-8") as f:
            raw = json.load(f)
        # Süresi dolmuş session'ları temizle
        now = time.time()
        return {k: v for k, v in raw.items() if v.get("expires_at", 0) > now}
    except Exception:
        return {}

def save_staff_sessions(data: dict):
    """Session'ları diske kaydet."""
    try:
        with open(SESSIONS_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[Session Kaydetme Hatası]: {e}", flush=True)

staff_sessions = load_staff_sessions()  # disk'ten başlangıçta yükle

def load_transcript_index() -> dict:
    if not os.path.exists(TRANSCRIPT_INDEX_PATH):
        return {}
    try:
        with open(TRANSCRIPT_INDEX_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_transcript_index(data: dict):
    try:
        with open(TRANSCRIPT_INDEX_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[Transcript Index Hata]: {e}", flush=True)

def create_staff_session(user_id: int) -> str:
    token = secrets.token_hex(32)
    staff_sessions[token] = {
        "user_id": user_id,
        "expires_at": time.time() + (86400 * 7) # 7 gün geçerli
    }
    save_staff_sessions(staff_sessions)  # diske kaydet
    return token


def get_embed_color() -> int:
    renk_str = str(config.get("embed_renk", "0x111216")).strip()
    try:
        return int(renk_str, 16) if renk_str.startswith("0x") else int(renk_str)
    except ValueError:
        return 0x111216

def get_brand_logo_url(guild: discord.Guild = None) -> str:
    cfg_logo = config.get("logo_url")
    if cfg_logo and str(cfg_logo).startswith("http"):
        return cfg_logo
    if guild and guild.icon:
        return guild.icon.url
    return "https://cdn.discordapp.com/attachments/1066708687319760926/115000000000000000/imza.png"

# ─────────────────────────────────────────────
# KATEGORİ TANIMLARI
# ─────────────────────────────────────────────
TICKET_CATEGORIES = {
    "general": {
        "label": "Genel Destek & Soru",
        "description": "Sunucu işleyişi, genel sorular ve danışma",
        "emoji": None,
        "prefix": "destek"
    },
    "staff": {
        "label": "Yetkili & Kadro Başvurusu",
        "description": "Yönetim ekibine katılmak için yetkili başvurusu",
        "emoji": None,
        "prefix": "yetkili"
    },
    "vip": {
        "label": "VIP / Rol & Satın Alım",
        "description": "Özel roller, boost ayrıcalıkları ve satın alımlar",
        "emoji": None,
        "prefix": "vip"
    },
    "report": {
        "label": "Şikayet & Bildiri",
        "description": "Kullanıcı veya kural ihlali bildirimleri",
        "emoji": None,
        "prefix": "sikayet"
    },
    "private": {
        "label": "Özel Görüşme (Yönetim)",
        "description": "Kurucu ve üst yönetim ile birebir görüşme",
        "emoji": None,
        "prefix": "ozel"
    }
}

# ─────────────────────────────────────────────
# DISCORD BOT BAŞLATMA
# ─────────────────────────────────────────────
intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.messages = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

# ─────────────────────────────────────────────
# YARDIMCI YETKİ VE TİCKET FONKSİYONLARI
# ─────────────────────────────────────────────
def is_ticket_staff(member: discord.Member) -> bool:
    """Kullanıcının yalnızca 0 yetkili rolüne sahip olup olmadığını denetler (Yönetici veya Kurucu bypass'ı yoktur)."""
    if not member:
        return False
    STAFF_ROLE_ID = 0
    return any(r.id == STAFF_ROLE_ID for r in getattr(member, "roles", []))

async def check_user_has_staff_role(user_id: int) -> bool:
    """Verilen Discord ID'sine sahip kullanıcının yalnızca 0 yetkili rolüne sahip olup olmadığını denetler (Yönetici veya Kurucu bypass'ı yoktur)."""
    if not user_id:
        return False
    STAFF_ROLE_ID = 0
    for guild in bot.guilds:
        member = guild.get_member(user_id)
        if not member:
            try:
                member = await guild.fetch_member(user_id)
            except Exception:
                member = None
        if member:
            if any(r.id == STAFF_ROLE_ID for r in getattr(member, "roles", [])):
                return True
    return False

async def is_valid_staff_session(token: str) -> bool:
    """Oturum anahtarının geçerliliğini ve kullanıcının 0 rolünü doğrulur."""
    if not token or token not in staff_sessions:
        return False
    data = staff_sessions[token]
    if time.time() > data["expires_at"]:
        staff_sessions.pop(token, None)
        return False
    user_id = data.get("user_id")
    if not await check_user_has_staff_role(user_id):
        staff_sessions.pop(token, None)
        return False
    return True

def get_user_open_ticket(guild: discord.Guild, user_id: int):
    """Kullanıcının sunucuda açık bir bileti olup olmadığını bulur."""
    data = load_tickets()
    active = data.get("active", {})
    for ch_id_str, info in active.items():
        if info.get("owner_id") == user_id and info.get("status") == "open":
            ch = guild.get_channel(int(ch_id_str))
            if ch:
                return ch, info
    return None, None

# ─────────────────────────────────────────────
# TRANSKRİPT ÜRETİCİ (İNTERAKTİF WEB SİTESİ - INDEX.HTML)
# ─────────────────────────────────────────────
# SVG İkon Sabitleri (Zero Emoji Politikası)
SVG_LOCK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>'
SVG_USER_CHECK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><polyline points="17 11 19 13 23 9"></polyline></svg>'
SVG_FLAG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>'
SVG_HISTORY = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline><path d="M3.05 11a9 9 0 0 1 .5-2m-.5 2h3m-3 0V8"></path></svg>'
SVG_MENU = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>'
SVG_SEARCH = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>'
SVG_PRINT = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>'
SVG_USER = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>'
SVG_SHIELD = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>'
SVG_TAG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>'
SVG_CLOCK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>'
SVG_CALENDAR = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>'
SVG_CHECK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>'
SVG_FILE = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>'
SVG_DOWNLOAD = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>'
SVG_COPY = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>'
SVG_HASH = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="9" x2="20" y2="9"></line><line x1="4" y1="15" x2="20" y2="15"></line><line x1="10" y1="3" x2="8" y2="21"></line><line x1="16" y1="3" x2="14" y2="21"></line></svg>'
SVG_CHEVRON = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>'
SVG_CLOSE = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>'
SVG_EXPAND = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>'
SVG_CHAT = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>'
SVG_SEND = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>'
SVG_ALERT_TRIANGLE = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>'
SVG_LINK = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>'
SVG_TERMINAL = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 17 10 11 4 5"></polyline><line x1="12" y1="19" x2="20" y2="19"></line></svg>'
SVG_SHIELD_ALERT = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>'

SVG_VOLUME_2 = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>'
SVG_VOLUME_X = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>'
SVG_ARROW_UP = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>'
SVG_ARROW_DOWN = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>'
SVG_JSON = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="10" y1="13" x2="10" y2="13.01"/><line x1="14" y1="13" x2="14" y2="13.01"/><path d="M10 17a3.5 3.5 0 0 0 4 0"/></svg>'
SVG_TXT = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>'
SVG_BOLD = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/><path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/></svg>'
SVG_ITALIC = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="4" x2="10" y2="4"/><line x1="14" y1="20" x2="5" y2="20"/><line x1="15" y1="4" x2="9" y2="20"/></svg>'
SVG_CODE = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>'
SVG_QUOTE = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/></svg>'
SVG_EYE = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>'
SVG_RADIO = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="2"/><path d="M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14"/></svg>'

SVG_CHECK_CIRCLE = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>'
SVG_SETTINGS = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>'
SVG_MIC = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>'
SVG_HEADPHONES = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"></path><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"></path></svg>'
SVG_REFRESH = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>'
SVG_TRASH = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>'

def parse_discord_markdown(text: str, user_dict: dict = None, role_dict: dict = None, channel_dict: dict = None) -> str:
    """Discord mesaj metnini modern HTML etiketlerine dönüştürür."""
    if not text:
        return ""
    text = html.escape(text)

    # 1. Kod blokları
    text = re.sub(
        r'```([a-zA-Z0-9_\-\+]*)\n(.*?)```',
        r'<div class="code-container"><div class="code-header"><span class="code-lang">\1</span><button class="code-copy-btn" onclick="copyCode(this)" type="button">' + SVG_COPY + r'<span>Kopyala</span></button></div><pre class="code-block"><code>\2</code></pre></div>',
        text,
        flags=re.DOTALL
    )
    text = re.sub(
        r'```(.*?)```',
        r'<div class="code-container"><div class="code-header"><span class="code-lang">KOD</span><button class="code-copy-btn" onclick="copyCode(this)" type="button">' + SVG_COPY + r'<span>Kopyala</span></button></div><pre class="code-block"><code>\1</code></pre></div>',
        text,
        flags=re.DOTALL
    )

    # 2. Satır içi kod
    text = re.sub(r'`([^`\n]+)`', r'<code class="inline-code">\1</code>', text)

    # 3. Kalın
    text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)

    # 4. İtalik
    text = re.sub(r'(?<!\*)\*([^\*\n]+)\*(?!\*)', r'<em>\1</em>', text)
    text = re.sub(r'(?<!_)_([^_\n]+)_(?!_)', r'<em>\1</em>', text)

    # 5. Üstü Çizili
    text = re.sub(r'~~([^~\n]+)~~', r'<del>\1</del>', text)

    # 6. Altı Çizili
    text = re.sub(r'__(.+?)__', r'<u>\1</u>', text)

    # 7. Spoiler
    text = re.sub(r'\|\|(.*?)\|\|', r'<span class="spoiler" onclick="this.classList.toggle(\'revealed\')">\1</span>', text)

    # 8. Alıntı
    text = re.sub(r'^&gt;\s?(.*)$', r'<blockquote>\1</blockquote>', text, flags=re.MULTILINE)

    # 9. Slash komut / interaction etiketleri
    def replace_slash(m):
        cmd_name = m.group(1).split(":")[0].strip()
        return f'<span class="mention slash">/{html.escape(cmd_name)}</span>'
    text = re.sub(r'&lt;/([a-zA-Z0-9_\-\s]+):[0-9]+&gt;', replace_slash, text)
    text = re.sub(r'&lt;/&gt;', '', text)

    # 10. Discord zaman etiketleri
    def replace_ts(m):
        try:
            ts = int(m.group(1))
            dt = datetime.fromtimestamp(ts)
            return f'<span class="mention time-tag">{dt.strftime("%d.%m.%Y %H:%M")}</span>'
        except Exception:
            return m.group(0)
    text = re.sub(r'&lt;t:([0-9]+)(?::[a-zA-Z])?&gt;', replace_ts, text)

    # 11. Kullanıcı Etiketleri
    def replace_user_mention(m):
        uid = int(m.group(1))
        name = user_dict.get(uid, "Kullanıcı") if user_dict else "Kullanıcı"
        return f'<span class="mention user">@{html.escape(name)}</span>'
    text = re.sub(r'&lt;@!?([0-9]+)&gt;', replace_user_mention, text)

    # 12. Rol Etiketleri
    def replace_role_mention(m):
        rid = int(m.group(1))
        name = role_dict.get(rid, "Rol") if role_dict else "Rol"
        return f'<span class="mention role">@{html.escape(name)}</span>'
    text = re.sub(r'&lt;@&amp;([0-9]+)&gt;', replace_role_mention, text)

    # 13. Kanal Etiketleri
    def replace_ch_mention(m):
        cid = int(m.group(1))
        name = channel_dict.get(cid, "kanal") if channel_dict else "kanal"
        return f'<span class="mention channel">#{html.escape(name)}</span>'
    text = re.sub(r'&lt;#([0-9]+)&gt;', replace_ch_mention, text)

    # 14. Özel Emojiler -> temiz metin tagi (Zero emoji kuralı)
    text = re.sub(r'&lt;a?:([a-zA-Z0-9_]+):[0-9]+&gt;', r'<span class="custom-tag">:\1:</span>', text)

    # 15. Bağlantılar
    text = re.sub(r'(https?://[^\s<"]+)', r'<a href="\1" target="_blank" rel="noopener noreferrer" class="chat-link">\1</a>', text)

    # 16. Satır sonları
    parts = re.split(r'(<div class="code-container">.*?</div>|<pre.*?</pre>)', text, flags=re.DOTALL)
    for i in range(len(parts)):
        if not parts[i].startswith('<div class="code-container">') and not parts[i].startswith('<pre'):
            parts[i] = parts[i].replace('\n', '<br>')
    text = "".join(parts)

    return text

cloudflared_proc = None
active_tunnel_url = None
tunnel_restart_lock = asyncio.Lock()

async def is_tunnel_healthy(url: str = None) -> bool:
    """Belirtilen Cloudflare URL'sinin canlı ve istekleri karşılayabildiğini test eder."""
    global active_tunnel_url
    target = (url or active_tunnel_url or "").strip().rstrip("/")
    if not target or not target.startswith("https://"):
        return False
    try:
        timeout = aiohttp.ClientTimeout(total=4.0)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(f"{target}/api/health") as resp:
                return resp.status in (200, 403, 404)
    except Exception:
        return False

async def start_cloudflare_tunnel(port: int = 8080) -> Optional[str]:
    """Cloudflare Tunnel (trycloudflare.com) üzerinden port açma gerektirmeyen güvenli HTTPS tüneli kurar."""
    global cloudflared_proc, active_tunnel_url
    cf_path = os.path.join(BASE_DIR, "cloudflared.exe")
    if not os.path.exists(cf_path):
        print("[Cloudflare] cloudflared.exe bulunamadı, tünel başlatılamadı.", flush=True)
        return None

    # Halihazırda çalışan bir cloudflared ve tünel URL'si sağlıklıysa tüneli öldürme, koru!
    t_file = os.path.join(BASE_DIR, "tunnel_url.txt")
    if os.path.exists(t_file):
        try:
            with open(t_file, "r", encoding="utf-8") as f:
                existing_url = f.read().strip()
            if existing_url.startswith("https://") and await is_tunnel_healthy(existing_url):
                print(f"[Cloudflare] Halihazırda çalışan tünel aktif ve sağlıklı, korunuyor: {existing_url}", flush=True)
                active_tunnel_url = existing_url
                return existing_url
        except Exception:
            pass

    if cloudflared_proc:
        try:
            cloudflared_proc.terminate()
            cloudflared_proc.kill()
        except Exception:
            pass
        cloudflared_proc = None

    try:
        subprocess.run(["taskkill", "/f", "/im", "cloudflared.exe"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

    try:
        cloudflared_proc = subprocess.Popen(
            [cf_path, "tunnel", "--url", f"http://127.0.0.1:{port}"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace"
        )
        print("[Cloudflare] Canlı HTTPS web tüneli başlatılıyor...", flush=True)

        start_t = time.time()
        found_url = None
        while time.time() - start_t < 25:
            line = await asyncio.to_thread(cloudflared_proc.stdout.readline)
            if not line:
                await asyncio.sleep(0.2)
                continue
            m = re.search(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com", line)
            if m:
                found_url = m.group(0).rstrip("/")
                active_tunnel_url = found_url
                print(f"[Cloudflare] Canlı Web Transkript Tüneli Hazır: {found_url}", flush=True)
                try:
                    with open(os.path.join(BASE_DIR, "tunnel_url.txt"), "w", encoding="utf-8") as f:
                        f.write(found_url)
                except Exception:
                    pass
                break

        async def drain_cf():
            global active_tunnel_url
            try:
                while cloudflared_proc and cloudflared_proc.poll() is None:
                    line_cf = await asyncio.to_thread(cloudflared_proc.stdout.readline)
                    if line_cf:
                        m_new = re.search(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com", line_cf)
                        if m_new:
                            fresh_url = m_new.group(0).rstrip("/")
                            if fresh_url != active_tunnel_url:
                                active_tunnel_url = fresh_url
                                print(f"[Cloudflare] Canlı Web Tüneli Güncellendi: {fresh_url}", flush=True)
                                try:
                                    with open(os.path.join(BASE_DIR, "tunnel_url.txt"), "w", encoding="utf-8") as f:
                                        f.write(fresh_url)
                                except Exception:
                                    pass
            except Exception:
                pass
        asyncio.create_task(drain_cf())
        return found_url
    except Exception as e:
        print(f"[Cloudflare Tunnel Başlatma Hatası]: {e}", flush=True)
        return None

async def ensure_public_web_url() -> str:
    """Canlı, erişilebilir ve doğrulanmış web portal adresini döner. Gerekirse tüneli otomatik ayağa kaldırır."""
    global active_tunnel_url
    cfg_url = str(config.get("web_base_url", "")).strip()
    if cfg_url and cfg_url.lower() != "auto" and not any(h in cfg_url for h in ["localhost", "127.0.0.1", "192.168."]):
        return cfg_url.rstrip("/")

    # Halihazırdaki URL sağlıklıysa anında dön
    if active_tunnel_url and await is_tunnel_healthy(active_tunnel_url):
        return active_tunnel_url.rstrip("/")

    async with tunnel_restart_lock:
        if active_tunnel_url and await is_tunnel_healthy(active_tunnel_url):
            return active_tunnel_url.rstrip("/")

        port = int(config.get("web_port", 8080))
        new_url = await start_cloudflare_tunnel(port)
        if new_url:
            for _ in range(6):
                await asyncio.sleep(1)
                if await is_tunnel_healthy(new_url):
                    break
            return new_url

        t_file = os.path.join(BASE_DIR, "tunnel_url.txt")
        if os.path.exists(t_file):
            try:
                with open(t_file, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content.startswith("https://") and await is_tunnel_healthy(content):
                        active_tunnel_url = content
                        return content
            except Exception:
                pass

        return f"http://127.0.0.1:{port}"

def get_public_web_url() -> str:
    global active_tunnel_url
    cfg_url = str(config.get("web_base_url", "")).strip()
    if cfg_url and cfg_url.lower() != "auto" and not any(h in cfg_url for h in ["localhost", "127.0.0.1", "192.168."]):
        return cfg_url.rstrip("/")
    if active_tunnel_url:
        return active_tunnel_url.rstrip("/")
    t_file = os.path.join(BASE_DIR, "tunnel_url.txt")
    if os.path.exists(t_file):
        try:
            with open(t_file, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if content.startswith("https://"):
                    active_tunnel_url = content
                    return content
        except Exception:
            pass
    port = int(config.get("web_port", 8080))
    return f"http://127.0.0.1:{port}"

def cleanup_tunnel():
    global cloudflared_proc
    if cloudflared_proc:
        try:
            cloudflared_proc.terminate()
            cloudflared_proc.kill()
        except Exception:
            pass

atexit.register(cleanup_tunnel)

async def generate_html_transcript(channel: discord.TextChannel, ticket_info: dict = None, existing_slug_id: str = None) -> tuple:
    """Bilet kanalındaki tüm konuşmaları modern ve lüks bir web sitesi arayüzü (index.html) olarak derler."""
    messages = [m async for m in channel.history(limit=2500, oldest_first=True)]

    clean_ch_name = channel.name.replace("🎫・", "").replace("🔒・", "").replace("🎫", "").replace("🔒", "").strip()
    if existing_slug_id:
        slug_id = existing_slug_id
    else:
        slug_id = f"{clean_ch_name}_{secrets.token_hex(4)}"
    ticket_id = ticket_info.get("id", f"#{channel.id}") if ticket_info else f"#{channel.id}"
    owner_name = ticket_info.get("owner_name", "Bilinmiyor") if ticket_info else "Bilinmiyor"
    owner_id = ticket_info.get("owner_id", "Bilinmiyor") if ticket_info else "Bilinmiyor"
    category = ticket_info.get("category", "Destek Talebi") if ticket_info else "Destek Talebi"
    subject = ticket_info.get("subject", "Belirtilmedi") if ticket_info else "Belirtilmedi"
    claimed_by_name = ticket_info.get("claimed_by_name", "Üstlenilmedi") if ticket_info else "Üstlenilmedi"
    created_at = ticket_info.get("created_at", datetime.now().strftime("%d.%m.%Y %H:%M:%S")) if ticket_info else datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    closed_at = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    guild_name = channel.guild.name if channel.guild else config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    logo_url = get_brand_logo_url(channel.guild)

    # Geçen süreyi ve tarih formatlarını hatasız hesapla
    c_dt = None
    for fmt in ["%Y-%m-%d %H:%M:%S", "%d.%m.%Y %H:%M:%S", "%Y-%m-%dT%H:%M:%S"]:
        try:
            c_dt = datetime.strptime(str(created_at).split(".")[0], fmt)
            break
        except Exception:
            pass

    if not c_dt and messages:
        c_dt = messages[0].created_at.replace(tzinfo=None)

    display_created = c_dt.strftime("%d.%m.%Y %H:%M:%S") if c_dt else str(created_at)
    display_closed = datetime.now().strftime("%d.%m.%Y %H:%M:%S")

    duration_str = "Hesaplanamadı"
    if c_dt:
        diff = datetime.now() - c_dt
        secs = max(0, int(diff.total_seconds()))
        if secs < 60:
            duration_str = f"{secs} saniye"
        elif secs < 3600:
            duration_str = f"{secs // 60} dakika"
        elif secs < 86400:
            duration_str = f"{secs // 3600} saat {(secs % 3600) // 60} dakika"
        else:
            duration_str = f"{secs // 86400} gün {(secs % 86400) // 3600} saat"

    created_at = display_created
    closed_at = display_closed

    # Çözümleme sözlükleri
    user_dict = {}
    for m in messages:
        user_dict[m.author.id] = m.author.display_name
    if channel.guild:
        for m in channel.guild.members:
            user_dict[m.id] = m.display_name
        role_dict = {r.id: r.name for r in channel.guild.roles}
        channel_dict = {c.id: c.name for c in channel.guild.channels}
    else:
        role_dict = {}
        channel_dict = {}

    # Katılımcılar ve mesajları derle
    messages_html = []
    media_items_list = []
    author_stats = {}
    total_attachments = 0

    for msg in messages:
        author_name = msg.author.display_name
        avatar_url = msg.author.display_avatar.url if msg.author.display_avatar else "https://cdn.discordapp.com/embed/avatars/0.png"
        timestamp = msg.created_at.strftime("%d.%m.%Y %H:%M:%S")

        # İstatistik topla
        if author_name not in author_stats:
            author_stats[author_name] = {
                "avatar": avatar_url,
                "count": 0,
                "is_bot": msg.author.bot,
                "is_owner": str(msg.author.id) == str(owner_id),
                "is_staff": is_ticket_staff(msg.author) if hasattr(msg.author, 'guild_permissions') else False
            }
        author_stats[author_name]["count"] += 1

        # Rol Rozeti
        if msg.author.bot:
            badge_cls = "badge-bot"
            badge_text = "BOT"
        elif str(msg.author.id) == str(owner_id):
            badge_cls = "badge-owner"
            badge_text = "TALEP SAHİBİ"
        elif is_ticket_staff(msg.author):
            badge_cls = "badge-staff"
            badge_text = "YETKİLİ"
        else:
            badge_cls = ""
            badge_text = ""

        badge_html = f'<span class="role-badge {badge_cls}">{badge_text}</span>' if badge_text else ""

        # Mesaj Gövdesi
        parsed_text = parse_discord_markdown(msg.content or "", user_dict, role_dict, channel_dict)

        # Discord Embedleri
        embeds_html = ""
        for emb in msg.embeds:
            color_hex = f"#{emb.color.value:06x}" if emb.color else "#6366f1"
            
            author_html = ""
            if emb.author and emb.author.name:
                author_icon = f'<img src="{emb.author.icon_url}" class="embed-author-icon">' if emb.author.icon_url else ""
                author_html = f'<div class="embed-author">{author_icon}<span>{html.escape(emb.author.name)}</span></div>'

            title_html = ""
            if emb.title:
                title_text = html.escape(emb.title)
                if emb.url:
                    title_html = f'<a href="{emb.url}" target="_blank" class="embed-title-link"><div class="embed-title">{title_text}</div></a>'
                else:
                    title_html = f'<div class="embed-title">{title_text}</div>'

            desc_html = f'<div class="embed-desc">{parse_discord_markdown(emb.description or "", user_dict, role_dict, channel_dict)}</div>' if emb.description else ""

            fields_html = ""
            if emb.fields:
                for f in emb.fields:
                    full_cls = "" if f.inline else " full-width"
                    fields_html += f'''
                    <div class="embed-field-box{full_cls}">
                        <div class="embed-field-title">{html.escape(f.name)}</div>
                        <div class="embed-field-content">{parse_discord_markdown(f.value, user_dict, role_dict, channel_dict)}</div>
                    </div>
                    '''
                fields_wrap = f'<div class="embed-fields-grid">{fields_html}</div>'
            else:
                fields_wrap = ""

            image_html = ""
            if emb.image and emb.image.url:
                image_html = f'<div class="embed-media"><img src="{emb.image.url}" class="embed-img" loading="lazy" onclick="openLightbox(\'{emb.image.url}\')"></div>'

            thumb_html = ""
            if emb.thumbnail and emb.thumbnail.url:
                thumb_html = f'<img src="{emb.thumbnail.url}" class="embed-thumbnail" loading="lazy">'

            footer_html = ""
            if emb.footer and emb.footer.text:
                footer_icon = f'<img src="{emb.footer.icon_url}" class="embed-footer-icon">' if emb.footer.icon_url else ""
                footer_html = f'<div class="embed-footer">{footer_icon}<span>{html.escape(emb.footer.text)}</span></div>'

            embeds_html += f'''
            <div class="discord-embed" style="border-left-color: {color_hex}">
                <div class="embed-inner">
                    <div class="embed-content-wrap">
                        {author_html}
                        {title_html}
                        {desc_html}
                        {fields_wrap}
                        {image_html}
                        {footer_html}
                    </div>
                    {thumb_html}
                </div>
            </div>
            '''

        # Dosya ve Resim Ekleri
        att_html = ""
        for att in msg.attachments:
            total_attachments += 1
            c_type = (att.content_type or "").lower()
            fname = att.filename.lower()
            is_img = c_type.startswith("image/") or any(fname.endswith(ext) for ext in [".png", ".jpg", ".jpeg", ".gif", ".webp"])
            size_kb = max(1, att.size // 1024)
            size_str = f"{size_kb} KB" if size_kb < 1024 else f"{size_kb / 1024:.1f} MB"
            media_items_list.append({
                "url": att.url,
                "filename": att.filename,
                "size_str": size_str,
                "is_image": is_img,
                "author": author_name,
                "msg_id": str(msg.id),
                "timestamp": timestamp
            })
            c_type = (att.content_type or "").lower()
            fname = att.filename.lower()
            if c_type.startswith("image/") or any(fname.endswith(ext) for ext in [".png", ".jpg", ".jpeg", ".gif", ".webp"]):
                att_html += f'''
                <div class="attachment-card">
                    <div class="attachment-image-wrap" onclick="openLightbox(\'{att.url}\')">
                        <img src="{att.url}" class="attachment-img" alt="{html.escape(att.filename)}" loading="lazy">
                        <div class="attachment-zoom-overlay">
                            {SVG_EXPAND}
                            <span>Görseli Büyüt</span>
                        </div>
                    </div>
                </div>
                '''
            else:
                size_kb = max(1, att.size // 1024)
                size_str = f"{size_kb} KB" if size_kb < 1024 else f"{size_kb / 1024:.1f} MB"
                att_html += f'''
                <div class="attachment-card">
                    <a href="{att.url}" target="_blank" class="attachment-file-pill" download="{html.escape(att.filename)}">
                        <div class="file-icon-box">{SVG_FILE}</div>
                        <div class="file-info">
                            <span class="file-name">{html.escape(att.filename)}</span>
                            <span class="file-size">{size_str}</span>
                        </div>
                        <div class="file-action-icon">{SVG_DOWNLOAD}</div>
                    </a>
                </div>
                '''

        msg_body = ""
        if parsed_text:
            msg_body += f'<div class="msg-text">{parsed_text}</div>'
        if embeds_html:
            msg_body += embeds_html
        if att_html:
            msg_body += att_html

        if not msg_body:
            msg_body = '<div class="msg-text text-muted" style="font-style:italic;">(İçerik bulunmuyor)</div>'

        item_html = f'''
        <div class="msg-card" id="msg-{msg.id}" data-author="{html.escape(author_name.lower())}" data-content="{html.escape((msg.content or "").lower())}">
            <div class="msg-avatar-wrap">
                <img class="msg-avatar" src="{avatar_url}" alt="{html.escape(author_name)}" loading="lazy" onclick="showUserPopover(event, '{msg.author.id}', '{html.escape(author_name)}', '{avatar_url}')" style="cursor:pointer;" title="Kullanıcı Profilini Aç" onerror="this.src=\'https://cdn.discordapp.com/embed/avatars/0.png\'">
            </div>
            <div class="msg-body">
                <div class="msg-meta">
                    <span class="msg-author">{html.escape(author_name)}</span>
                    {badge_html}
                    <span class="msg-time">{timestamp}</span>
                    <div class="msg-hover-actions">
                        <button class="msg-action-btn" onclick="quoteMessage(this)" type="button" title="Bu mesajı yanıta alıntıla">{SVG_QUOTE}</button>
                        <button class="msg-action-btn" onclick="copyMessageText(this)" type="button" title="Mesaj metnini kopyala">{SVG_COPY}</button>
                    </div>
                </div>
                {msg_body}
            </div>
        </div>
        '''
        messages_html.append(item_html)

    
    # Medya Galerisi Çekmecesi HTML'i
    media_cards = []
    for item in media_items_list:
        if item["is_image"]:
            media_cards.append(f'''
            <div class="media-drawer-card">
                <div class="media-drawer-thumb-wrap" onclick="openLightbox(\'{item["url"]}\')">
                    <img src="{item["url"]}" class="media-drawer-thumb" alt="{html.escape(item["filename"])}" loading="lazy">
                </div>
                <div class="media-drawer-info">
                    <div class="media-drawer-name" title="{html.escape(item["filename"])}">{html.escape(item["filename"])}</div>
                    <div class="media-drawer-meta">
                        <span>@{html.escape(item["author"])}</span>
                        <span>{item["timestamp"]}</span>
                    </div>
                    <div class="media-drawer-actions">
                        <button class="media-drawer-btn" onclick="jumpToMessage(\'{item["msg_id"]}\')">{SVG_CHAT} <span>Mesaja Git</span></button>
                        <a href="{item["url"]}" class="media-drawer-btn" target="_blank" download="{html.escape(item["filename"])}">{SVG_DOWNLOAD} <span>İndir</span></a>
                    </div>
                </div>
            </div>''')
        else:
            media_cards.append(f'''
            <div class="media-drawer-card">
                <div class="media-drawer-info">
                    <div class="media-drawer-name" title="{html.escape(item["filename"])}">{html.escape(item["filename"])}</div>
                    <div class="media-drawer-meta">
                        <span>{item["size_str"]} • @{html.escape(item["author"])}</span>
                        <span>{item["timestamp"]}</span>
                    </div>
                    <div class="media-drawer-actions">
                        <button class="media-drawer-btn" onclick="jumpToMessage(\'{item["msg_id"]}\')">{SVG_CHAT} <span>Mesaja Git</span></button>
                        <a href="{item["url"]}" class="media-drawer-btn" target="_blank" download="{html.escape(item["filename"])}">{SVG_DOWNLOAD} <span>İndir</span></a>
                    </div>
                </div>
            </div>''')

    if not media_cards:
        media_drawer_html = '<div style="text-align:center; padding:40px 20px; color:var(--text-muted); font-size:13px;">Bu bilette herhangi bir görsel veya dosya eki bulunmuyor.</div>'
    else:
        media_drawer_html = "".join(media_cards)

    # Varsa kayıtlı dahili yetkili notlarını da akışa ekle
    notes_file = os.path.join(TRANSCRIPTS_DIR, f"{slug_id}_notes.json")
    if os.path.exists(notes_file):
        try:
            with open(notes_file, "r", encoding="utf-8") as f:
                saved_notes = json.load(f)
            for n in saved_notes:
                safe_note = html.escape(n.get("note", "")).replace("\n", "<br>")
                note_html = f'''
                <div class="msg-card internal-note-card">
                    <div class="msg-avatar-wrap">
                        <img class="msg-avatar" src="{n.get("avatar", "https://cdn.discordapp.com/embed/avatars/0.png")}" alt="{html.escape(n.get("author", "Yetkili"))}">
                    </div>
                    <div class="msg-body">
                        <div class="msg-meta">
                            <span class="msg-author" style="color:#fbbf24;">{html.escape(n.get("author", "Yetkili"))}</span>
                            <span class="badge-internal-note">DAHİLİ YETKİLİ NOTU</span>
                            <span class="msg-time">{n.get("timestamp", "Kayıtlı")}</span>
                        </div>
                        <div class="msg-text">{safe_note}</div>
                    </div>
                </div>
                '''
                messages_html.append(note_html)
        except Exception:
            pass

    all_messages_str = "\n".join(messages_html)

    # Katılımcı butonları & dropdown opsiyonları
    participant_chips = [f'<button class="p-chip active" onclick="setFilterAuthor(\'all\', this)">Tümü <span class="chip-count">{len(messages)}</span></button>']
    author_options = []
    for a_name, a_info in sorted(author_stats.items(), key=lambda x: x[1]["count"], reverse=True):
        safe_a = html.escape(a_name)
        participant_chips.append(f'''
        <button class="p-chip" onclick="setFilterAuthor(\'{safe_a.lower()}\', this)" title="{safe_a}">
            <img src="{a_info["avatar"]}" class="chip-avatar" alt="{safe_a}">
            <span>{safe_a}</span>
            <span class="chip-count">{a_info["count"]}</span>
        </button>''')
        author_options.append(f'<option value="{safe_a.lower()}">{safe_a}</option>')

    participant_chips_html = "\n".join(participant_chips)
    author_options_html = "\n".join(author_options)

    # Logo HTML
    if logo_url:
        logo_html = f'<img src="{logo_url}" class="brand-logo-img" alt="{bot_name}">'
    else:
        logo_html = '<div class="brand-logo-fallback">IM</div>'

    # İlgilenen Yetkili HTML
    if not claimed_by_name or claimed_by_name.lower() in ["üstlenilmedi", "yetkili üstlenmedi", "bilinmiyor"]:
        claimed_html = '<span class="staff-unclaimed">Yetkili Üstlenmedi</span>'
    else:
        claimed_html = f'<span class="user-pill">{SVG_SHIELD} @{html.escape(claimed_by_name)}</span>'

    is_ticket_claimed = bool(claimed_by_name and claimed_by_name.lower() not in ["üstlenilmedi", "yetkili üstlenmedi", "henüz üstlenilmedi", "bilinmiyor"])
    claim_btn_attr = f'class="sidebar-btn claimed-disabled" disabled="disabled" data-claimed="true" title="Bu bilet zaten @{html.escape(claimed_by_name)} tarafından üstlenilmiş"' if is_ticket_claimed else 'class="sidebar-btn" data-claimed="false"'
    display_claim_name = f'@{claimed_by_name.replace("@", "")}' if is_ticket_claimed else (claimed_by_name or 'Henüz Üstlenilmedi')

    # Benzersiz Belge Kimliği ve Canlı Kanal Durumu
    secret_key = secrets.token_urlsafe(24)
    file_path = os.path.join(TRANSCRIPTS_DIR, f"{slug_id}.html")

    is_channel_active = False
    if channel and channel.guild:
        try:
            if channel.guild.get_channel(channel.id):
                is_channel_active = True
        except Exception:
            is_channel_active = False

    channel_status_badge = f"""
    <div class="status-badge-live" title="Discord Canlı Kanal Bağlantısı Aktif">
        <span class="pulse-dot-green"></span>
        <span>CANLI</span>
    </div>""" if is_channel_active else f"""
    <div class="status-badge-closed" title="Kapatıldı ve Arşivlendi">
        <span class="pulse-dot"></span>
        <span>ARŞİV</span>
    </div>"""

    console_status_pill = f"""
    <div class="channel-status-pill live">
        <span class="pulse-dot-green"></span>
        <span>CANLI BAĞLANTI AKTİF</span>
    </div>""" if is_channel_active else f"""
    <div class="channel-status-pill closed">
        <span class="pulse-dot-gray"></span>
        <span>ARŞİV KAYDI (SALT OKUNUR)</span>
    </div>"""

    # Öncelik Hesaplama ve Dinamik Durumlar
    current_priority = "Normal"
    if ticket_info and ticket_info.get("priority"):
        current_priority = str(ticket_info.get("priority")).strip()
    elif clean_ch_name.startswith("acil-"):
        current_priority = "ACİL"
    elif clean_ch_name.startswith("yuksek-"):
        current_priority = "Yüksek"
    elif clean_ch_name.startswith("dusuk-"):
        current_priority = "Düşük"
    elif slug_id:
        t_idx_temp = load_transcript_index()
        if slug_id in t_idx_temp and t_idx_temp[slug_id].get("priority"):
            current_priority = t_idx_temp[slug_id]["priority"]

    p_norm = current_priority.lower().replace("ç", "c").replace("ş", "s").replace("ü", "u").replace("ı", "i").replace("ö", "o")
    if "acil" in p_norm:
        p_cls = "acil"
        p_display = "ACİL"
    elif "yuksek" in p_norm:
        p_cls = "yuksek"
        p_display = "Yüksek"
    elif "dusuk" in p_norm:
        p_cls = "dusuk"
        p_display = "Düşük"
    else:
        p_cls = "normal"
        p_display = "Normal"

    sel_dusuk = 'selected' if p_cls == 'dusuk' else ''
    sel_normal = 'selected' if p_cls == 'normal' else ''
    sel_yuksek = 'selected' if p_cls == 'yuksek' else ''
    sel_acil = 'selected' if p_cls == 'acil' else ''

    act_dusuk = 'active' if p_cls == 'dusuk' else ''
    act_normal = 'active' if p_cls == 'normal' else ''
    act_yuksek = 'active' if p_cls == 'yuksek' else ''
    act_acil = 'active' if p_cls == 'acil' else ''

    # Komple HTML Dokümanı
    full_html = f"""<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transkript • {clean_ch_name} ({ticket_id})</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
    :root {{
        --bg-void: #06070a;
        --bg-base: #0b0d14;
        --bg-surface: rgba(18, 21, 33, 0.7);
        --bg-surface-elevated: rgba(24, 28, 45, 0.85);
        --bg-card: rgba(22, 26, 40, 0.6);
        --bg-card-hover: rgba(30, 36, 56, 0.8);
        --border-subtle: rgba(255, 255, 255, 0.07);
        --border-light: rgba(255, 255, 255, 0.12);
        --border-accent: rgba(99, 102, 241, 0.4);
        
        --text-pure: #ffffff;
        --text-primary: #f1f5f9;
        --text-secondary: #94a3b8;
        --text-muted: #64748b;
        --text-dim: #475569;
        
        --brand-blurple: #6366f1;
        --brand-indigo: #4f46e5;
        --brand-cyan: #38bdf8;
        --brand-emerald: #10b981;
        --brand-amber: #f59e0b;
        --brand-rose: #f43f5e;
        --brand-purple: #a855f7;

        --glow-primary: rgba(99, 102, 241, 0.25);
        --font-sans: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        --font-mono: 'JetBrains Mono', Consolas, monospace;
    }}

    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    
    body {{
        background-color: var(--bg-void);
        color: var(--text-primary);
        font-family: var(--font-sans);
        line-height: 1.6;
        min-height: 100vh;
        overflow-x: hidden;
        position: relative;
        -webkit-font-smoothing: antialiased;
    }}

    /* Ambient Background Lighting */
    .ambient-canvas {{
        position: fixed;
        inset: 0;
        pointer-events: none;
        z-index: 0;
        overflow: hidden;
    }}
    .glow-sphere-1 {{
        position: absolute;
        top: -120px;
        left: 50%;
        transform: translateX(-50%);
        width: 800px;
        height: 450px;
        background: radial-gradient(ellipse at center, rgba(99, 102, 241, 0.16) 0%, rgba(56, 189, 248, 0.05) 45%, transparent 70%);
        filter: blur(50px);
    }}
    .glow-sphere-2 {{
        position: absolute;
        top: 35%;
        right: -100px;
        width: 500px;
        height: 500px;
        background: radial-gradient(circle, rgba(168, 85, 247, 0.08) 0%, transparent 65%);
        filter: blur(60px);
    }}
    .subtle-grid {{
        position: absolute;
        inset: 0;
        background-image: linear-gradient(rgba(255, 255, 255, 0.02) 1px, transparent 1px),
                          linear-gradient(90deg, rgba(255, 255, 255, 0.02) 1px, transparent 1px);
        background-size: 40px 40px;
        mask-image: radial-gradient(ellipse at top, rgba(0,0,0,1) 30%, rgba(0,0,0,0) 80%);
        -webkit-mask-image: radial-gradient(ellipse at top, rgba(0,0,0,1) 30%, rgba(0,0,0,0) 80%);
    }}

    /* Top Navigation */
    .top-nav {{
        position: sticky;
        top: 0;
        z-index: 100;
        background: rgba(11, 13, 20, 0.82);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border-bottom: 1px solid var(--border-subtle);
        padding: 12px 32px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
    }}
    .brand-cluster {{
        display: flex;
        align-items: center;
        gap: 14px;
        text-decoration: none;
    }}
    .brand-logo-frame {{
        width: 42px;
        height: 42px;
        border-radius: 12px;
        padding: 2px;
        background: linear-gradient(135deg, rgba(99, 102, 241, 0.8), rgba(56, 189, 248, 0.5));
        box-shadow: 0 4px 16px rgba(99, 102, 241, 0.35);
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
    }}
    .brand-logo-img {{
        width: 100%;
        height: 100%;
        border-radius: 10px;
        object-fit: cover;
    }}
    .brand-logo-fallback {{
        width: 100%;
        height: 100%;
        border-radius: 10px;
        background: #161a29;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        font-size: 16px;
        color: #fff;
    }}
    .brand-info {{
        display: flex;
        flex-direction: column;
    }}
    .brand-title-wrap {{
        display: flex;
        align-items: center;
        gap: 8px;
    }}
    .brand-title {{
        font-size: 17px;
        font-weight: 800;
        color: var(--text-pure);
        letter-spacing: -0.2px;
    }}
    .brand-verified-pill {{
        background: rgba(99, 102, 241, 0.15);
        border: 1px solid rgba(99, 102, 241, 0.35);
        color: #a5b4fc;
        font-size: 10px;
        font-weight: 700;
        padding: 2px 7px;
        border-radius: 6px;
        letter-spacing: 0.5px;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }}
    .brand-sub {{
        font-size: 11px;
        color: var(--text-muted);
        font-weight: 500;
        letter-spacing: 0.3px;
    }}

    /* Nav Controls */
    .nav-actions {{
        display: flex;
        align-items: center;
        gap: 12px;
    }}
    .search-wrapper {{
        position: relative;
        display: flex;
        align-items: center;
    }}
    .search-icon-box {{
        position: absolute;
        left: 12px;
        color: var(--text-muted);
        display: flex;
        align-items: center;
        pointer-events: none;
    }}
    .search-input {{
        background: rgba(22, 26, 40, 0.8);
        border: 1px solid var(--border-subtle);
        color: var(--text-pure);
        font-family: var(--font-sans);
        font-size: 13px;
        padding: 9px 38px 9px 36px;
        border-radius: 10px;
        width: 240px;
        outline: none;
        transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    }}
    .search-input:focus {{
        width: 310px;
        border-color: var(--brand-blurple);
        background: rgba(28, 33, 52, 0.95);
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.25), 0 8px 20px rgba(0,0,0,0.3);
    }}
    .search-input::placeholder {{
        color: var(--text-muted);
        font-size: 12.5px;
    }}
    .search-shortcut-hint {{
        position: absolute;
        right: 10px;
        font-size: 10px;
        font-family: var(--font-mono);
        color: var(--text-muted);
        background: rgba(255,255,255,0.06);
        border: 1px solid rgba(255,255,255,0.08);
        padding: 2px 6px;
        border-radius: 5px;
        pointer-events: none;
    }}
    .search-clear-btn {{
        position: absolute;
        right: 10px;
        background: none;
        border: none;
        color: var(--text-muted);
        cursor: pointer;
        padding: 4px;
        display: none;
        align-items: center;
        justify-content: center;
    }}
    .search-clear-btn:hover {{
        color: var(--text-pure);
    }}

    .filter-select-wrap {{
        position: relative;
        display: flex;
        align-items: center;
    }}
    .filter-select {{
        appearance: none;
        -webkit-appearance: none;
        background: rgba(22, 26, 40, 0.8);
        border: 1px solid var(--border-subtle);
        color: var(--text-primary);
        font-family: var(--font-sans);
        font-size: 13px;
        font-weight: 500;
        padding: 9px 34px 9px 14px;
        border-radius: 10px;
        outline: none;
        cursor: pointer;
        transition: all 0.2s;
    }}
    .filter-select:hover {{
        border-color: var(--border-light);
        background: rgba(28, 33, 52, 0.9);
    }}
    .filter-chevron {{
        position: absolute;
        right: 12px;
        color: var(--text-muted);
        pointer-events: none;
        display: flex;
        align-items: center;
    }}

    .btn-print {{
        background: linear-gradient(135deg, rgba(99, 102, 241, 0.15), rgba(56, 189, 248, 0.15));
        border: 1px solid rgba(99, 102, 241, 0.35);
        color: var(--text-pure);
        font-family: var(--font-sans);
        font-size: 13px;
        font-weight: 600;
        padding: 9px 16px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }}
    .btn-print:hover {{
        background: linear-gradient(135deg, rgba(99, 102, 241, 0.3), rgba(56, 189, 248, 0.3));
        border-color: var(--brand-blurple);
        transform: translateY(-1px);
        box-shadow: 0 4px 14px rgba(99, 102, 241, 0.3);
    }}

    /* Main Container */
    .main-stage {{
        position: relative;
        z-index: 1;
        max-width: 1080px;
        margin: 32px auto 60px;
        padding: 0 24px;
    }}

    /* Ticket Showcase Hero Card */
    .ticket-hero-card {{
        background: var(--bg-surface);
        border: 1px solid var(--border-subtle);
        border-radius: 20px;
        padding: 28px;
        margin-bottom: 24px;
        position: relative;
        overflow: hidden;
        backdrop-filter: blur(24px);
        -webkit-backdrop-filter: blur(24px);
        box-shadow: 0 16px 40px -10px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.08);
    }}
    .hero-top-accent {{
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(90deg, var(--brand-blurple) 0%, var(--brand-cyan) 50%, var(--brand-purple) 100%);
    }}
    .hero-header {{
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 24px;
        gap: 20px;
        flex-wrap: wrap;
    }}
    .hero-breadcrumb {{
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 11px;
        font-family: var(--font-mono);
        color: var(--text-muted);
        text-transform: uppercase;
        letter-spacing: 0.8px;
        margin-bottom: 6px;
    }}
    .hero-title-row {{
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }}
    .hero-title {{
        font-size: 24px;
        font-weight: 800;
        color: var(--text-pure);
        letter-spacing: -0.5px;
    }}
    .ticket-id-chip {{
        background: rgba(99, 102, 241, 0.15);
        border: 1px solid rgba(99, 102, 241, 0.35);
        color: #c7d2fe;
        font-family: var(--font-mono);
        font-size: 12px;
        font-weight: 600;
        padding: 3px 10px;
        border-radius: 8px;
    }}
    .status-badge-closed {{
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(148, 163, 184, 0.12);
        border: 1px solid rgba(148, 163, 184, 0.25);
        padding: 3px 9px;
        border-radius: 6px;
        font-size: 10.5px;
        font-weight: 800;
        letter-spacing: 0.5px;
        color: #94a3b8;
        white-space: nowrap;
        line-height: 1.2;
    }}
    .pulse-dot {{
        width: 7px;
        height: 7px;
        background: #10b981;
        border-radius: 50%;
        box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);
        animation: pulseAnimation 2s infinite;
    }}
    @keyframes pulseAnimation {{
        0% {{ transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }}
        70% {{ transform: scale(1); box-shadow: 0 0 0 7px rgba(16, 185, 129, 0); }}
        100% {{ transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }}
    }}

    /* Hero Metrics Grid */
    .metrics-grid {{
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 12px;
        margin-bottom: 20px;
    }}
    .metric-card {{
        background: var(--bg-card);
        border: 1px solid var(--border-subtle);
        border-radius: 14px;
        padding: 14px 16px;
        display: flex;
        align-items: center;
        gap: 14px;
        transition: all 0.2s ease;
    }}
    .metric-card:hover {{
        background: var(--bg-card-hover);
        border-color: var(--border-light);
        transform: translateY(-1px);
    }}
    .metric-icon-box {{
        width: 36px;
        height: 36px;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.06);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--brand-cyan);
        flex-shrink: 0;
    }}
    .metric-text {{
        display: flex;
        flex-direction: column;
        min-width: 0;
    }}
    .metric-label {{
        font-size: 11px;
        font-weight: 700;
        color: var(--text-muted);
        text-transform: uppercase;
        letter-spacing: 0.6px;
        margin-bottom: 2px;
    }}
    .metric-value {{
        font-size: 13.5px;
        font-weight: 600;
        color: var(--text-pure);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }}
    .user-pill {{
        color: var(--brand-cyan);
        background: rgba(56, 189, 248, 0.1);
        padding: 2px 8px;
        border-radius: 6px;
        border: 1px solid rgba(56, 189, 248, 0.2);
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }}
    .staff-unclaimed {{
        color: var(--brand-amber);
        font-weight: 500;
        font-style: italic;
    }}

    /* Quick Stats Bar */
    .quick-stats-strip {{
        background: rgba(14, 17, 27, 0.6);
        border: 1px solid var(--border-subtle);
        border-radius: 12px;
        padding: 10px 18px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        flex-wrap: wrap;
    }}
    .quick-stat-group {{
        display: flex;
        align-items: center;
        gap: 20px;
    }}
    .quick-stat-item {{
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 12px;
        color: var(--text-secondary);
    }}
    .quick-stat-val {{
        font-weight: 700;
        color: var(--text-pure);
        font-family: var(--font-mono);
    }}
    .security-badge {{
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 11px;
        font-weight: 600;
        color: #a5b4fc;
    }}

    /* Participant Chips Bar */
    .participants-bar {{
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 20px;
        overflow-x: auto;
        padding-bottom: 4px;
        scrollbar-width: none;
    }}
    .participants-bar::-webkit-scrollbar {{
        display: none;
    }}
    .p-chip {{
        background: var(--bg-card);
        border: 1px solid var(--border-subtle);
        color: var(--text-secondary);
        font-family: var(--font-sans);
        font-size: 12.5px;
        font-weight: 600;
        padding: 6px 14px;
        border-radius: 9999px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        white-space: nowrap;
        transition: all 0.2s;
    }}
    .p-chip:hover {{
        background: var(--bg-card-hover);
        color: var(--text-pure);
        border-color: var(--border-light);
    }}
    .p-chip.active {{
        background: rgba(99, 102, 241, 0.2);
        border-color: var(--brand-blurple);
        color: #ffffff;
        box-shadow: 0 0 14px rgba(99, 102, 241, 0.25);
    }}
    .chip-avatar {{
        width: 18px;
        height: 18px;
        border-radius: 50%;
        object-fit: cover;
    }}
    .chip-count {{
        background: rgba(255, 255, 255, 0.08);
        padding: 1px 6px;
        border-radius: 10px;
        font-size: 11px;
        font-family: var(--font-mono);
    }}

    /* Messages Section */
    .chat-section {{
        background: var(--bg-surface);
        border: 1px solid var(--border-subtle);
        border-radius: 20px;
        overflow: hidden;
        backdrop-filter: blur(24px);
        -webkit-backdrop-filter: blur(24px);
        box-shadow: 0 16px 40px -10px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.08);
    }}
    .chat-section-header {{
        padding: 16px 24px;
        background: rgba(20, 24, 38, 0.7);
        border-bottom: 1px solid var(--border-subtle);
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
    }}
    .chat-header-title {{
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 13.5px;
        font-weight: 700;
        color: var(--text-pure);
    }}
    .chat-header-count {{
        font-size: 12px;
        font-family: var(--font-mono);
        color: var(--brand-cyan);
        background: rgba(56, 189, 248, 0.1);
        border: 1px solid rgba(56, 189, 248, 0.2);
        padding: 2px 8px;
        border-radius: 6px;
    }}

    /* Message Item */
    .msg-stream {{
        padding: 16px 0;
    }}
    .msg-card {{
        display: flex;
        padding: 14px 28px;
        gap: 18px;
        transition: background-color 0.15s ease;
        position: relative;
    }}
    .msg-card:hover {{
        background-color: rgba(255, 255, 255, 0.025);
    }}
    .msg-avatar-wrap {{
        flex-shrink: 0;
    }}
    .msg-avatar {{
        width: 44px;
        height: 44px;
        border-radius: 12px;
        background-color: #1a1e2e;
        border: 1px solid var(--border-subtle);
        object-fit: cover;
        box-shadow: 0 4px 10px rgba(0,0,0,0.3);
    }}
    .msg-body {{
        flex: 1;
        min-width: 0;
    }}
    .msg-meta {{
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 6px;
        flex-wrap: wrap;
    }}
    .msg-author {{
        font-size: 14.5px;
        font-weight: 700;
        color: var(--text-pure);
        letter-spacing: -0.2px;
    }}
    .role-badge {{
        font-size: 10px;
        font-weight: 800;
        padding: 2px 7px;
        border-radius: 5px;
        text-transform: uppercase;
        letter-spacing: 0.6px;
    }}
    .badge-bot {{
        background: linear-gradient(135deg, #6366f1, #4f46e5);
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(99, 102, 241, 0.4);
    }}
    .badge-owner {{
        background: rgba(56, 189, 248, 0.15);
        color: var(--brand-cyan);
        border: 1px solid rgba(56, 189, 248, 0.35);
    }}
    .badge-staff {{
        background: rgba(245, 158, 11, 0.15);
        color: var(--brand-amber);
        border: 1px solid rgba(245, 158, 11, 0.35);
    }}
    .msg-time {{
        font-size: 12px;
        color: var(--text-muted);
        font-family: var(--font-mono);
    }}

    .msg-text {{
        font-size: 14.5px;
        color: #e2e8f0;
        word-break: break-word;
        line-height: 1.6;
    }}

    /* Mentions */
    .mention {{
        padding: 2px 7px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 600;
        display: inline-block;
    }}
    .mention.user {{
        background: rgba(99, 102, 241, 0.2);
        color: #c7d2fe;
        border: 1px solid rgba(99, 102, 241, 0.3);
    }}
    .mention.role {{
        background: rgba(245, 158, 11, 0.18);
        color: #fde68a;
        border: 1px solid rgba(245, 158, 11, 0.3);
    }}
    .mention.channel {{
        background: rgba(56, 189, 248, 0.18);
        color: #bae6fd;
        border: 1px solid rgba(56, 189, 248, 0.3);
    }}
    .mention.slash {{
        background: rgba(168, 85, 247, 0.18);
        color: #e9d5ff;
        border: 1px solid rgba(168, 85, 247, 0.3);
        font-family: var(--font-mono);
    }}
    .mention.time-tag {{
        background: rgba(255, 255, 255, 0.08);
        color: #cbd5e1;
        font-family: var(--font-mono);
        font-size: 12px;
    }}
    .custom-tag {{
        font-family: var(--font-mono);
        font-size: 12.5px;
        color: #94a3b8;
    }}

    /* Inline Code & Code Block */
    .inline-code {{
        background: rgba(30, 35, 53, 0.8);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: #f43f5e;
        padding: 2px 6px;
        border-radius: 5px;
        font-family: var(--font-mono);
        font-size: 13px;
    }}
    .code-container {{
        background: #0d101a;
        border: 1px solid var(--border-subtle);
        border-radius: 10px;
        margin: 10px 0;
        overflow: hidden;
    }}
    .code-header {{
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: rgba(255, 255, 255, 0.03);
        border-bottom: 1px solid var(--border-subtle);
        padding: 6px 14px;
        font-family: var(--font-mono);
        font-size: 11px;
        color: var(--text-muted);
        text-transform: uppercase;
    }}
    .code-copy-btn {{
        background: none;
        border: 1px solid var(--border-subtle);
        color: var(--text-secondary);
        font-family: var(--font-sans);
        font-size: 11px;
        font-weight: 600;
        padding: 3px 8px;
        border-radius: 5px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 4px;
        transition: all 0.2s;
    }}
    .code-copy-btn:hover {{
        background: rgba(255, 255, 255, 0.08);
        color: #fff;
    }}
    .code-block {{
        padding: 12px 14px;
        overflow-x: auto;
        font-family: var(--font-mono);
        font-size: 13px;
        color: #cbd5e1;
        line-height: 1.5;
    }}

    /* Spoiler & Quote */
    .spoiler {{
        background: #252b3d;
        color: transparent;
        padding: 2px 6px;
        border-radius: 5px;
        cursor: pointer;
        user-select: none;
        transition: all 0.2s;
    }}
    .spoiler.revealed {{
        background: rgba(255, 255, 255, 0.08);
        color: inherit;
    }}
    blockquote {{
        border-left: 3px solid var(--brand-blurple);
        padding-left: 12px;
        margin: 6px 0;
        color: var(--text-secondary);
        background: rgba(99, 102, 241, 0.04);
        border-radius: 0 6px 6px 0;
    }}

    /* Discord Embeds */
    .discord-embed {{
        background: rgba(18, 22, 35, 0.85);
        border-radius: 12px;
        border-left: 4px solid var(--brand-blurple);
        border-top: 1px solid var(--border-subtle);
        border-right: 1px solid var(--border-subtle);
        border-bottom: 1px solid var(--border-subtle);
        padding: 16px 20px;
        margin-top: 10px;
        max-width: 620px;
        box-shadow: 0 6px 20px rgba(0,0,0,0.25);
    }}
    .embed-inner {{
        display: flex;
        gap: 16px;
        align-items: flex-start;
    }}
    .embed-content-wrap {{
        flex: 1;
        min-width: 0;
    }}
    .embed-thumbnail {{
        max-width: 80px;
        max-height: 80px;
        border-radius: 8px;
        object-fit: cover;
        flex-shrink: 0;
    }}
    .embed-author {{
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 12px;
        font-weight: 600;
        color: var(--text-pure);
        margin-bottom: 6px;
    }}
    .embed-author-icon {{
        width: 20px;
        height: 20px;
        border-radius: 50%;
    }}
    .embed-title-link {{
        text-decoration: none;
        color: inherit;
    }}
    .embed-title-link:hover .embed-title {{
        text-decoration: underline;
        color: var(--brand-cyan);
    }}
    .embed-title {{
        font-size: 15px;
        font-weight: 700;
        color: var(--text-pure);
        margin-bottom: 8px;
    }}
    .embed-desc {{
        font-size: 13.5px;
        color: #cbd5e1;
        margin-bottom: 14px;
        line-height: 1.5;
    }}
    .embed-fields-grid {{
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }}
    .embed-field-box {{
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.05);
        padding: 10px 12px;
        border-radius: 8px;
    }}
    .embed-field-box.full-width {{
        grid-column: span 2;
    }}
    .embed-field-title {{
        font-size: 10.5px;
        font-weight: 700;
        color: var(--text-muted);
        text-transform: uppercase;
        letter-spacing: 0.6px;
        margin-bottom: 4px;
    }}
    .embed-field-content {{
        font-size: 13px;
        color: #f1f5f9;
        font-weight: 500;
    }}
    .embed-media {{
        margin-top: 10px;
    }}
    .embed-img {{
        max-width: 100%;
        max-height: 350px;
        border-radius: 8px;
        cursor: pointer;
    }}
    .embed-footer {{
        margin-top: 14px;
        font-size: 11px;
        color: var(--text-muted);
        border-top: 1px solid rgba(255, 255, 255, 0.06);
        padding-top: 8px;
        display: flex;
        align-items: center;
        gap: 6px;
    }}
    .embed-footer-icon {{
        width: 16px;
        height: 16px;
        border-radius: 50%;
    }}

    /* Attachments */
    .attachment-card {{
        margin-top: 10px;
        display: inline-block;
    }}
    .attachment-image-wrap {{
        position: relative;
        display: inline-block;
        border-radius: 12px;
        overflow: hidden;
        border: 1px solid var(--border-subtle);
        cursor: pointer;
    }}
    .attachment-img {{
        max-width: 440px;
        max-height: 320px;
        display: block;
        transition: transform 0.25s ease;
    }}
    .attachment-image-wrap:hover .attachment-img {{
        transform: scale(1.02);
    }}
    .attachment-zoom-overlay {{
        position: absolute;
        inset: 0;
        background: rgba(0, 0, 0, 0.4);
        opacity: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        transition: opacity 0.2s;
        gap: 6px;
        font-size: 12px;
        font-weight: 600;
    }}
    .attachment-image-wrap:hover .attachment-zoom-overlay {{
        opacity: 1;
    }}

    .attachment-file-pill {{
        display: inline-flex;
        align-items: center;
        gap: 12px;
        background: rgba(22, 26, 40, 0.85);
        border: 1px solid var(--border-subtle);
        padding: 10px 16px;
        border-radius: 10px;
        color: var(--text-pure);
        text-decoration: none;
        font-size: 13px;
        font-weight: 600;
        transition: all 0.2s;
    }}
    .attachment-file-pill:hover {{
        background: rgba(30, 36, 56, 0.95);
        border-color: var(--brand-cyan);
        transform: translateY(-1px);
    }}
    .file-icon-box {{
        color: var(--brand-cyan);
        display: flex;
        align-items: center;
    }}
    .file-size {{
        font-size: 11px;
        color: var(--text-muted);
        font-family: var(--font-mono);
    }}

    /* Search Highlight */
    mark.search-highlight {{
        background: rgba(245, 158, 11, 0.35);
        color: #ffffff;
        border-bottom: 2px solid #f59e0b;
        padding: 1px 3px;
        border-radius: 3px;
    }}

    /* Lightbox Modal */
    .lightbox-modal {{
        position: fixed;
        inset: 0;
        z-index: 999;
        background: rgba(5, 6, 10, 0.9);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        display: none;
        align-items: center;
        justify-content: center;
        padding: 30px;
    }}
    .lightbox-modal.active {{
        display: flex;
    }}
    .lightbox-content {{
        max-width: 90vw;
        max-height: 85vh;
        position: relative;
    }}
    .lightbox-img {{
        max-width: 100%;
        max-height: 85vh;
        border-radius: 12px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.8);
        border: 1px solid rgba(255, 255, 255, 0.15);
    }}
    .lightbox-close {{
        position: absolute;
        top: -45px;
        right: 0;
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #fff;
        width: 36px;
        height: 36px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s;
    }}
    .lightbox-close:hover {{
        background: rgba(255, 255, 255, 0.25);
        transform: scale(1.08);
    }}

    /* Footer */
    .portal-footer {{
        margin-top: 48px;
        text-align: center;
        color: var(--text-muted);
        font-size: 12px;
    }}
    .portal-footer p {{
        margin-bottom: 6px;
    }}
    .footer-highlight {{
        color: var(--text-secondary);
        font-weight: 600;
    }}

    /* Responsive */
    @media (max-width: 860px) {{
        .metrics-grid {{ grid-template-columns: repeat(2, 1fr); }}
    }}
    @media (max-width: 640px) {{
        .top-nav {{ padding: 12px 16px; flex-direction: column; align-items: stretch; gap: 14px; }}
        .nav-actions {{ flex-direction: column; align-items: stretch; }}
        .search-input {{ width: 100%; }}
        .search-input:focus {{ width: 100%; }}
        .metrics-grid {{ grid-template-columns: 1fr; }}
        .embed-fields-grid {{ grid-template-columns: 1fr; }}
        .embed-field-box.full-width {{ grid-column: span 1; }}
        .main-stage {{ padding: 0 14px; margin-top: 18px; }}
        .msg-card {{ padding: 12px 14px; }}
    }}

    /* Print Styles */
    @media print {{
        body {{ background: #fff !important; color: #000 !important; }}
        .ambient-canvas, .top-nav, .participants-bar, .lightbox-modal {{ display: none !important; }}
        .main-stage {{ max-width: 100% !important; margin: 0 !important; padding: 0 !important; }}
        .ticket-hero-card, .chat-section, .msg-card {{ border: 1px solid #ccc !important; background: #fff !important; color: #000 !important; box-shadow: none !important; }}
        .msg-text, .msg-author, .metric-value, .hero-title {{ color: #000 !important; }}
    }}

    /* Top Action Buttons */
    .btn-action-warn {{
        background: rgba(239, 68, 68, 0.12);
        border: 1px solid rgba(239, 68, 68, 0.35);
        color: #fca5a5;
        font-family: var(--font-sans);
        font-size: 13px;
        font-weight: 600;
        padding: 9px 16px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }}
    .btn-action-warn:hover {{
        background: rgba(239, 68, 68, 0.24);
        border-color: #ef4444;
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(239, 68, 68, 0.35);
        color: #fff;
    }}
    .btn-action-chat {{
        background: rgba(99, 102, 241, 0.15);
        border: 1px solid rgba(99, 102, 241, 0.35);
        color: #c7d2fe;
        font-family: var(--font-sans);
        font-size: 13px;
        font-weight: 600;
        padding: 9px 16px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }}
    .btn-action-chat:hover {{
        background: rgba(99, 102, 241, 0.3);
        border-color: var(--brand-blurple);
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(99, 102, 241, 0.35);
        color: #fff;
    }}
    .btn-action-copy {{
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid var(--border-subtle);
        color: var(--text-secondary);
        font-family: var(--font-sans);
        font-size: 13px;
        font-weight: 600;
        padding: 9px 16px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        transition: all 0.2s;
    }}
    .btn-action-copy:hover {{
        background: rgba(255, 255, 255, 0.1);
        color: var(--text-pure);
        border-color: var(--border-light);
    }}
    .btn-action-logout {{
        background: rgba(239, 68, 68, 0.08);
        border: 1px solid rgba(239, 68, 68, 0.28);
        color: #f87171;
        font-family: var(--font-sans);
        font-size: 13px;
        font-weight: 600;
        padding: 9px 16px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }}
    .btn-action-logout:hover {{
        background: rgba(239, 68, 68, 0.22);
        border-color: #ef4444;
        color: #fff;
        transform: translateY(-1px);
    }}

    /* Live Channel Pulse */
    .status-badge-live {{
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(16, 185, 129, 0.14);
        border: 1px solid rgba(16, 185, 129, 0.4);
        padding: 3px 9px;
        border-radius: 6px;
        font-size: 10.5px;
        font-weight: 800;
        letter-spacing: 0.5px;
        color: #34d399;
        white-space: nowrap;
        box-shadow: 0 0 10px rgba(16, 185, 129, 0.15);
        line-height: 1.2;
    }}
    .pulse-dot-green {{
        width: 8px;
        height: 8px;
        background: #10b981;
        border-radius: 50%;
        box-shadow: 0 0 0 rgba(16, 185, 129, 0.7);
        animation: pulseGreen 2s infinite;
    }}
    @keyframes pulseGreen {{
        0% {{ transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }}
        70% {{ transform: scale(1); box-shadow: 0 0 0 7px rgba(16, 185, 129, 0); }}
        100% {{ transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }}
    }}

    /* Live Staff Action Dock */
    .staff-action-console {{
        background: linear-gradient(180deg, rgba(18, 22, 35, 0.95) 0%, rgba(13, 15, 24, 0.98) 100%);
        border: 1px solid rgba(99, 102, 241, 0.3);
        border-radius: 20px;
        padding: 24px;
        margin-top: 24px;
        box-shadow: 0 16px 40px -10px rgba(0, 0, 0, 0.7), 0 0 30px rgba(99, 102, 241, 0.12);
        position: relative;
        overflow: hidden;
    }}
    .console-top-glow {{
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, transparent 0%, rgba(99, 102, 241, 0.8) 50%, transparent 100%);
    }}
    .console-header {{
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        margin-bottom: 18px;
        flex-wrap: wrap;
    }}
    .console-title-cluster {{
        display: flex;
        align-items: center;
        gap: 12px;
    }}
    .console-icon {{
        width: 36px;
        height: 36px;
        border-radius: 10px;
        background: rgba(99, 102, 241, 0.15);
        border: 1px solid rgba(99, 102, 241, 0.35);
        color: #818cf8;
        display: flex;
        align-items: center;
        justify-content: center;
    }}
    .console-heading {{
        font-size: 15px;
        font-weight: 700;
        color: var(--text-pure);
    }}
    .console-subheading {{
        font-size: 12px;
        color: var(--text-muted);
    }}
    .console-badge-row {{
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
    }}
    .channel-status-pill {{
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.5px;
    }}
    .channel-status-pill.live {{
        background: rgba(16, 185, 129, 0.12);
        border: 1px solid rgba(16, 185, 129, 0.3);
        color: #6ee7b7;
    }}
    .channel-status-pill.closed {{
        background: rgba(148, 163, 184, 0.1);
        border: 1px solid rgba(148, 163, 184, 0.2);
        color: #94a3b8;
    }}
    .staff-role-pill {{
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(99, 102, 241, 0.12);
        border: 1px solid rgba(99, 102, 241, 0.25);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        color: #a5b4fc;
    }}

    .quick-templates-bar {{
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 16px;
        flex-wrap: wrap;
    }}
    .template-label {{
        font-size: 11.5px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--text-muted);
        margin-right: 4px;
    }}
    .template-pill {{
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        color: var(--text-secondary);
        font-family: var(--font-sans);
        font-size: 12px;
        font-weight: 500;
        padding: 5px 12px;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.2s;
    }}
    .template-pill:hover {{
        background: rgba(99, 102, 241, 0.18);
        border-color: rgba(99, 102, 241, 0.4);
        color: #fff;
        transform: translateY(-1px);
    }}
    .template-pill.danger {{
        border-color: rgba(239, 68, 68, 0.3);
        color: #fca5a5;
    }}
    .template-pill.danger:hover {{
        background: rgba(239, 68, 68, 0.2);
        border-color: #ef4444;
        color: #fff;
    }}

    .console-input-wrap {{
        background: #090a10;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 14px;
        padding: 14px;
        transition: border-color 0.2s, box-shadow 0.2s;
    }}
    .console-input-wrap:focus-within {{
        border-color: var(--brand-blurple);
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
    }}
    .console-textarea {{
        width: 100%;
        background: transparent;
        border: none;
        outline: none;
        color: #fff;
        font-family: var(--font-sans);
        font-size: 14px;
        resize: vertical;
        min-height: 48px;
        line-height: 1.5;
    }}
    .console-textarea::placeholder {{
        color: var(--text-dim);
    }}
    .console-input-footer {{
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 10px;
        padding-top: 10px;
        border-top: 1px solid rgba(255, 255, 255, 0.06);
        flex-wrap: wrap;
        gap: 10px;
    }}
    .input-hints {{
        font-size: 11.5px;
        color: var(--text-muted);
    }}
    .btn-console-send {{
        background: linear-gradient(135deg, var(--brand-blurple), #4338ca);
        border: none;
        color: #fff;
        font-family: var(--font-sans);
        font-size: 13px;
        font-weight: 600;
        padding: 9px 20px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        transition: all 0.2s;
        box-shadow: 0 4px 14px rgba(99, 102, 241, 0.35);
    }}
    .btn-console-send:hover {{
        background: linear-gradient(135deg, #7174f8, #4f46e5);
        transform: translateY(-1px);
        box-shadow: 0 6px 18px rgba(99, 102, 241, 0.5);
    }}
    .btn-console-send:disabled {{
        opacity: 0.6;
        cursor: not-allowed;
        transform: none;
    }}

    /* Warning Modal */
    .warn-modal-overlay {{
        position: fixed;
        inset: 0;
        z-index: 1000;
        background: rgba(4, 5, 8, 0.85);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        display: none;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }}
    .warn-modal-overlay.active {{
        display: flex;
    }}
    .warn-modal-card {{
        background: #111420;
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 20px;
        width: 100%;
        max-width: 520px;
        padding: 28px;
        box-shadow: 0 24px 60px rgba(0, 0, 0, 0.8), 0 0 30px rgba(239, 68, 68, 0.15);
        animation: modalScaleIn 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    }}
    @keyframes modalScaleIn {{
        from {{ transform: scale(0.94); opacity: 0; }}
        to {{ transform: scale(1); opacity: 1; }}
    }}
    .warn-modal-header {{
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        margin-bottom: 20px;
    }}
    .warn-title-group {{
        display: flex;
        align-items: center;
        gap: 14px;
    }}
    .warn-icon-box {{
        width: 44px;
        height: 44px;
        border-radius: 12px;
        background: rgba(239, 68, 68, 0.15);
        border: 1px solid rgba(239, 68, 68, 0.35);
        color: #ef4444;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }}
    .warn-modal-title {{
        font-size: 18px;
        font-weight: 700;
        color: #fff;
    }}
    .warn-modal-desc {{
        font-size: 12.5px;
        color: var(--text-muted);
        margin-top: 2px;
    }}
    .modal-close-btn {{
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: var(--text-muted);
        border-radius: 8px;
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s;
    }}
    .modal-close-btn:hover {{
        color: #fff;
        background: rgba(255, 255, 255, 0.1);
    }}
    .warn-target-box {{
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.07);
        border-radius: 12px;
        padding: 12px 16px;
        margin-bottom: 18px;
    }}
    .target-label {{
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        color: var(--text-muted);
        letter-spacing: 0.5px;
        margin-bottom: 6px;
    }}
    .target-info-row {{
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }}
    .target-name {{
        font-size: 14px;
        font-weight: 700;
        color: #fff;
    }}
    .target-id {{
        font-size: 12px;
        color: var(--text-muted);
        font-family: var(--font-mono);
    }}
    .target-ticket {{
        font-size: 11.5px;
        color: var(--brand-blurple);
        font-weight: 600;
    }}
    .warn-form-group {{
        margin-bottom: 18px;
    }}
    .warn-field-label {{
        display: block;
        font-size: 12px;
        font-weight: 700;
        color: var(--text-secondary);
        margin-bottom: 8px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }}
    .warn-type-grid {{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
        gap: 8px;
    }}
    .warn-type-btn {{
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        color: var(--text-secondary);
        font-family: var(--font-sans);
        font-size: 12.5px;
        font-weight: 600;
        padding: 8px 10px;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.2s;
        text-align: center;
    }}
    .warn-type-btn:hover {{
        background: rgba(255, 255, 255, 0.08);
        color: #fff;
    }}
    .warn-type-btn.active {{
        background: rgba(239, 68, 68, 0.15);
        border-color: #ef4444;
        color: #fca5a5;
    }}
    .warn-type-btn.danger.active {{
        background: rgba(220, 38, 38, 0.25);
        border-color: #dc2626;
        color: #fff;
        box-shadow: 0 0 12px rgba(220, 38, 38, 0.35);
    }}
    .warn-textarea {{
        width: 100%;
        background: #090a10;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        padding: 12px;
        color: #fff;
        font-family: var(--font-sans);
        font-size: 13px;
        outline: none;
        resize: vertical;
        min-height: 75px;
        line-height: 1.5;
    }}
    .warn-textarea:focus {{
        border-color: #ef4444;
        box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.2);
    }}
    .warn-options-group {{
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-bottom: 22px;
    }}
    .checkbox-container {{
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 12.5px;
        color: var(--text-secondary);
        cursor: pointer;
        user-select: none;
    }}
    .checkbox-container input {{
        accent-color: #ef4444;
        width: 16px;
        height: 16px;
        cursor: pointer;
    }}
    .warn-modal-actions {{
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 12px;
    }}
    .btn-warn-cancel {{
        background: transparent;
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: var(--text-secondary);
        font-family: var(--font-sans);
        font-size: 13px;
        font-weight: 600;
        padding: 10px 18px;
        border-radius: 10px;
        cursor: pointer;
        transition: all 0.2s;
    }}
    .btn-warn-cancel:hover {{
        background: rgba(255, 255, 255, 0.06);
        color: #fff;
    }}
    .btn-warn-submit {{
        background: linear-gradient(135deg, #ef4444, #b91c1c);
        border: none;
        color: #fff;
        font-family: var(--font-sans);
        font-size: 13px;
        font-weight: 600;
        padding: 10px 22px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        transition: all 0.2s;
        box-shadow: 0 4px 16px rgba(239, 68, 68, 0.35);
    }}
    .btn-warn-submit:hover {{
        background: linear-gradient(135deg, #f87171, #dc2626);
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(239, 68, 68, 0.5);
    }}
    .btn-warn-submit:disabled {{
        opacity: 0.6;
        cursor: not-allowed;
        transform: none;
    }}

    /* Toast Notification System */
    .toast-container {{
        position: fixed;
        top: 24px;
        right: 24px;
        z-index: 99999;
        display: flex;
        flex-direction: column;
        gap: 10px;
        pointer-events: none;
    }}
    .custom-toast {{
        background: #141724;
        border: 1px solid var(--border-subtle);
        border-radius: 12px;
        padding: 14px 18px;
        color: #fff;
        font-size: 13px;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 12px;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.7);
        pointer-events: auto;
        animation: toastSlideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        max-width: 380px;
    }}
    .custom-toast.success {{
        border-color: rgba(16, 185, 129, 0.4);
        color: #6ee7b7;
        background: linear-gradient(135deg, #111e1f, #141724);
    }}
    .custom-toast.error {{
        border-color: rgba(239, 68, 68, 0.4);
        color: #fca5a5;
        background: linear-gradient(135deg, #241416, #141724);
    }}
    .custom-toast.info {{
        border-color: rgba(99, 102, 241, 0.4);
        color: #c7d2fe;
        background: linear-gradient(135deg, #15182d, #141724);
    }}
    .custom-toast.fade-out {{
        opacity: 0;
        transform: translateX(30px);
        transition: opacity 0.3s, transform 0.3s;
    }}
    @keyframes toastSlideIn {{
        from {{ transform: translateX(50px); opacity: 0; }}
        to {{ transform: translateX(0); opacity: 1; }}
    }}

    /* Web Message Card In Stream */
    .msg-card.web-staff-msg {{
        background: rgba(99, 102, 241, 0.07);
        border-left: 3px solid var(--brand-blurple);
        border-radius: 14px;
        margin-top: 8px;
    }}
    .badge-web-staff {{
        background: rgba(99, 102, 241, 0.2);
        color: #818cf8;
        border: 1px solid rgba(99, 102, 241, 0.4);
        font-size: 10px;
        font-weight: 700;
        padding: 2px 7px;
        border-radius: 6px;
        letter-spacing: 0.5px;
    }}
    .warn-event-banner {{
        background: rgba(239, 68, 68, 0.1);
        border: 1px solid rgba(239, 68, 68, 0.3);
        border-radius: 14px;
        padding: 14px 18px;
        margin: 16px 0;
        display: flex;
        align-items: center;
        gap: 14px;
        color: #fca5a5;
    }}
    .warn-banner-icon {{
        color: #ef4444;
        flex-shrink: 0;
    }}
    .warn-banner-title {{
        font-size: 13.5px;
        font-weight: 700;
        color: #fff;
    }}
    .warn-banner-desc {{
        font-size: 12px;
        color: #fca5a5;
        margin-top: 2px;
    }}

    
    /* ─── LUXURY CYBER TERMINAL ENHANCEMENTS (V2) ─── */
    .scroll-progress-line {{
        position: fixed;
        top: 0;
        left: 0;
        height: 3px;
        width: 0%;
        background: linear-gradient(90deg, #6366f1, #38bdf8, #a855f7, #ec4899);
        box-shadow: 0 0 12px rgba(99, 102, 241, 0.9), 0 0 24px rgba(56, 189, 248, 0.6);
        z-index: 9999;
        transition: width 0.08s ease-out;
        pointer-events: none;
    }}

    /* Ambient Glow Enhancements */
    .glow-sphere-3 {{
        position: absolute;
        bottom: 15%;
        left: -100px;
        width: 600px;
        height: 600px;
        background: radial-gradient(circle, rgba(56, 189, 248, 0.07) 0%, transparent 60%);
        filter: blur(70px);
        pointer-events: none;
    }}

    

    /* Hero Quick Actions */
    .hero-quick-actions {{
        display: flex;
        align-items: center;
        gap: 8px;
        margin-top: 14px;
        padding-top: 14px;
        border-top: 1px solid rgba(255, 255, 255, 0.05);
        flex-wrap: wrap;
    }}
    .hero-action-pill {{
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.09);
        color: var(--text-secondary);
        font-family: var(--font-sans);
        font-size: 12px;
        font-weight: 600;
        padding: 6px 12px;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        cursor: pointer;
        transition: all 0.2s ease;
    }}
    .hero-action-pill:hover {{
        background: rgba(99, 102, 241, 0.15);
        border-color: rgba(99, 102, 241, 0.35);
        color: #fff;
        transform: translateY(-1px);
    }}



    /* Markdown Format Toolbar */
    .markdown-toolbar {{
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 12px;
        background: rgba(14, 17, 26, 0.85);
        border: 1px solid rgba(255, 255, 255, 0.07);
        border-radius: 10px 10px 0 0;
        margin-bottom: -1px;
        flex-wrap: wrap;
    }}
    .toolbar-title {{
        font-size: 11px;
        font-weight: 700;
        color: var(--text-muted);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-right: 4px;
    }}
    .md-tool-btn {{
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        color: var(--text-secondary);
        font-family: var(--font-mono);
        font-size: 11.5px;
        font-weight: 600;
        padding: 4px 8px;
        border-radius: 6px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all 0.15s;
        line-height: 1;
    }}
    .md-tool-btn:hover {{
        background: rgba(99, 102, 241, 0.2);
        border-color: rgba(99, 102, 241, 0.4);
        color: #fff;
    }}
    .toolbar-spacer {{
        flex: 1;
    }}
    .sound-toggle-btn {{
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        color: var(--text-secondary);
        font-size: 11px;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 6px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s;
    }}
    .sound-toggle-btn.active {{
        background: rgba(16, 185, 129, 0.15);
        border-color: rgba(16, 185, 129, 0.4);
        color: #6ee7b7;
    }}

    /* Live Audio Waveform Animation */
    .waveform-radar {{
        display: flex;
        align-items: center;
        gap: 3px;
        height: 14px;
    }}
    .waveform-bar {{
        width: 2px;
        height: 100%;
        background: #10b981;
        border-radius: 2px;
        animation: wavePulse 1.2s infinite ease-in-out;
    }}
    .waveform-bar:nth-child(2) {{ animation-delay: 0.2s; }}
    .waveform-bar:nth-child(3) {{ animation-delay: 0.4s; }}
    .waveform-bar:nth-child(4) {{ animation-delay: 0.1s; }}
    @keyframes wavePulse {{
        0%, 100% {{ height: 4px; opacity: 0.4; }}
        50% {{ height: 14px; opacity: 1; }}
    }}

    /* Floating Navigation HUD */
    .floating-nav-hud {{
        position: fixed;
        bottom: 28px;
        right: 28px;
        display: flex;
        flex-direction: column;
        gap: 8px;
        z-index: 100;
    }}
    .nav-hud-btn {{
        width: 42px;
        height: 42px;
        border-radius: 12px;
        background: rgba(18, 21, 33, 0.85);
        border: 1px solid rgba(255, 255, 255, 0.12);
        color: var(--text-secondary);
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        backdrop-filter: blur(16px);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
        transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }}
    .nav-hud-btn:hover {{
        background: rgba(99, 102, 241, 0.25);
        border-color: var(--brand-blurple);
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 10px 28px rgba(99, 102, 241, 0.35);
    }}

    /* Warning Modal Live Preview Layout */
    .warn-modal-card {{
        max-width: 900px !important;
        width: 95% !important;
    }}
    .warn-modal-split {{
        display: grid;
        grid-template-columns: 1.1fr 0.9fr;
        gap: 24px;
        margin-top: 18px;
    }}
    @media (max-width: 768px) {{
        .warn-modal-split {{
            grid-template-columns: 1fr;
        }}
    }}
    .warn-dm-preview-card {{
        background: #111216;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 12px;
        padding: 18px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        position: relative;
    }}
    .preview-header-badge {{
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        font-size: 11px;
        font-weight: 700;
        color: var(--text-muted);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }}
    .discord-dm-embed-sim {{
        background: #1e1f26;
        border-left: 4px solid #ed4245;
        border-radius: 4px;
        padding: 14px 16px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }}
    .dm-embed-title {{
        font-size: 14px;
        font-weight: 700;
        color: #fff;
    }}
    .dm-embed-body {{
        font-size: 12.5px;
        color: #dcddde;
        line-height: 1.5;
    }}
    .dm-embed-footer {{
        font-size: 11px;
        color: #949ba4;
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 4px;
    }}

    
    /* Discord-Style Message Hover Actions */
    .msg-meta {{
        position: relative;
    }}
    .msg-hover-actions {{
        margin-left: auto;
        display: flex;
        align-items: center;
        gap: 4px;
        opacity: 0;
        transform: translateY(-2px);
        transition: all 0.15s ease;
    }}
    .msg-card:hover .msg-hover-actions {{
        opacity: 1;
        transform: translateY(0);
    }}
    .msg-action-btn {{
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: var(--text-secondary);
        border-radius: 6px;
        padding: 4px 6px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: all 0.15s;
    }}
    .msg-action-btn:hover {{
        background: rgba(99, 102, 241, 0.25);
        border-color: rgba(99, 102, 241, 0.45);
        color: #fff;
    }}
    .hero-summary-actions {{
        display: flex;
        align-items: center;
        gap: 8px;
    }}

    
    /* ─── MEDIA DRAWER (EK DOSYALAR VE GÖRSELLER) ─── */
    .media-drawer-overlay {{
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.65);
        backdrop-filter: blur(8px);
        z-index: 1000;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.25s ease;
    }}
    .media-drawer-overlay.active {{
        opacity: 1;
        pointer-events: auto;
    }}
    .media-drawer {{
        position: fixed;
        top: 0;
        right: -420px;
        width: 100%;
        max-width: 400px;
        height: 100vh;
        background: #12141e;
        border-left: 1px solid var(--border-subtle);
        box-shadow: -10px 0 40px rgba(0, 0, 0, 0.7);
        z-index: 1001;
        display: flex;
        flex-direction: column;
        transition: right 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }}
    .media-drawer.active {{
        right: 0;
    }}
    .drawer-header {{
        padding: 20px;
        border-bottom: 1px solid var(--border-subtle);
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: rgba(20, 24, 38, 0.9);
    }}
    .drawer-title-row {{
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 14px;
        font-weight: 700;
        color: #fff;
    }}
    .drawer-close-btn {{
        background: transparent;
        border: none;
        color: var(--text-secondary);
        cursor: pointer;
        padding: 4px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.15s;
    }}
    .drawer-close-btn:hover {{
        color: #fff;
        background: rgba(255, 255, 255, 0.1);
    }}
    .drawer-body {{
        padding: 16px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 12px;
        flex: 1;
    }}
    .media-drawer-card {{
        background: rgba(24, 28, 45, 0.7);
        border: 1px solid var(--border-subtle);
        border-radius: 12px;
        overflow: hidden;
        transition: all 0.2s;
    }}
    .media-drawer-card:hover {{
        border-color: var(--brand-blurple);
        transform: translateY(-1px);
    }}
    .media-drawer-thumb-wrap {{
        width: 100%;
        height: 160px;
        background: #000;
        position: relative;
        cursor: pointer;
        overflow: hidden;
    }}
    .media-drawer-thumb {{
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.2s;
    }}
    .media-drawer-thumb-wrap:hover .media-drawer-thumb {{
        transform: scale(1.03);
    }}
    .media-drawer-info {{
        padding: 12px 14px;
        display: flex;
        flex-direction: column;
        gap: 6px;
    }}
    .media-drawer-name {{
        font-size: 12.5px;
        font-weight: 600;
        color: #fff;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }}
    .media-drawer-meta {{
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 11px;
        color: var(--text-muted);
    }}
    .media-drawer-actions {{
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 4px;
    }}
    .media-drawer-btn {{
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: var(--text-secondary);
        font-size: 11.5px;
        font-weight: 600;
        padding: 5px 10px;
        border-radius: 6px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        text-decoration: none;
        transition: all 0.15s;
    }}
    .media-drawer-btn:hover {{
        background: rgba(99, 102, 241, 0.2);
        border-color: rgba(99, 102, 241, 0.4);
        color: #fff;
    }}

    /* ─── DAHİLİ YETKİLİ NOTU (INTERNAL STAFF NOTES) ─── */
    .console-mode-tabs {{
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 14px;
        background: rgba(14, 17, 26, 0.9);
        border: 1px solid rgba(255, 255, 255, 0.07);
        border-radius: 12px 12px 0 0;
        margin-bottom: -1px;
    }}
    .mode-tab {{
        background: transparent;
        border: 1px solid transparent;
        color: var(--text-secondary);
        font-family: var(--font-sans);
        font-size: 12.5px;
        font-weight: 600;
        padding: 6px 14px;
        border-radius: 8px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 7px;
        transition: all 0.15s;
    }}
    .mode-tab:hover {{
        color: #fff;
        background: rgba(255, 255, 255, 0.05);
    }}
    .mode-tab.active {{
        background: rgba(99, 102, 241, 0.18);
        border-color: rgba(99, 102, 241, 0.4);
        color: #fff;
    }}
    .mode-tab.note-mode.active {{
        background: rgba(245, 158, 11, 0.18);
        border-color: rgba(245, 158, 11, 0.4);
        color: #fbbf24;
    }}
    .staff-action-console.note-active {{
        border-color: rgba(245, 158, 11, 0.35);
    }}
    .internal-note-card {{
        background: rgba(245, 158, 11, 0.05) !important;
        border-left: 4px solid #f59e0b !important;
    }}
    .badge-internal-note {{
        background: rgba(245, 158, 11, 0.18);
        color: #fbbf24;
        font-size: 10px;
        font-weight: 700;
        padding: 2px 8px;
        border-radius: 4px;
        border: 1px solid rgba(245, 158, 11, 0.35);
        letter-spacing: 0.5px;
    }}
    .btn-console-send.note-btn {{
        background: #f59e0b !important;
        color: #000 !important;
        font-weight: 700 !important;
    }}
    .btn-console-send.note-btn:hover {{
        background: #fbbf24 !important;
        box-shadow: 0 4px 16px rgba(245, 158, 11, 0.4) !important;
    }}

    /* ─── KULLANICI PROFİL POPOVER ─── */
    .user-profile-popover {{
        position: absolute;
        width: 280px;
        background: #181b28;
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 14px;
        box-shadow: 0 12px 36px rgba(0, 0, 0, 0.75);
        z-index: 1000;
        padding: 16px;
        display: none;
        flex-direction: column;
        gap: 12px;
        animation: popoverFadeIn 0.15s ease-out;
    }}
    .user-profile-popover.active {{
        display: flex;
    }}
    @keyframes popoverFadeIn {{
        from {{ opacity: 0; transform: translateY(4px); }}
        to {{ opacity: 1; transform: translateY(0); }}
    }}
    .popover-header {{
        display: flex;
        align-items: center;
        gap: 12px;
    }}
    .popover-avatar {{
        width: 46px;
        height: 46px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid var(--border-subtle);
    }}
    .popover-names {{
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }}
    .popover-display {{
        font-size: 14px;
        font-weight: 700;
        color: #fff;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }}
    .popover-id-row {{
        font-family: var(--font-mono);
        font-size: 11px;
        color: var(--text-muted);
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 2px;
    }}
    .popover-copy-id {{
        cursor: pointer;
        padding: 2px 4px;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 4px;
        color: var(--text-secondary);
        font-size: 10px;
    }}
    .popover-copy-id:hover {{
        color: #fff;
        background: rgba(255, 255, 255, 0.1);
    }}
    .popover-actions {{
        display: flex;
        flex-direction: column;
        gap: 6px;
        padding-top: 10px;
        border-top: 1px solid rgba(255, 255, 255, 0.07);
    }}
    .popover-btn {{
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        color: var(--text-secondary);
        font-size: 12px;
        font-weight: 600;
        padding: 7px 10px;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 8px;
        transition: all 0.15s;
    }}
    .popover-btn:hover {{
        background: rgba(99, 102, 241, 0.18);
        border-color: rgba(99, 102, 241, 0.35);
        color: #fff;
    }}
    .popover-btn.danger:hover {{
        background: rgba(239, 68, 68, 0.18);
        border-color: rgba(239, 68, 68, 0.35);
        color: #fca5a5;
    }}

    /* Message Highlight Pulse on Jump */
    @keyframes msgFlash {{
        0%, 100% {{ background: var(--bg-card); }}
        50% {{ background: rgba(99, 102, 241, 0.25); border-color: var(--brand-blurple); }}
    }}
    .msg-card.highlighted {{
        animation: msgFlash 1.6s ease-in-out;
    }}

    
    /* ─── YENİ KURUMSAL KONTROLLER (ÖNCELİK, DIŞA AKTAR, KAPAT, GEÇMİŞ) ─── */
    .btn-action-close {{
        background: rgba(239, 68, 68, 0.12);
        border: 1px solid rgba(239, 68, 68, 0.3);
        color: #fca5a5;
        font-family: var(--font-sans);
        font-size: 12px;
        font-weight: 600;
        padding: 6px 12px;
        border-radius: 8px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s;
    }}
    .btn-action-close:hover {{
        background: rgba(239, 68, 68, 0.25);
        border-color: rgba(239, 68, 68, 0.5);
        color: #fff;
    }}
    .btn-action-close:disabled {{
        opacity: 0.5;
        cursor: not-allowed;
    }}
    .btn-action-claim {{
        background: rgba(99, 102, 241, 0.12);
        border: 1px solid rgba(99, 102, 241, 0.3);
        color: #c7d2fe;
        font-family: var(--font-sans);
        font-size: 12px;
        font-weight: 600;
        padding: 6px 12px;
        border-radius: 8px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s;
    }}
    .btn-action-claim:hover {{
        background: rgba(99, 102, 241, 0.25);
        border-color: rgba(99, 102, 241, 0.5);
        color: #fff;
    }}
    .priority-select-wrap {{
        position: relative;
        display: inline-flex;
        align-items: center;
    }}
    .priority-select {{
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid var(--border-subtle);
        color: var(--text-primary);
        font-family: var(--font-sans);
        font-size: 12px;
        font-weight: 600;
        padding: 6px 26px 6px 10px;
        border-radius: 8px;
        cursor: pointer;
        outline: none;
        appearance: none;
        -webkit-appearance: none;
        transition: all 0.2s;
    }}
    .priority-select:hover, .priority-select:focus {{
        border-color: var(--brand-blurple);
        background: rgba(255, 255, 255, 0.08);
    }}
    .priority-chevron {{
        position: absolute;
        right: 8px;
        pointer-events: none;
        color: var(--text-muted);
        display: flex;
        align-items: center;
    }}

    /* Export Dropdown */
    .export-dropdown-wrap {{
        position: relative;
        display: inline-block;
    }}
    .btn-action-export {{
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid var(--border-subtle);
        color: var(--text-secondary);
        font-family: var(--font-sans);
        font-size: 12px;
        font-weight: 600;
        padding: 6px 12px;
        border-radius: 8px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s;
    }}
    .btn-action-export:hover {{
        background: rgba(255, 255, 255, 0.08);
        color: #fff;
    }}
    .export-menu {{
        position: absolute;
        top: calc(100% + 6px);
        right: 0;
        background: #151825;
        border: 1px solid var(--border-subtle);
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
        padding: 6px;
        display: none;
        flex-direction: column;
        gap: 4px;
        min-width: 210px;
        z-index: 1000;
    }}
    .export-menu.active {{
        display: flex;
    }}
    .export-item {{
        background: transparent;
        border: none;
        color: var(--text-secondary);
        font-family: var(--font-sans);
        font-size: 12px;
        font-weight: 500;
        padding: 8px 10px;
        border-radius: 6px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 8px;
        text-align: left;
        width: 100%;
        transition: all 0.15s;
    }}
    .export-item:hover {{
        background: rgba(99, 102, 241, 0.15);
        color: #fff;
    }}

    /* Search Match Highlight */
    mark.search-match {{
        background: rgba(234, 179, 8, 0.35);
        color: #fef08a;
        padding: 0 2px;
        border-radius: 2px;
        font-weight: 700;
    }}

    /* User History Modal */
    .history-modal-body {{
        max-height: 480px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 16px;
    }}
    .history-stat-grid {{
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
    }}
    .history-stat-box {{
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.07);
        border-radius: 10px;
        padding: 12px;
        text-align: center;
    }}
    .history-stat-num {{
        font-size: 20px;
        font-weight: 800;
        color: #fff;
    }}
    .history-stat-lbl {{
        font-size: 11px;
        color: var(--text-muted);
        text-transform: uppercase;
        margin-top: 2px;
    }}
    .history-table {{
        width: 100%;
        border-collapse: collapse;
        font-size: 12px;
    }}
    .history-table th {{
        text-align: left;
        padding: 8px 10px;
        color: var(--text-muted);
        font-weight: 600;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }}
    .history-table td {{
        padding: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.04);
        color: var(--text-secondary);
    }}
    .history-table tr:hover td {{
        background: rgba(255, 255, 255, 0.02);
    }}
    .history-link {{
        color: var(--brand-blurple);
        text-decoration: none;
        font-weight: 600;
    }}
    .history-link:hover {{
        text-decoration: underline;
    }}
    .history-badge {{
        font-size: 10px;
        font-weight: 700;
        padding: 2px 6px;
        border-radius: 4px;
        letter-spacing: 0.5px;
    }}
    .history-badge.open {{
        background: rgba(16, 185, 129, 0.15);
        color: #34d399;
    }}
    .history-badge.closed {{
        background: rgba(148, 163, 184, 0.15);
        color: #94a3b8;
    }}

    /* Print Stylesheet */
    @media print {{
        body {{ background: #fff !important; color: #000 !important; }}
        .top-nav, .floating-nav-hud, .staff-action-console, .participants-bar, .media-drawer, .media-drawer-overlay, .user-profile-popover, .warn-modal-overlay, .toast-container, .export-dropdown-wrap, .search-wrapper, .filter-select-wrap, .msg-hover-actions {{ display: none !important; }}
        .ambient-canvas, .scroll-progress-line {{ display: none !important; }}
        .portal-layout {{ padding: 0 !important; max-width: 100% !important; }}
        .hero-card {{ background: #f8fafc !important; border: 1px solid #cbd5e1 !important; color: #000 !important; box-shadow: none !important; margin-bottom: 20px !important; }}
        .metric-value {{ color: #0f172a !important; }}
        .metric-label {{ color: #64748b !important; }}
        .msg-stream {{ gap: 8px !important; }}
        .msg-card {{ background: #fff !important; border: 1px solid #e2e8f0 !important; color: #000 !important; break-inside: avoid; margin-bottom: 8px !important; box-shadow: none !important; }}
        .msg-author {{ color: #1e293b !important; }}
        .msg-text {{ color: #334155 !important; }}
        .msg-time {{ color: #64748b !important; }}
    }}

    
    /* ─── DİKEY SOL SİDEBAR & YENİ KURUMSAL DÜZEN ─── */
    body {{
        display: flex !important;
        min-height: 100vh;
        background-color: var(--bg-base);
        overflow-x: hidden;
    }}
    .sidebar-overlay {{
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.7);
        backdrop-filter: blur(4px);
        z-index: 998;
        display: none;
    }}
    .sidebar-overlay.active {{
        display: block;
    }}
    .app-sidebar {{
        width: 270px;
        min-width: 270px;
        max-width: 270px;
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        background: #0d0f17;
        border-right: 1px solid var(--border-subtle);
        display: flex;
        flex-direction: column;
        z-index: 999;
        box-shadow: 4px 0 24px rgba(0, 0, 0, 0.4);
    }}
    .sidebar-brand-box {{
        padding: 20px 18px 16px 18px;
        border-bottom: 1px solid var(--border-subtle);
        display: flex;
        align-items: center;
        gap: 12px;
        background: rgba(18, 22, 34, 0.4);
    }}
    .sidebar-brand-info {{
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }}
    .sidebar-brand-title {{
        font-size: 15px;
        font-weight: 800;
        color: #fff;
        letter-spacing: 0.5px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }}
    .sidebar-brand-badge {{
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 10px;
        font-weight: 700;
        color: #818cf8;
        background: rgba(99, 102, 241, 0.15);
        border: 1px solid rgba(99, 102, 241, 0.3);
        padding: 1px 6px;
        border-radius: 4px;
        margin-top: 2px;
        width: fit-content;
    }}
    .sidebar-ticket-card {{
        margin: 14px 14px 8px 14px;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.07);
        border-radius: 12px;
        padding: 12px;
        display: flex;
        flex-direction: column;
        gap: 8px;
    }}
    .sidebar-ticket-head {{
        display: flex;
        align-items: center;
        justify-content: space-between;
    }}
    .sidebar-ticket-id {{
        font-size: 14px;
        font-weight: 800;
        color: #fff;
        font-family: var(--font-mono);
    }}
    .sidebar-ticket-user {{
        font-size: 11.5px;
        color: var(--text-secondary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }}
    .sidebar-priority-row {{
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-top: 8px;
        margin-top: 4px;
        border-top: 1px solid rgba(255, 255, 255, 0.06);
        position: relative;
    }}
    .sidebar-priority-label {{
        font-size: 11px;
        color: var(--text-muted);
        display: flex;
        align-items: center;
        gap: 5px;
        font-weight: 600;
        letter-spacing: 0.2px;
    }}
    /* Custom Modern Priority Dropdown */
    .custom-priority-dropdown {{
        position: relative;
    }}
    .priority-trigger-btn {{
        background: rgba(18, 22, 36, 0.85);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: var(--text-primary);
        font-family: var(--font-sans);
        font-size: 11px;
        font-weight: 600;
        padding: 4px 8px;
        border-radius: 7px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        outline: none;
        user-select: none;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.25);
    }}
    .priority-trigger-btn:hover {{
        background: rgba(26, 32, 52, 0.95);
        border-color: rgba(99, 102, 241, 0.4);
        transform: translateY(-1px);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.35);
    }}
    .priority-trigger-btn.open {{
        border-color: #6366f1;
        box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.25);
    }}
    .priority-dot {{
        width: 7px;
        height: 7px;
        border-radius: 50%;
        display: inline-block;
        flex-shrink: 0;
    }}
    .dot-dusuk {{ background: #10b981; box-shadow: 0 0 7px rgba(16, 185, 129, 0.9); }}
    .dot-normal {{ background: #3b82f6; box-shadow: 0 0 7px rgba(59, 130, 246, 0.9); }}
    .dot-yuksek {{ background: #f59e0b; box-shadow: 0 0 8px rgba(245, 158, 11, 0.9); }}
    .dot-acil {{ background: #ef4444; box-shadow: 0 0 10px rgba(239, 68, 68, 0.95); animation: pulse-neon 1.4s infinite alternate ease-in-out; }}

    @keyframes pulse-neon {{
        0% {{ transform: scale(0.9); opacity: 0.8; }}
        100% {{ transform: scale(1.25); opacity: 1; filter: brightness(1.25); }}
    }}

    .priority-chevron {{
        display: flex;
        align-items: center;
        transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        opacity: 0.7;
    }}
    .priority-chevron svg {{
        width: 12px;
        height: 12px;
    }}
    .priority-trigger-btn.open .priority-chevron {{
        transform: rotate(180deg);
        opacity: 1;
    }}
    .priority-popover {{
        position: absolute;
        top: calc(100% + 5px);
        right: 0;
        min-width: 155px;
        background: #111422;
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 9px;
        padding: 5px;
        box-shadow: 0 12px 28px -4px rgba(0, 0, 0, 0.75), 0 0 1px 1px rgba(255, 255, 255, 0.05);
        z-index: 1000;
        opacity: 0;
        pointer-events: none;
        transform: translateY(-4px) scale(0.96);
        transition: all 0.18s cubic-bezier(0.16, 1, 0.3, 1);
        backdrop-filter: blur(14px);
    }}
    .priority-popover.open {{
        opacity: 1;
        pointer-events: auto;
        transform: translateY(0) scale(1);
    }}
    .priority-popover-header {{
        font-size: 9px;
        font-weight: 700;
        text-transform: uppercase;
        color: var(--text-muted);
        letter-spacing: 0.6px;
        padding: 4px 8px 6px 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        margin-bottom: 3px;
    }}
    .priority-popover-item {{
        display: flex;
        align-items: center;
        gap: 7px;
        padding: 6px 8px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 11px;
        font-weight: 600;
        color: var(--text-secondary);
        transition: all 0.15s ease;
        user-select: none;
    }}
    .priority-popover-item:hover {{
        background: rgba(255, 255, 255, 0.07);
        color: #fff;
    }}
    .priority-popover-item.active {{
        background: rgba(99, 102, 241, 0.18);
        color: #fff;
        border-left: 2px solid #6366f1;
    }}
    .p-name {{
        flex: 1;
        text-align: left;
    }}
    .p-tag {{
        font-size: 8px;
        font-weight: 700;
        padding: 2px 5px;
        border-radius: 4px;
        letter-spacing: 0.3px;
    }}
    .tag-dusuk {{ background: rgba(16, 185, 129, 0.15); color: #10b981; }}
    .tag-normal {{ background: rgba(59, 130, 246, 0.15); color: #60a5fa; }}
    .tag-yuksek {{ background: rgba(245, 158, 11, 0.15); color: #fbbf24; }}
    .tag-acil {{ background: rgba(239, 68, 68, 0.2); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.35); }}

    /* Sidebar Live Sync Card */
    .sidebar-live-sync-card {{
        background: rgba(20, 24, 38, 0.6);
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: 9px;
        padding: 8px 10px;
        margin-bottom: 6px;
        display: flex;
        flex-direction: column;
        gap: 6px;
    }}
    .sidebar-btn.sync-btn {{
        background: linear-gradient(135deg, rgba(99, 102, 241, 0.18), rgba(168, 85, 247, 0.18));
        border: 1px solid rgba(99, 102, 241, 0.35);
        color: #e0e7ff;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 7px 10px;
        border-radius: 7px;
        cursor: pointer;
        font-size: 11.5px;
        font-weight: 600;
        transition: all 0.2s ease;
        width: 100%;
    }}
    .sidebar-btn.sync-btn:hover {{
        background: linear-gradient(135deg, rgba(99, 102, 241, 0.28), rgba(168, 85, 247, 0.28));
        border-color: rgba(99, 102, 241, 0.6);
        box-shadow: 0 0 12px rgba(99, 102, 241, 0.2);
        color: #fff;
    }}
    .sync-icon {{
        flex-shrink: 0;
        transition: transform 0.4s ease;
    }}
    .sync-icon.spinning {{
        animation: spinIcon 0.7s linear infinite;
    }}
    @keyframes spinIcon {{
        from {{ transform: rotate(0deg); }}
        to {{ transform: rotate(360deg); }}
    }}
    .sync-meta-bar {{
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 2px;
    }}
    .sync-meta-text {{
        font-size: 10px;
        color: var(--text-muted);
        font-weight: 500;
    }}
    .sync-toggle-label {{
        display: flex;
        align-items: center;
        gap: 5px;
        cursor: pointer;
        font-size: 9.5px;
        color: var(--text-secondary);
        font-weight: 600;
        user-select: none;
    }}
    .sync-toggle-switch {{
        position: relative;
        display: inline-block;
        width: 26px;
        height: 14px;
    }}
    .sync-toggle-switch input {{
        opacity: 0;
        width: 0;
        height: 0;
    }}
    .sync-toggle-slider {{
        position: absolute;
        cursor: pointer;
        top: 0; left: 0; right: 0; bottom: 0;
        background-color: rgba(255, 255, 255, 0.15);
        transition: .25s;
        border-radius: 14px;
    }}
    .sync-toggle-slider:before {{
        position: absolute;
        content: "";
        height: 10px;
        width: 10px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .25s;
        border-radius: 50%;
    }}
    .sync-toggle-switch input:checked + .sync-toggle-slider {{
        background-color: #10b981;
        box-shadow: 0 0 8px rgba(16, 185, 129, 0.5);
    }}
    .sync-toggle-switch input:checked + .sync-toggle-slider:before {{
        transform: translateX(12px);
    }}

    /* Chat Section Quick Sync Button */
    .chat-section-header {{
        display: flex;
        align-items: center;
        justify-content: space-between;
    }}
    .chat-header-actions {{
        display: flex;
        align-items: center;
        gap: 8px;
    }}
    .chat-quick-sync-btn {{
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.08);
        color: var(--text-secondary);
        font-size: 11px;
        font-weight: 600;
        padding: 4px 9px;
        border-radius: 6px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 5px;
        transition: all 0.2s ease;
    }}
    .chat-quick-sync-btn:hover {{
        background: rgba(99, 102, 241, 0.15);
        border-color: rgba(99, 102, 241, 0.4);
        color: #fff;
    }}
    .sidebar-scroll-area {{
        flex: 1;
        overflow-y: auto;
        padding: 10px 14px 16px 14px;
        display: flex;
        flex-direction: column;
        gap: 4px;
    }}
    .sidebar-sec-title {{
        font-size: 10.5px;
        font-weight: 700;
        color: var(--text-muted);
        letter-spacing: 0.7px;
        text-transform: uppercase;
        padding: 10px 8px 4px 8px;
    }}
    .sidebar-btn {{
        width: 100%;
        background: transparent;
        border: 1px solid transparent;
        color: var(--text-secondary);
        font-family: var(--font-sans);
        font-size: 12px;
        font-weight: 600;
        padding: 8px 10px;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 10px;
        text-align: left;
        transition: all 0.15s ease;
    }}
    
    .sidebar-btn.claimed-disabled {{
        opacity: 0.78 !important;
        cursor: not-allowed !important;
        background: rgba(88, 101, 242, 0.12) !important;
        border-color: rgba(88, 101, 242, 0.3) !important;
        color: #c7d2fe !important;
    }}

    .sidebar-btn:hover {{
        background: rgba(255, 255, 255, 0.05);
        color: #fff;
    }}
    .sidebar-btn.primary {{
        background: rgba(99, 102, 241, 0.12);
        border-color: rgba(99, 102, 241, 0.25);
        color: #c7d2fe;
    }}
    .sidebar-btn.primary:hover {{
        background: rgba(99, 102, 241, 0.22);
        color: #fff;
    }}
    .sidebar-btn.warning {{
        background: rgba(245, 158, 11, 0.1);
        border-color: rgba(245, 158, 11, 0.22);
        color: #fbbf24;
    }}
    .sidebar-btn.warning:hover {{
        background: rgba(245, 158, 11, 0.2);
        color: #fff;
    }}
    .sidebar-btn.danger {{
        background: rgba(239, 68, 68, 0.1);
        border-color: rgba(239, 68, 68, 0.22);
        color: #fca5a5;
    }}
    .sidebar-btn.danger:hover {{
        background: rgba(239, 68, 68, 0.22);
        color: #fff;
    }}
    .sidebar-badge-count {{
        margin-left: auto;
        background: rgba(255, 255, 255, 0.08);
        color: var(--text-secondary);
        font-size: 10.5px;
        font-weight: 700;
        padding: 2px 6px;
        border-radius: 10px;
    }}
    .sidebar-footer {{
        padding: 12px 14px;
        border-top: 1px solid var(--border-subtle);
        background: rgba(14, 17, 26, 0.6);
    }}
    .sidebar-logout-btn {{
        width: 100%;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.08);
        color: var(--text-muted);
        font-family: var(--font-sans);
        font-size: 12px;
        font-weight: 600;
        padding: 7px 10px;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all 0.15s;
    }}
    .sidebar-logout-btn:hover {{
        background: rgba(239, 68, 68, 0.15);
        border-color: rgba(239, 68, 68, 0.35);
        color: #fca5a5;
    }}

    /* Main Content Wrapper */
    .main-wrapper {{
        margin-left: 270px;
        width: calc(100% - 270px);
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        flex: 1;
        position: relative;
    }}
    .top-nav {{
        position: sticky;
        top: 0;
        z-index: 90;
        background: rgba(11, 13, 20, 0.85);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border-bottom: 1px solid var(--border-subtle);
        padding: 12px 28px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
    }}
    .top-nav-left {{
        display: flex;
        align-items: center;
        gap: 12px;
    }}
    .mobile-sidebar-toggle {{
        display: none;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid var(--border-subtle);
        color: #fff;
        padding: 6px;
        border-radius: 6px;
        cursor: pointer;
    }}
    .top-ticket-badge {{
        background: rgba(99, 102, 241, 0.18);
        border: 1px solid rgba(99, 102, 241, 0.35);
        color: #a5b4fc;
        font-family: var(--font-mono);
        font-size: 12px;
        font-weight: 700;
        padding: 3px 8px;
        border-radius: 6px;
    }}
    .top-ticket-name {{
        font-size: 14px;
        font-weight: 700;
        color: #fff;
    }}
    .top-ticket-cat {{
        font-size: 12px;
        color: var(--text-muted);
    }}
    .top-nav-right {{
        display: flex;
        align-items: center;
        gap: 12px;
    }}

    @media (max-width: 960px) {{
        .app-sidebar {{
            left: -270px;
            transition: left 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }}
        .app-sidebar.active {{
            left: 0;
        }}
        .main-wrapper {{
            margin-left: 0 !important;
            width: 100% !important;
        }}
        .mobile-sidebar-toggle {{
            display: flex !important;
        }}
    }}
    @media print {{
        .app-sidebar, .sidebar-overlay, .mobile-sidebar-toggle {{ display: none !important; }}
        .main-wrapper {{ margin-left: 0 !important; width: 100% !important; }}
    }}

    </style>
</head>
<body>
    <div class="scroll-progress-line" id="scrollProgressLine"></div>
    <div class="ambient-canvas">
        <div class="glow-sphere-1"></div>
        <div class="glow-sphere-2"></div>
        <div class="glow-sphere-3"></div>
        <div class="subtle-grid"></div>
    </div>

        <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

    <!-- DİKEY SOL SİDEBAR (LOGO & TÜM AKSİYONLAR) -->
    <aside class="app-sidebar" id="appSidebar">
        <div class="sidebar-brand-box">
            <div class="brand-logo-frame">
                {logo_html}
            </div>
            <div class="sidebar-brand-info">
                <span class="sidebar-brand-title">{bot_name}</span>
                <span class="sidebar-brand-badge">{SVG_SHIELD} DOĞRULANMIŞ ARŞİV</span>
            </div>
        </div>

        <div class="sidebar-ticket-card">
            <div class="sidebar-ticket-head">
                <span class="sidebar-ticket-id">{ticket_id}</span>
                {channel_status_badge}
            </div>
            <div class="sidebar-ticket-user">#{clean_ch_name} • @{owner_name}</div>
            <div class="sidebar-priority-row">
                <span class="sidebar-priority-label">{SVG_FLAG} Öncelik:</span>
                <div class="custom-priority-dropdown" id="customPriorityDropdown">
                    <select id="prioritySelect" style="display:none;" onchange="changeTicketPriority(this.value)">
                        <option value="Düşük" {sel_dusuk}>Düşük</option>
                        <option value="Normal" {sel_normal}>Normal</option>
                        <option value="Yüksek" {sel_yuksek}>Yüksek</option>
                        <option value="Acil" {sel_acil}>ACİL</option>
                    </select>
                    <button type="button" class="priority-trigger-btn" id="priorityTriggerBtn" onclick="togglePriorityMenu(event)">
                        <span class="priority-dot dot-{p_cls}"></span>
                        <span class="priority-label-text" id="priorityLabelText">{p_display}</span>
                        <span class="priority-chevron">{SVG_CHEVRON}</span>
                    </button>
                    <div class="priority-popover" id="priorityPopover">
                        <div class="priority-popover-header">Öncelik Düzeyi</div>
                        <div class="priority-popover-item {act_dusuk}" data-value="Düşük" onclick="onSelectPriorityCustom('Düşük')">
                            <span class="priority-dot dot-dusuk"></span>
                            <span class="p-name">Düşük</span>
                            <span class="p-tag tag-dusuk">STANDART</span>
                        </div>
                        <div class="priority-popover-item {act_normal}" data-value="Normal" onclick="onSelectPriorityCustom('Normal')">
                            <span class="priority-dot dot-normal"></span>
                            <span class="p-name">Normal</span>
                            <span class="p-tag tag-normal">NORMAL</span>
                        </div>
                        <div class="priority-popover-item {act_yuksek}" data-value="Yüksek" onclick="onSelectPriorityCustom('Yüksek')">
                            <span class="priority-dot dot-yuksek"></span>
                            <span class="p-name">Yüksek</span>
                            <span class="p-tag tag-yuksek">ÖNEMLİ</span>
                        </div>
                        <div class="priority-popover-item {act_acil}" data-value="Acil" onclick="onSelectPriorityCustom('Acil')">
                            <span class="priority-dot dot-acil"></span>
                            <span class="p-name" style="color:#f87171;font-weight:700;">ACİL</span>
                            <span class="p-tag tag-acil">KRİTİK</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="sidebar-scroll-area">
            <div class="sidebar-sec-title">BİLET YÖNETİMİ</div>

            <!-- CANLI SOHBET SENKRONİZASYON KARTI -->
            <div class="sidebar-live-sync-card">
                <button class="sidebar-btn sync-btn" id="sidebarSyncBtn" onclick="syncTicketMessages(true)" type="button" title="Discord bilet kanalındaki yeni mesajları anında ekrana düşür">
                    <svg class="sync-icon" id="syncIconSpin" viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/>
                    </svg>
                    <span>Sohbeti Yenile</span>
                </button>
                <div class="sync-meta-bar">
                    <span class="sync-meta-text" id="syncLastTime">Otomatik Akış: Aktif (5s)</span>
                    <label class="sync-toggle-label" title="Otomatik canlı senkronizasyonu aç/kapat">
                        <span class="sync-toggle-switch">
                            <input type="checkbox" id="autoSyncToggle" checked onchange="toggleAutoSync(this.checked)">
                            <span class="sync-toggle-slider"></span>
                        </span>
                    </label>
                </div>
            </div>

            <a href="/" class="sidebar-btn primary" style="margin-bottom: 6px; text-decoration: none;">
                {SVG_MENU}
                <span>Tüm Biletler Menüsü</span>
            </a>
            <button class="sidebar-btn primary" onclick="focusLiveChat()" type="button">
                {SVG_SEND}
                <span>Bilete Canlı Yaz</span>
            </button>
            <button class="sidebar-btn warning" onclick="setConsoleMode('note'); focusLiveChat();" type="button">
                {SVG_SHIELD}
                <span>Dahili Not Ekle</span>
            </button>
            <button class="sidebar-btn" onclick="toggleMediaDrawer()" type="button">
                {SVG_FILE}
                <span>Ek Dosyalar &amp; Medya</span>
                <span class="sidebar-badge-count">{total_attachments}</span>
            </button>
            <button {claim_btn_attr} id="btnActionClaim" onclick="claimTicketWeb()" type="button">
                {SVG_USER_CHECK}
                <span id="claimBtnLabel">{display_claim_name}</span>
            </button>
            <button class="sidebar-btn" onclick="openWarnModal()" type="button">
                {SVG_ALERT_TRIANGLE}
                <span>Kullanıcıyı Uyar</span>
            </button>
            <button class="sidebar-btn" onclick="openUserHistoryModal()" type="button">
                {SVG_HISTORY}
                <span>Destek Geçmişi &amp; Sicil</span>
            </button>
            <button class="sidebar-btn danger" id="btnActionClose" onclick="openCloseTicketModal()" type="button">
                {SVG_LOCK}
                <span>Bileti Kapat &amp; Kilitle</span>
            </button>

            <div class="sidebar-sec-title" style="margin-top: 14px;">DIŞA AKTARMA &amp; ÇIKTI</div>
            <button class="sidebar-btn" onclick="printTranscript()" type="button">
                {SVG_PRINT}
                <span>Yazdır / PDF Kaydet</span>
            </button>
            <button class="sidebar-btn" onclick="exportTranscriptJson()" type="button">
                {SVG_JSON}
                <span>JSON Formatında İndir</span>
            </button>
            <button class="sidebar-btn" onclick="exportTranscriptTxt()" type="button">
                {SVG_TXT}
                <span>Metin (TXT) İndir</span>
            </button>
            <button class="sidebar-btn" onclick="copySiteLink(this)" type="button">
                {SVG_LINK}
                <span>Transkript Linkini Kopyala</span>
            </button>
        </div>

        <div class="sidebar-footer">
            <button class="sidebar-logout-btn" onclick="logoutStaff()" type="button">
                {SVG_SHIELD}
                <span>Güvenli Çıkış Yap</span>
            </button>
        </div>
    </aside>

    <!-- SAĞ ANA İÇERİK ALANI -->
    <div class="main-wrapper">
        <header class="top-nav">
            <div class="top-nav-left">
                <button class="mobile-sidebar-toggle" onclick="toggleSidebar()" type="button" aria-label="Menüyü Aç">{SVG_MENU}</button>
                <div class="top-ticket-badge">{ticket_id}</div>
                <div class="top-ticket-name">#{clean_ch_name}</div>
                <div class="top-ticket-cat">• {category}</div>
            </div>

            <div class="top-nav-right">
                <div class="search-wrapper">
                    <span class="search-icon-box">{SVG_SEARCH}</span>
                    <input type="text" id="searchInput" class="search-input" placeholder="Mesaj veya kelime ara..." oninput="onSearchInput()">
                    <span id="searchShortcut" class="search-shortcut-hint">Ctrl K</span>
                    <button id="searchClearBtn" class="search-clear-btn" onclick="clearSearch()" type="button">{SVG_CLOSE}</button>
                </div>
                <div class="filter-select-wrap">
                    <select id="authorSelect" class="filter-select" onchange="onAuthorSelect()">
                        <option value="all">Tüm Katılımcılar</option>
                        {author_options_html}
                    </select>
                    <span class="filter-chevron">{SVG_CHEVRON}</span>
                </div>
            </div>
        </header>

    <main class="main-stage">
        <section class="ticket-hero-card">
            <div class="hero-top-accent"></div>
            <div class="hero-header">
                <div>
                    <div class="hero-breadcrumb">
                        <span>ARŞİV</span>
                        <span>/</span>
                        <span>{guild_name}</span>
                        <span>/</span>
                        <span>#{clean_ch_name}</span>
                    </div>
                    <div class="hero-title-row">
                        <h1 class="hero-title">#{clean_ch_name}</h1>
                        <span class="ticket-id-chip">{ticket_id}</span>
                    </div>
                </div>
{channel_status_badge}
            </div>

            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="metric-icon-box">{SVG_USER}</div>
                    <div class="metric-text">
                        <span class="metric-label">Talep Sahibi</span>
                        <span class="metric-value"><span class="user-pill">@{owner_name}</span></span>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon-box">{SVG_TAG}</div>
                    <div class="metric-text">
                        <span class="metric-label">Kategori</span>
                        <span class="metric-value">{category}</span>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon-box">{SVG_SHIELD}</div>
                    <div class="metric-text">
                        <span class="metric-label">İlgilenen Yetkili</span>
                        <span class="metric-value">{claimed_html}</span>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon-box">{SVG_CALENDAR}</div>
                    <div class="metric-text">
                        <span class="metric-label">Açılış Zamanı</span>
                        <span class="metric-value">{created_at}</span>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon-box">{SVG_CHECK}</div>
                    <div class="metric-text">
                        <span class="metric-label">Kapanış Zamanı</span>
                        <span class="metric-value">{closed_at}</span>
                    </div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon-box">{SVG_CLOCK}</div>
                    <div class="metric-text">
                        <span class="metric-label">Toplam Süre</span>
                        <span class="metric-value">{duration_str}</span>
                    </div>
                </div>
            </div>

            <div class="quick-stats-strip">
                <div class="quick-stat-group">
                    <div class="quick-stat-item">
                        {SVG_CHAT}
                        <span>Toplam: <strong class="quick-stat-val" id="totalMsgCount">{len(messages)}</strong> mesaj</span>
                    </div>
                    <div class="quick-stat-item">
                        {SVG_USER}
                        <span>Katılımcı: <strong class="quick-stat-val">{len(author_stats)}</strong> kişi</span>
                    </div>
                    <div class="quick-stat-item">
                        {SVG_FILE}
                        <span>Ek Dosyalar: <strong class="quick-stat-val">{total_attachments}</strong> adet</span>
                    </div>
                </div>
                <div class="hero-summary-actions">
                    <button class="hero-action-pill" onclick="exportTranscriptJson()" type="button" title="Konuşma verisini JSON olarak indir">
                        {SVG_JSON}
                        <span>JSON İndir</span>
                    </button>
                    <button class="hero-action-pill" onclick="exportTranscriptTxt()" type="button" title="Metin (.txt) olarak indir">
                        {SVG_TXT}
                        <span>TXT İndir</span>
                    </button>
                </div>
            </div>
        </section>

        <nav class="participants-bar" id="participantsBar">
            {participant_chips_html}
        </nav>

        <section class="chat-section">
            <div class="chat-section-header">
                <div class="chat-header-title">
                    {SVG_HASH}
                    <span>Sohbet Geçmişi</span>
                </div>
                <div class="chat-header-actions">
                    <button class="chat-quick-sync-btn" onclick="syncTicketMessages(true)" type="button" title="Discord ile anlık senkronize et">
                        <svg class="sync-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/>
                        </svg>
                        <span>Yenile</span>
                    </button>
                    <div id="matchCounter" class="chat-header-count">Toplam {len(messages)} mesaj</div>
                </div>
            </div>

            <div class="msg-stream" id="msgStream">
                {all_messages_str}
            </div>
        </section>

        <!-- Yetkili Canlı Eylem ve Mesaj Docku -->
        <section class="staff-action-console" id="staffLiveDock">
            <div class="console-top-glow"></div>
            <div class="console-header">
                <div class="console-title-cluster">
                    <div class="console-icon">{SVG_TERMINAL}</div>
                    <div>
                        <div class="console-heading">Yetkili Canlı İletişim Konsolu</div>
                        <div class="console-subheading">Buradan göndereceğiniz mesajlar anında Discord bilet kanalına (#{clean_ch_name}) iletilir.</div>
                    </div>
                </div>
                <div class="console-badge-row">
                    {console_status_pill}
                    <div class="staff-role-pill">
                        {SVG_SHIELD}
                        <span>Yetkili: 0</span>
                    </div>
                </div>
            </div>

            <div class="console-mode-tabs">
                <button type="button" class="mode-tab active" id="tabLiveMsg" onclick="setConsoleMode('message')">
                    {SVG_SEND}
                    <span>Bilete Yaz (Discord)</span>
                </button>
                <button type="button" class="mode-tab note-mode" id="tabStaffNote" onclick="setConsoleMode('note')">
                    {SVG_SHIELD}
                    <span>Dahili Not Ekle (Sadece Yetkililer Görür)</span>
                </button>
            </div>
            <div class="quick-templates-bar">
                <span class="template-label">Hazır Yanıtlar:</span>
                <button class="template-pill" onclick="insertTemplate('Talebiniz yetkili ekibimiz tarafından incelenmektedir.')" type="button">İnceleniyor</button>
                <button class="template-pill" onclick="insertTemplate('Lütfen sorununuzu detaylandıran net bir ekran görüntüsü veya video iletin.')" type="button">Ekran Görüntüsü</button>
                <button class="template-pill" onclick="insertTemplate('Gerekli kontroller sağlanmış olup probleminiz çözümlenmiştir. Farklı bir sorunuz varsa iletebilirsiniz.')" type="button">Çözümlendi</button>
                <button class="template-pill" onclick="insertTemplate('İşleminize devam edebilmemiz için kullanıcı adınızı ve Discord ID\'nizi belirtin.')" type="button">Bilgi İste</button>
                <button class="template-pill danger" onclick="openWarnModal()" type="button">Kullanıcıyı Uyar</button>
            </div>

            <div class="markdown-toolbar">
                <span class="toolbar-title">Biçim:</span>
                <button type="button" class="md-tool-btn" onclick="wrapText('**', '**')" title="Kalın (Bold)">{SVG_BOLD}</button>
                <button type="button" class="md-tool-btn" onclick="wrapText('*', '*')" title="İtalik (Italic)">{SVG_ITALIC}</button>
                <button type="button" class="md-tool-btn" onclick="wrapText('`', '`')" title="Satır İçi Kod">{SVG_CODE}</button>
                <button type="button" class="md-tool-btn" onclick="wrapText('```\n', '\n```')" title="Kod Bloğu">KOD</button>
                <button type="button" class="md-tool-btn" onclick="wrapText('> ', '')" title="Alıntı">{SVG_QUOTE}</button>
                <button type="button" class="md-tool-btn" onclick="wrapText('||', '||')" title="Spoiler">SPOILER</button>
                <div class="toolbar-spacer"></div>
                
            </div>
            <div class="console-input-wrap">
                <textarea id="liveChatInput" class="console-textarea" placeholder="Bilete Discord üzerinden canlı mesaj yazın... (Ctrl + Enter ile hızlı gönder)" rows="2" oninput="updateCharCounter()"></textarea>
                <div class="console-input-footer">
                    <div class="input-hints">
                        <span id="charCountLabel">0 / 2000 karakter • 1 satır</span>
                    </div>
                    <div class="input-actions">
                        <button id="sendLiveMsgBtn" class="btn-console-send" onclick="dispatchLiveAction()" type="button">
                            {SVG_SEND}
                            <span>Bilete Gönder</span>
                        </button>
                    </div>
                </div>
            </div>
        </section>

        <footer class="portal-footer">
            <p><span class="footer-highlight">{bot_name}</span> • Priv Ticket Transcript Architecture &copy; 2026</p>
            <p>Bu kayıt sunucu güvenliği ve müşteri memnuniyeti protokolü uyarınca şifrelenerek saklanmıştır.</p>
        </footer>
    </main>

    
    <!-- Bileti Kapat & Arşivle Modalı -->
    <div class="warn-modal-overlay" id="closeTicketModal" onclick="if(event.target===this) closeCloseTicketModal()">
        <div class="warn-modal-card" style="max-width: 520px !important;">
            <div class="warn-modal-header">
                <div class="warn-title-group">
                    <div class="warn-icon-box" style="background:rgba(239,68,68,0.15); border-color:rgba(239,68,68,0.35); color:#ef4444;">{SVG_LOCK}</div>
                    <div>
                        <h2 class="warn-modal-title">Talebi Kapat ve Arşivle</h2>
                        <p class="warn-modal-desc">Bilet kanalını kilitler, arşiv kaydını tamamlar ve kullanıcıya bildirim gönderir.</p>
                    </div>
                </div>
                <button class="modal-close-btn" onclick="closeCloseTicketModal()" type="button">{SVG_CLOSE}</button>
            </div>
            <div class="warn-form-group">
                <label class="warn-field-label">Kapanış Gerekçesi</label>
                <textarea id="closeReasonInput" class="warn-textarea" placeholder="Biletin kapatılma nedenini veya çözüm özetini yazın..." rows="3">Sorun çözüldü ve işlem tamamlandı.</textarea>
            </div>
            <div class="warn-options-group">
                <label class="checkbox-container">
                    <input type="checkbox" id="closeSendDmCheck" checked>
                    <span>Kullanıcıya Discord DM bilgilendirmesi ilet</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" id="closeLogChannelCheck" checked>
                    <span>#ticket-log kanalına transkript dökümünü düş</span>
                </label>
            </div>
            <div class="warn-modal-actions">
                <button type="button" class="btn-warn-cancel" onclick="closeCloseTicketModal()">Vazgeç</button>
                <button type="button" id="submitCloseBtn" class="btn-warn-submit" onclick="submitCloseTicket()" style="background:#ef4444; color:#fff;">
                    {SVG_LOCK}
                    <span>Bileti Kapat ve Kilitle</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Kullanıcı Destek Geçmişi & Sicil Modalı -->
    <div class="warn-modal-overlay" id="userHistoryModal" onclick="if(event.target===this) closeUserHistoryModal()">
        <div class="warn-modal-card" style="max-width: 620px !important;">
            <div class="warn-modal-header">
                <div class="warn-title-group">
                    <div class="warn-icon-box" style="background:rgba(99,102,241,0.15); border-color:rgba(99,102,241,0.35); color:#818cf8;">{SVG_HISTORY}</div>
                    <div>
                        <h2 class="warn-modal-title" id="historyModalTitle">Kullanıcı Sicil &amp; Destek Geçmişi</h2>
                        <p class="warn-modal-desc">Kullanıcının sunucudaki önceki destek talepleri ve uyarı geçmişi.</p>
                    </div>
                </div>
                <button class="modal-close-btn" onclick="closeUserHistoryModal()" type="button">{SVG_CLOSE}</button>
            </div>
            <div class="history-modal-body" id="historyModalBody">
                <div style="text-align:center; padding:30px; color:var(--text-muted);">Yükleniyor...</div>
            </div>
        </div>
    </div>

    </div><!-- /main-wrapper -->

    <!-- Lightbox Modal -->
    <div id="lightboxModal" class="lightbox-modal" onclick="closeLightbox(event)">
        <div class="lightbox-content" onclick="event.stopPropagation()">
            <button class="lightbox-close" onclick="closeLightbox(event)" type="button">{SVG_CLOSE}</button>
            <img id="lightboxImg" class="lightbox-img" src="" alt="Büyütülmüş Görsel">
        </div>
    </div>

        <!-- Kullanıcı İhtar & Uyarı Modalı -->
    <div class="warn-modal-overlay" id="warnModal" onclick="if(event.target===this) closeWarnModal()">
        <div class="warn-modal-card" style="max-width: 540px !important;">
            <div class="warn-modal-header">
                <div class="warn-title-group">
                    <div class="warn-icon-box">{SVG_SHIELD_ALERT}</div>
                    <div>
                        <h2 class="warn-modal-title">Kullanıcı İhtar & Uyarı Paneli</h2>
                        <p class="warn-modal-desc">Discord üzerinden üyeye resmi yetkili uyarısı ve DM bildirimi iletir.</p>
                    </div>
                </div>
                <button class="modal-close-btn" onclick="closeWarnModal()" type="button">{SVG_CLOSE}</button>
            </div>

            <div class="warn-target-box">
                <div class="target-label">Hedef Kullanıcı</div>
                <div class="target-info-row">
                    <span class="target-name">@{owner_name}</span>
                    <span class="target-id">ID: {owner_id}</span>
                    <span class="target-ticket">Bilet: {ticket_id}</span>
                </div>
            </div>

            <div class="warn-form-group">
                <label class="warn-field-label">Uyarı Türü</label>
                <div class="warn-type-grid">
                    <button type="button" class="warn-type-btn active" onclick="selectWarnType(this, 'Kural İhlali')">Kural İhlali</button>
                    <button type="button" class="warn-type-btn" onclick="selectWarnType(this, 'Yetkiliye Saygısızlık')">Yetkiliye Saygısızlık</button>
                    <button type="button" class="warn-type-btn" onclick="selectWarnType(this, 'Gereksiz / Troll Bilet')">Gereksiz / Troll Bilet</button>
                    <button type="button" class="warn-type-btn" onclick="selectWarnType(this, 'Spam / Flood')">Spam / Flood</button>
                    <button type="button" class="warn-type-btn danger" onclick="selectWarnType(this, 'Son Uyarı')">Son Uyarı</button>
                </div>
                <input type="hidden" id="selectedWarnType" value="Kural İhlali">
            </div>

            <div class="warn-form-group">
                <label for="warnReasonInput" class="warn-field-label">Uyarı Gerekçesi</label>
                <textarea id="warnReasonInput" class="warn-textarea" placeholder="Kullanıcıya iletilecek uyarı nedenini yazın..." rows="3"></textarea>
            </div>

            <div class="warn-options-group">
                <label class="checkbox-container">
                    <input type="checkbox" id="warnSendDmCheck" checked>
                    <span>Kullanıcıya Discord DM bildirimi gönder</span>
                </label>
                <label class="checkbox-container">
                    <input type="checkbox" id="warnLogChannelCheck" checked>
                    <span>#ticket-log kanalına kayıt düş</span>
                </label>
            </div>

            <div class="warn-modal-actions">
                <button type="button" class="btn-warn-cancel" onclick="closeWarnModal()">Vazgeç</button>
                <button type="button" id="submitWarnBtn" class="btn-warn-submit" onclick="submitUserWarning()">
                    {SVG_ALERT_TRIANGLE}
                    <span>Uyarıyı Gönder</span>
                </button>
            </div>
        </div>
    </div>

    
    <div class="floating-nav-hud">
        <button class="nav-hud-btn" onclick="scrollToTop()" type="button" title="En Üste Çık">{SVG_ARROW_UP}</button>
        <button class="nav-hud-btn" onclick="focusLiveChat()" type="button" title="Canlı İletişim Konsoluna Git">{SVG_TERMINAL}</button>
        <button class="nav-hud-btn" onclick="scrollToBottom()" type="button" title="En Alta İn">{SVG_ARROW_DOWN}</button>
    </div>

        <!-- Medya Galerisi Çekmecesi -->
    <div class="media-drawer-overlay" id="mediaDrawerOverlay" onclick="toggleMediaDrawer()"></div>
    <aside class="media-drawer" id="mediaDrawer">
        <div class="drawer-header">
            <div class="drawer-title-row">
                {SVG_FILE}
                <span>Ek Dosyalar &amp; Görseller ({total_attachments})</span>
            </div>
            <button class="drawer-close-btn" onclick="toggleMediaDrawer()" type="button">{SVG_CLOSE}</button>
        </div>
        <div class="drawer-body">
            {media_drawer_html}
        </div>
    </aside>

    <!-- Kullanıcı Profil Kartı Popover -->
    <div class="user-profile-popover" id="userProfilePopover">
        <div class="popover-header">
            <img src="" id="popoverAvatar" class="popover-avatar" alt="Avatar">
            <div class="popover-names">
                <span id="popoverName" class="popover-display">Kullanıcı</span>
                <div class="popover-id-row">
                    <span id="popoverId">ID</span>
                    <span class="popover-copy-id" onclick="copyPopoverId()">Kopyala</span>
                </div>
            </div>
        </div>
        <div class="popover-actions">
            <button type="button" class="popover-btn" onclick="filterByPopoverUser()">
                {SVG_USER}
                <span>Sadece Bu Kullanıcıyı Göster</span>
            </button>
                        <button type="button" class="popover-btn" onclick="openUserHistoryModal()">
                {SVG_HISTORY}
                <span>Destek Geçmişi &amp; Sicil</span>
            </button>
            <button type="button" class="popover-btn danger" onclick="warnPopoverUser()">
                {SVG_ALERT_TRIANGLE}
                <span>Bu Kullanıcıyı Uyar</span>
            </button>
        </div>
    </div>

    <!-- Bildirim Toast Alanı -->
    <div class="toast-container" id="toastContainer"></div>

    <script>

        window.TRANSCRIPT_DATA = {{
            slug_id: '{slug_id}',
            owner_id: '{owner_id}',
            owner_name: '{html.escape(str(owner_name))}',
            channel_id: '{channel.id if channel else ""}',
            channel_name: '{html.escape(clean_ch_name)}',
            ticket_id: '{ticket_id}',
            is_active: {str(is_channel_active).lower()}
        }};

        // ─── SES EFEKTLERİ MOTORU (WEB AUDIO API SYNTHESIZER) ───
        let audioCtx = null;
        let soundFxEnabled = true;

        function playSynthSound(type) {{
            if (!soundFxEnabled) return;
            try {{
                if (!audioCtx) {{
                    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                }}
                if (audioCtx.state === 'suspended') {{
                    audioCtx.resume();
                }}
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                const now = audioCtx.currentTime;

                if (type === 'click') {{
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(800, now);
                    osc.frequency.exponentialRampToValueAtTime(400, now + 0.05);
                    gain.gain.setValueAtTime(0.04, now);
                    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
                    osc.start(now);
                    osc.stop(now + 0.05);
                }} else if (type === 'sent') {{
                    osc.type = 'triangle';
                    osc.frequency.setValueAtTime(520, now);
                    osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
                    gain.gain.setValueAtTime(0.08, now);
                    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
                    osc.start(now);
                    osc.stop(now + 0.12);
                }} else if (type === 'warn') {{
                    osc.type = 'sawtooth';
                    osc.frequency.setValueAtTime(260, now);
                    osc.frequency.exponentialRampToValueAtTime(140, now + 0.2);
                    gain.gain.setValueAtTime(0.06, now);
                    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
                    osc.start(now);
                    osc.stop(now + 0.2);
                }} else if (type === 'receive') {{
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(440, now);
                    osc.frequency.exponentialRampToValueAtTime(880, now + 0.1);
                    gain.gain.setValueAtTime(0.06, now);
                    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
                    osc.start(now);
                    osc.stop(now + 0.1);
                }}
            }} catch(e) {{}}
        }}

        // ─── OKUMA İLERLEME ÇUBUĞU (SCROLL PROGRESS) ───
        window.addEventListener('scroll', () => {{
            const bar = document.getElementById('scrollProgressLine');
            if (!bar) return;
            const winScroll = document.documentElement.scrollTop || document.body.scrollTop;
            const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = height > 0 ? (winScroll / height) * 100 : 0;
            bar.style.width = scrolled + '%';
        }});

        // ─── HIZLI KAYDIRMA FONKSİYONLARI ───
        function scrollToTop() {{
            playSynthSound('click');
            window.scrollTo({{ top: 0, behavior: 'smooth' }});
        }}
        function scrollToBottom() {{
            playSynthSound('click');
            window.scrollTo({{ top: document.body.scrollHeight, behavior: 'smooth' }});
        }}

        // ─── MARKDOWN YARDIMCILARI ───
        function wrapText(before, after) {{
            playSynthSound('click');
            const input = document.getElementById('liveChatInput');
            if (!input) return;
            const start = input.selectionStart || 0;
            const end = input.selectionEnd || 0;
            const val = input.value;
            const selected = val.substring(start, end) || 'metin';
            input.value = val.substring(0, start) + before + selected + after + val.substring(end);
            input.focus();
            input.setSelectionRange(start + before.length, start + before.length + selected.length);
            updateCharCounter();
        }}

        // ─── KARAKTER VE SATIR SAYACI ───
        function updateCharCounter() {{
            const input = document.getElementById('liveChatInput');
            const label = document.getElementById('charCountLabel');
            if (!input || !label) return;
            const len = input.value.length;
            const lines = input.value.split(String.fromCharCode(10)).length;
            label.innerText = len + ' / 2000 karakter • ' + lines + ' satır';
            if (len > 1900) {{
                label.style.color = '#ef4444';
            }} else {{
                label.style.color = '';
            }}
        }}

        // ─── UYARI MODALI CANLI DM ÖNİZLEME MOTORU ───
        function updateDmPreview() {{
            const reasonInput = document.getElementById('warnReasonInput');
            const typeInput = document.getElementById('selectedWarnType');
            const previewReason = document.getElementById('previewReasonText');
            const previewType = document.getElementById('previewWarnType');

            if (previewType && typeInput) {{
                previewType.innerText = typeInput.value || 'Kural İhlali';
            }}
            if (previewReason) {{
                const text = reasonInput ? reasonInput.value.trim() : '';
                if (text) {{
                    previewReason.innerText = text;
                    previewReason.style.color = '#fff';
                }} else {{
                    previewReason.innerText = 'Lütfen gerekçe belirtiniz...';
                    previewReason.style.color = '#f87171';
                }}
            }}
        }}

        // ─── VERİ DIŞA AKTARMA (JSON & TXT EXPORT) ───
        function exportTranscriptJson() {{
            playSynthSound('click');
            const d = window.TRANSCRIPT_DATA || {{}};
            const cards = document.querySelectorAll('#msgStream .msg-card');
            const msgs = [];
            cards.forEach(c => {{
                const author = c.querySelector('.msg-author') ? c.querySelector('.msg-author').innerText.trim() : '';
                const time = c.querySelector('.msg-time') ? c.querySelector('.msg-time').innerText.trim() : '';
                const text = c.querySelector('.msg-text') ? c.querySelector('.msg-text').innerText.trim() : '';
                msgs.push({{ author, time, text }});
            }});
            const exportData = {{
                metadata: d,
                total_messages: msgs.length,
                exported_at: new Date().toISOString(),
                messages: msgs
            }};
            const blob = new Blob([JSON.stringify(exportData, null, 2)], {{ type: 'application/json' }});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = (d.slug_id || 'transkript') + '.json';
            a.click();
            URL.revokeObjectURL(url);
            showToast('JSON formatında konuşma dökümü indirildi.', 'success');
        }}

        function exportTranscriptTxt() {{
            playSynthSound('click');
            const d = window.TRANSCRIPT_DATA || {{}};
            let txt = '========================================' + String.fromCharCode(10);
            txt += '  IMZA DESTEK SISTEMI - TICKET DOKUMU' + String.fromCharCode(10);
            txt += '========================================' + String.fromCharCode(10);
            txt += 'Kanal: #' + (d.channel_name || '') + String.fromCharCode(10);
            txt += 'Bilet No: ' + (d.ticket_id || '') + String.fromCharCode(10);
            txt += 'Talep Sahibi: ' + (d.owner_name || '') + ' (' + (d.owner_id || '') + ')' + String.fromCharCode(10);
            txt += 'Dışa Aktarma Tarihi: ' + new Date().toLocaleString('tr-TR') + String.fromCharCode(10);
            txt += '========================================' + String.fromCharCode(10) + String.fromCharCode(10);

            const cards = document.querySelectorAll('#msgStream .msg-card');
            cards.forEach(c => {{
                const author = c.querySelector('.msg-author') ? c.querySelector('.msg-author').innerText.trim() : '';
                const time = c.querySelector('.msg-time') ? c.querySelector('.msg-time').innerText.trim() : '';
                const text = c.querySelector('.msg-text') ? c.querySelector('.msg-text').innerText.trim() : '';
                txt += '[' + time + '] ' + author + ':' + String.fromCharCode(10) + text + String.fromCharCode(10) + String.fromCharCode(10);
            }});

            const blob = new Blob([txt], {{ type: 'text/plain;charset=utf-8' }});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = (d.slug_id || 'transkript') + '.txt';
            a.click();
            URL.revokeObjectURL(url);
            showToast('Metin (TXT) konuşma dökümü indirildi.', 'success');
        }}

        // Bildirim Toast Motoru
        function showToast(message, type = 'success') {{
            const container = document.getElementById('toastContainer');
            if (!container) return;
            const toast = document.createElement('div');
            toast.className = 'custom-toast ' + type;
            let icon = '';
            if (type === 'success') icon = '{SVG_CHECK_CIRCLE}';
            else if (type === 'error') icon = '{SVG_ALERT_TRIANGLE}';
            else icon = '{SVG_TERMINAL}';
            toast.innerHTML = icon + '<span>' + message + '</span>';
            container.appendChild(toast);
            setTimeout(() => {{
                toast.classList.add('fade-out');
                setTimeout(() => toast.remove(), 300);
            }}, 3800);
        }}

        // Canlı chat kutusuna odaklan
        function focusLiveChat() {{
            const dock = document.getElementById('staffLiveDock');
            const input = document.getElementById('liveChatInput');
            if (dock && input) {{
                dock.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
                input.focus();
            }}
        }}

        // Hazır şablon yapıştırma
        function insertTemplate(text) {{
            const input = document.getElementById('liveChatInput');
            if (input) {{
                input.value = text;
                input.focus();
                showToast('Şablon mesaja eklendi.', 'info');
            }}
        }}

        // Oturumu kapat
        async function logoutStaff() {{
            try {{
                await fetch('/api/staff/logout', {{ method: 'POST', credentials: 'include' }});
            }} catch (e) {{}}
            showToast('Oturum kapatıldı, giriş kapısına yönlendiriliyorsunuz...', 'info');
            setTimeout(() => {{
                window.location.href = window.location.pathname;
            }}, 600);
        }}

        // Discord Bilet Kanalına Canlı Mesaj Gönderme
        async function sendLiveTicketMessage() {{
            const input = document.getElementById('liveChatInput');
            const btn = document.getElementById('sendLiveMsgBtn');
            const text = input ? input.value.trim() : '';

            if (!text) {{
                showToast('Lütfen gönderilecek bir mesaj yazın.', 'error');
                if (input) input.focus();
                return;
            }}

            if (btn) {{
                btn.disabled = true;
                btn.innerHTML = '{SVG_SEND}<span>İletiliyor...</span>';
            }}

            try {{
                const res = await fetch('/api/ticket/send-message', {{
                    method: 'POST',
                    credentials: 'include',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{
                        transcript_id: window.TRANSCRIPT_DATA.slug_id,
                        message: text
                    }})
                }});
                const result = await res.json();

                if (result.success) {{
                    playSynthSound('sent');
                    showToast(result.message || 'Mesaj Discord bilet kanalına iletildi!', 'success');
                    if (input) input.value = '';

                    // Mesaj akışına anlık yetkili kartı olarak ekle
                    const stream = document.getElementById('msgStream');
                    if (stream) {{
                        const d = result.data || {{}};
                        const safeMsg = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').split(String.fromCharCode(10)).join('<br>');
                        const msgCard = document.createElement('div');
                        msgCard.className = 'msg-card web-staff-msg';
                        msgCard.dataset.author = (d.author || 'Yetkili').toLowerCase();
                        msgCard.innerHTML = `
                            <div class="msg-avatar-col">
                                <img src="${{d.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png'}}" class="msg-avatar" alt="${{d.author || 'Yetkili'}}">
                            </div>
                            <div class="msg-main-col">
                                <div class="msg-header-row">
                                    <span class="author-name staff-name">${{d.author || 'Yetkili'}}</span>
                                    <span class="badge-web-staff">YETKİLİ WEB MESAJI</span>
                                    <span class="msg-timestamp">${{d.timestamp || 'Şimdi'}}</span>
                                </div>
                                <div class="msg-body">
                                    <div class="msg-text">${{safeMsg}}</div>
                                </div>
                            </div>
                        `;
                        stream.appendChild(msgCard);
                        msgCard.scrollIntoView({{ behavior: 'smooth', block: 'end' }});
                    }}
                }} else {{
                    showToast(result.message || 'Mesaj gönderilemedi.', 'error');
                }}
            }} catch (err) {{
                showToast('Sunucu bağlantı hatası: ' + err.message, 'error');
            }} finally {{
                if (btn) {{
                    btn.disabled = false;
                    btn.innerHTML = '{SVG_SEND}<span>Bilete Gönder</span>';
                }}
            }}
        }}

        // Kullanıcı Uyarı Modalı Fonksiyonları
        function openWarnModal() {{
            playSynthSound('warn');
            const modal = document.getElementById('warnModal');
            if (modal) {{
                modal.classList.add('active');
                updateDmPreview();
                const reasonInput = document.getElementById('warnReasonInput');
                if (reasonInput) reasonInput.focus();
            }}
        }}

        function closeWarnModal() {{
            const modal = document.getElementById('warnModal');
            if (modal) modal.classList.remove('active');
        }}

        function selectWarnType(btn, type) {{
            playSynthSound('click');
            document.querySelectorAll('.warn-type-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const hidden = document.getElementById('selectedWarnType');
            if (hidden) hidden.value = type;
            updateDmPreview();
        }}

        async function submitUserWarning() {{
            const reasonInput = document.getElementById('warnReasonInput');
            const typeInput = document.getElementById('selectedWarnType');
            const sendDmCheck = document.getElementById('warnSendDmCheck');
            const logChannelCheck = document.getElementById('warnLogChannelCheck');
            const submitBtn = document.getElementById('submitWarnBtn');

            const reason = reasonInput ? reasonInput.value.trim() : '';
            const warnType = typeInput ? typeInput.value : 'Kural İhlali';
            const sendDm = sendDmCheck ? sendDmCheck.checked : true;
            const logChannel = logChannelCheck ? logChannelCheck.checked : true;

            if (!reason) {{
                showToast('Lütfen uyarı gerekçesini belirtin.', 'error');
                if (reasonInput) reasonInput.focus();
                return;
            }}

            if (submitBtn) {{
                submitBtn.disabled = true;
                submitBtn.innerHTML = '{SVG_ALERT_TRIANGLE}<span>Uyarı İletiliyor...</span>';
            }}

            try {{
                const res = await fetch('/api/ticket/warn-user', {{
                    method: 'POST',
                    credentials: 'include',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{
                        transcript_id: window.TRANSCRIPT_DATA.slug_id,
                        warn_type: warnType,
                        reason: reason,
                        send_dm: sendDm,
                        log_channel: logChannel
                    }})
                }});
                const result = await res.json();

                if (result.success) {{
                    closeWarnModal();
                    showToast(result.message || 'Kullanıcı başarıyla uyarıldı!', 'success');
                    if (reasonInput) reasonInput.value = '';

                    // Mesaj akışına uyarı kartı ekle
                    const stream = document.getElementById('msgStream');
                    if (stream) {{
                        const banner = document.createElement('div');
                        banner.className = 'warn-event-banner';
                        banner.innerHTML = `
                            <div class="warn-banner-icon">{SVG_SHIELD_ALERT}</div>
                            <div>
                                <div class="warn-banner-title">Yetkili Uyarısı Verildi: ${{warnType}}</div>
                                <div class="warn-banner-desc">Gerekçe: ${{reason}} (Uyaran: Yetkili Web Portalı)</div>
                            </div>
                        `;
                        stream.appendChild(banner);
                        banner.scrollIntoView({{ behavior: 'smooth', block: 'end' }});
                    }}
                }} else {{
                    showToast(result.message || 'Uyarı işlemi başarısız!', 'error');
                }}
            }} catch (err) {{
                showToast('Bağlantı hatası: ' + err.message, 'error');
            }} finally {{
                if (submitBtn) {{
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '{SVG_ALERT_TRIANGLE}<span>Uyarıyı Gönder ve Kaydet</span>';
                }}
            }}
        }}

        // Transkript Bağlantısını Kopyala
        function copySiteLink(btn) {{
            const url = window.location.href.split('#')[0];
            navigator.clipboard.writeText(url).then(() => {{
                showToast('Transkript bağlantısı panoya kopyalandı!', 'success');
                if (btn) {{
                    const origHtml = btn.innerHTML;
                    btn.innerHTML = '{SVG_CHECK}<span>Kopyalandı!</span>';
                    btn.style.borderColor = '#10b981';
                    btn.style.color = '#10b981';
                    setTimeout(() => {{
                        btn.innerHTML = origHtml;
                        btn.style.borderColor = '';
                        btn.style.color = '';
                    }}, 2000);
                }}
            }}).catch(() => {{
                showToast('Bağlantı kopyalanamadı.', 'error');
            }});
        }}

        // Ctrl + Enter ile mesaj gönderme
        document.addEventListener('keydown', (e) => {{
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {{
                const input = document.getElementById('liveChatInput');
                if (document.activeElement === input) {{
                    e.preventDefault();
                    sendLiveTicketMessage();
                }}
            }}
        }});

        let currentAuthor = 'all';
        let searchQuery = '';

        // Keyboard Shortcut Ctrl+K
        document.addEventListener('keydown', (e) => {{
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {{
                e.preventDefault();
                document.getElementById('searchInput').focus();
            }}
            if (e.key === 'Escape') {{
                closeLightbox();
            }}
        }});

        function onSearchInput() {{
            const input = document.getElementById('searchInput');
            searchQuery = input.value.trim().toLowerCase();
            const clearBtn = document.getElementById('searchClearBtn');
            const shortcutHint = document.getElementById('searchShortcut');
            
            if (searchQuery.length > 0) {{
                clearBtn.style.display = 'flex';
                shortcutHint.style.display = 'none';
            }} else {{
                clearBtn.style.display = 'none';
                shortcutHint.style.display = 'block';
            }}
            applyFilters();
        }}

        function clearSearch() {{
            const input = document.getElementById('searchInput');
            input.value = '';
            searchQuery = '';
            document.getElementById('searchClearBtn').style.display = 'none';
            document.getElementById('searchShortcut').style.display = 'block';
            applyFilters();
            input.focus();
        }}

        function onAuthorSelect() {{
            const select = document.getElementById('authorSelect');
            currentAuthor = select.value.toLowerCase();
            syncParticipantChips(currentAuthor);
            applyFilters();
        }}

        function setFilterAuthor(author, btnEl) {{
            currentAuthor = author.toLowerCase();
            document.getElementById('authorSelect').value = currentAuthor;
            syncParticipantChips(currentAuthor);
            applyFilters();
        }}

        function syncParticipantChips(activeAuthor) {{
            const chips = document.querySelectorAll('.p-chip');
            chips.forEach(chip => {{
                chip.classList.remove('active');
            }});
            if (activeAuthor === 'all') {{
                chips[0]?.classList.add('active');
            }} else {{
                chips.forEach(chip => {{
                    const onclickAttr = chip.getAttribute('onclick') || '';
                    if (onclickAttr.includes(`'${{activeAuthor}}'`)) {{
                        chip.classList.add('active');
                    }}
                }});
            }}
        }}

        function applyFilters() {{
            const cards = document.querySelectorAll('.msg-card');
            let visibleCount = 0;

            cards.forEach(card => {{
                const author = (card.getAttribute('data-author') || '').toLowerCase();
                const content = (card.getAttribute('data-content') || '').toLowerCase();
                
                const matchesAuthor = (currentAuthor === 'all') || (author === currentAuthor);
                const matchesSearch = !searchQuery || author.includes(searchQuery) || content.includes(searchQuery);

                if (matchesAuthor && matchesSearch) {{
                    card.style.display = 'flex';
                    visibleCount++;
                }} else {{
                    card.style.display = 'none';
                }}
            }});

            const counter = document.getElementById('matchCounter');
            if (counter) {{
                if (searchQuery || currentAuthor !== 'all') {{
                    counter.innerText = `${{visibleCount}} / ${{cards.length}} mesaj eşleşti`;
                }} else {{
                    counter.innerText = `Toplam ${{cards.length}} mesaj`;
                }}
            }}
        }}

        function copyCode(btn) {{
            const pre = btn.closest('.code-container').querySelector('code');
            if (!pre) return;
            navigator.clipboard.writeText(pre.innerText).then(() => {{
                const span = btn.querySelector('span');
                const orig = span ? span.innerText : 'Kopyala';
                if (span) span.innerText = 'Kopyalandı!';
                btn.style.color = '#34d399';
                setTimeout(() => {{
                    if (span) span.innerText = orig;
                    btn.style.color = '';
                }}, 2000);
            }});
        }}

        
        // ─── MEDYA GALERİSİ ÇEKMECESİ ───
        function toggleMediaDrawer() {{
            const drawer = document.getElementById('mediaDrawer');
            const overlay = document.getElementById('mediaDrawerOverlay');
            if (drawer && overlay) {{
                drawer.classList.toggle('active');
                overlay.classList.toggle('active');
            }}
        }}

        function jumpToMessage(msgId) {{
            toggleMediaDrawer();
            const el = document.getElementById('msg-' + msgId);
            if (el) {{
                el.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
                el.classList.add('highlighted');
                setTimeout(() => el.classList.remove('highlighted'), 2000);
            }} else {{
                showToast('İlgili mesaj akışta bulunamadı.', 'info');
            }}
        }}

        // ─── KULLANICI PROFİL POPOVER ───
        let activePopoverUser = {{ id: '', name: '', avatar: '' }};
        function showUserPopover(e, userId, userName, avatarUrl) {{
            e.stopPropagation();
            activePopoverUser = {{ id: userId, name: userName, avatar: avatarUrl }};
            const popover = document.getElementById('userProfilePopover');
            if (!popover) return;
            const avatarEl = document.getElementById('popoverAvatar');
            const nameEl = document.getElementById('popoverName');
            const idEl = document.getElementById('popoverId');
            if (avatarEl) avatarEl.src = avatarUrl || 'https://cdn.discordapp.com/embed/avatars/0.png';
            if (nameEl) nameEl.innerText = userName || 'Kullanıcı';
            if (idEl) idEl.innerText = userId || '';

            const rect = e.target.getBoundingClientRect();
            popover.style.top = (rect.bottom + window.scrollY + 6) + 'px';
            popover.style.left = Math.min(window.innerWidth - 300, Math.max(10, rect.left)) + 'px';
            popover.classList.add('active');
        }}

        function copyPopoverId() {{
            if (activePopoverUser.id) {{
                navigator.clipboard.writeText(activePopoverUser.id).then(() => {{
                    showToast('Discord ID (' + activePopoverUser.id + ') panoya kopyalandı.', 'success');
                }});
            }}
        }}

        function filterByPopoverUser() {{
            const popover = document.getElementById('userProfilePopover');
            if (popover) popover.classList.remove('active');
            if (activePopoverUser.name) {{
                const chips = Array.from(document.querySelectorAll('.p-chip'));
                const chip = chips.find(c => c.getAttribute('onclick') && c.getAttribute('onclick').toLowerCase().includes(activePopoverUser.name.toLowerCase()));
                if (chip) {{
                    setFilterAuthor(activePopoverUser.name.toLowerCase(), chip);
                }} else {{
                    const authorSelect = document.getElementById('authorSelect');
                    if (authorSelect) {{
                        authorSelect.value = activePopoverUser.name.toLowerCase();
                        onAuthorSelect();
                    }}
                }}
            }}
        }}

        function warnPopoverUser() {{
            const popover = document.getElementById('userProfilePopover');
            if (popover) popover.classList.remove('active');
            openWarnModal();
            // Hedef bilgileri güncelle
            const targetName = document.querySelector('.target-name');
            const targetId = document.querySelector('.target-id');
            if (targetName && activePopoverUser.name) targetName.innerText = '@' + activePopoverUser.name;
            if (targetId && activePopoverUser.id) targetId.innerText = 'ID: ' + activePopoverUser.id;
        }}

        document.addEventListener('click', (e) => {{
            const popover = document.getElementById('userProfilePopover');
            if (popover && popover.classList.contains('active') && !popover.contains(e.target)) {{
                popover.classList.remove('active');
            }}
        }});

        // ─── MESAJ HOVER İŞLEMLERİ (ALINTILA & KOPYALA) ───
        function quoteMessage(btn) {{
            const card = btn.closest('.msg-card');
            if (!card) return;
            const author = card.querySelector('.msg-author') ? card.querySelector('.msg-author').innerText.trim() : 'Kullanıcı';
            const textEl = card.querySelector('.msg-text');
            const text = textEl ? textEl.innerText.trim() : '';
            if (!text) return;
            const input = document.getElementById('liveChatInput');
            if (input) {{
                const quoteText = '> **' + author + '**: ' + text.split(String.fromCharCode(10)).join(' ') + String.fromCharCode(10) + String.fromCharCode(10);
                input.value = quoteText + input.value;
                focusLiveChat();
                showToast('Mesaj alıntılandı.', 'info');
            }}
        }}

        function copyMessageText(btn) {{
            const card = btn.closest('.msg-card');
            if (!card) return;
            const textEl = card.querySelector('.msg-text');
            const text = textEl ? textEl.innerText.trim() : '';
            if (!text) return;
            navigator.clipboard.writeText(text).then(() => {{
                showToast('Mesaj metni panoya kopyalandı.', 'success');
            }}).catch(() => {{
                showToast('Mesaj kopyalanamadı.', 'error');
            }});
        }}

        // ─── DAHİLİ YETKİLİ NOTU SİSTEMİ ───
        let currentConsoleMode = 'message';
        function setConsoleMode(mode) {{
            currentConsoleMode = mode;
            const tabMsg = document.getElementById('tabLiveMsg');
            const tabNote = document.getElementById('tabStaffNote');
            const dock = document.getElementById('staffLiveDock');
            const input = document.getElementById('liveChatInput');
            const btn = document.getElementById('sendLiveMsgBtn');

            if (mode === 'note') {{
                if (tabMsg) tabMsg.classList.remove('active');
                if (tabNote) tabNote.classList.add('active');
                if (dock) dock.classList.add('note-active');
                if (input) input.placeholder = 'Yetkililere özel dahili not yazın... (Kullanıcıya gitmez, arşive kalıcı işlenir)';
                if (btn) {{
                    btn.className = 'btn-console-send note-btn';
                    btn.innerHTML = '{SVG_SHIELD}<span>Dahili Notu Kaydet</span>';
                }}
            }} else {{
                if (tabNote) tabNote.classList.remove('active');
                if (tabMsg) tabMsg.classList.add('active');
                if (dock) dock.classList.remove('note-active');
                if (input) input.placeholder = 'Bilete Discord üzerinden canlı mesaj yazın... (Ctrl + Enter ile hızlı gönder)';
                if (btn) {{
                    btn.className = 'btn-console-send';
                    btn.innerHTML = '{SVG_SEND}<span>Bilete Gönder</span>';
                }}
            }}
        }}

        async function dispatchLiveAction() {{
            if (currentConsoleMode === 'note') {{
                await sendStaffInternalNote();
            }} else {{
                await sendLiveTicketMessage();
            }}
        }}

        async function sendStaffInternalNote() {{
            const input = document.getElementById('liveChatInput');
            const btn = document.getElementById('sendLiveMsgBtn');
            const text = input ? input.value.trim() : '';

            if (!text) {{
                showToast('Lütfen kaydedilecek bir not yazın.', 'error');
                if (input) input.focus();
                return;
            }}

            if (btn) {{
                btn.disabled = true;
                btn.innerHTML = '{SVG_SHIELD}<span>Kaydediliyor...</span>';
            }}

            try {{
                const res = await fetch('/api/ticket/add-note', {{
                    method: 'POST',
                    credentials: 'include',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{
                        transcript_id: window.TRANSCRIPT_DATA.slug_id,
                        note: text
                    }})
                }});
                const result = await res.json();

                if (result.success) {{
                    showToast('Yetkili dahili notu kaydedildi!', 'success');
                    if (input) input.value = '';

                    const stream = document.getElementById('msgStream');
                    if (stream) {{
                        const d = result.data || {{}};
                        const safeMsg = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').split(String.fromCharCode(10)).join('<br>');
                        const noteCard = document.createElement('div');
                        noteCard.className = 'msg-card internal-note-card';
                        noteCard.innerHTML = `
                            <div class="msg-avatar-wrap">
                                <img class="msg-avatar" src="${{d.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png'}}" alt="${{d.author || 'Yetkili'}}">
                            </div>
                            <div class="msg-body">
                                <div class="msg-meta">
                                    <span class="msg-author" style="color:#fbbf24;">${{d.author || 'Yetkili'}}</span>
                                    <span class="badge-internal-note">DAHİLİ YETKİLİ NOTU</span>
                                    <span class="msg-time">${{d.timestamp || 'Şimdi'}}</span>
                                </div>
                                <div class="msg-text">${{safeMsg}}</div>
                            </div>
                        `;
                        stream.appendChild(noteCard);
                        noteCard.scrollIntoView({{ behavior: 'smooth', block: 'end' }});
                    }}
                }} else {{
                    showToast(result.message || 'Not kaydedilemedi.', 'error');
                }}
            }} catch (err) {{
                showToast('Bağlantı hatası: ' + err.message, 'error');
            }} finally {{
                if (btn) {{
                    btn.disabled = false;
                    btn.innerHTML = '{SVG_SHIELD}<span>Dahili Notu Kaydet</span>';
                }}
            }}
        }}

        
        // ─── DIŞA AKTAR MENÜSÜ & YAZDIRMA ───
        function toggleExportMenu(e) {{
            e.stopPropagation();
            const menu = document.getElementById('exportMenu');
            if (menu) menu.classList.toggle('active');
        }}

        function printTranscript() {{
            const menu = document.getElementById('exportMenu');
            if (menu) menu.classList.remove('active');
            window.print();
        }}

        document.addEventListener('click', (e) => {{
            const menu = document.getElementById('exportMenu');
            if (menu && menu.classList.contains('active') && !menu.contains(e.target)) {{
                menu.classList.remove('active');
            }}
        }});

        // ─── BİLETİ WEB ÜZERİNDEN KAPATMA ───
        function openCloseTicketModal() {{
            const modal = document.getElementById('closeTicketModal');
            if (modal) modal.classList.add('active');
        }}

        function closeCloseTicketModal() {{
            const modal = document.getElementById('closeTicketModal');
            if (modal) modal.classList.remove('active');
        }}

        async function submitCloseTicket() {{
            const reasonInput = document.getElementById('closeReasonInput');
            const sendDm = document.getElementById('closeSendDmCheck')?.checked ?? true;
            const logChannel = document.getElementById('closeLogChannelCheck')?.checked ?? true;
            const btn = document.getElementById('submitCloseBtn');
            const reason = reasonInput ? reasonInput.value.trim() : '';

            if (!reason) {{
                showToast('Lütfen bir kapanış gerekçesi belirtin.', 'error');
                return;
            }}

            if (btn) {{
                btn.disabled = true;
                btn.innerHTML = '{SVG_LOCK}<span>Kapatılıyor...</span>';
            }}

            try {{
                const res = await fetch('/api/ticket/close', {{
                    method: 'POST',
                    credentials: 'include',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{
                        transcript_id: window.TRANSCRIPT_DATA.slug_id,
                        reason: reason,
                        send_dm: sendDm,
                        archive_log: logChannel
                    }})
                }});
                const result = await res.json();
                if (result.success) {{
                    closeCloseTicketModal();
                    showToast(result.message || 'Bilet başarıyla kapatıldı!', 'success');

                    // UI Güncellemesi
                    const closeBtn = document.getElementById('btnActionClose');
                    if (closeBtn) {{
                        closeBtn.disabled = true;
                        closeBtn.innerHTML = '{SVG_LOCK}<span>Kapatıldı</span>';
                        closeBtn.style.opacity = '0.6';
                    }}

                    // Mesaj akışına kapanış kartı ekle
                    const stream = document.getElementById('msgStream');
                    if (stream) {{
                        const banner = document.createElement('div');
                        banner.className = 'warn-event-banner';
                        banner.style.borderColor = 'rgba(239, 68, 68, 0.4)';
                        banner.innerHTML = `
                            <div class="warn-banner-icon">{SVG_LOCK}</div>
                            <div>
                                <div class="warn-banner-title">Talep Web Portalı Üzerinden Sonlandırıldı</div>
                                <div class="warn-banner-desc">Gerekçe: ${{reason}} (Kapatan: ${{result.closed_by || 'Yetkili'}})</div>
                            </div>
                        `;
                        stream.appendChild(banner);
                        banner.scrollIntoView({{ behavior: 'smooth', block: 'end' }});
                    }}
                }} else {{
                    showToast(result.message || 'Bilet kapatılamadı.', 'error');
                }}
            }} catch (err) {{
                showToast('Sunucu bağlantı hatası: ' + err.message, 'error');
            }} finally {{
                if (btn) {{
                    btn.disabled = false;
                    btn.innerHTML = '{SVG_LOCK}<span>Bileti Kapat ve Kilitle</span>';
                }}
            }}
        }}

        // ─── TALEBİ WEB ÜZERİNDEN ÜSTLENME (ANTİ-SPAM KORUMALI) ───
        async function claimTicketWeb() {{
            const btn = document.getElementById('btnActionClaim');
            const lbl = document.getElementById('claimBtnLabel');

            if (btn && (btn.disabled || btn.dataset.claimed === 'true' || btn.classList.contains('claimed-disabled'))) {{
                showToast('Bu bilet zaten bir yetkili tarafından üstlenilmiş! Tekrar üstlenilemez.', 'warning');
                return;
            }}

            if (btn) {{
                btn.disabled = true;
                btn.style.opacity = '0.6';
            }}

            try {{
                const res = await fetch('/api/ticket/claim', {{
                    method: 'POST',
                    credentials: 'include',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{
                        transcript_id: window.TRANSCRIPT_DATA.slug_id
                    }})
                }});
                const result = await res.json();
                if (result.success) {{
                    const staffName = result.claimed_by_name || 'Yetkili';
                    showToast(result.message || ('Talep @' + staffName + ' adına üstlenildi!'), 'success');
                    if (lbl) lbl.innerText = '@' + staffName;
                    if (btn) {{
                        btn.classList.add('claimed-disabled');
                        btn.dataset.claimed = 'true';
                        btn.disabled = true;
                        btn.style.opacity = '0.8';
                        btn.title = 'Bu bilet zaten @' + staffName + ' tarafından üstlenildi';
                    }}

                    // 1. Karşılama embedindeki 'İlgilenen Yetkili' alanını anında güncelle
                    document.querySelectorAll('.embed-field-box').forEach(box => {{
                        const title = box.querySelector('.embed-field-title');
                        const content = box.querySelector('.embed-field-content');
                        if (title && title.innerText.trim() === 'İlgilenen Yetkili' && content) {{
                            content.innerHTML = '<span class="user-pill" style="color:#818cf8; font-weight:700;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px;"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>@' + staffName + '</span>';
                        }}
                    }});

                    // 2. Metrik kartındaki 'İlgilenen Yetkili' alanını anında güncelle
                    document.querySelectorAll('.metric-card').forEach(card => {{
                        const label = card.querySelector('.metric-label');
                        const val = card.querySelector('.metric-value');
                        if (label && label.innerText.trim() === 'İlgilenen Yetkili' && val) {{
                            val.innerHTML = '<span class="user-pill"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px;"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>@' + staffName + '</span>';
                        }}
                    }});
                }} else {{
                    if (result.already_claimed) {{
                        if (btn) {{
                            btn.classList.add('claimed-disabled');
                            btn.dataset.claimed = 'true';
                            btn.disabled = true;
                            btn.style.opacity = '0.8';
                            btn.title = 'Bu bilet zaten @' + (result.claimed_by_name || 'Yetkili') + ' tarafından üstlenildi';
                        }}
                        if (lbl && result.claimed_by_name) {{
                            lbl.innerText = '@' + result.claimed_by_name;
                        }}
                    }} else {{
                        if (btn) {{
                            btn.disabled = false;
                            btn.style.opacity = '';
                        }}
                    }}
                    showToast(result.message || 'Üstlenme işlemi yapılamadı.', 'warning');
                }}
            }} catch (err) {{
                showToast('Bağlantı hatası: ' + err.message, 'error');
                if (btn && btn.dataset.claimed !== 'true') {{
                    btn.disabled = false;
                    btn.style.opacity = '';
                }}
            }}
        }}

        // ─── ÖNCELİK SEVİYESİ DEĞİŞTİRME & DİSCORD KANAL ADI GÜNCELLEME ───
        async function changeTicketPriority(val) {{
            try {{
                const res = await fetch('/api/ticket/set-priority', {{
                    method: 'POST',
                    credentials: 'include',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{
                        transcript_id: window.TRANSCRIPT_DATA.slug_id,
                        priority: val
                    }})
                }});
                const result = await res.json();
                if (result.success) {{
                    showToast(result.message || ('Öncelik ' + val + ' olarak güncellendi.'), 'success');
                    if (typeof updatePriorityUI === 'function') {{
                        updatePriorityUI(val);
                    }}
                    if (result.channel_name) {{
                        const newName = '#' + result.channel_name;
                        // Sidebar kullanıcı bilgisi
                        const userEl = document.querySelector('.sidebar-ticket-user');
                        if (userEl) {{
                            const parts = userEl.innerText.split('•');
                            if (parts.length > 1) {{
                                userEl.innerText = newName + ' • ' + parts[1].trim();
                            }} else {{
                                userEl.innerText = newName;
                            }}
                        }}
                        // Üst nav başlığı
                        const topName = document.querySelector('.top-ticket-name');
                        if (topName) topName.innerText = newName;
                        // Hero başlığı
                        const heroTitle = document.querySelector('.hero-title');
                        if (heroTitle) heroTitle.innerText = newName;
                    }}
                }} else {{
                    showToast(result.message || 'Öncelik güncellenemedi.', 'error');
                }}
            }} catch (err) {{
                showToast('Bağlantı hatası: ' + err.message, 'error');
            }}
        }}

        // ─── KULLANICI DESTEK GEÇMİŞİ & SİCİL MODALI ───
        function openUserHistoryModal() {{
            const popover = document.getElementById('userProfilePopover');
            if (popover) popover.classList.remove('active');

            const modal = document.getElementById('userHistoryModal');
            const title = document.getElementById('historyModalTitle');
            const body = document.getElementById('historyModalBody');
            if (!modal) return;

            modal.classList.add('active');
            if (title) title.innerText = (activePopoverUser.name || 'Kullanıcı') + ' • Destek Geçmişi';
            if (body) body.innerHTML = '<div style="text-align:center; padding:30px; color:var(--text-muted);">Veriler alınıyor...</div>';

            loadUserHistoryData(activePopoverUser.id);
        }}

        function closeUserHistoryModal() {{
            const modal = document.getElementById('userHistoryModal');
            if (modal) modal.classList.remove('active');
        }}

        async function loadUserHistoryData(userId) {{
            const body = document.getElementById('historyModalBody');
            if (!body) return;

            try {{
                const res = await fetch('/api/user/history?user_id=' + encodeURIComponent(userId), {{
                    credentials: 'include'
                }});
                const data = await res.json();
                if (!data.success) {{
                    body.innerHTML = '<div style="text-align:center; padding:20px; color:#ef4444;">' + (data.message || 'Veri alınamadı.') + '</div>';
                    return;
                }}

                const tickets = data.tickets || [];
                const warnings = data.warnings || [];
                const activeCount = tickets.filter(t => t.status === 'open').length;

                let html = `
                    <div class="history-stat-grid">
                        <div class="history-stat-box">
                            <div class="history-stat-num">${{tickets.length}}</div>
                            <div class="history-stat-lbl">Toplam Talep</div>
                        </div>
                        <div class="history-stat-box">
                            <div class="history-stat-num" style="color:#10b981;">${{tickets.length - activeCount}}</div>
                            <div class="history-stat-lbl">Çözümlenen</div>
                        </div>
                        <div class="history-stat-box">
                            <div class="history-stat-num" style="color:#ef4444;">${{warnings.length}}</div>
                            <div class="history-stat-lbl">Kayıtlı İhtar</div>
                        </div>
                    </div>
                `;

                // Biletler Tablosu
                html += '<h4 style="font-size:13px; font-weight:700; color:#fff; margin-top:8px;">Önceki Destek Talepleri</h4>';
                if (tickets.length === 0) {{
                    html += '<div style="padding:15px; color:var(--text-muted); font-size:12px;">Kayıtlı bilet geçmişi bulunamadı.</div>';
                }} else {{
                    html += '<table class="history-table"><thead><tr><th>Bilet</th><th>Kategori</th><th>Tarih</th><th>Durum</th><th>İşlem</th></tr></thead><tbody>';
                    tickets.forEach(t => {{
                        const isCurrent = (t.slug_id === window.TRANSCRIPT_DATA.slug_id);
                        html += `<tr>
                            <td style="font-weight:700; color:#fff;">${{t.ticket_id}}</td>
                            <td>${{t.category || 'Genel'}}</td>
                            <td>${{t.created_at || '-'}}</td>
                            <td><span class="history-badge ${{t.status === 'open' ? 'open' : 'closed'}}">${{t.status === 'open' ? 'AÇIK' : 'ARŞİV'}}</span></td>
                            <td>${{isCurrent ? '<span style="color:var(--text-muted);">Mevcut</span>' : '<a href="/transcript/' + t.slug_id + '" target="_blank" class="history-link">Görüntüle</a>'}}</td>
                        </tr>`;
                    }});
                    html += '</tbody></table>';
                }}

                // Uyarılar Listesi
                html += '<h4 style="font-size:13px; font-weight:700; color:#ef4444; margin-top:12px;">Sicil &amp; İhtar Kayıtları</h4>';
                if (warnings.length === 0) {{
                    html += '<div style="padding:15px; color:#10b981; font-size:12px; background:rgba(16,185,129,0.06); border-radius:8px;">Bu kullanıcının sistemde kayıtlı herhangi bir ihlali bulunmuyor.</div>';
                }} else {{
                    html += '<table class="history-table"><thead><tr><th>İhlal Türü</th><th>Gerekçe</th><th>Yetkili</th><th>Tarih</th></tr></thead><tbody>';
                    warnings.forEach(w => {{
                        html += `<tr>
                            <td style="color:#ef4444; font-weight:700;">${{w.warn_type || 'Kural İhlali'}}</td>
                            <td>${{w.reason || '-'}}</td>
                            <td>${{w.staff_name || 'Yetkili'}}</td>
                            <td>${{w.timestamp || '-'}}</td>
                        </tr>`;
                    }});
                    html += '</tbody></table>';
                }}

                body.innerHTML = html;
            }} catch (e) {{
                body.innerHTML = '<div style="text-align:center; padding:20px; color:#ef4444;">Bağlantı hatası: ' + e.message + '</div>';
            }}
        }}

        
        // ─── MOBİL SIDEBAR TOGGLE ───
        function toggleSidebar() {{
            const sidebar = document.getElementById('appSidebar');
            const overlay = document.getElementById('sidebarOverlay');
            if (sidebar && overlay) {{
                sidebar.classList.toggle('active');
                overlay.classList.toggle('active');
            }}
        }}

        function openLightbox(imgUrl) {{
            const modal = document.getElementById('lightboxModal');
            const img = document.getElementById('lightboxImg');
            img.src = imgUrl;
            modal.classList.add('active');
        }}

        function closeLightbox() {{
            const modal = document.getElementById('lightboxModal');
            modal.classList.remove('active');
        }}

        // ─── ÖZEL ÖNCELİK MENÜSÜ FONKSİYONLARI ───
        function togglePriorityMenu(event) {{
            if (event) {{
                event.stopPropagation();
            }}
            const popover = document.getElementById('priorityPopover');
            const btn = document.getElementById('priorityTriggerBtn');
            if (popover && btn) {{
                const isOpen = popover.classList.contains('open');
                if (isOpen) {{
                    popover.classList.remove('open');
                    btn.classList.remove('open');
                }} else {{
                    popover.classList.add('open');
                    btn.classList.add('open');
                }}
            }}
        }}

        async function onSelectPriorityCustom(val) {{
            const popover = document.getElementById('priorityPopover');
            const btn = document.getElementById('priorityTriggerBtn');
            if (popover) popover.classList.remove('open');
            if (btn) btn.classList.remove('open');

            updatePriorityUI(val);
            await changeTicketPriority(val);
        }}

        function updatePriorityUI(val) {{
            const label = document.getElementById('priorityLabelText');
            const trigger = document.getElementById('priorityTriggerBtn');
            const dot = trigger ? trigger.querySelector('.priority-dot') : null;
            const nativeSelect = document.getElementById('prioritySelect');

            const s = (val || '').toLowerCase();
            let key = 'Normal';
            let cls = 'normal';
            let text = 'Normal';
            let selectVal = 'Normal';

            if (s.indexOf('acil') !== -1) {{
                key = 'Acil';
                cls = 'acil';
                text = 'ACİL';
                selectVal = 'Acil';
            }} else if (s.indexOf('yuksek') !== -1 || s.indexOf('y\u00fcksek') !== -1) {{
                key = 'Yüksek';
                cls = 'yuksek';
                text = 'Yüksek';
                selectVal = 'Yüksek';
            }} else if (s.indexOf('dusuk') !== -1 || s.indexOf('d\u00fc\u015f\u00fck') !== -1) {{
                key = 'Düşük';
                cls = 'dusuk';
                text = 'Düşük';
                selectVal = 'Düşük';
            }}

            if (nativeSelect) nativeSelect.value = selectVal;
            if (label) label.innerText = text;
            if (dot) {{
                dot.className = 'priority-dot dot-' + cls;
            }}

            const items = document.querySelectorAll('.priority-popover-item');
            items.forEach(el => {{
                const ev = (el.getAttribute('data-value') || '').toLowerCase();
                if ((cls === 'acil' && ev.indexOf('acil') !== -1) ||
                    (cls === 'yuksek' && (ev.indexOf('yuksek') !== -1 || ev.indexOf('y\u00fcksek') !== -1)) ||
                    (cls === 'dusuk' && (ev.indexOf('dusuk') !== -1 || ev.indexOf('d\u00fc\u015f\u00fck') !== -1)) ||
                    (cls === 'normal' && ev.indexOf('normal') !== -1)) {{
                    el.classList.add('active');
                }} else {{
                    el.classList.remove('active');
                }}
            }});
        }}

        document.addEventListener('click', function(e) {{
            const dropdown = document.getElementById('customPriorityDropdown');
            if (dropdown && !dropdown.contains(e.target)) {{
                const popover = document.getElementById('priorityPopover');
                const btn = document.getElementById('priorityTriggerBtn');
                if (popover) popover.classList.remove('open');
                if (btn) btn.classList.remove('open');
            }}
        }});

        // ─── CANLI MESAJ VE ANLIK SSE SENKRONİZASYON MOTORU ───
        let isSyncing = false;
        let autoSyncTimer = null;
        let sseSource = null;

        function updateClaimUI(claimedName, isClaimed) {{
            if (!claimedName) return;
            const lower = String(claimedName).toLowerCase().trim();
            const isReallyClaimed = isClaimed || (lower !== 'üstlenilmedi' && lower !== 'henüz üstlenilmedi' && lower !== 'yetkili üstlenmedi' && lower !== 'bilinmiyor');
            const btn = document.getElementById('btnActionClaim');
            const lbl = document.getElementById('claimBtnLabel');
            if (isReallyClaimed) {{
                const cleanName = String(claimedName).replace(/^@/, '');
                if (lbl) lbl.innerText = '@' + cleanName;
                if (btn) {{
                    btn.classList.add('claimed-disabled');
                    btn.dataset.claimed = 'true';
                    btn.disabled = true;
                    btn.style.opacity = '0.8';
                    btn.title = 'Bu bilet zaten @' + cleanName + ' tarafından üstlenildi';
                }}
                document.querySelectorAll('.embed-field-box').forEach(box => {{
                    const title = box.querySelector('.embed-field-title');
                    const content = box.querySelector('.embed-field-content');
                    if (title && title.innerText.trim() === 'İlgilenen Yetkili' && content) {{
                        content.innerHTML = '<span class="user-pill" style="color:#818cf8; font-weight:700;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px;"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>@' + cleanName + '</span>';
                    }}
                }});
            }} else {{
                if (lbl) lbl.innerText = 'Henüz Üstlenilmedi';
                if (btn) {{
                    btn.classList.remove('claimed-disabled');
                    btn.dataset.claimed = 'false';
                    btn.disabled = false;
                    btn.style.opacity = '';
                    btn.title = 'Bileti Üstlen';
                }}
            }}
        }}

        function applyLiveMessages(newHtml, totalMsgs, isManual = false, extraData = null) {{
            if (extraData && extraData.claimed_by_name) {{
                updateClaimUI(extraData.claimed_by_name, extraData.is_claimed);
            }}
            if (!newHtml) return;
            const stream = document.getElementById('msgStream');
            const counter = document.getElementById('matchCounter');

            const parser = new DOMParser();
            const doc = parser.parseFromString(newHtml, 'text/html');
            const newCards = doc.querySelectorAll('.msg-card');
            const currentCards = stream ? stream.querySelectorAll('.msg-card') : [];

            if (newCards.length > currentCards.length) {{
                if (stream) {{
                    stream.innerHTML = newHtml;
                    if (typeof onSearchInput === 'function') onSearchInput();
                    const lastCard = stream.lastElementChild;
                    if (lastCard) {{
                        lastCard.scrollIntoView({{ behavior: 'smooth', block: 'end' }});
                    }}
                }}
                playSynthSound('receive');
                if (isManual) showToast(`Sohbet güncellendi (${{newCards.length}} mesaj)`, 'success');
            }} else if (newCards.length > 0 && stream) {{
                const prevScroll = window.scrollY;
                stream.innerHTML = newHtml;
                if (typeof onSearchInput === 'function') onSearchInput();
                window.scrollTo(0, prevScroll);
                if (isManual) showToast('Sohbet güncel, yeni mesaj yok.', 'info');
            }}

            const totalCount = totalMsgs || newCards.length;
            if (counter) counter.innerText = `Toplam ${{totalCount}} mesaj`;

            const now = new Date();
            const timeStr = ('0' + now.getHours()).slice(-2) + ':' + ('0' + now.getMinutes()).slice(-2) + ':' + ('0' + now.getSeconds()).slice(-2);
            const timeLabel = document.getElementById('syncLastTime');
            if (timeLabel) timeLabel.innerText = `Anlık Akış: ${{timeStr}}`;
        }}

        // Manuel veya periyodik senkronizasyon
        async function syncTicketMessages(isManual = false) {{
            if (isSyncing) return;
            const syncBtn = document.getElementById('sidebarSyncBtn');
            const spinIcon = document.getElementById('syncIconSpin');

            isSyncing = true;
            if (spinIcon) spinIcon.classList.add('spinning');
            if (syncBtn) syncBtn.style.opacity = '0.7';

            try {{
                const res = await fetch('/api/ticket/sync', {{
                    method: 'POST',
                    credentials: 'include',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ transcript_id: window.TRANSCRIPT_DATA.slug_id }})
                }});
                const result = await res.json();

                if (result.success) {{
                    if (result.claimed_by_name) updateClaimUI(result.claimed_by_name, result.is_claimed);
                    if (result.messages_html) {{
                        applyLiveMessages(result.messages_html, result.total_messages, isManual, result);
                    }}
                }} else if (result.message && isManual) {{
                    showToast(result.message, 'info');
                }}
            }} catch (err) {{
                if (isManual) showToast('Senkronizasyon hatası: ' + err.message, 'error');
            }} finally {{
                isSyncing = false;
                if (spinIcon) spinIcon.classList.remove('spinning');
                if (syncBtn) syncBtn.style.opacity = '';
            }}
        }}

        // Discord'a mesaj atıldığında salisesinde ekrana düşüren SSE Canlı Dinleyicisi
        function initLiveSSE() {{
            if (typeof EventSource === 'undefined') return;
            if (sseSource) {{
                try {{ sseSource.close(); }} catch(e) {{}}
            }}
            try {{
                const streamUrl = '/api/ticket/stream/' + window.TRANSCRIPT_DATA.slug_id + (window.location.search || '');
                sseSource = new EventSource(streamUrl);
                sseSource.onmessage = function(event) {{
                    try {{
                        const data = JSON.parse(event.data);
                        if (data && data.claimed_by_name) {{
                            updateClaimUI(data.claimed_by_name, data.is_claimed);
                        }}
                        if (data && data.messages_html) {{
                            applyLiveMessages(data.messages_html, data.total_messages, false, data);
                        }}
                    }} catch(e) {{}}
                }};
                sseSource.onerror = function() {{
                    // EventSource arka planda otomatik tekrar dener
                }};
            }} catch(e) {{}}
        }}

        function toggleAutoSync(enabled) {{
            if (autoSyncTimer) {{
                clearInterval(autoSyncTimer);
                autoSyncTimer = null;
            }}
            const timeLabel = document.getElementById('syncLastTime');
            if (enabled) {{
                initLiveSSE();
                autoSyncTimer = setInterval(() => {{
                    if (!document.hidden) {{
                        syncTicketMessages(false);
                    }}
                }}, 6000);
                if (timeLabel) timeLabel.innerText = 'Otomatik Canlı Akış: Aktif';
            }} else {{
                if (sseSource) {{
                    try {{ sseSource.close(); }} catch(e) {{}}
                    sseSource = null;
                }}
                if (timeLabel) timeLabel.innerText = 'Otomatik Akış: Kapalı';
            }}
        }}

        // Sayfa açıldığında otomatik canlı akışı devreye sok
        setTimeout(() => {{
            toggleAutoSync(true);
        }}, 1000);
    </script>
</body>
</html>
"""

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(full_html)

    # Transcript Index'e kaydet
    t_index = load_transcript_index()
    existing_rec = t_index.get(slug_id, {})
    t_index[slug_id] = {
        "id": slug_id,
        "file_path": file_path,
        "secret_key": secret_key,
        "channel_id": channel.id,
        "channel_name": channel.name,
        "ticket_id": ticket_id,
        "owner_name": owner_name,
        "owner_id": owner_id,
        "category": category,
        "subject": subject,
        "claimed_by_name": claimed_by_name or existing_rec.get("claimed_by_name"),
        "claimed_by_id": (ticket_info.get("claimed_by") if ticket_info else None) or existing_rec.get("claimed_by_id"),
        "created_at": existing_rec.get("created_at") or datetime.now().strftime("%d.%m.%Y %H:%M:%S"),
        "status": "closed"
    }
    save_transcript_index(t_index)

    # Web URL'si (Temiz bağlantı - yetkisiz erişime kapalı)
    base_url = get_public_web_url()
    site_url = f"{base_url}/transcript/{slug_id}"

    # Düz metin yedeği de al
    try:
        await generate_text_transcript(channel, ticket_info)
    except Exception:
        pass

    return site_url, slug_id, secret_key, file_path

# ─────────────────────────────────────────────
# YETKİLİ WEB PORTALI & AIOHTTP SUNUCUSU
# ─────────────────────────────────────────────
def render_auth_gateway_html(tid: str) -> str:
    bot_name = html.escape(config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ"))
    target_role = "0"
    return f"""<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yetkili Doğrulama Portalı • {bot_name}</title>
    <style>
        :root {{
            --bg-base: #0a0b10;
            --bg-surface: #12141e;
            --border: #272c40;
            --accent: #5865f2;
            --text-primary: #f8fafc;
            --text-secondary: #94a3b8;
            --danger: #ef4444;
            --success: #10b981;
        }}
        * {{ margin:0; padding:0; box-sizing:border-box; }}
        body {{
            background-color: var(--bg-base);
            color: var(--text-primary);
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 20px;
        }}
        .auth-card {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            width: 100%;
            max-width: 450px;
            padding: 32px;
            box-shadow: 0 12px 40px rgba(0,0,0,0.6);
        }}
        .auth-header {{
            text-align: center;
            margin-bottom: 24px;
        }}
        .brand-badge {{
            display: inline-block;
            background: linear-gradient(135deg, var(--accent), #8b5cf6);
            color: #fff;
            font-weight: 700;
            font-size: 13px;
            padding: 6px 14px;
            border-radius: 20px;
            margin-bottom: 12px;
            letter-spacing: 1px;
        }}
        .auth-header h1 {{
            font-size: 20px;
            font-weight: 700;
            color: #fff;
            margin-bottom: 6px;
        }}
        .auth-header p {{
            font-size: 13px;
            color: var(--text-secondary);
            line-height: 1.5;
        }}
        .alert-box {{
            background: rgba(239, 68, 68, 0.1);
            border-left: 4px solid var(--danger);
            padding: 12px 14px;
            border-radius: 6px;
            font-size: 12.5px;
            color: #fca5a5;
            margin-bottom: 20px;
            line-height: 1.4;
        }}
        .role-highlight {{
            color: #fff;
            font-weight: 700;
            background: rgba(255,255,255,0.15);
            padding: 1px 6px;
            border-radius: 4px;
        }}
        .form-group {{
            margin-bottom: 16px;
        }}
        .form-group label {{
            display: block;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-secondary);
            margin-bottom: 6px;
        }}
        .form-input {{
            width: 100%;
            background: #181b28;
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 12px 14px;
            color: #fff;
            font-size: 14px;
            outline: none;
            transition: border-color 0.2s;
        }}
        .form-input:focus {{
            border-color: var(--accent);
        }}
        .btn-submit {{
            width: 100%;
            background: var(--accent);
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 13px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s, transform 0.1s;
            margin-top: 8px;
        }}
        .btn-submit:hover {{
            background: #4752c4;
        }}
        .btn-submit:active {{
            transform: scale(0.99);
        }}
        .help-note {{
            margin-top: 18px;
            padding-top: 16px;
            border-top: 1px solid var(--border);
            font-size: 12px;
            color: var(--text-secondary);
            line-height: 1.5;
            text-align: center;
        }}
        .help-note code {{
            background: #1e2233;
            color: #38bdf8;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: monospace;
        }}
        .status-msg {{
            display: none;
            margin-top: 12px;
            padding: 10px;
            border-radius: 6px;
            font-size: 12.5px;
            text-align: center;
        }}
        .status-msg.error {{
            display: block;
            background: rgba(239, 68, 68, 0.15);
            color: #fca5a5;
            border: 1px solid var(--danger);
        }}
        .status-msg.success {{
            display: block;
            background: rgba(16, 185, 129, 0.15);
            color: #6ee7b7;
            border: 1px solid var(--success);
        }}
    </style>
</head>
<body>
    <div class="auth-card">
        <div class="auth-header">
            <div class="brand-badge">{bot_name}</div>
            <h1>Yetkili Doğrulama Portalı</h1>
            <p>Bu arşiv dökümü güvenlik protokolü ile korunmaktadır.</p>
        </div>

        <div class="alert-box">
            Bu konuşma kaydı yalnızca <span class="role-highlight">{target_role}</span> yetkili rolüne sahip kullanıcılara açıktır.
        </div>

        <div class="form-group">
            <label for="userId">Discord Kullanıcı ID</label>
            <input type="text" id="userId" class="form-input" placeholder="Örn: 154048656..." autocomplete="off">
        </div>

        <div class="form-group">
            <label for="staffPin">6 Haneli Doğrulama Kodu</label>
            <input type="text" id="staffPin" class="form-input" placeholder="Örn: 849201" maxlength="6" autocomplete="off">
        </div>

        <button class="btn-submit" id="submitBtn" onclick="verifyStaff()">Yetkiyi Doğrula ve Giriş Yap</button>

        <div id="statusMsg" class="status-msg"></div>

        <div class="help-note">
            Kodunuz yok mu? Discord sunucusunda <code>/yetkili-kod</code> komutunu yazarak 10 dakika geçerli kodunuzu alabilirsiniz.
        </div>
    </div>

    <script>
        async function verifyStaff() {{
            const userId = document.getElementById('userId').value.trim();
            const pin = document.getElementById('staffPin').value.trim();
            const statusMsg = document.getElementById('statusMsg');
            const submitBtn = document.getElementById('submitBtn');

            if (!userId || !pin) {{
                statusMsg.className = 'status-msg error';
                statusMsg.innerText = 'Lütfen Discord ID ve 6 haneli kodu girin.';
                return;
            }}

            submitBtn.disabled = true;
            submitBtn.innerText = 'Yetki Denetleniyor...';
            statusMsg.style.display = 'none';

            try {{
                const res = await fetch('/api/verify-staff', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ user_id: userId, pin: pin, transcript_id: '{tid}' }})
                }});
                const data = await res.json();
                if (data.success) {{
                    statusMsg.className = 'status-msg success';
                    statusMsg.innerText = 'Yetki doğrulandı! Sayfaya yönlendiriliyorsunuz...';
                    setTimeout(() => {{
                        window.location.href = data.redirect || window.location.href;
                    }}, 800);
                }} else {{
                    statusMsg.className = 'status-msg error';
                    statusMsg.innerText = data.message || 'Yetki doğrulaması başarısız!';
                    submitBtn.disabled = false;
                    submitBtn.innerText = 'Yetkiyi Doğrula ve Giriş Yap';
                }}
            }} catch (err) {{
                statusMsg.className = 'status-msg error';
                statusMsg.innerText = 'Bağlantı hatası oluştu. Lütfen tekrar deneyin.';
                submitBtn.disabled = false;
                submitBtn.innerText = 'Yetkiyi Doğrula ve Giriş Yap';
            }}
        }}
    </script>
</body>
</html>
"""

async def handle_web_transcript(request: web.Request) -> web.Response:
    tid = request.match_info.get("id", "")
    auth_query = request.query.get("auth", "").strip()
    session_cookie = request.cookies.get("imza_staff_auth", "").strip()

    index_data = load_transcript_index()
    record = index_data.get(tid)
    if not record:
        return web.Response(
            text="<div style='background:#0a0b10;color:#fff;font-family:sans-serif;padding:60px;text-align:center;'><h2>Transkript bulunamadı veya arşivden kaldırılmış.</h2></div>",
            status=404,
            content_type="text/html",
            charset="utf-8"
        )

    valid_token = None
    if auth_query and await is_valid_staff_session(auth_query):
        valid_token = auth_query
    elif session_cookie and await is_valid_staff_session(session_cookie):
        valid_token = session_cookie

    if not valid_token:
        html_page = render_auth_gateway_html(tid)
        return web.Response(text=html_page, status=403, content_type="text/html", charset="utf-8")

    # Bilet kanalı Discord'da aktifse açılışta canlı mesajları senkronize et
    ch_id = record.get("channel_id")
    target_channel = None
    if ch_id:
        for g in bot.guilds:
            target_channel = g.get_channel(int(ch_id))
            if target_channel:
                break
    if not target_channel and record.get("channel_name"):
        for g in bot.guilds:
            target_channel = discord.utils.get(g.text_channels, name=record.get("channel_name"))
            if target_channel:
                break

    if target_channel:
        try:
            tdata = load_tickets()
            ticket_info = tdata.get("active", {}).get(str(target_channel.id), record)
            await generate_html_transcript(target_channel, ticket_info, existing_slug_id=tid)
        except Exception as e:
            print(f"[Live Web Transcript Refresh Hatası]: {e}", flush=True)

    fpath = record.get("file_path")
    if not fpath or not os.path.exists(fpath):
        return web.Response(
            text="<div style='background:#0a0b10;color:#fff;font-family:sans-serif;padding:60px;text-align:center;'><h2>Transkript dosyası diskte bulunamadı.</h2></div>",
            status=404,
            content_type="text/html",
            charset="utf-8"
        )

    with open(fpath, "r", encoding="utf-8") as f:
        content = f.read()

    resp = web.Response(text=content, content_type="text/html", charset="utf-8")
    resp.set_cookie("imza_staff_auth", valid_token, max_age=86400 * 7, httponly=True)
    return resp

async def handle_verify_staff(request: web.Request) -> web.Response:
    try:
        data = await request.json()
    except Exception:
        return web.json_response({"success": False, "message": "Geçersiz istek formatı."})

    user_id_raw = str(data.get("user_id", "")).strip()
    pin = str(data.get("pin", "")).strip()
    tid = str(data.get("transcript_id", "")).strip()

    if not user_id_raw.isdigit() or not pin:
        return web.json_response({"success": False, "message": "Lütfen geçerli bir Discord ID ve 6 haneli kodu girin."})

    user_id = int(user_id_raw)
    pin_record = staff_pins.get(pin)
    if not pin_record:
        return web.json_response({"success": False, "message": "Hatalı veya süresi dolmuş kod!"})

    if time.time() > pin_record["expires_at"]:
        staff_pins.pop(pin, None)
        return web.json_response({"success": False, "message": "Bu kodun süresi dolmuş. Lütfen Discord'dan yeni kod alın."})

    if pin_record["user_id"] != user_id:
        return web.json_response({"success": False, "message": "Bu kod belirttiğiniz Discord ID ile eşleşmiyor!"})

    member = None
    if bot.guilds:
        for g in bot.guilds:
            member = g.get_member(user_id)
            if member:
                break
            try:
                member = await g.fetch_member(user_id)
                if member:
                    break
            except Exception:
                pass

    if not member:
        return web.json_response({"success": False, "message": "Belirtilen Discord kullanıcısı sunucuda bulunamadı!"})

    # Yalnızca 0 rolüne sahip kişiler giriş yapabilir
    STAFF_ROLE_ID = 0
    has_perm = any(r.id == STAFF_ROLE_ID for r in getattr(member, "roles", []))

    if not has_perm:
        return web.json_response({"success": False, "message": "Erişim Reddedildi: Hesabınızda 0 yetkili rolü bulunmuyor!"})

    staff_pins.pop(pin, None)
    session_token = create_staff_session(user_id)

    redirect_url = f"/transcript/{tid}" if tid else "/"
    resp = web.json_response({"success": True, "redirect": redirect_url})
    resp.set_cookie("imza_staff_auth", session_token, max_age=86400 * 7, httponly=True)
    return resp

async def handle_ticket_send_message(request: web.Request) -> web.Response:
    """Web portalından Discord bilet kanalına canlı mesaj gönderir."""
    auth_token = request.headers.get("X-Staff-Auth") or request.cookies.get("imza_staff_auth")
    if not auth_token or not await is_valid_staff_session(auth_token):
        return web.json_response({
            "success": False,
            "message": "Yetkisiz işlem: Yalnızca 0 yetkili rolüne sahip kullanıcılar mesaj gönderebilir."
        }, status=403)

    session_data = staff_sessions.get(auth_token, {})
    staff_id = session_data.get("user_id")

    try:
        data = await request.json()
    except Exception:
        return web.json_response({"success": False, "message": "Geçersiz veri formatı."}, status=400)

    slug_id = str(data.get("transcript_id", "")).strip()
    msg_text = str(data.get("message", "")).strip()

    if not msg_text:
        return web.json_response({"success": False, "message": "Lütfen gönderilecek bir mesaj yazın."}, status=400)

    index_data = load_transcript_index()
    record = index_data.get(slug_id, {})
    ch_id = record.get("channel_id")
    ch_name = record.get("channel_name")

    target_channel = None
    for g in bot.guilds:
        if ch_id:
            target_channel = g.get_channel(int(ch_id))
            if target_channel:
                break
        if ch_name:
            target_channel = discord.utils.get(g.text_channels, name=ch_name)
            if target_channel:
                break

    if not target_channel:
        return web.json_response({
            "success": False,
            "message": "Bu destek talebi sonlandırıldığı ve Discord kanalı silindiği için kanala canlı mesaj gönderilemez. (Arşivlenmiş Kayıt)"
        }, status=404)

    staff_member = None
    if target_channel.guild:
        staff_member = target_channel.guild.get_member(staff_id)
        if not staff_member:
            try:
                staff_member = await target_channel.guild.fetch_member(staff_id)
            except Exception:
                staff_member = None

    staff_name = staff_member.display_name if staff_member else "Yetkili"
    staff_avatar = staff_member.display_avatar.url if staff_member and staff_member.display_avatar else None

    embed = discord.Embed(
        description=msg_text,
        color=0x5865f2,
        timestamp=datetime.now(timezone.utc)
    )
    if staff_avatar:
        embed.set_author(name=f"{staff_name} (Web Portalı)", icon_url=staff_avatar)
    else:
        embed.set_author(name=f"{staff_name} (Web Portalı)")
    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Yetkili Web Mesajı")

    try:
        await target_channel.send(embed=embed)
        print(f"[Web Mesaj] {staff_name} -> #{target_channel.name}: {msg_text[:40]}", flush=True)
        return web.json_response({
            "success": True,
            "message": f"Mesajınız başarıyla #{target_channel.name} kanalına iletildi.",
            "data": {
                "author": staff_name,
                "avatar": staff_avatar or "https://cdn.discordapp.com/embed/avatars/0.png",
                "content": msg_text,
                "timestamp": datetime.now().strftime("%d.%m.%Y %H:%M:%S")
            }
        })
    except Exception as e:
        return web.json_response({"success": False, "message": f"Discord kanalı mesaj hatası: {e}"}, status=500)

async def handle_ticket_warn_user(request: web.Request) -> web.Response:
    """Web portalından kullanıcıya resmi uyarı ve DM gönderir, loglara işler."""
    auth_token = request.headers.get("X-Staff-Auth") or request.cookies.get("imza_staff_auth")
    if not auth_token or not await is_valid_staff_session(auth_token):
        return web.json_response({
            "success": False,
            "message": "Yetkisiz işlem: Yalnızca 0 yetkili rolüne sahip kullanıcılar uyarı verebilir."
        }, status=403)

    session_data = staff_sessions.get(auth_token, {})
    staff_id = session_data.get("user_id")

    try:
        data = await request.json()
    except Exception:
        return web.json_response({"success": False, "message": "Geçersiz veri formatı."}, status=400)

    slug_id = str(data.get("transcript_id", "")).strip()
    reason = str(data.get("reason", "")).strip()
    warn_type = str(data.get("warn_type", "Resmi Uyarı")).strip()
    send_dm = bool(data.get("send_dm", True))
    log_channel_flag = bool(data.get("log_channel", True))

    if not reason:
        return web.json_response({"success": False, "message": "Lütfen bir uyarı gerekçesi belirtin."}, status=400)

    index_data = load_transcript_index()
    record = index_data.get(slug_id, {})
    owner_id = record.get("owner_id")
    ticket_id = record.get("ticket_id", "#0000")
    ch_name = record.get("channel_name", "destek")
    ch_id = record.get("channel_id")

    if not owner_id:
        return web.json_response({"success": False, "message": "Kullanıcı ID\'si transkript kaydında bulunamadı."}, status=404)

    target_member = None
    staff_member = None
    target_guild = None

    for g in bot.guilds:
        if not target_member:
            target_member = g.get_member(int(owner_id))
            if not target_member:
                try:
                    target_member = await g.fetch_member(int(owner_id))
                except Exception:
                    pass
        if not staff_member and staff_id:
            staff_member = g.get_member(int(staff_id))
            if not staff_member:
                try:
                    staff_member = await g.fetch_member(int(staff_id))
                except Exception:
                    pass
        if target_member:
            target_guild = g
            break

    staff_name = staff_member.display_name if staff_member else "Yetkili Ekibi"
    dm_status = False

    # 1. Kullanıcıya DM İlet
    if send_dm and target_member:
        try:
            dm_embed = discord.Embed(
                title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  {warn_type}",
                description=(
                    f"Sayın {target_member.mention},\n\n"
                    f"Açmış olduğunuz **{ch_name}** ({ticket_id}) destek talebindeki tutumunuz / işlem doğrultusunda "
                    f"yetkili yönetimimiz tarafından resmi olarak **uyarıldınız**.\n\n"
                    f"• **Uyarı Türü:** `{warn_type}`\n"
                    f"• **Uyarı Gerekçesi:** {reason}\n"
                    f"• **İlgili Talep:** `{ticket_id}`\n"
                    f"• **Uyaran Yetkili:** {staff_name}\n"
                    f"• **Tarih:** <t:{int(time.time())}:F>\n\n"
                    f"*Lütfen sunucu kurallarına ve destek sistemi işleyişine riayet ediniz.*"
                ),
                color=0xed4245,
                timestamp=datetime.now(timezone.utc)
            )
            dm_embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Güvenlik & Denetim")
            logo = get_brand_logo_url(target_guild)
            if logo:
                dm_embed.set_thumbnail(url=logo)
            await target_member.send(embed=dm_embed)
            dm_status = True
        except Exception as e:
            print(f"[Uyarı DM Hatası]: {e}", flush=True)

    # 2. Bilet kanalı açıksa kanala da uyarısını işle
    if log_channel_flag:
        target_channel = None
        if target_guild:
            if ch_id:
                target_channel = target_guild.get_channel(int(ch_id))
            if not target_channel and ch_name:
                target_channel = discord.utils.get(target_guild.text_channels, name=ch_name)

        if target_channel:
            try:
                ch_embed = discord.Embed(
                    title="Kullanıcıya Web Portalı Üzerinden Uyarı Verildi",
                    description=(
                        f"• **Uyarılan Üye:** <@{owner_id}>\n"
                        f"• **Uyarı Türü:** `{warn_type}`\n"
                        f"• **Gerekçe:** {reason}\n"
                        f"• **Uyaran Yetkili:** {staff_name}\n"
                        f"• **DM Durumu:** {'İletildi' if dm_status else 'DM Kapalı / İletilemedi'}"
                    ),
                    color=0xed4245,
                    timestamp=datetime.now(timezone.utc)
                )
                ch_embed.set_footer(text="Yetkili Web Portalı Denetimi")
                await target_channel.send(embed=ch_embed)
            except Exception:
                pass

        # 3. Log kanalına gönder
        log_ch_id = config.get("ticket_log_kanal_id")
        if log_ch_id and target_guild:
            log_ch = target_guild.get_channel(int(log_ch_id))
            if log_ch:
                try:
                    log_embed = discord.Embed(
                        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Yetkili Web Uyarısı",
                        description=(
                            f"**{ch_name}** konuşma dökümü üzerinden bir kullanıcıya yetkili uyarısı verildi.\n\n"
                            f"• **Uyarılan Kullanıcı:** <@{owner_id}>\n"
                            f"• **Uyarı Türü:** `{warn_type}`\n"
                            f"• **Gerekçe:** {reason}\n"
                            f"• **Uyaran Yetkili:** {staff_name}\n"
                            f"• **DM Bildirimi:** {'İletildi' if dm_status else 'DM Kapalı'}\n"
                            f"• **Tarih:** <t:{int(time.time())}:F>"
                        ),
                        color=0xed4245,
                        timestamp=datetime.now(timezone.utc)
                    )
                    log_embed.set_footer(text=f"{ticket_id} • Web Portalı Kaydı")
                    logo = get_brand_logo_url(target_guild)
                    if logo:
                        log_embed.set_thumbnail(url=logo)
                    await log_ch.send(embed=log_embed)
                except Exception:
                    pass

    
    # Kullanıcının kalıcı sicil/uyarı geçmişine ekle
    try:
        user_warns_file = os.path.join(TRANSCRIPTS_DIR, f"{owner_id}_warnings.json")
        user_warns = []
        if os.path.exists(user_warns_file):
            with open(user_warns_file, "r", encoding="utf-8") as wf:
                user_warns = json.load(wf)
        user_warns.append({
            "ticket_id": ticket_id,
            "warn_type": warn_type,
            "reason": reason,
            "staff_name": staff_name,
            "timestamp": datetime.now().strftime("%d.%m.%Y %H:%M:%S")
        })
        with open(user_warns_file, "w", encoding="utf-8") as wf:
            json.dump(user_warns, wf, ensure_ascii=False, indent=2)

        # Kullanıcının aktif bilet kanallarındaki karşılama embedini güncel sicil ile anında tazele
        tdata_active = load_tickets()
        for cid_str, act_info in tdata_active.get("active", {}).items():
            if str(act_info.get("owner_id")) == str(owner_id):
                asyncio.create_task(refresh_ticket_welcome_embed(int(cid_str)))
    except Exception:
        pass

    dm_msg = "Kullanıcıya Discord DM bildirimi iletildi." if dm_status else "Kullanıcının DM kutusu kapalı olduğu için DM iletilemedi, ancak sunucu içi loglara işlendi."
    return web.json_response({
        "success": True,
        "message": f"Uyarı başarıyla verildi! {dm_msg}",
        "data": {
            "warn_type": warn_type,
            "reason": reason,
            "staff_name": staff_name,
            "dm_sent": dm_status,
            "timestamp": datetime.now().strftime("%d.%m.%Y %H:%M:%S")
        }
    })


GLOBAL_USER_AVATAR_CACHE = {}

async def resolve_user_avatar_url(user_id: int | str, guild: discord.Guild = None) -> str:
    """Kullanıcının gerçek Discord profil fotoğrafını (avatarını) çözer; yoksa resmi Discord avatarını döner."""
    uid_str = str(user_id).strip()
    if not uid_str:
        return "https://cdn.discordapp.com/embed/avatars/0.png"

    if uid_str in GLOBAL_USER_AVATAR_CACHE:
        return GLOBAL_USER_AVATAR_CACHE[uid_str]

    if not uid_str.isdigit():
        return "https://cdn.discordapp.com/embed/avatars/0.png"

    uid = int(uid_str)
    av_url = None

    if guild:
        m = guild.get_member(uid)
        if m and m.display_avatar:
            av_url = m.display_avatar.url

    if not av_url:
        u = bot.get_user(uid)
        if u and u.display_avatar:
            av_url = u.display_avatar.url

    if not av_url and guild:
        try:
            m = await asyncio.wait_for(guild.fetch_member(uid), timeout=0.8)
            if m and m.display_avatar:
                av_url = m.display_avatar.url
        except Exception:
            pass

    if not av_url:
        try:
            u = await asyncio.wait_for(bot.fetch_user(uid), timeout=0.8)
            if u and u.display_avatar:
                av_url = u.display_avatar.url
        except Exception:
            pass

    if not av_url:
        av_url = f"https://cdn.discordapp.com/embed/avatars/{(uid >> 22) % 6}.png"

    GLOBAL_USER_AVATAR_CACHE[uid_str] = av_url
    return av_url


async def handle_home_page(request: web.Request) -> web.Response:
    """Tüm biletlerin listelendiği, filtrelendiği ve yönetildiği Discord tarzı ultra modern bilet portalı."""
    session_cookie = request.cookies.get("imza_staff_auth", "").strip()
    auth_query = request.query.get("auth", "").strip()

    valid_token = None
    if auth_query and await is_valid_staff_session(auth_query):
        valid_token = auth_query
    elif session_cookie and await is_valid_staff_session(session_cookie):
        valid_token = session_cookie

    if not valid_token:
        html_page = render_auth_gateway_html("")
        return web.Response(text=html_page, status=403, content_type="text/html", charset="utf-8")

    # Oturumdaki Yetkili Bilgilerini Çek (Discord Profil Barı İçin)
    session_data = staff_sessions.get(valid_token, {})
    user_id = session_data.get("user_id")
    user_name = "Yetkili"
    user_avatar_url = ""
    user_banner_url = ""
    user_accent_color = ""
    first_guild = bot.guilds[0] if bot.guilds else None

    if user_id and first_guild:
        member = first_guild.get_member(user_id)
        if not member:
            try:
                member = await first_guild.fetch_member(user_id)
            except Exception:
                member = None
        if member:
            user_name = member.display_name or member.name
            if member.display_avatar:
                user_avatar_url = member.display_avatar.url

    # Discord API üzerinden kullanıcının afiş (banner) ve renk bilgilerini çek
    if user_id:
        try:
            u_obj = await asyncio.wait_for(bot.fetch_user(user_id), timeout=2.0)
            if u_obj:
                if not user_name or user_name == "Yetkili":
                    user_name = u_obj.display_name or u_obj.name
                if not user_avatar_url and u_obj.display_avatar:
                    user_avatar_url = u_obj.display_avatar.url
                if u_obj.banner:
                    user_banner_url = u_obj.banner.url
                elif u_obj.accent_color:
                    user_accent_color = str(u_obj.accent_color)
        except Exception as e:
            print(f"[Dashboard Banner Fetch]: {e}", flush=True)

    if not user_name or user_name == "Yetkili":
        # Fallback to 6Closy or first staff member
        if first_guild:
            for m in first_guild.members:
                if any(r.id == TICKET_YETKILI_ROL_ID for r in m.roles):
                    user_name = m.display_name or m.name
                    user_id = m.id
                    if m.display_avatar:
                        user_avatar_url = m.display_avatar.url
                    break
        if not user_name:
            user_name = "6Closy"

    # Avatar görseli veya fallback
    if user_avatar_url:
        avatar_elem = f'<img src="{user_avatar_url}" class="discord-bar-avatar" alt="Avatar">'
        modal_avatar_elem = f'<img src="{user_avatar_url}" class="settings-avatar-img" alt="Avatar">'
    else:
        initial = (user_name[:1] if user_name else "Y").upper()
        avatar_elem = f'<div class="discord-bar-avatar-fallback">{initial}</div>'
        modal_avatar_elem = f'<div class="settings-avatar-fallback">{initial}</div>'

    # Discord Banner görseli veya renkli fallback
    if user_banner_url:
        banner_header_elem = f'<img src="{user_banner_url}" class="profile-banner-img" alt="Discord Banner">'
    elif user_accent_color:
        banner_header_elem = f'<div class="profile-banner-color" style="background-color: {user_accent_color}; width: 100%; height: 100%;"></div>'
    else:
        banner_header_elem = '<div class="profile-banner-fallback"></div>'

    banner_zoom_url = user_banner_url or user_avatar_url or ""
    avatar_zoom_url = user_avatar_url or ""

    # Bilet Verilerini Topla
    tdata = load_tickets()
    active_tickets = tdata.get("active", {})
    index_data = load_transcript_index()

    # Self-healing: Discord sunucusunda silinmiş olan zombi/hayalet biletleri temizle
    tdata_dirty = False
    valid_active = {}
    for cid, act in list(active_tickets.items()):
        ch = None
        if first_guild:
            try:
                ch = first_guild.get_channel(int(cid))
                if not ch and bot.is_ready():
                    try:
                        ch = await bot.fetch_channel(int(cid))
                    except (discord.NotFound, discord.Forbidden):
                        ch = None
            except Exception:
                ch = None

        if first_guild and not ch:
            # Kanal Discord'dan silinmiş, aktif listeden anında temizle!
            active_tickets.pop(cid, None)
            tdata_dirty = True
        else:
            valid_active[cid] = act

    if tdata_dirty:
        tdata["active"] = active_tickets
        save_tickets(tdata)

    all_tickets = []
    seen_ticket_ids = set()

    # 1. Canlı/Aktif Biletler
    for cid, act in valid_active.items():
        t_id = act.get("id", "#0000")
        seen_ticket_ids.add(t_id)
        ch_name = f"talep-{t_id.replace('#', '')}-{act.get('owner_name', '').lower()}"
        if first_guild:
            ch_obj = first_guild.get_channel(int(cid))
            if ch_obj:
                ch_name = ch_obj.name

        slug = None
        for sid, rec in index_data.items():
            if rec.get("ticket_id") == t_id or str(rec.get("channel_id")) == str(cid):
                slug = sid
                break
        if not slug:
            for fn in os.listdir(TRANSCRIPTS_DIR):
                if fn.startswith(f"talep-{t_id.replace('#', '')}") and fn.endswith(".html"):
                    slug = fn[:-5]
                    break

        is_closed_status = (act.get("status") == "closed") or (ch_name.startswith("kilit-"))
        t_status = "closed" if is_closed_status else "open"

        all_tickets.append({
            "ticket_id": t_id,
            "channel_name": ch_name,
            "owner_name": act.get("owner_name", "Kullanıcı"),
            "owner_id": str(act.get("owner_id", "")),
            "category": act.get("category", "Genel Destek"),
            "subject": act.get("subject", ""),
            "claimed_by_name": act.get("claimed_by_name") or "Henüz Üstlenilmedi",
            "status": t_status,
            "created_at": act.get("created_at", ""),
            "slug": slug or f"talep-{t_id.replace('#', '')}"
        })

    # 2. Arşivlenen / Sonlandırılan Biletler
    for sid, rec in reversed(list(index_data.items())):
        t_id = rec.get("ticket_id", "#0000")
        if t_id in seen_ticket_ids:
            continue
        seen_ticket_ids.add(t_id)
        all_tickets.append({
            "ticket_id": t_id,
            "channel_name": rec.get("channel_name", sid),
            "owner_name": rec.get("owner_name", "Kullanıcı"),
            "owner_id": str(rec.get("owner_id", "")),
            "category": rec.get("category", "Genel Destek"),
            "subject": rec.get("subject", ""),
            "claimed_by_name": rec.get("claimed_by_name") or "Üstlenilmedi",
            "status": "closed",
            "created_at": rec.get("created_at", ""),
            "slug": sid
        })

    total_count = len(all_tickets)
    active_count = sum(1 for t in all_tickets if t["status"] == "open")
    closed_count = total_count - active_count
    categories = sorted(list(set(t["category"] for t in all_tickets if t["category"])))

    # Toplu Sicil Verilerini Tara (Transcripts ve Welcome-bot Guard)
    warn_files = [f for f in os.listdir(TRANSCRIPTS_DIR) if f.endswith("_warnings.json")]
    all_warned_uids = set()
    for wf in warn_files:
        uid_str = wf.replace("_warnings.json", "")
        if uid_str.isdigit():
            all_warned_uids.add(int(uid_str))

    welcome_cfg_path = os.path.join(BASE_DIR, "..", "imza-welcome-bot", "config.json")
    guard_dict = {}
    if os.path.exists(welcome_cfg_path):
        try:
            with open(welcome_cfg_path, "r", encoding="utf-8") as wcf:
                guard_dict = json.load(wcf).get("guard_uyarilar", {})
                for guid_str in guard_dict.keys():
                    if guid_str.isdigit():
                        all_warned_uids.add(int(guid_str))
        except Exception:
            pass

    # Tüm bilet sahiplerinin ve sicilli üyelerin Discord avatarlarını paralel olarak getir
    unique_owner_ids = list(dict.fromkeys([t["owner_id"] for t in all_tickets if t.get("owner_id")] + [str(u) for u in all_warned_uids]))
    avatar_tasks = [resolve_user_avatar_url(oid, first_guild) for oid in unique_owner_ids]
    avatar_results = await asyncio.gather(*avatar_tasks, return_exceptions=True)
    user_avatar_map = {}
    for oid, res in zip(unique_owner_ids, avatar_results):
        if isinstance(res, str) and res.startswith("http"):
            user_avatar_map[oid] = res
        else:
            user_avatar_map[oid] = "https://cdn.discordapp.com/embed/avatars/0.png"

    # Toplu Sicil Verilerini İşle
    all_sicil_users = []
    total_warn_records = 0
    high_risk_users = 0
    total_guard_alerts = sum(int(v) for v in guard_dict.values()) if guard_dict else 0

    for u_id in all_warned_uids:
        w_list = get_user_warnings(u_id)
        g_count = int(guard_dict.get(str(u_id), 0))
        t_count = len(w_list) + g_count
        total_warn_records += len(w_list)

        m_obj = first_guild.get_member(u_id) if first_guild else None
        u_display = m_obj.display_name if m_obj else f"Kullanici_{u_id}"
        u_name = m_obj.name if m_obj else f"kullanici_{u_id}"
        u_avatar = user_avatar_map.get(str(u_id), "https://cdn.discordapp.com/embed/avatars/0.png")

        is_to = False
        if m_obj and hasattr(m_obj, "is_timed_out") and m_obj.is_timed_out():
            is_to = True

        if t_count >= 3:
            high_risk_users += 1
            status_cls = "badge-risky"
            status_txt = f"Riskli Profil ({t_count} Kayıt)"
        elif t_count > 0:
            status_cls = "badge-warned"
            status_txt = f"İhtarlı Profil ({t_count} Kayıt)"
        elif is_to:
            status_cls = "badge-warned"
            status_txt = "Kısıtlı Profil (Timeout)"
        else:
            status_cls = "badge-clean"
            status_txt = "Temiz Profil"

        last_warn = w_list[-1] if w_list else None
        last_reason = last_warn.get("reason", "Guard Güvenlik İhlali") if last_warn else ("Guard Güvenlik İhlali" if g_count else "-")
        last_type = last_warn.get("warn_type", "Güvenlik") if last_warn else "Guard"
        last_staff = last_warn.get("staff_name", "Sistem") if last_warn else "Bot Guard"
        last_time = last_warn.get("timestamp", "-") if last_warn else "-"
        last_ticket = last_warn.get("ticket_id", "Manuel") if last_warn else "Güvenlik"

        all_sicil_users.append({
            "user_id": u_id,
            "display_name": u_display,
            "user_name": u_name,
            "avatar_url": u_avatar,
            "total_count": t_count,
            "warn_count": len(w_list),
            "guard_count": g_count,
            "status_cls": status_cls,
            "status_txt": status_txt,
            "is_timeout": is_to,
            "last_reason": last_reason,
            "last_type": last_type,
            "last_staff": last_staff,
            "last_time": last_time,
            "last_ticket": last_ticket
        })

    all_sicil_users.sort(key=lambda x: (x["total_count"], x["last_time"]), reverse=True)
    total_warned_users = len(all_sicil_users)

    # Toplu Sicil Tablo Satırları HTML
    sicil_rows_html = []
    for su in all_sicil_users:
        user_link = f"/sicil/{su['user_id']}"
        sicil_rows_html.append(f"""
        <tr class="dash-sicil-row" data-status="{su['status_cls']}" data-search="{str(su['user_id'])} {html.escape(su['display_name'].lower())} {html.escape(su['user_name'].lower())} {html.escape(su['last_reason'].lower())} {html.escape(su['last_staff'].lower())}">
            <td>
                <div class="dash-owner-chip">
                    <div class="dash-owner-avatar-wrap">
                        <img src="{su['avatar_url']}" class="dash-owner-avatar-img" alt="Avatar" loading="lazy" onerror="this.onerror=null; this.src='https://cdn.discordapp.com/embed/avatars/0.png';">
                    </div>
                    <div>
                        <div class="dash-owner-name">@{html.escape(su['display_name'])}</div>
                        <div class="dash-owner-id" onclick="copyIdDirect('{su['user_id']}')" style="cursor:pointer;" title="Kopyalamak için tıkla">ID: {su['user_id']}</div>
                    </div>
                </div>
            </td>
            <td>
                <span class="status-badge {su['status_cls']}">
                    <span class="status-dot"></span>
                    <span>{su['status_txt']}</span>
                </span>
            </td>
            <td>
                <span class="dash-cat-pill cat-report" style="font-family:var(--font-mono); font-size:12px;">{su['total_count']} Kayıt</span>
            </td>
            <td>
                <div style="max-width:320px;">
                    <div style="font-size:11px; font-weight:700; color:#fbbf24; margin-bottom:2px;">[{html.escape(su['last_type'])}]</div>
                    <div style="font-size:13px; font-weight:600; color:#f1f5f9; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="{html.escape(su['last_reason'])}">{html.escape(su['last_reason'])}</div>
                </div>
            </td>
            <td>
                <span class="user-pill claimed">{SVG_SHIELD} @{html.escape(su['last_staff'])}</span>
                <span style="font-size:11px; color:var(--text-muted); margin-left:4px;">({html.escape(su['last_ticket'])})</span>
            </td>
            <td>
                <span class="dash-date-cell">{html.escape(su['last_time'])}</span>
            </td>
            <td>
                <div class="dash-action-group">
                    <button type="button" class="dash-action-btn" onclick="openSicilModal('{su['user_id']}', '{html.escape(su['display_name'])}', '{html.escape(su['user_name'])}', '{su['avatar_url']}', '{su['status_cls']}', '{su['status_txt']}')" title="Kullanıcının Sicil Dosyasını İncele">
                        {SVG_FILE}
                        <span>Sicil Dosyası</span>
                    </button>
                    <button type="button" class="dash-action-btn" onclick="clearSicilFromDash('{su['user_id']}', '{html.escape(su['display_name'])}')" title="Tüm Sicili Temizle (0)" style="border-color: rgba(239, 68, 68, 0.35); color: #f87171;">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                        <span>Sicili Temizle</span>
                    </button>
                </div>
            </td>
        </tr>
        """)
    sicil_rows_str = "".join(sicil_rows_html) if sicil_rows_html else "<tr><td colspan='7' style='text-align:center; padding:36px; color:var(--text-muted);'>Kayıtlı sicil veya ihtar verisi bulunamadı.</td></tr>"

    # Tablo Satırları HTML
    rows_html = []
    for t in all_tickets:
        is_open = (t["status"] == "open")
        status_pill = '<span class="dash-badge open"><span class="pulse-dot"></span> AÇIK</span>' if is_open else '<span class="dash-badge closed">ARŞİV</span>'
        claimed_str = t["claimed_by_name"]
        claimed_pill = f'<span class="user-pill claimed">{SVG_SHIELD} @{html.escape(claimed_str)}</span>' if (claimed_str and claimed_str not in ["Üstlenilmedi", "Henüz Üstlenilmedi"]) else '<span class="user-pill unassigned">Henüz Üstlenilmedi</span>'
        link_url = f"/transcript/{t['slug']}" if t['slug'] else "#"

        cat_cls = "cat-general"
        c_low = t['category'].lower()
        if "özel" in c_low or "yönetim" in c_low:
            cat_cls = "cat-special"
        elif "şikayet" in c_low or "bildiri" in c_low:
            cat_cls = "cat-report"
        elif "vip" in c_low or "rol" in c_low or "satın" in c_low:
            cat_cls = "cat-vip"

        owner_avatar_url = user_avatar_map.get(t['owner_id'], "https://cdn.discordapp.com/embed/avatars/0.png")

        rows_html.append(f"""
        <tr class="dash-ticket-row" data-url="{link_url}" data-status="{t['status']}" data-cat="{html.escape(t['category'].lower())}" data-search="{html.escape(t['ticket_id'].lower())} {html.escape(t['channel_name'].lower())} {html.escape(t['owner_name'].lower())} {html.escape(t['claimed_by_name'].lower())} {html.escape(t['subject'].lower())}" onclick="navigateToTicket('{link_url}', event)">
            <td>
                <div class="dash-t-id-group">
                    <span class="dash-t-id">{html.escape(t['ticket_id'])}</span>
                    <span class="dash-t-ch">#{html.escape(t['channel_name'])}</span>
                </div>
            </td>
            <td>
                <div class="dash-owner-info">
                    <div class="dash-owner-chip">
                        <div class="dash-owner-avatar-wrap">
                            <img src="{owner_avatar_url}" class="dash-owner-avatar-img" alt="Discord Avatar" loading="lazy" onerror="this.onerror=null; this.src='https://cdn.discordapp.com/embed/avatars/0.png';">
                        </div>
                        <div>
                            <div class="dash-owner-name">@{html.escape(t['owner_name'])}</div>
                            <div class="dash-owner-id">ID: {t['owner_id']}</div>
                        </div>
                    </div>
                </div>
            </td>
            <td><span class="dash-cat-pill {cat_cls}">{html.escape(t['category'])}</span></td>
            <td>{claimed_pill}</td>
            <td>{status_pill}</td>
            <td class="dash-date-cell">{html.escape(t['created_at'])}</td>
            <td>
                <div class="dash-action-group">
                    <a href="{link_url}" class="dash-action-btn" title="Transkript ve detayları aç" onclick="event.stopPropagation()">
                        {SVG_EYE}
                        <span>İncele</span>
                    </a>
                    <button type="button" class="dash-action-btn delete" title="Bu bileti veya arşivi sil" onclick="deleteTicketPrompt('{t['ticket_id']}', '{t['slug']}', '{t['status']}', event)">
                        {SVG_TRASH}
                        <span>Sil</span>
                    </button>
                </div>
            </td>
        </tr>
        """)

    table_rows_str = "".join(rows_html)
    cat_options = "".join(f'<option value="{html.escape(c.lower())}">{html.escape(c)}</option>' for c in categories)

    bot_name = html.escape(config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ"))
    logo_url = get_brand_logo_url(first_guild)
    logo_img = f'<img src="{logo_url}" class="dash-logo" alt="Logo">' if logo_url else f'<div class="dash-logo-fallback">{bot_name[:2]}</div>'

    dashboard_html = f"""<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{bot_name} • Bilet Yönetim &amp; Denetim Portalı</title>
    <style>
        :root {{
            --bg-base: #08090e;
            --bg-sidebar: #0f111a;
            --bg-surface: #131724;
            --bg-card: #181d2e;
            --bg-card-hover: #1f253a;
            --border: #23293d;
            --border-focus: #5865f2;
            --brand: #5865f2;
            --brand-glow: rgba(88, 101, 242, 0.35);
            --brand-gradient: linear-gradient(135deg, #5865f2 0%, #7950f2 100%);
            --text-primary: #f8fafc;
            --text-secondary: #94a3b8;
            --text-muted: #64748b;
            --success: #10b981;
            --success-glow: rgba(16, 185, 129, 0.3);
            --danger: #ef4444;
            --amber: #f59e0b;
            --purple: #a855f7;
            --font-sans: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
            --font-mono: 'Consolas', 'Fira Code', monospace;
        }}
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            background: var(--bg-base);
            color: var(--text-primary);
            font-family: var(--font-sans);
            display: flex;
            min-height: 100vh;
            overflow-x: hidden;
        }}

        /* Ambient Glow Spheres */
        .ambient-glow-1 {{
            position: fixed;
            top: -150px;
            left: 20%;
            width: 550px;
            height: 550px;
            background: radial-gradient(circle, rgba(88, 101, 242, 0.12) 0%, transparent 70%);
            pointer-events: none;
            z-index: 0;
            filter: blur(80px);
        }}
        .ambient-glow-2 {{
            position: fixed;
            bottom: -150px;
            right: 5%;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(16, 185, 129, 0.08) 0%, transparent 70%);
            pointer-events: none;
            z-index: 0;
            filter: blur(90px);
        }}

        /* Left Sidebar */
        .dash-sidebar {{
            width: 280px;
            min-width: 280px;
            background: var(--bg-sidebar);
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            z-index: 100;
            box-shadow: 4px 0 24px rgba(0, 0, 0, 0.4);
        }}
        .dash-brand-box {{
            padding: 22px 20px 18px 20px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 14px;
            background: rgba(19, 23, 36, 0.6);
            backdrop-filter: blur(10px);
        }}
        .dash-logo {{ width: 44px; height: 44px; border-radius: 12px; object-fit: cover; box-shadow: 0 4px 12px rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); }}
        .dash-logo-fallback {{ width: 44px; height: 44px; border-radius: 12px; background: var(--brand-gradient); display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 17px; color: #fff; box-shadow: 0 4px 14px var(--brand-glow); }}
        .dash-brand-title {{ font-size: 16px; font-weight: 800; color: #fff; letter-spacing: -0.3px; }}
        .dash-brand-pill {{ font-size: 10.5px; font-weight: 700; color: #a5b4fc; background: rgba(99, 102, 241, 0.15); border: 1px solid rgba(99, 102, 241, 0.35); padding: 2px 7px; border-radius: 5px; display: inline-flex; align-items: center; gap: 5px; margin-top: 4px; }}

        .dash-nav-group {{
            padding: 20px 14px;
            display: flex;
            flex-direction: column;
            gap: 6px;
            flex: 1;
            overflow-y: auto;
        }}
        .dash-nav-label {{
            font-size: 11px;
            font-weight: 800;
            color: var(--text-muted);
            letter-spacing: 0.8px;
            text-transform: uppercase;
            padding: 6px 10px 8px 10px;
        }}
        .dash-nav-item {{
            background: transparent;
            border: 1px solid transparent;
            color: var(--text-secondary);
            font-family: var(--font-sans);
            font-size: 13.5px;
            font-weight: 600;
            padding: 10px 14px;
            border-radius: 9px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: space-between;
            text-decoration: none;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }}
        .dash-nav-item:hover {{
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            transform: translateX(2px);
        }}
        .dash-nav-item.active {{
            background: rgba(88, 101, 242, 0.18);
            border-color: rgba(88, 101, 242, 0.4);
            color: #fff;
            box-shadow: 0 4px 14px rgba(88, 101, 242, 0.15);
        }}
        .dash-nav-count {{
            background: rgba(255, 255, 255, 0.07);
            color: var(--text-secondary);
            font-size: 11px;
            font-weight: 700;
            padding: 2px 8px;
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }}

        /* Discord Style User Profile Bar at bottom */
        .discord-user-bar {{
            margin-top: auto;
            background: #090a10;
            border-top: 1px solid var(--border);
            padding: 12px 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: background 0.15s;
            cursor: pointer;
            user-select: none;
        }}
        .discord-user-bar:hover {{
            background: #111420;
        }}
        .user-avatar-wrap {{
            position: relative;
            width: 38px;
            height: 38px;
            min-width: 38px;
        }}
        .discord-bar-avatar {{
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 1px solid rgba(255, 255, 255, 0.15);
        }}
        .discord-bar-avatar-fallback {{
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: var(--brand-gradient);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 15px;
        }}
        .user-status-dot {{
            position: absolute;
            bottom: -1px;
            right: -1px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            border: 2.5px solid #090a10;
            background: #10b981;
            box-shadow: 0 0 6px #10b981;
        }}
        .user-status-dot.streaming {{
            background: #a855f7;
            box-shadow: 0 0 6px #a855f7;
        }}
        .dash-user-details {{
            display: flex;
            flex-direction: column;
            overflow: hidden;
            flex: 1;
        }}
        .dash-user-name {{
            font-size: 13.5px;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .dash-user-tag {{
            font-size: 11px;
            color: var(--text-muted);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .dash-user-actions {{
            display: flex;
            align-items: center;
            gap: 2px;
        }}
        .dash-icon-btn {{
            background: transparent;
            border: none;
            color: var(--text-secondary);
            width: 32px;
            height: 32px;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.15s;
        }}
        .dash-icon-btn:hover {{
            background: rgba(255, 255, 255, 0.08);
            color: #fff;
        }}
        .dash-icon-btn.logout {{ color: var(--text-muted); transition: all 0.2s; }}
        .dash-icon-btn.logout:hover {{ color: #fca5a5; background: rgba(239, 68, 68, 0.2); transform: scale(1.08); }}
        .dash-icon-btn.active-muted {{
            color: #ef4444;
            background: rgba(239, 68, 68, 0.15);
        }}

        /* Main Content */
        .dash-main {{
            margin-left: 280px;
            flex: 1;
            padding: 34px 44px;
            display: flex;
            flex-direction: column;
            gap: 24px;
            position: relative;
            z-index: 1;
            max-width: 1600px;
        }}

        /* Top Header */
        .dash-header-row {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
        }}
        .dash-header-left {{ display: flex; flex-direction: column; gap: 4px; }}
        .dash-breadcrumb {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            font-weight: 700;
            color: #818cf8;
            text-transform: uppercase;
            letter-spacing: 0.8px;
        }}
        .dash-title {{
            font-size: 26px;
            font-weight: 800;
            color: #fff;
            letter-spacing: -0.6px;
        }}
        .dash-sub {{
            font-size: 13.5px;
            color: var(--text-secondary);
        }}

        .dash-header-actions {{
            display: flex;
            align-items: center;
            gap: 12px;
        }}
        .dash-top-badge {{
            background: rgba(19, 23, 36, 0.8);
            border: 1px solid var(--border);
            padding: 7px 14px;
            border-radius: 8px;
            font-size: 12.5px;
            font-weight: 600;
            color: var(--text-secondary);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            backdrop-filter: blur(10px);
        }}
        .dash-top-refresh-btn {{
            background: rgba(88, 101, 242, 0.12);
            border: 1px solid rgba(88, 101, 242, 0.35);
            color: #c7d2fe;
            font-family: var(--font-sans);
            font-size: 12.5px;
            font-weight: 700;
            padding: 8px 14px;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
        }}
        .dash-top-refresh-btn:hover {{
            background: rgba(88, 101, 242, 0.25);
            color: #fff;
            box-shadow: 0 4px 14px rgba(88, 101, 242, 0.2);
            transform: translateY(-1px);
        }}

        /* KPI Stat Cards */
        .dash-stats-grid {{
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
        }}
        .dash-stat-card {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 22px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35);
            transition: all 0.25s ease;
        }}
        .dash-stat-card:hover {{
            transform: translateY(-2px);
            border-color: rgba(255, 255, 255, 0.15);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.5);
        }}
        .dash-stat-card::before {{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
        }}
        .dash-stat-card.c-total::before {{ background: linear-gradient(90deg, #5865f2, #818cf8); }}
        .dash-stat-card.c-active::before {{ background: linear-gradient(90deg, #10b981, #34d399); }}
        .dash-stat-card.c-archive::before {{ background: linear-gradient(90deg, #64748b, #94a3b8); }}
        .dash-stat-card.c-cats::before {{ background: linear-gradient(90deg, #a855f7, #c084fc); }}

        .dash-stat-head {{
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        .dash-stat-label {{
            font-size: 11.5px;
            font-weight: 800;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.8px;
        }}
        .dash-stat-icon-badge {{
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        .c-total .dash-stat-icon-badge {{ background: rgba(88, 101, 242, 0.15); color: #818cf8; }}
        .c-active .dash-stat-icon-badge {{ background: rgba(16, 185, 129, 0.15); color: #34d399; }}
        .c-archive .dash-stat-icon-badge {{ background: rgba(148, 163, 184, 0.15); color: #94a3b8; }}
        .c-cats .dash-stat-icon-badge {{ background: rgba(168, 85, 247, 0.15); color: #c084fc; }}

        .dash-stat-num {{
            font-size: 32px;
            font-weight: 800;
            color: #fff;
            font-family: var(--font-mono);
            line-height: 1.1;
        }}
        .c-active .dash-stat-num {{ color: #10b981; }}
        .c-archive .dash-stat-num {{ color: #cbd5e1; }}
        .c-cats .dash-stat-num {{ color: #c084fc; }}
        .dash-stat-desc {{ font-size: 12px; color: var(--text-muted); }}

        /* Controls & Filter Bar */
        .dash-controls-bar {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 14px 20px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
        }}
        .dash-search-wrap {{
            position: relative;
            flex: 1;
            max-width: 460px;
            display: flex;
            align-items: center;
        }}
        .dash-search-icon {{
            position: absolute;
            left: 14px;
            color: var(--text-muted);
            pointer-events: none;
            display: flex;
        }}
        .dash-search-input {{
            width: 100%;
            background: #181d2e;
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 10px 42px 10px 40px;
            color: #fff;
            font-size: 13.5px;
            outline: none;
            transition: all 0.2s;
        }}
        .dash-search-input:focus {{
            border-color: var(--border-focus);
            box-shadow: 0 0 16px var(--brand-glow);
            background: #1c2236;
        }}
        .dash-search-shortcut {{
            position: absolute;
            right: 12px;
            font-size: 10.5px;
            font-weight: 700;
            color: var(--text-muted);
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 2px 6px;
            border-radius: 4px;
            pointer-events: none;
        }}

        .dash-filters {{
            display: flex;
            align-items: center;
            gap: 12px;
        }}
        .dash-filter-counter {{
            font-size: 12.5px;
            font-weight: 600;
            color: var(--text-secondary);
            margin-right: 4px;
        }}
        .dash-select {{
            background: #181d2e;
            border: 1px solid var(--border);
            color: var(--text-primary);
            font-size: 12.5px;
            font-weight: 600;
            padding: 9px 14px;
            border-radius: 10px;
            cursor: pointer;
            outline: none;
            transition: all 0.15s;
        }}
        .dash-select:hover {{
            border-color: rgba(255, 255, 255, 0.2);
        }}
        @keyframes spinIcon {{
            from {{ transform: rotate(0deg); }}
            to {{ transform: rotate(360deg); }}
        }}
        .btn-sync-spin {{
            animation: spinIcon 0.8s linear infinite;
        }}

        /* Table Card */
        .dash-table-card {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4);
        }}
        .dash-table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }}
        .dash-table th {{
            background: rgba(21, 26, 40, 0.85);
            padding: 16px 20px;
            text-align: left;
            font-weight: 800;
            color: var(--text-muted);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            border-bottom: 1px solid var(--border);
        }}
        .dash-table td {{
            padding: 16px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            vertical-align: middle;
        }}
        .dash-ticket-row {{
            cursor: pointer;
            transition: background 0.15s ease;
        }}
        .dash-ticket-row:hover td {{
            background: rgba(255, 255, 255, 0.025);
        }}

        .dash-t-id-group {{ display: flex; flex-direction: column; gap: 2px; }}
        .dash-t-id {{ font-size: 14.5px; font-weight: 800; color: #fff; font-family: var(--font-mono); }}
        .dash-t-ch {{ font-size: 11.5px; color: var(--text-muted); }}

        .dash-owner-chip {{
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .dash-owner-avatar-wrap {{
            position: relative;
            width: 34px;
            height: 34px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        .dash-owner-avatar-img {{
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 1.5px solid rgba(88, 101, 242, 0.4);
            background: #181d2e;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.35);
            display: block;
            transition: transform 0.15s ease, border-color 0.15s ease;
        }}
        .dash-ticket-row:hover .dash-owner-avatar-img {{
            transform: scale(1.08);
            border-color: #5865f2;
        }}
        .dash-owner-avatar {{
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: rgba(88, 101, 242, 0.15);
            border: 1px solid rgba(88, 101, 242, 0.3);
            color: #a5b4fc;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 12px;
        }}
        .dash-owner-name {{ font-weight: 700; color: #fff; font-size: 13px; line-height: 1.2; }}
        .dash-owner-id {{ font-size: 10.5px; color: var(--text-muted); font-family: var(--font-mono); margin-top: 2px; }}

        .dash-cat-pill {{
            display: inline-flex;
            align-items: center;
            font-size: 11.5px;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 7px;
            border: 1px solid transparent;
        }}
        .dash-cat-pill.cat-special {{
            background: rgba(168, 85, 247, 0.12);
            border-color: rgba(168, 85, 247, 0.3);
            color: #d8b4fe;
        }}
        .dash-cat-pill.cat-report {{
            background: rgba(244, 63, 94, 0.12);
            border-color: rgba(244, 63, 94, 0.3);
            color: #fda4af;
        }}
        .dash-cat-pill.cat-vip {{
            background: rgba(245, 158, 11, 0.12);
            border-color: rgba(245, 158, 11, 0.3);
            color: #fcd34d;
        }}
        .dash-cat-pill.cat-general {{
            background: rgba(14, 165, 233, 0.12);
            border-color: rgba(14, 165, 233, 0.3);
            color: #7dd3fc;
        }}

        .user-pill {{
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-size: 11.5px;
            font-weight: 600;
            padding: 4px 10px;
            border-radius: 7px;
        }}
        .user-pill.claimed {{
            background: rgba(99, 102, 241, 0.15);
            border: 1px solid rgba(99, 102, 241, 0.35);
            color: #c7d2fe;
        }}
        .user-pill.unassigned {{
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.08);
            color: var(--text-muted);
        }}

        .dash-badge {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 11px;
            font-weight: 800;
            padding: 4px 9px;
            border-radius: 7px;
            letter-spacing: 0.5px;
        }}
        .dash-badge.open {{
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.35);
            color: #34d399;
        }}
        .dash-badge.closed {{
            background: rgba(148, 163, 184, 0.12);
            border: 1px solid rgba(148, 163, 184, 0.25);
            color: #94a3b8;
        }}
        .pulse-dot {{
            width: 7px;
            height: 7px;
            background: #10b981;
            border-radius: 50%;
            box-shadow: 0 0 10px #10b981;
        }}
        .status-badge {{
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11.5px;
            font-weight: 700;
            letter-spacing: 0.2px;
        }}
        .badge-clean {{
            background: rgba(16, 185, 129, 0.12);
            color: #34d399;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }}
        .badge-warned {{
            background: rgba(245, 158, 11, 0.12);
            color: #fbbf24;
            border: 1px solid rgba(245, 158, 11, 0.3);
        }}
        .badge-risky {{
            background: rgba(239, 68, 68, 0.12);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }}
        .status-dot {{
            width: 6.5px;
            height: 6.5px;
            border-radius: 50%;
            background: currentColor;
            box-shadow: 0 0 6px currentColor;
        }}
        .dash-date-cell {{ color: var(--text-secondary); font-size: 12.5px; font-family: var(--font-mono); }}

        .dash-action-group {{
            display: inline-flex;
            align-items: center;
            gap: 7px;
        }}
        .dash-action-btn {{
            background: rgba(99, 102, 241, 0.12);
            border: 1px solid rgba(99, 102, 241, 0.3);
            color: #c7d2fe;
            text-decoration: none;
            font-size: 11.5px;
            font-weight: 700;
            padding: 6px 12px;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.2s;
            cursor: pointer;
            outline: none;
        }}
        .dash-action-btn:hover {{
            background: rgba(99, 102, 241, 0.25);
            color: #fff;
            border-color: rgba(99, 102, 241, 0.55);
            box-shadow: 0 4px 14px rgba(99, 102, 241, 0.2);
            transform: scale(1.03);
        }}
        .dash-action-btn.delete {{
            background: rgba(239, 68, 68, 0.1);
            border-color: rgba(239, 68, 68, 0.3);
            color: #fca5a5;
        }}
        .dash-action-btn.delete:hover {{
            background: rgba(239, 68, 68, 0.25);
            color: #fff;
            border-color: rgba(239, 68, 68, 0.6);
            box-shadow: 0 4px 14px rgba(239, 68, 68, 0.25);
            transform: scale(1.03);
        }}

        /* DISCORD USER SETTINGS MODAL */
        .discord-modal-overlay {{
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(16px);
            z-index: 1000;
            display: none;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.2s ease;
        }}
        .discord-modal-overlay.open {{
            display: flex;
            opacity: 1;
        }}
        .discord-settings-modal {{
            width: 900px;
            max-width: 95vw;
            height: 600px;
            max-height: 90vh;
            background: #111420;
            border: 1px solid var(--border);
            border-radius: 18px;
            display: flex;
            overflow: hidden;
            position: relative;
        }}
        .sicil-modal-card {{
            width: 760px;
            max-width: 95vw;
            max-height: 88vh;
            background: #0f121d;
            border: 1px solid var(--border);
            border-radius: 18px;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            box-shadow: 0 24px 70px rgba(0, 0, 0, 0.85);
            position: relative;
        }}
        .sicil-modal-header {{
            padding: 18px 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            background: #131726;
        }}
        .sicil-modal-body {{
            padding: 22px 24px;
            overflow-y: auto;
            flex: 1;
        }}
        .sicil-modal-footer {{
            padding: 16px 24px;
            background: #0b0d14;
            border-top: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        .sicil-close-btn {{
            width: 32px;
            height: 32px;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.12);
            color: var(--text-secondary);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.15s ease;
            flex-shrink: 0;
        }}
        .sicil-close-btn:hover {{
            background: rgba(239, 68, 68, 0.2);
            border-color: rgba(239, 68, 68, 0.4);
            color: #ef4444;
            transform: scale(1.05);
        }}
        .btn-modal-cancel {{
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.12);
            color: #cbd5e1;
            font-family: var(--font-sans);
            font-size: 13px;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            padding: 8px 18px;
            transition: all 0.15s ease;
        }}
        .btn-modal-cancel:hover {{
            background: rgba(255, 255, 255, 0.12);
            color: #fff;
            border-color: rgba(255, 255, 255, 0.22);
        }}
        .settings-nav-sidebar {{
            width: 240px;
            background: #0b0d14;
            border-right: 1px solid var(--border);
            padding: 28px 16px;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }}
        .settings-nav-heading {{
            font-size: 11px;
            font-weight: 800;
            color: var(--text-muted);
            letter-spacing: 0.8px;
            text-transform: uppercase;
            padding: 4px 10px 8px 10px;
        }}
        .settings-tab-btn {{
            background: transparent;
            border: 1px solid transparent;
            color: var(--text-secondary);
            font-family: var(--font-sans);
            font-size: 13.5px;
            font-weight: 600;
            padding: 10px 14px;
            border-radius: 8px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            text-align: left;
            transition: all 0.15s;
        }}
        .settings-tab-btn:hover {{
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
        }}
        .settings-tab-btn.active {{
            background: rgba(88, 101, 242, 0.18);
            border-color: rgba(88, 101, 242, 0.35);
            color: #fff;
        }}
        .settings-nav-divider {{
            height: 1px;
            background: var(--border);
            margin: 10px 0;
        }}
        .settings-logout-btn {{
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.25);
            color: #fca5a5;
            font-family: var(--font-sans);
            font-size: 13px;
            font-weight: 700;
            padding: 10px 14px;
            border-radius: 8px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: auto;
            transition: all 0.15s;
        }}
        .settings-logout-btn:hover {{
            background: rgba(239, 68, 68, 0.25);
            color: #fff;
        }}

        /* Settings Content Area */
        .settings-content-pane {{
            flex: 1;
            padding: 34px 38px;
            overflow-y: auto;
            position: relative;
        }}
        .settings-close-btn {{
            position: absolute;
            top: 24px;
            right: 24px;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.12);
            color: var(--text-secondary);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.15s;
            z-index: 10;
        }}
        .settings-close-btn:hover {{
            background: rgba(255, 255, 255, 0.15);
            color: #fff;
            transform: scale(1.05);
        }}

        .settings-tab-panel {{ display: none; }}
        .settings-tab-panel.active {{ display: block; }}

        .settings-title {{ font-size: 20px; font-weight: 800; color: #fff; margin-bottom: 20px; }}

        /* Profile Showcase */
        .profile-banner-card {{
            background: #181d2e;
            border: 1px solid var(--border);
            border-radius: 14px;
            overflow: hidden;
            margin-bottom: 24px;
        }}
        .profile-banner-header {{
            height: 130px;
            background: var(--brand-gradient);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }}
        .profile-banner-img {{
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            transition: transform 0.25s ease;
        }}
        .profile-banner-header:hover .profile-banner-img {{
            transform: scale(1.02);
        }}
        .profile-banner-fallback {{
            width: 100%;
            height: 100%;
            background: var(--brand-gradient);
        }}
        .profile-banner-color {{
            width: 100%;
            height: 100%;
        }}
        .profile-zoom-overlay {{
            position: absolute;
            inset: 0;
            background: rgba(0, 0, 0, 0.45);
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
            opacity: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            transition: opacity 0.2s ease;
            gap: 8px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 0.3px;
            pointer-events: none;
            text-shadow: 0 2px 4px rgba(0,0,0,0.6);
        }}
        .profile-banner-header:hover .profile-zoom-overlay {{
            opacity: 1;
        }}
        .profile-banner-body {{
            padding: 0 24px 20px 24px;
            position: relative;
        }}
        .settings-avatar-wrap {{
            position: relative;
            width: 82px;
            height: 82px;
            margin-top: -42px;
            margin-bottom: 14px;
            cursor: pointer;
        }}
        .settings-avatar-img {{
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #181d2e;
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.5);
            background: #181d2e;
            transition: transform 0.2s ease;
        }}
        .settings-avatar-wrap:hover .settings-avatar-img {{
            transform: scale(1.03);
        }}
        .avatar-zoom-overlay {{
            position: absolute;
            inset: 0;
            border-radius: 50%;
            background: rgba(0, 0, 0, 0.55);
            backdrop-filter: blur(2px);
            -webkit-backdrop-filter: blur(2px);
            opacity: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #fff;
            transition: opacity 0.2s ease;
            gap: 2px;
            font-size: 10px;
            font-weight: 700;
            pointer-events: none;
            border: 4px solid transparent;
            text-shadow: 0 1px 3px rgba(0,0,0,0.8);
        }}
        .settings-avatar-wrap:hover .avatar-zoom-overlay {{
            opacity: 1;
        }}
        .settings-avatar-fallback {{
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: var(--brand-gradient);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 28px;
            border: 4px solid #181d2e;
        }}

        /* Lightbox Modal (Büyütülmüş Görsel) */
        .lightbox-modal {{
            position: fixed;
            inset: 0;
            z-index: 9999999;
            background: rgba(4, 5, 9, 0.93);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
            display: none;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }}
        .lightbox-modal.active {{
            display: flex;
        }}
        .lightbox-content {{
            max-width: 90vw;
            max-height: 85vh;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        .lightbox-img {{
            max-width: 100%;
            max-height: 85vh;
            border-radius: 14px;
            box-shadow: 0 25px 70px rgba(0, 0, 0, 0.85);
            border: 1px solid rgba(255, 255, 255, 0.15);
            object-fit: contain;
            display: block;
            animation: lightBoxZoom 0.22s cubic-bezier(0.16, 1, 0.3, 1);
        }}
        @keyframes lightBoxZoom {{
            from {{ transform: scale(0.92); opacity: 0; }}
            to {{ transform: scale(1); opacity: 1; }}
        }}
        .lightbox-close {{
            position: absolute;
            top: -46px;
            right: 0;
            background: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.25);
            color: #fff;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s ease;
            outline: none;
        }}
        .lightbox-close:hover {{
            background: rgba(255, 255, 255, 0.28);
            transform: scale(1.08);
        }}
        .settings-avatar-fallback {{
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: var(--brand-gradient);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 28px;
            border: 4px solid #181d2e;
        }}
        .profile-banner-name {{ font-size: 18px; font-weight: 800; color: #fff; }}
        .profile-banner-badges {{
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 6px;
            flex-wrap: wrap;
        }}
        .prof-badge {{
            font-size: 11px;
            font-weight: 700;
            padding: 3px 8px;
            border-radius: 6px;
        }}
        .prof-badge.role {{
            background: rgba(88, 101, 242, 0.2);
            border: 1px solid rgba(88, 101, 242, 0.4);
            color: #a5b4fc;
        }}
        .prof-badge.verified {{
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.35);
            color: #34d399;
        }}

        .settings-field-group {{
            background: #181d2e;
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px 20px;
            display: flex;
            flex-direction: column;
            gap: 14px;
            margin-bottom: 18px;
        }}
        .settings-field-row {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
        }}
        .settings-field-label {{ font-size: 13.5px; font-weight: 700; color: #fff; }}
        .settings-field-desc {{ font-size: 12px; color: var(--text-muted); margin-top: 2px; }}
        .settings-val-chip {{
            font-size: 12.5px;
            font-family: var(--font-mono);
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border);
            padding: 4px 10px;
            border-radius: 6px;
            color: #cbd5e1;
        }}

        /* Toggle switch */
        .settings-toggle {{
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
        }}
        .settings-toggle input {{ opacity: 0; width: 0; height: 0; }}
        .toggle-slider {{
            position: absolute;
            cursor: pointer;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: #2b324a;
            transition: .25s;
            border-radius: 24px;
        }}
        .toggle-slider:before {{
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .25s;
            border-radius: 50%;
        }}
        input:checked + .toggle-slider {{
            background-color: var(--brand);
        }}
        input:checked + .toggle-slider:before {{
            transform: translateX(20px);
        }}

        .settings-btn {{
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid var(--border);
            color: #fff;
            font-family: var(--font-sans);
            font-size: 12.5px;
            font-weight: 700;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.15s;
        }}
        .settings-btn:hover {{
            background: rgba(255, 255, 255, 0.12);
        }}

        @media (max-width: 1100px) {{
            .dash-sidebar {{ display: none; }}
            .dash-main {{ margin-left: 0; padding: 20px; }}
            .dash-stats-grid {{ grid-template-columns: repeat(2, 1fr); }}
        }}
    </style>
</head>
<body>
    <div class="ambient-glow-1"></div>
    <div class="ambient-glow-2"></div>

    <!-- Sol Dikey Sidebar (Discord Stili) -->
    <aside class="dash-sidebar">
        <div class="dash-brand-box">
            {logo_img}
            <div class="dash-brand-info">
                <span class="dash-brand-title">{bot_name}</span>
                <span class="dash-brand-pill">{SVG_SHIELD} YETKİLİ PANELİ</span>
            </div>
        </div>

        <nav class="dash-nav-group">
            <div class="dash-nav-label">BİLET YÖNETİMİ</div>
            <button type="button" class="dash-nav-item active" id="navBtnAll" onclick="filterByNav('all', this)">
                <span style="display:flex; align-items:center; gap:8px;">{SVG_FILE} Tüm Biletler</span>
                <span class="dash-nav-count">{total_count}</span>
            </button>
            <button type="button" class="dash-nav-item" id="navBtnOpen" onclick="filterByNav('open', this)">
                <span style="display:flex; align-items:center; gap:8px;">{SVG_CHAT} Açık / Aktif</span>
                <span class="dash-nav-count" style="color:#10b981;">{active_count}</span>
            </button>
            <button type="button" class="dash-nav-item" id="navBtnClosed" onclick="filterByNav('closed', this)">
                <span style="display:flex; align-items:center; gap:8px;">{SVG_CHECK_CIRCLE} Arşiv / Kapatılan</span>
                <span class="dash-nav-count">{closed_count}</span>
            </button>
            <button type="button" class="dash-nav-item" id="navBtnSiciller" onclick="filterByNav('siciller', this)">
                <span style="display:flex; align-items:center; gap:8px;">{SVG_SHIELD} Toplu Siciller</span>
                <span class="dash-nav-count" style="color:#f59e0b;">{total_warned_users}</span>
            </button>

            <div class="dash-nav-label" style="margin-top: 18px;">AYARLAR &amp; SİSTEM</div>
            <button type="button" class="dash-nav-item" onclick="openDiscordSettings('profile')">
                <span style="display:flex; align-items:center; gap:8px;">{SVG_USER} Profil &amp; Yetki</span>
                <span class="dash-brand-pill" style="margin:0; font-size:9.5px; padding:1px 6px;">ONAYLI</span>
            </button>
            <button type="button" class="dash-nav-item" onclick="openDiscordSettings('appearance')">
                <span style="display:flex; align-items:center; gap:8px;">{SVG_EXPAND} Görünüm &amp; Tema</span>
            </button>
            <button type="button" class="dash-nav-item" onclick="openDiscordSettings('sound')">
                <span style="display:flex; align-items:center; gap:8px;">{SVG_VOLUME_2} Ses &amp; Bildirim</span>
            </button>
            <button type="button" class="dash-nav-item" onclick="openDiscordSettings('security')">
                <span style="display:flex; align-items:center; gap:8px;">{SVG_SHIELD} Yetki &amp; Oturum</span>
            </button>
        </nav>

        <!-- Sadeleştirilmiş & Şık Discord Kullanıcı Barı -->
        <div class="discord-user-bar" id="discordUserBar" onclick="openDiscordSettings('profile')" title="Kullanıcı Profili &amp; Ayarlar">
            <div class="user-avatar-wrap">
                {avatar_elem}
                <span class="user-status-dot streaming" id="userStatusDot" title="Yayında / Canlı"></span>
            </div>
            <div class="dash-user-details">
                <span class="dash-user-name">@{html.escape(user_name)}</span>
                <span class="dash-user-tag">Yetkili • {bot_name}</span>
            </div>
            <div class="dash-user-actions" onclick="event.stopPropagation()">
                <button type="button" class="dash-icon-btn logout" title="Güvenli Çıkış Yap" onclick="logoutStaff()">
                    {SVG_SHIELD_ALERT}
                </button>
            </div>
        </div>
    </aside>

    <!-- Ana Panel İçeriği -->
    <main class="dash-main">
        <!-- 1. BİLETLER GÖRÜNÜMÜ -->
        <div id="viewTickets" style="display:flex; flex-direction:column; gap:24px;">
            <div class="dash-header-row">
                <div class="dash-header-left">
                    <div class="dash-breadcrumb">
                        <span>{bot_name}</span>
                        <span>/</span>
                        <span>MERKEZİ BİLET YÖNETİMİ</span>
                    </div>
                    <h1 class="dash-title">Bilet Yönetim &amp; Denetim Portalı</h1>
                    <p class="dash-sub">Sunucu destek talepleri, canlı biletler ve doğrulanmış konuşma dökümleri.</p>
                </div>
                <div class="dash-header-actions">
                    <div class="dash-top-badge" id="liveClockBadge">
                        <span class="pulse-dot"></span>
                        <span id="liveClockText">--:--:--</span>
                    </div>
                    <button type="button" class="dash-top-refresh-btn" onclick="refreshDashboard(this)">
                        {SVG_REFRESH}
                        <span>Yenile</span>
                    </button>
                </div>
            </div>

            <!-- KPI İstatistik Metrikleri -->
            <div class="dash-stats-grid">
                <div class="dash-stat-card c-total">
                    <div class="dash-stat-head">
                        <span class="dash-stat-label">Toplam Bilet</span>
                        <div class="dash-stat-icon-badge">{SVG_FILE}</div>
                    </div>
                    <span class="dash-stat-num">{total_count}</span>
                    <span class="dash-stat-desc">Tüm zamanların bilet arşivi</span>
                </div>
                <div class="dash-stat-card c-active">
                    <div class="dash-stat-head">
                        <span class="dash-stat-label">Aktif / Açık Bilet</span>
                        <div class="dash-stat-icon-badge">{SVG_CHAT}</div>
                    </div>
                    <span class="dash-stat-num">{active_count}</span>
                    <span class="dash-stat-desc">Şu an yanıt bekleyen talepler</span>
                </div>
                <div class="dash-stat-card c-archive">
                    <div class="dash-stat-head">
                        <span class="dash-stat-label">Arşiv / Kapatılan</span>
                        <div class="dash-stat-icon-badge">{SVG_CHECK_CIRCLE}</div>
                    </div>
                    <span class="dash-stat-num">{closed_count}</span>
                    <span class="dash-stat-desc">Başarıyla çözülen kayıtlar</span>
                </div>
                <div class="dash-stat-card c-cats">
                    <div class="dash-stat-head">
                        <span class="dash-stat-label">Kategori Çeşidi</span>
                        <div class="dash-stat-icon-badge">{SVG_TAG}</div>
                    </div>
                    <span class="dash-stat-num">{len(categories)}</span>
                    <span class="dash-stat-desc">Farklı talep departmanı</span>
                </div>
            </div>

            <!-- Filtre ve Arama Çubuğu -->
            <div class="dash-controls-bar">
                <div class="dash-search-wrap">
                    <span class="dash-search-icon">{SVG_SEARCH}</span>
                    <input type="text" id="dashSearchInput" class="dash-search-input" placeholder="Bilet no, kullanıcı adı, konu veya yetkili ara..." oninput="applyDashFilters()">
                    <span class="dash-search-shortcut">CTRL + K</span>
                </div>
                <div class="dash-filters">
                    <span class="dash-filter-counter" id="dashCounterBadge">{total_count} bilet gösteriliyor</span>
                    <button type="button" class="dash-action-btn" id="btnLiveSync" onclick="checkLiveTicketSync(true)" title="Discord ile Canlı Senkronize Et" style="padding: 7px 13px; font-weight: 600; gap: 7px; border-color: rgba(99,102,241,0.45); color: #a5b4fc; background: rgba(99,102,241,0.1);">
                        <svg id="syncSpinIcon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
                        <span>Senkronize Et</span>
                    </button>
                    <select id="dashStatusFilter" class="dash-select" onchange="applyDashFilters()">
                        <option value="all">Tüm Durumlar</option>
                        <option value="open">Yalnızca Açık / Aktif</option>
                        <option value="closed">Yalnızca Arşiv / Kapatılan</option>
                    </select>
                    <select id="dashCatFilter" class="dash-select" onchange="applyDashFilters()">
                        <option value="all">Tüm Kategoriler</option>
                        {cat_options}
                    </select>
                </div>
            </div>

            <!-- Biletler Tablosu -->
            <div class="dash-table-card">
                <table class="dash-table">
                    <thead>
                        <tr>
                            <th>Bilet / Kanal</th>
                            <th>Talep Sahibi</th>
                            <th>Kategori</th>
                            <th>İlgilenen Yetkili</th>
                            <th>Durum</th>
                            <th>Oluşturulma Tarihi</th>
                            <th>İşlem</th>
                        </tr>
                    </thead>
                    <tbody id="dashTableBody">
                        {table_rows_str or "<tr><td colspan='7' style='text-align:center; padding:30px; color:var(--text-muted);'>Kayıtlı bilet bulunamadı.</td></tr>"}
                    </tbody>
                </table>
            </div>
        </div>

        <!-- 2. TOPLU SİCİLLER GÖRÜNÜMÜ -->
        <div id="viewSiciller" style="display:none; flex-direction:column; gap:24px;">
            <div class="dash-header-row">
                <div class="dash-header-left">
                    <div class="dash-breadcrumb">
                        <span>{bot_name}</span>
                        <span>/</span>
                        <span>MERKEZİ DENETİM SİSTEMİ</span>
                        <span>/</span>
                        <span style="color:#fbbf24;">TOPLU SİCİL VERİTABANI</span>
                    </div>
                    <h1 class="dash-title">Toplu Kullanıcı Sicil Kayıtları</h1>
                    <p class="dash-sub">Sunucu genelinde ceza veya ihtar almış tüm üyelerin kayıtları, gerekçeleri ve sicil dosyaları.</p>
                </div>
                <div class="dash-header-actions">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <input type="text" id="quickIdInput" placeholder="Discord ID ile sorgula..." class="dash-search-input" style="width:210px; padding:8px 14px;" onkeydown="if(event.key==='Enter') openQuickSicil()">
                        <button type="button" class="dash-action-btn" style="padding:9px 16px; background:#5865f2; color:#fff; border:none; cursor:pointer;" onclick="openQuickSicil()">
                            <span>Sorgula</span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Sicil KPI İstatistikleri -->
            <div class="dash-stats-grid">
                <div class="dash-stat-card c-archive">
                    <div class="dash-stat-head">
                        <span class="dash-stat-label">Toplam Ceza / İhtar</span>
                        <div class="dash-stat-icon-badge" style="color:#fbbf24;">{SVG_SHIELD_ALERT}</div>
                    </div>
                    <span class="dash-stat-num" style="color:#fbbf24;">{total_warn_records}</span>
                    <span class="dash-stat-desc">Kayıtlı tüm ihlaller</span>
                </div>
                <div class="dash-stat-card c-total">
                    <div class="dash-stat-head">
                        <span class="dash-stat-label">İhtarlı Kullanıcı</span>
                        <div class="dash-stat-icon-badge" style="color:#f59e0b;">{SVG_USER}</div>
                    </div>
                    <span class="dash-stat-num" style="color:#f59e0b;">{total_warned_users}</span>
                    <span class="dash-stat-desc">Sicil kaydı bulunan kişi</span>
                </div>
                <div class="dash-stat-card c-active">
                    <div class="dash-stat-head">
                        <span class="dash-stat-label">Riskli Profiller</span>
                        <div class="dash-stat-icon-badge" style="color:#ef4444;">{SVG_ALERT_TRIANGLE}</div>
                    </div>
                    <span class="dash-stat-num" style="color:#ef4444;">{high_risk_users}</span>
                    <span class="dash-stat-desc">3 veya daha fazla ceza</span>
                </div>
                <div class="dash-stat-card c-cats">
                    <div class="dash-stat-head">
                        <span class="dash-stat-label">Sunucu Güvenlik İhlali</span>
                        <div class="dash-stat-icon-badge" style="color:#10b981;">{SVG_SHIELD}</div>
                    </div>
                    <span class="dash-stat-num" style="color:#10b981;">{total_guard_alerts}</span>
                    <span class="dash-stat-desc">Guard &amp; bot koruma tetiklenmesi</span>
                </div>
            </div>

            <!-- Sicil Arama ve Filtre Çubuğu -->
            <div class="dash-controls-bar">
                <div class="dash-search-wrap">
                    <span class="dash-search-icon">{SVG_SEARCH}</span>
                    <input type="text" id="sicilSearchInput" class="dash-search-input" placeholder="Kullanıcı adı, ID, gerekçe veya yetkili ara..." oninput="applySicilFilters()">
                </div>
                <div class="dash-filters">
                    <span class="dash-filter-counter" id="sicilCounterBadge">{total_warned_users} kullanıcı gösteriliyor</span>
                    <button type="button" class="dash-action-btn" id="btnSicilRefresh" onclick="refreshDashboard(this)" title="Sicil Veritabanını Yenile" style="padding: 7px 13px; font-weight: 600; gap: 7px; border-color: rgba(99,102,241,0.45); color: #a5b4fc; background: rgba(99,102,241,0.1);">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
                        <span>Yenile</span>
                    </button>
                    <select id="sicilStatusFilter" class="dash-select" onchange="applySicilFilters()">
                        <option value="all">Tüm Profiller</option>
                        <option value="badge-risky">Yalnızca Riskli (3+ İhtar)</option>
                        <option value="badge-warned">İhtarlı Profiller</option>
                        <option value="badge-clean">Temiz Profiller</option>
                    </select>
                </div>
            </div>

            <!-- Sicil Tablosu -->
            <div class="dash-table-card">
                <table class="dash-table">
                    <thead>
                        <tr>
                            <th>Kullanıcı</th>
                            <th>Sicil Durumu</th>
                            <th>Toplam İhtar</th>
                            <th>Son İhlal (Neyden Aldı)</th>
                            <th>İşlem Yapan Yetkili</th>
                            <th>Son İşlem Tarihi</th>
                            <th>İşlem</th>
                        </tr>
                    </thead>
                    <tbody id="sicilTableBody">
                        {sicil_rows_str}
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- DISCORD TARZI AYARLAR VE PROFİL MODALI -->
    <div class="discord-modal-overlay" id="discordSettingsModal" onclick="closeDiscordSettingsOnBackdrop(event)">
        <div class="discord-settings-modal" onclick="event.stopPropagation()">
            <!-- Sol Ayarlar Menüsü -->
            <div class="settings-nav-sidebar">
                <div class="settings-nav-heading">KULLANICI AYARLARI</div>
                <button type="button" class="settings-tab-btn active" data-tab="profile" onclick="switchSettingsTab('profile', this)">
                    {SVG_USER}
                    <span>Profilim</span>
                </button>
                <button type="button" class="settings-tab-btn" data-tab="appearance" onclick="switchSettingsTab('appearance', this)">
                    {SVG_EXPAND}
                    <span>Görünüm &amp; Tema</span>
                </button>
                <button type="button" class="settings-tab-btn" data-tab="sound" onclick="switchSettingsTab('sound', this)">
                    {SVG_VOLUME_2}
                    <span>Ses &amp; Bildirim</span>
                </button>
                <button type="button" class="settings-tab-btn" data-tab="security" onclick="switchSettingsTab('security', this)">
                    {SVG_SHIELD}
                    <span>Yetki &amp; Oturum</span>
                </button>

                <div class="settings-nav-divider"></div>

                <button type="button" class="settings-logout-btn" onclick="logoutStaff()">
                    {SVG_SHIELD_ALERT}
                    <span>Güvenli Çıkış Yap</span>
                </button>
            </div>

            <!-- Sağ Ayarlar İçeriği -->
            <div class="settings-content-pane">
                <button type="button" class="settings-close-btn" onclick="closeDiscordSettings()" title="Kapat (ESC)">
                    {SVG_CLOSE}
                </button>

                <!-- TAB 1: PROFİLİM -->
                <div class="settings-tab-panel active" id="tabProfile">
                    <h2 class="settings-title">Kullanıcı Profili</h2>
                    <div class="profile-banner-card">
                        <div class="profile-banner-header" onclick="openLightbox('{banner_zoom_url}')" title="Afişi Büyüt">
                            {banner_header_elem}
                            <div class="profile-zoom-overlay">
                                {SVG_EXPAND}
                                <span>Görseli Büyüt</span>
                            </div>
                        </div>
                        <div class="profile-banner-body">
                            <div class="settings-avatar-wrap" onclick="openLightbox('{avatar_zoom_url}')" title="Profil Fotoğrafını Büyüt">
                                {modal_avatar_elem}
                                <div class="avatar-zoom-overlay">
                                    {SVG_EXPAND}
                                    <span>Büyüt</span>
                                </div>
                            </div>
                            <div class="profile-banner-name">@{html.escape(user_name)}</div>
                            <div class="profile-banner-badges">
                                <span class="prof-badge role">YETKİLİ (0)</span>
                                <span class="prof-badge verified">{SVG_CHECK} DOĞRULANMIŞ ERİŞİM</span>
                            </div>
                        </div>
                    </div>

                    <div class="settings-field-group">
                        <div class="settings-field-row">
                            <div>
                                <div class="settings-field-label">Discord Kullanıcı ID</div>
                                <div class="settings-field-desc">Sunucu yetkili kaydınıza bağlı kimlik.</div>
                            </div>
                            <span class="settings-val-chip">{user_id or "Bilinmiyor"}</span>
                        </div>
                        <div class="settings-field-row">
                            <div>
                                <div class="settings-field-label">Bağlı Sunucu</div>
                                <div class="settings-field-desc">Aktif Discord sunucusu.</div>
                            </div>
                            <span class="settings-val-chip">{bot_name} (discord.gg/imzapriw)</span>
                        </div>
                        <div class="settings-field-row">
                            <div>
                                <div class="settings-field-label">Oturum Süresi</div>
                                <div class="settings-field-desc">Güvenlik kapısı oturumu.</div>
                            </div>
                            <span class="settings-val-chip" style="color:#10b981;">7 Gün Geçerli • Aktif</span>
                        </div>
                    </div>
                </div>

                <!-- TAB 2: GÖRÜNÜM & TEMA -->
                <div class="settings-tab-panel" id="tabAppearance">
                    <h2 class="settings-title">Görünüm ve Tema Ayarları</h2>
                    <div class="settings-field-group">
                        <div class="settings-field-row">
                            <div>
                                <div class="settings-field-label">Parıltı ve Glow Efektleri</div>
                                <div class="settings-field-desc">Kartlar ve butonlar üzerindeki neon aydınlatmalar.</div>
                            </div>
                            <label class="settings-toggle">
                                <input type="checkbox" id="toggleGlow" checked onchange="toggleGlowEffects(this)">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        <div class="settings-field-row">
                            <div>
                                <div class="settings-field-label">Kompakt Tablo Görünümü</div>
                                <div class="settings-field-desc">Daha fazla bileti ekranda görmek için satır aralıklarını daraltır.</div>
                            </div>
                            <label class="settings-toggle">
                                <input type="checkbox" id="toggleCompact" onchange="toggleCompactTable(this)">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- TAB 3: SES & BİLDİRİM -->
                <div class="settings-tab-panel" id="tabSound">
                    <h2 class="settings-title">Ses ve Bildirimler</h2>
                    <div class="settings-field-group">
                        <div class="settings-field-row">
                            <div>
                                <div class="settings-field-label">Yeni Bilet &amp; Mesaj Sesi</div>
                                <div class="settings-field-desc">Sayfa açıkken gelen bildirimlerde ses çalınır.</div>
                            </div>
                            <label class="settings-toggle">
                                <input type="checkbox" id="toggleSound" checked>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                        <div class="settings-field-row">
                            <div>
                                <div class="settings-field-label">Test Sesi Çal</div>
                                <div class="settings-field-desc">Bildirim ses tonunu test edin.</div>
                            </div>
                            <button type="button" class="settings-btn" onclick="playTestChime()">
                                {SVG_VOLUME_2}
                                <span>Sesi Sına</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- TAB 4: GÜVENLİK -->
                <div class="settings-tab-panel" id="tabSecurity">
                    <h2 class="settings-title">Yetki &amp; Oturum Güvenliği</h2>
                    <div class="settings-field-group">
                        <div class="settings-field-row">
                            <div>
                                <div class="settings-field-label">Gerekli Yetkili Rolü</div>
                                <div class="settings-field-desc">Bu panele erişim için sunucuda zorunlu olan rol.</div>
                            </div>
                            <span class="settings-val-chip" style="color:#818cf8;">0</span>
                        </div>
                        <div class="settings-field-row">
                            <div>
                                <div class="settings-field-label">Oturum Çerezi</div>
                                <div class="settings-field-desc">Tarayıcınıza tanımlanan şifreli anahtar.</div>
                            </div>
                            <span class="settings-val-chip">imza_staff_auth (Güvenli)</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- KULLANICI SİCİL DOSYASI MODALI (DİREKT ERİŞİM & CANLI YENİLEME) -->
    <div class="discord-modal-overlay" id="sicilDetailModal" onclick="closeSicilModalOnBackdrop(event)">
        <div class="sicil-modal-card" onclick="event.stopPropagation()">
            <!-- Modal Header -->
            <div class="sicil-modal-header">
                <div style="display:flex; align-items:center; gap:14px;">
                    <div class="dash-owner-avatar-wrap" style="width:48px; height:48px; min-width:48px;">
                        <img id="smAvatar" src="" class="dash-owner-avatar-img" alt="Avatar">
                    </div>
                    <div>
                        <div style="display:flex; align-items:center; gap:10px;">
                            <h3 id="smDisplayName" style="font-size:16px; font-weight:800; color:#fff;"></h3>
                            <span id="smStatusBadge" class="status-badge"></span>
                        </div>
                        <div style="font-size:12px; color:var(--text-muted); display:flex; align-items:center; gap:8px; margin-top:3px;">
                            <span id="smUserName"></span>
                            <span>•</span>
                            <span id="smUserId" style="font-family:var(--font-mono); color:#818cf8;"></span>
                        </div>
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <button type="button" class="dash-action-btn" id="btnSmRefresh" onclick="refreshCurrentSicilModal()" title="Sicil Verilerini Canlı Yenile" style="padding:7px 12px; gap:6px; background:rgba(99,102,241,0.12); color:#a5b4fc; border-color:rgba(99,102,241,0.35);">
                        <svg id="smRefreshSpinIcon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
                        <span>Yenile</span>
                    </button>
                    <a id="smExternalLink" href="#" target="_blank" class="dash-action-btn" title="Ayrı Sekmede Aç" style="padding:7px 12px; gap:6px; color:#cbd5e1;">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                        <span>Ayrı Sekme</span>
                    </a>
                    <button type="button" class="sicil-close-btn" onclick="closeSicilModal()" title="Kapat">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                    </button>
                </div>
            </div>

            <!-- Modal Body -->
            <div class="sicil-modal-body" id="smBody">
                <div style="text-align:center; padding:36px; color:var(--text-muted);">Sicil kayıtları yükleniyor...</div>
            </div>

            <!-- Modal Footer -->
            <div class="sicil-modal-footer">
                <button type="button" class="dash-action-btn" id="smBtnClear" onclick="clearSicilFromModal()" style="border-color: rgba(239, 68, 68, 0.35); color: #f87171; padding:8px 16px;">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                    <span>Sicili Temizle (0)</span>
                </button>
                <button type="button" class="btn-modal-cancel" onclick="closeSicilModal()">Kapat</button>
            </div>
        </div>
    </div>

    <script>
        let currentStatusFilter = 'all';

        // Canlı Saat
        function updateLiveClock() {{
            const now = new Date();
            const timeStr = now.toLocaleTimeString('tr-TR');
            const el = document.getElementById('liveClockText');
            if (el) el.innerText = timeStr;
        }}
        setInterval(updateLiveClock, 1000);
        updateLiveClock();

        function filterByNav(status, btn) {{
            currentStatusFilter = status;
            document.querySelectorAll('.dash-nav-item').forEach(b => b.classList.remove('active'));
            if (btn) btn.classList.add('active');

            const viewTickets = document.getElementById('viewTickets');
            const viewSiciller = document.getElementById('viewSiciller');

            if (status === 'siciller') {{
                if (viewTickets) viewTickets.style.display = 'none';
                if (viewSiciller) viewSiciller.style.display = 'flex';
                applySicilFilters();
            }} else {{
                if (viewTickets) viewTickets.style.display = 'flex';
                if (viewSiciller) viewSiciller.style.display = 'none';
                const select = document.getElementById('dashStatusFilter');
                if (select) select.value = status;
                applyDashFilters();
            }}
        }}

        function applySicilFilters() {{
            const query = (document.getElementById('sicilSearchInput')?.value || '').trim().toLowerCase();
            const statusVal = document.getElementById('sicilStatusFilter')?.value || 'all';

            const rows = document.querySelectorAll('.dash-sicil-row');
            let matchCount = 0;

            rows.forEach(row => {{
                const rStatus = row.getAttribute('data-status') || '';
                const rSearch = row.getAttribute('data-search') || '';

                const matchesStatus = (statusVal === 'all') || (rStatus === statusVal);
                const matchesSearch = !query || rSearch.includes(query);

                if (matchesStatus && matchesSearch) {{
                    row.style.display = '';
                    matchCount++;
                }} else {{
                    row.style.display = 'none';
                }}
            }});

            const counter = document.getElementById('sicilCounterBadge');
            if (counter) counter.innerText = matchCount + ' kullanıcı gösteriliyor';
        }}

        function openQuickSicil() {{
            const id = (document.getElementById('quickIdInput')?.value || '').trim();
            if (!id || !/^\\d+$/.test(id)) {{
                alert('Lütfen geçerli bir Discord Kullanıcı ID girin.');
                return;
            }}
            window.open('/sicil/' + id, '_blank');
        }}

        function copyIdDirect(id) {{
            navigator.clipboard.writeText(id).then(() => {{
                const clock = document.getElementById('liveClockText');
                if (clock) {{
                    const orig = clock.innerText;
                    clock.innerText = 'ID Kopyalandı!';
                    setTimeout(() => {{ clock.innerText = orig; }}, 1500);
                }}
            }});
        }}

        async function clearSicilFromDash(userId, userName) {{
            if (!confirm(`@${{userName}} kullanıcısının tüm sicil ve ceza kayıtlarını silmek istediğinize emin misiniz? (Yetkili Rolü: 0)`)) {{
                return;
            }}
            try {{
                const res = await fetch('/api/sicil/delete', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ user_id: userId, clear_all: true }})
                }});
                const data = await res.json();
                if (res.ok && data.success) {{
                    alert(data.message || 'Sicil başarıyla temizlendi!');
                    window.location.reload();
                }} else {{
                    alert(data.message || 'Sicil silinemedi!');
                }}
            }} catch(err) {{
                alert('İşlem hatası: ' + err.message);
            }}
        }}

        let currentModalUserId = '';
        let currentModalDisplayName = '';

        async function openSicilModal(userId, displayName, userName, avatarUrl, statusCls, statusTxt) {{
            currentModalUserId = userId;
            currentModalDisplayName = displayName;

            const modal = document.getElementById('sicilDetailModal');
            if (!modal) return;

            document.getElementById('smAvatar').src = avatarUrl || 'https://cdn.discordapp.com/embed/avatars/0.png';
            document.getElementById('smDisplayName').innerText = displayName;
            document.getElementById('smUserName').innerText = '@' + userName;
            document.getElementById('smUserId').innerText = 'ID: ' + userId;

            const badge = document.getElementById('smStatusBadge');
            if (badge) {{
                badge.className = 'status-badge ' + statusCls;
                badge.innerText = statusTxt;
            }}

            const extLink = document.getElementById('smExternalLink');
            if (extLink) extLink.href = `${{window.location.origin}}/sicil/${{userId}}`;

            modal.classList.add('open');
            await loadSicilModalContent(userId);
        }}

        async function loadSicilModalContent(userId) {{
            const body = document.getElementById('smBody');
            const spin = document.getElementById('smRefreshSpinIcon');
            if (spin) spin.classList.add('btn-sync-spin');

            body.innerHTML = `
                <div style="text-align:center; padding:36px; color:var(--text-muted);">
                    <div style="display:inline-block; width:10px; height:10px; border-radius:50%; background:#818cf8; margin-bottom:10px;"></div>
                    <div>Sicil ve ceza kayıtları çekiliyor...</div>
                </div>`;

            try {{
                const res = await fetch(`/api/user/history?user_id=${{userId}}`, {{ credentials: 'include' }});
                if (!res.ok) throw new Error('Sunucu yanıt vermedi (' + res.status + ')');
                const data = await res.json();
                if (!data.success) throw new Error(data.message || 'Veriler alınamadı');

                const warns = data.warnings || [];
                const tickets = data.tickets || [];
                const guardCount = data.guard_count || 0;
                const totalRecords = warns.length + guardCount;

                let html = `
                    <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:12px; margin-bottom:20px;">
                        <div style="background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:12px; padding:12px 14px; text-align:center;">
                            <div style="font-size:11px; color:var(--text-muted); font-weight:700;">TOPLAM İHTAR</div>
                            <div style="font-size:20px; font-weight:800; color:#fbbf24; font-family:var(--font-mono); margin-top:3px;">${{warns.length}}</div>
                        </div>
                        <div style="background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:12px; padding:12px 14px; text-align:center;">
                            <div style="font-size:11px; color:var(--text-muted); font-weight:700;">GUARD İHLALİ</div>
                            <div style="font-size:20px; font-weight:800; color:#ef4444; font-family:var(--font-mono); margin-top:3px;">${{guardCount}}</div>
                        </div>
                        <div style="background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:12px; padding:12px 14px; text-align:center;">
                            <div style="font-size:11px; color:var(--text-muted); font-weight:700;">DESTEK TALEPLERİ</div>
                            <div style="font-size:20px; font-weight:800; color:#818cf8; font-family:var(--font-mono); margin-top:3px;">${{tickets.length}}</div>
                        </div>
                    </div>`;

                if (totalRecords === 0) {{
                    html += `
                        <div style="background:rgba(16,185,129,0.06); border:1px solid rgba(16,185,129,0.25); border-radius:14px; padding:32px 20px; text-align:center;">
                            <div style="font-size:15px; font-weight:700; color:#34d399; margin-bottom:4px;">Temiz Sicil Kaydı</div>
                            <div style="font-size:12.5px; color:var(--text-muted);">Bu kullanıcıya ait herhangi bir ihtar, ceza veya guard güvenlik ihlali bulunmuyor.</div>
                        </div>`;
                }} else {{
                    html += `<div style="font-size:13px; font-weight:700; color:#fff; margin-bottom:12px; display:flex; align-items:center; gap:6px;">
                        <span>İhlal &amp; Ceza Kayıtları</span>
                        <span style="font-size:11px; color:var(--text-muted);">(${{totalRecords}} kayıt)</span>
                    </div>`;

                    if (guardCount > 0) {{
                        for (let g = 0; g < guardCount; g++) {{
                            html += `
                                <div style="background:rgba(239,68,68,0.06); border:1px solid rgba(239,68,68,0.25); border-radius:12px; padding:14px 16px; margin-bottom:10px;">
                                    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:6px;">
                                        <span style="font-size:11px; font-weight:700; color:#ef4444; background:rgba(239,68,68,0.14); border:1px solid rgba(239,68,68,0.3); padding:2px 8px; border-radius:6px;">Guard Güvenlik İhlali</span>
                                        <span style="font-size:11.5px; font-family:var(--font-mono); color:var(--text-muted);">Otomatik Sistem</span>
                                    </div>
                                    <div style="font-size:13px; color:#f1f5f9; font-weight:600; line-height:1.5; margin-bottom:8px;">Sunucu koruma (Guard) sistemi tarafından güvenlik ihlali tespit edildi ve işlem uygulandı.</div>
                                    <div style="display:flex; align-items:center; gap:14px; font-size:11.5px; color:var(--text-muted);">
                                        <span>İşlem: <strong style="color:#fca5a5;">Welcome / Guard Bot</strong></span>
                                        <span>Kaynak: <code style="color:#818cf8;">Security Guard</code></span>
                                    </div>
                                </div>`;
                        }}
                    }}

                    warns.slice().reverse().forEach((w) => {{
                        const wType = w.warn_type || 'İhtar / Ceza';
                        const wReason = w.reason || 'Gerekçe belirtilmedi.';
                        const wStaff = w.staff_name || 'Yetkili';
                        const wTime = w.timestamp || '-';
                        const wTicket = w.ticket_id || 'Manuel Sicil';

                        html += `
                            <div style="background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:12px; padding:14px 16px; margin-bottom:10px;">
                                <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:6px;">
                                    <span style="font-size:11px; font-weight:700; color:#fbbf24; background:rgba(251,191,36,0.12); border:1px solid rgba(251,191,36,0.25); padding:2px 8px; border-radius:6px;">${{wType}}</span>
                                    <span style="font-size:11.5px; font-family:var(--font-mono); color:var(--text-muted);">${{wTime}}</span>
                                </div>
                                <div style="font-size:13px; color:#f1f5f9; font-weight:600; line-height:1.5; margin-bottom:8px;">${{wReason}}</div>
                                <div style="display:flex; align-items:center; gap:14px; font-size:11.5px; color:var(--text-muted);">
                                    <span>İşlem Yapan: <strong style="color:#cbd5e1;">@${{wStaff}}</strong></span>
                                    <span>Kaynak: <code style="color:#818cf8;">${{wTicket}}</code></span>
                                </div>
                            </div>`;
                    }});
                }}

                body.innerHTML = html;
            }} catch(err) {{
                body.innerHTML = `
                    <div style="text-align:center; padding:32px 16px; color:#f87171;">
                        <div style="font-weight:700; margin-bottom:6px;">Sicil Verisi Yüklenemedi</div>
                        <div style="font-size:12.5px; color:var(--text-muted); margin-bottom:16px;">${{err.message}}</div>
                        <button type="button" class="dash-action-btn" onclick="loadSicilModalContent('${{userId}}')" style="margin:0 auto; padding:6px 14px;">
                            Tekrar Dene
                        </button>
                    </div>`;
            }} finally {{
                if (spin) setTimeout(() => spin.classList.remove('btn-sync-spin'), 500);
            }}
        }}

        async function refreshCurrentSicilModal() {{
            if (currentModalUserId) {{
                await loadSicilModalContent(currentModalUserId);
                showDashboardToast('Kullanıcı sicil kaydı yenilendi.', 'info');
            }}
        }}

        function closeSicilModal() {{
            const modal = document.getElementById('sicilDetailModal');
            if (modal) modal.classList.remove('open');
        }}

        function closeSicilModalOnBackdrop(event) {{
            if (event.target && event.target.id === 'sicilDetailModal') {{
                closeSicilModal();
            }}
        }}

        function clearSicilFromModal() {{
            if (currentModalUserId) {{
                clearSicilFromDash(currentModalUserId, currentModalDisplayName);
                closeSicilModal();
            }}
        }}

        function applyDashFilters() {{
            const query = (document.getElementById('dashSearchInput')?.value || '').trim().toLowerCase();
            const statusVal = document.getElementById('dashStatusFilter')?.value || currentStatusFilter;
            const catVal = document.getElementById('dashCatFilter')?.value || 'all';

            const rows = document.querySelectorAll('.dash-ticket-row');
            let matchCount = 0;

            rows.forEach(row => {{
                const rStatus = row.getAttribute('data-status');
                const rCat = row.getAttribute('data-cat');
                const rSearch = row.getAttribute('data-search') || '';

                const matchesStatus = (statusVal === 'all') || (rStatus === statusVal);
                const matchesCat = (catVal === 'all') || (rCat === catVal);
                const matchesSearch = !query || rSearch.includes(query);

                if (matchesStatus && matchesCat && matchesSearch) {{
                    row.style.display = '';
                    matchCount++;
                }} else {{
                    row.style.display = 'none';
                }}
            }});

            const counter = document.getElementById('dashCounterBadge');
            if (counter) counter.innerText = matchCount + ' bilet gösteriliyor';
        }}

        function navigateToTicket(url, event) {{
            if (url && url !== '#') {{
                window.location.href = url;
            }}
        }}

        function refreshDashboard(btn) {{
            if (btn) btn.style.transform = 'rotate(180deg)';
            window.location.reload();
        }}

        let lastKnownTicketFingerprint = '';
        async function checkLiveTicketSync(manual = false) {{
            const syncIcon = document.getElementById('syncSpinIcon');
            const syncBtn = document.getElementById('btnLiveSync');
            if (syncIcon) syncIcon.classList.add('btn-sync-spin');
            if (syncBtn) syncBtn.style.opacity = '0.75';

            try {{
                const res = await fetch('/api/ticket/sync-check', {{ credentials: 'include' }});
                if (!res.ok) return;
                const data = await res.json();
                if (!data.success) return;

                const newFingerprint = `${{data.active_count}}_${{data.closed_count}}_${{data.total_count}}_` +
                    (data.tickets ? data.tickets.map(t => `${{t.ticket_id}}:${{t.status}}`).join(',') : '');

                if (lastKnownTicketFingerprint === '') {{
                    lastKnownTicketFingerprint = newFingerprint;
                    if (manual) {{
                        showDashboardToast('Tüm biletler güncel ve Discord ile senkronize.', 'info');
                    }}
                }} else if (lastKnownTicketFingerprint !== newFingerprint) {{
                    lastKnownTicketFingerprint = newFingerprint;
                    if (manual) {{
                        showDashboardToast('Bilet listesi güncellendi, senkronize ediliyor...', 'success');
                    }} else {{
                        showDashboardToast('Discord bilet durumu güncellendi.', 'info');
                    }}
                    setTimeout(() => window.location.reload(), 400);
                }} else if (manual) {{
                    showDashboardToast('Tüm biletler Discord ile tam senkronize.', 'info');
                }}
            }} catch(e) {{
                if (manual) showDashboardToast('Senkronizasyon kontrolü yapılamadı: ' + e.message, 'error');
            }} finally {{
                if (syncIcon) setTimeout(() => syncIcon.classList.remove('btn-sync-spin'), 600);
                if (syncBtn) setTimeout(() => syncBtn.style.opacity = '1', 600);
            }}
        }}

        // Sayfa açıldığında ilk parmak izini kaydet
        setTimeout(() => checkLiveTicketSync(false), 1200);

        // URL'den gelen arama parametresini otomatik kutuya yaz ve filtrele
        (function() {{
            try {{
                const params = new URLSearchParams(window.location.search);
                const q = params.get('search') || params.get('q');
                if (q) {{
                    const sInput = document.getElementById('dashSearchInput');
                    if (sInput) {{
                        sInput.value = q;
                        setTimeout(applyDashFilters, 100);
                    }}
                }}
            }} catch(err) {{}}
        }})();

        // Her 8 saniyede bir Discord bilet durumunu arka planda sessizce denetle
        setInterval(() => checkLiveTicketSync(false), 8000);

        // Kullanıcı tarayıcı sekmesine geri döndüğünde anında tazele
        document.addEventListener('visibilitychange', () => {{
            if (document.visibilityState === 'visible') checkLiveTicketSync(false);
        }});
        window.addEventListener('focus', () => checkLiveTicketSync(false));

        // Klavye Kısayolları (Ctrl+K Arama, ESC Kapatma)
        window.addEventListener('keydown', (e) => {{
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {{
                e.preventDefault();
                const search = document.getElementById('dashSearchInput');
                if (search) {{
                    search.focus();
                    search.select();
                }}
            }}
            if (e.key === 'Escape') {{
                closeLightbox();
                closeDiscordSettings();
            }}
        }});

        // Discord Ses Efekti (Web Audio API)
        function playTestChime() {{
            try {{
                const ctx = new (window.AudioContext || window.webkitAudioContext)();
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
                osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15); // A5
                gain.gain.setValueAtTime(0.12, ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start();
                osc.stop(ctx.currentTime + 0.36);
            }} catch(e) {{}}
        }}

        // Discord Kullanıcı Barı Butonları
        function toggleMic(btn) {{
            btn.classList.toggle('active-muted');
        }}
        function toggleDeaf(btn) {{
            btn.classList.toggle('active-muted');
        }}

        // Discord Ayarlar Modalı
        function openDiscordSettings(tabName) {{
            const modal = document.getElementById('discordSettingsModal');
            if (modal) {{
                modal.style.display = 'flex';
                setTimeout(() => modal.classList.add('open'), 10);
            }}
            if (tabName) {{
                const targetBtn = document.querySelector(`.settings-tab-btn[data-tab="${{tabName}}"]`);
                switchSettingsTab(tabName, targetBtn);
            }}
        }}
        function closeDiscordSettings() {{
            const modal = document.getElementById('discordSettingsModal');
            if (modal) {{
                modal.classList.remove('open');
                setTimeout(() => modal.style.display = 'none', 200);
            }}
        }}
        function closeDiscordSettingsOnBackdrop(e) {{
            if (e.target.id === 'discordSettingsModal') {{
                closeDiscordSettings();
            }}
        }}

        function switchSettingsTab(tabName, btn) {{
            document.querySelectorAll('.settings-tab-btn').forEach(b => b.classList.remove('active'));
            if (!btn) {{
                btn = document.querySelector(`.settings-tab-btn[data-tab="${{tabName}}"]`);
            }}
            if (btn) btn.classList.add('active');
            document.querySelectorAll('.settings-tab-panel').forEach(p => p.classList.remove('active'));
            const targetId = 'tab' + tabName.charAt(0).toUpperCase() + tabName.slice(1);
            const target = document.getElementById(targetId);
            if (target) target.classList.add('active');
        }}

        function toggleGlowEffects(cb) {{
            const orbs = document.querySelectorAll('.ambient-glow-1, .ambient-glow-2');
            orbs.forEach(o => o.style.display = cb.checked ? '' : 'none');
        }}

        function toggleCompactTable(cb) {{
            const tds = document.querySelectorAll('.dash-table td, .dash-table th');
            tds.forEach(td => td.style.padding = cb.checked ? '10px 14px' : '16px 20px');
        }}

        function showDashboardToast(msg, type) {{
            let container = document.getElementById('dashToastContainer');
            if (!container) {{
                container = document.createElement('div');
                container.id = 'dashToastContainer';
                container.style.cssText = 'position:fixed; bottom:24px; right:24px; z-index:99999; display:flex; flex-direction:column; gap:10px; pointer-events:none;';
                document.body.appendChild(container);
            }}
            const toast = document.createElement('div');
            const bg = (type === 'error') ? '#ef4444' : ((type === 'success') ? '#10b981' : '#5865f2');
            toast.style.cssText = `background:#181d2e; color:#fff; border:1px solid rgba(255,255,255,0.1); border-left:4px solid ${{bg}}; padding:12px 18px; border-radius:10px; font-size:13px; font-weight:600; box-shadow:0 10px 30px rgba(0,0,0,0.5); pointer-events:auto; display:flex; align-items:center; gap:10px; opacity:0; transform:translateY(15px); transition:all 0.25s cubic-bezier(0.16, 1, 0.3, 1);`;
            toast.innerHTML = `<span>${{msg}}</span>`;
            container.appendChild(toast);
            setTimeout(() => {{
                toast.style.opacity = '1';
                toast.style.transform = 'translateY(0)';
            }}, 10);
            setTimeout(() => {{
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(15px)';
                setTimeout(() => toast.remove(), 250);
            }}, 3500);
        }}

        async function deleteTicketPrompt(ticketId, slug, status, event) {{
            if (event) event.stopPropagation();

            const isArchive = (status === 'closed');
            const confirmMsg = isArchive
                ? `${{ticketId}} numaralı arşiv kaydını ve dökümünü tamamen silmek istediğinize emin misiniz?`
                : `${{ticketId}} numaralı aktif açık destek talebini sonlandırıp, Discord kanalını silmek ve arşive taşımak istediğinize emin misiniz?`;

            if (!confirm(confirmMsg)) return;

            const targetRow = (event && event.target) ? event.target.closest('tr') : document.querySelector(`tr[data-search*="${{ticketId.toLowerCase()}}"]`);
            if (targetRow) targetRow.style.opacity = '0.35';

            showDashboardToast(`${{ticketId}} siliniyor...`, 'info');

            try {{
                const res = await fetch('/api/ticket/delete', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    credentials: 'include',
                    body: JSON.stringify({{ ticket_id: ticketId, slug: slug }})
                }});
                const data = await res.json();
                if (data.success) {{
                    showDashboardToast(data.message || `${{ticketId}} başarıyla silindi.`, 'success');
                    if (targetRow) {{
                        targetRow.style.transition = 'all 0.35s ease';
                        targetRow.style.transform = 'scale(0.96)';
                        targetRow.style.opacity = '0';
                        setTimeout(() => {{
                            targetRow.remove();
                            const counter = document.getElementById('dashCounterBadge');
                            if (counter) {{
                                const visibleRows = document.querySelectorAll('.dash-ticket-row:not([style*="display: none"])');
                                counter.innerText = visibleRows.length + ' bilet gösteriliyor';
                            }}
                        }}, 350);
                    }}
                }} else {{
                    if (targetRow) targetRow.style.opacity = '1';
                    showDashboardToast(data.message || 'Silme işlemi başarısız oldu.', 'error');
                }}
            }} catch (err) {{
                if (targetRow) targetRow.style.opacity = '1';
                showDashboardToast('Bağlantı hatası: ' + err.message, 'error');
            }}
        }}

        async function logoutStaff() {{
            try {{
                await fetch('/api/staff/logout', {{ method: 'POST', credentials: 'include' }});
            }} catch(e) {{}}
            window.location.reload();
        }}

        function openLightbox(imgUrl) {{
            if (!imgUrl || imgUrl === 'None' || imgUrl === 'undefined' || imgUrl === '') return;
            const modal = document.getElementById('lightboxModal');
            const img = document.getElementById('lightboxImg');
            if (modal && img) {{
                img.src = imgUrl;
                modal.classList.add('active');
            }}
        }}

        function closeLightbox(event) {{
            if (event) event.stopPropagation();
            const modal = document.getElementById('lightboxModal');
            if (modal) {{
                modal.classList.remove('active');
            }}
        }}
    </script>

    <!-- Lightbox Modal (Görsel Büyütme) -->
    <div id="lightboxModal" class="lightbox-modal" onclick="closeLightbox(event)">
        <div class="lightbox-content" onclick="event.stopPropagation()">
            <button class="lightbox-close" onclick="closeLightbox(event)" type="button" title="Kapat">{SVG_CLOSE}</button>
            <img id="lightboxImg" class="lightbox-img" src="" alt="Büyütülmüş Görsel">
        </div>
    </div>
</body>
</html>"""
    resp = web.Response(text=dashboard_html, content_type="text/html", charset="utf-8")
    if valid_token:
        resp.set_cookie("imza_staff_auth", valid_token, max_age=86400 * 7, httponly=True)
    return resp

async def handle_staff_logout(request: web.Request) -> web.Response:
    """Yetkili oturumunu sonlandırır ve çerezi siler."""
    auth_token = request.cookies.get("imza_staff_auth")
    if auth_token and auth_token in staff_sessions:
        staff_sessions.pop(auth_token, None)
        save_staff_sessions(staff_sessions)
    resp = web.json_response({"success": True, "message": "Oturum başarıyla sonlandırıldı."})
    resp.del_cookie("imza_staff_auth")
    return resp

async def handle_ticket_add_note(request: web.Request) -> web.Response:
    """Yetkilinin bilet transkriptine dahili not eklemesini sağlar."""
    session_cookie = request.cookies.get("imza_staff_auth")
    if not session_cookie or not await is_valid_staff_session(session_cookie):
        return web.json_response({"success": False, "message": "Yetkisiz işlem: Oturum geçersiz."}, status=403)

    user_id = staff_sessions[session_cookie]["user_id"]
    try:
        data = await request.json()
    except Exception:
        return web.json_response({"success": False, "message": "Geçersiz veri."}, status=400)

    slug_id = data.get("transcript_id", "").strip()
    note_text = data.get("note", "").strip()
    if not slug_id or not note_text:
        return web.json_response({"success": False, "message": "Not metni boş olamaz."}, status=400)

    notes_file = os.path.join(TRANSCRIPTS_DIR, f"{slug_id}_notes.json")
    notes = []
    if os.path.exists(notes_file):
        try:
            with open(notes_file, "r", encoding="utf-8") as f:
                notes = json.load(f)
        except Exception:
            notes = []

    staff_member = None
    if bot.guilds:
        for g in bot.guilds:
            staff_member = g.get_member(user_id)
            if staff_member:
                break

    author_name = staff_member.display_name if staff_member else "Yetkili"
    author_avatar = str(staff_member.display_avatar.url) if staff_member and staff_member.display_avatar else "https://cdn.discordapp.com/embed/avatars/0.png"
    now_str = datetime.now().strftime("%d.%m.%Y %H:%M")

    new_note = {
        "author": author_name,
        "avatar": author_avatar,
        "author_id": user_id,
        "note": note_text,
        "timestamp": now_str
    }
    notes.append(new_note)
    try:
        with open(notes_file, "w", encoding="utf-8") as f:
            json.dump(notes, f, ensure_ascii=False, indent=2)
    except Exception as e:
        return web.json_response({"success": False, "message": f"Kayıt hatası: {e}"}, status=500)

    return web.json_response({"success": True, "message": "Yetkili dahili notu kaydedildi!", "data": new_note})


async def handle_ticket_claim_web(request: web.Request) -> web.Response:
    """Web portalı üzerinden yetkilinin bileti üstlenmesini sağlar ve Discord embedi dahil her yeri günceller."""
    auth_token = request.headers.get("X-Staff-Auth") or request.cookies.get("imza_staff_auth")
    if not auth_token or not await is_valid_staff_session(auth_token):
        return web.json_response({"success": False, "message": "Yetkisiz işlem: Oturum geçersiz."}, status=403)

    session_data = staff_sessions.get(auth_token, {})
    staff_id = session_data.get("user_id")
    try:
        data = await request.json()
    except Exception:
        return web.json_response({"success": False, "message": "Geçersiz veri."}, status=400)

    slug_id = str(data.get("transcript_id", "")).strip()
    if not slug_id:
        return web.json_response({"success": False, "message": "Bilet ID belirtilmedi."}, status=400)

    index_data = load_transcript_index()
    record = index_data.get(slug_id, {})
    ch_id = record.get("channel_id")

    # Eğer record'da channel_id yoksa aktif biletlerden ara
    tdata = load_tickets()
    if not ch_id:
        for cid, act in tdata.get("active", {}).items():
            if act.get("id") == record.get("ticket_id") or slug_id.startswith(f"talep-{act.get('id', '').replace('#', '')}"):
                ch_id = int(cid)
                break

    staff_member = None
    target_channel = None
    target_guild = None
    for g in bot.guilds:
        if not staff_member and staff_id:
            staff_member = g.get_member(int(staff_id))
            if not staff_member:
                try:
                    staff_member = await g.fetch_member(int(staff_id))
                except Exception:
                    pass
        if ch_id and not target_channel:
            target_channel = g.get_channel(int(ch_id))
        if target_channel:
            target_guild = g
        if staff_member and target_channel:
            break

    staff_name = staff_member.display_name if staff_member else "Yetkili"

    # 0. Anti-Spam & Çift Üstlenme Engeli: Bilet zaten üstlenilmiş mi?
    existing_staff = None
    if ch_id and str(ch_id) in tdata.get("active", {}):
        act_info = tdata["active"][str(ch_id)]
        c_by = act_info.get("claimed_by")
        c_name = act_info.get("claimed_by_name")
        if c_by or (c_name and c_name not in ["Üstlenilmedi", "Henüz Üstlenilmedi", "Yetkili Üstlenmedi"]):
            existing_staff = c_name or "Başka bir yetkili"
    elif record.get("claimed_by_id") or (record.get("claimed_by_name") and record.get("claimed_by_name") not in ["Üstlenilmedi", "Henüz Üstlenilmedi", "Yetkili Üstlenmedi"]):
        existing_staff = record.get("claimed_by_name") or "Başka bir yetkili"

    if existing_staff:
        clean_name = existing_staff.replace("@", "")
        return web.json_response({
            "success": False,
            "already_claimed": True,
            "claimed_by_name": clean_name,
            "message": f"Bu bilet zaten @{clean_name} tarafından üstlenilmiş! Tekrar üstlenilemez."
        }, status=400)

    # 1. tickets.json güncelle
    ticket_info = None
    if ch_id and str(ch_id) in tdata.get("active", {}):
        ticket_info = tdata["active"][str(ch_id)]
        ticket_info["claimed_by"] = int(staff_id)
        ticket_info["claimed_by_name"] = staff_name
        save_tickets(tdata)

    # 2. transcript index güncelle
    record["claimed_by_name"] = staff_name
    record["claimed_by_id"] = str(staff_id)
    save_transcript_index(index_data)

    # 3. DISCORD'DAKİ KARŞILAMA MESAJI EMBED'İNİ GÜNCELLE ('İlgilenen Yetkili' ve güncel sicil alanı)
    if ch_id:
        try:
            await refresh_ticket_welcome_embed(int(ch_id))
            print(f"[Web Claim] Discord karşılama mesajı embedi {staff_name} ile güncellendi.", flush=True)
        except Exception as e:
            print(f"[Web Claim Welcome Embed Güncelleme Hatası]: {e}", flush=True)

    # 4. DISCORD KANALINA ÜSTLENME BİLDİRİMİ GÖNDER
    if target_channel:
        try:
            embed = discord.Embed(
                description=f"Bu destek talebi yetkili {staff_member.mention if staff_member else staff_name} tarafından **web portalı üzerinden üstlenildi**.",
                color=0x5865f2
            )
            await target_channel.send(embed=embed)
        except Exception:
            pass

    # 5. DİSKTEKİ TRANSKRİPT HTML DOSYASINI DA GÜNCELLE
    fpath = record.get("file_path")
    if fpath and os.path.exists(fpath):
        try:
            with open(fpath, "r", encoding="utf-8", errors="replace") as tf:
                thtml = tf.read()
            # Replace 'Henüz Üstlenilmedi' in embed
            thtml = re.sub(
                r'(<div class="embed-field-title">İlgilenen Yetkili</div>\s*<div class="embed-field-content">).*?(</div>)',
                f'\1<span class="user-pill" style="color:#818cf8; font-weight:700;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px;"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg> @{staff_name}</span>\2',
                thtml,
                flags=re.DOTALL
            )
            # Replace metric-card if present
            thtml = re.sub(
                r'(<span class="metric-label">İlgilenen Yetkili</span>\s*<span class="metric-value">).*?(</span>)',
                f'\1<span class="user-pill">@{staff_name}</span>\2',
                thtml,
                flags=re.DOTALL
            )
            # Replace sidebar button text
            thtml = re.sub(
                r'(<span id="claimBtnLabel">).*?(</span>)',
                f'\1@{staff_name}\2',
                thtml
            )
            with open(fpath, "w", encoding="utf-8") as tf:
                tf.write(thtml)
            print(f"[Web Claim] Disk üzerindeki HTML dosyası ({fpath}) güncellendi.", flush=True)
        except Exception as e:
            print(f"[Web Claim HTML Güncelleme Hatası]: {e}", flush=True)

    return web.json_response({
        "success": True,
        "message": f"Talep @{staff_name} adına üstlenildi ve Discord'a yansıtıldı!",
        "claimed_by_name": staff_name
    })


async def handle_ticket_close_web(request: web.Request) -> web.Response:
    """Web portalı üzerinden bileti kapatır ve kilitler."""
    auth_token = request.headers.get("X-Staff-Auth") or request.cookies.get("imza_staff_auth")
    if not auth_token or not await is_valid_staff_session(auth_token):
        return web.json_response({"success": False, "message": "Yetkisiz işlem: Oturum geçersiz."}, status=403)

    session_data = staff_sessions.get(auth_token, {})
    staff_id = session_data.get("user_id")
    try:
        data = await request.json()
    except Exception:
        return web.json_response({"success": False, "message": "Geçersiz veri."}, status=400)

    slug_id = str(data.get("transcript_id", "")).strip()
    reason = str(data.get("reason", "İşlem yetkili tarafından tamamlandı.")).strip() or "İşlem yetkili tarafından tamamlandı."
    send_dm = bool(data.get("send_dm", True))
    archive_log = bool(data.get("archive_log", True))

    index_data = load_transcript_index()
    record = index_data.get(slug_id, {})
    ch_id = record.get("channel_id")
    owner_id = record.get("owner_id")
    ticket_id = record.get("ticket_id", "#0000")
    ch_name = record.get("channel_name", "destek")

    staff_member = None
    target_channel = None
    target_guild = None
    owner_member = None
    for g in bot.guilds:
        if not staff_member and staff_id:
            staff_member = g.get_member(int(staff_id))
        if ch_id and not target_channel:
            target_channel = g.get_channel(int(ch_id))
        if owner_id and not owner_member:
            owner_member = g.get_member(int(owner_id))
        if target_channel:
            target_guild = g
            break

    staff_name = staff_member.display_name if staff_member else "Yetkili"
    now_iso = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    now_str = datetime.now().strftime("%d.%m.%Y %H:%M:%S")

    tdata = load_tickets()
    if ch_id and str(ch_id) in tdata.get("active", {}):
        tdata["active"][str(ch_id)]["status"] = "closed"
        tdata["active"][str(ch_id)]["closed_by"] = int(staff_id)
        tdata["active"][str(ch_id)]["closed_by_name"] = staff_name
        tdata["active"][str(ch_id)]["closed_at"] = now_iso
        tdata["active"][str(ch_id)]["close_reason"] = reason
        save_tickets(tdata)

    record["status"] = "closed"
    record["closed_by_name"] = staff_name
    record["closed_at"] = now_str
    record["close_reason"] = reason
    save_transcript_index(index_data)

    if target_channel and owner_member:
        try:
            await target_channel.set_permissions(owner_member, read_messages=True, send_messages=False, add_reactions=False)
        except Exception:
            pass

    if target_channel:
        try:
            close_embed = discord.Embed(
                title="Bilet Web Portalı Üzerinden Kapatıldı",
                description=(
                    f"Bu destek talebi yetkili **{staff_name}** tarafından sonlandırıldı ve arşivlendi.\n\n"
                    f"• **Kapanış Gerekçesi:** {reason}\n"
                    f"• **Kapatan Yetkili:** {staff_member.mention if staff_member else staff_name}\n"
                    f"• **Tarih:** <t:{int(time.time())}:F>"
                ),
                color=0xed4245,
                timestamp=datetime.now(timezone.utc)
            )
            await target_channel.send(embed=close_embed)
        except Exception:
            pass

    if send_dm and owner_member:
        try:
            dm_embed = discord.Embed(
                title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Bilet Sonlandırıldı",
                description=(
                    f"Merhaba {owner_member.mention},\n\n"
                    f"**{ch_name}** ({ticket_id}) numaralı destek talebiniz yetkili ekibimiz tarafından kapatılmıştır.\n\n"
                    f"• **Gerekçe:** {reason}\n"
                    f"• **İlgilenen Yetkili:** {staff_name}\n"
                    f"• **Tarih:** {now_str}\n\n"
                    f"Hizmetimizle ilgili görüş veya sorularınız için yeni talep açabilirsiniz."
                ),
                color=0x5865f2
            )
            await owner_member.send(embed=dm_embed)
        except Exception:
            pass

    if archive_log and target_guild:
        log_ch_id = config.get("ticket_log_kanal_id")
        if log_ch_id:
            log_ch = target_guild.get_channel(int(log_ch_id))
            if log_ch:
                try:
                    log_embed = discord.Embed(
                        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Bilet Kapatıldı (Web Portalı)",
                        description=(
                            f"**{ch_name}** ({ticket_id}) talebi web yönetim portalı üzerinden kapatıldı.\n\n"
                            f"• **Talep Sahibi:** <@{owner_id}>\n"
                            f"• **Kapatan Yetkili:** {staff_name}\n"
                            f"• **Gerekçe:** {reason}\n"
                            f"• **Transkript Bağlantısı:** [Transkripti İncele]({get_public_web_url()}/transcript/{slug_id})"
                        ),
                        color=0x5865f2,
                        timestamp=datetime.now(timezone.utc)
                    )
                    await log_ch.send(embed=log_embed)
                except Exception:
                    pass

    return web.json_response({
        "success": True,
        "message": "Bilet başarıyla kapatıldı ve arşivlendi!",
        "closed_at": now_str,
        "closed_by": staff_name
    })


async def handle_ticket_set_priority(request: web.Request) -> web.Response:
    """Biletin öncelik seviyesini ayarlar ve Discord kanal ismini önceliğe göre anında günceller."""
    auth_token = request.headers.get("X-Staff-Auth") or request.cookies.get("imza_staff_auth")
    if not auth_token or not await is_valid_staff_session(auth_token):
        return web.json_response({"success": False, "message": "Yetkisiz işlem: Oturum geçersiz."}, status=403)

    try:
        data = await request.json()
    except Exception:
        return web.json_response({"success": False, "message": "Geçersiz format."}, status=400)

    slug_id = str(data.get("transcript_id", "")).strip()
    raw_priority = str(data.get("priority", "Normal")).strip()
    
    # Türkçe karakter & harf duyarlılığı olmadan garantili normalizasyon
    s = raw_priority.replace('İ', 'i').replace('I', 'i').replace('ı', 'i').replace('i', 'i')
    s = s.replace('Ü', 'u').replace('ü', 'u')
    s = s.replace('Ş', 's').replace('ş', 's')
    s = s.replace('Ğ', 'g').replace('ğ', 'g')
    s = s.replace('Ö', 'o').replace('ö', 'o')
    s = s.replace('Ç', 'c').replace('ç', 'c')
    s = s.lower()

    if 'acil' in s:
        priority = "ACİL"
    elif 'yuksek' in s:
        priority = "Yüksek"
    elif 'dusuk' in s:
        priority = "Düşük"
    else:
        priority = "Normal"

    index_data = load_transcript_index()
    record = index_data.get(slug_id, {})
    ch_id = record.get("channel_id")

    tdata = load_tickets()
    if not ch_id:
        for cid, act in tdata.get("active", {}).items():
            if act.get("id") == record.get("ticket_id") or slug_id.startswith(f"talep-{act.get('id', '').replace('#', '')}"):
                ch_id = int(cid)
                break

    # Discord kanalını bul
    target_channel = None
    target_guild = None
    if ch_id:
        for g in bot.guilds:
            c = g.get_channel(int(ch_id))
            if c:
                target_channel = c
                target_guild = g
                break
        if not target_channel:
            try:
                target_channel = await bot.fetch_channel(int(ch_id))
            except Exception:
                target_channel = None

    # Öncelik ön eki belirleme
    prefix_map = {
        "Düşük": "dusuk",
        "Normal": "talep",
        "Yüksek": "yuksek",
        "ACİL": "acil",
        "Acil": "acil"
    }
    prefix = prefix_map.get(priority, "talep")

    color_map = {
        "ACİL": 0xef4444,
        "Acil": 0xef4444,
        "Yüksek": 0xf59e0b,
        "Normal": 0x5865f2,
        "Düşük": 0x10b981
    }

    new_channel_name = None
    old_channel_name = target_channel.name if target_channel else record.get("channel_name", "")

    if target_channel:
        curr_name = target_channel.name.replace("🎫・", "").replace("🔒・", "").replace("🎫", "").replace("🔒", "").strip()
        # Format tespiti: örn talep-0020-6closy veya acil-0020-6closy
        m = re.match(r'^(?:talep|kilit|acil|yuksek|dusuk)-(\d{4})-(.*)$', curr_name)
        if m:
            t_num = m.group(1)
            t_rest = m.group(2)
            new_channel_name = f"{prefix}-{t_num}-{t_rest}"[:30]
        else:
            t_id = record.get("ticket_id") or (tdata.get("active", {}).get(str(ch_id), {}).get("id")) or "#0000"
            t_num = t_id.replace("#", "")
            t_owner = (record.get("owner_name") or tdata.get("active", {}).get(str(ch_id), {}).get("owner_name") or "kullanici").lower()
            new_channel_name = f"{prefix}-{t_num}-{t_owner}"[:30]

        # Discord güncellemelerini arka planda yap (Rate-limit korumalı ve iptal edilmeyen döngü)
        async def _async_discord_priority_update(ch, new_name, p_label, p_color):
            try:
                embed = discord.Embed(
                    description=f"Bu destek talebinin önceliği web portalı üzerinden **{p_label}** olarak güncellendi.\nYeni kanal adı: `#{new_name}`",
                    color=p_color
                )
                await ch.send(embed=embed)
            except Exception as e:
                print(f"[Web Priority Embed]: {e}", flush=True)

            if new_name and ch.name != new_name:
                for attempt in range(5):
                    try:
                        await ch.edit(name=new_name, reason=f"Bilet önceliği web portalından '{p_label}' olarak güncellendi.")
                        print(f"[Web Priority] Kanal adı #{new_name} olarak güncellendi.", flush=True)
                        break
                    except discord.RateLimited as rl:
                        wait_s = getattr(rl, 'retry_after', 5)
                        print(f"[Web Priority] Discord kanal adı düzenleme rate limitinde ({wait_s:.1f}s), bekleniyor...", flush=True)
                        await asyncio.sleep(wait_s + 0.5)
                    except discord.HTTPException as he:
                        if he.status == 429:
                            print(f"[Web Priority] 429 Rate Limit, bekleniyor...", flush=True)
                            await asyncio.sleep(10)
                        else:
                            print(f"[Web Priority Edit HTTPException]: {he}", flush=True)
                            break
                    except Exception as e:
                        print(f"[Web Priority Edit Hatası]: {e}", flush=True)
                        break

        asyncio.create_task(_async_discord_priority_update(target_channel, new_channel_name, priority, color_map.get(priority, 0x5865f2)))

    # Verileri güncelle
    record["priority"] = priority
    if new_channel_name:
        record["channel_name"] = new_channel_name
    save_transcript_index(index_data)

    if ch_id and str(ch_id) in tdata.get("active", {}):
        tdata["active"][str(ch_id)]["priority"] = priority
        if new_channel_name:
            tdata["active"][str(ch_id)]["channel_name"] = new_channel_name
        save_tickets(tdata)

    # Disk üzerindeki HTML transkript dosyasını güncelle
    fpath = record.get("file_path")
    if fpath and os.path.exists(fpath):
        try:
            with open(fpath, "r", encoding="utf-8") as fh:
                thtml = fh.read()
            for p_opt in ["Düşük", "Normal", "Yüksek", "ACİL", "Acil"]:
                thtml = thtml.replace(f'value="{p_opt}" selected', f'value="{p_opt}"')
            thtml = thtml.replace(f'value="{priority}"', f'value="{priority}" selected')
            if new_channel_name and old_channel_name:
                thtml = thtml.replace(f"#{old_channel_name}", f"#{new_channel_name}")
            # Özel Öncelik UI elementlerini de güncelle
            p_cls_map = {"Düşük": "dusuk", "Normal": "normal", "Yüksek": "yuksek", "ACİL": "acil", "Acil": "acil"}
            p_display_map = {"Düşük": "Düşük", "Normal": "Normal", "Yüksek": "Yüksek", "ACİL": "ACİL", "Acil": "ACİL"}
            curr_c = p_cls_map.get(priority, "normal")
            curr_d = p_display_map.get(priority, "Normal")
            thtml = re.sub(r'<span class="priority-dot dot-[^"]*"></span>', f'<span class="priority-dot dot-{curr_c}"></span>', thtml, count=1)
            thtml = re.sub(r'<span class="priority-label-text" id="priorityLabelText">[^<]*</span>', f'<span class="priority-label-text" id="priorityLabelText">{curr_d}</span>', thtml)

            with open(fpath, "w", encoding="utf-8") as fh:
                fh.write(thtml)
        except Exception:
            pass

    return web.json_response({
        "success": True,
        "message": f"Bilet önceliği '{priority}' yapıldı ve Discord kanal adı #{new_channel_name or old_channel_name} olarak güncellendi!",
        "priority": priority,
        "channel_name": new_channel_name or old_channel_name
    })


async def handle_ticket_sync(request: web.Request) -> web.Response:
    """Canlı bilet kanalındaki yeni mesajları Discord'dan senkronize edip HTML akışını döner."""
    auth_token = request.headers.get("X-Staff-Auth") or request.cookies.get("imza_staff_auth") or request.query.get("auth")
    if not auth_token or not await is_valid_staff_session(auth_token):
        return web.json_response({"success": False, "message": "Yetkisiz oturum."}, status=403)

    try:
        data = await request.json()
    except Exception:
        return web.json_response({"success": False, "message": "Geçersiz JSON formatı."}, status=400)

    slug_id = str(data.get("transcript_id", "")).strip()
    if not slug_id:
        return web.json_response({"success": False, "message": "Bilet ID belirtilmedi."}, status=400)

    index_data = load_transcript_index()
    record = index_data.get(slug_id, {})
    ch_id = record.get("channel_id")

    target_channel = None
    if ch_id:
        for g in bot.guilds:
            target_channel = g.get_channel(int(ch_id))
            if target_channel:
                break
    if not target_channel and record.get("channel_name"):
        for g in bot.guilds:
            target_channel = discord.utils.get(g.text_channels, name=record.get("channel_name"))
            if target_channel:
                break

    if not target_channel:
        return web.json_response({
            "success": True,
            "active": False,
            "message": "Bu destek talebi sonlandırılmış (Discord kanalı kapalı)."
        })

    try:
        tdata = load_tickets()
        ticket_info = tdata.get("active", {}).get(str(target_channel.id), record)
        site_url, slug, sec, fpath = await generate_html_transcript(target_channel, ticket_info, existing_slug_id=slug_id)

        messages_html = ""
        msg_count = 0
        if fpath and os.path.exists(fpath):
            with open(fpath, "r", encoding="utf-8") as fh:
                thtml = fh.read()
            m = re.search(r'<div class="msg-stream" id="msgStream">\s*(.*?)\s*</div>\s*</section>', thtml, re.DOTALL)
            if m:
                messages_html = m.group(1)
            mc = re.search(r'id="matchCounter"[^>]*>Toplam (\d+) mesaj</div>', thtml)
            if mc:
                msg_count = int(mc.group(1))

        claimed_name = ticket_info.get("claimed_by_name") if ticket_info else None
        is_claimed = bool(claimed_name and str(claimed_name).lower() not in ["üstlenilmedi", "yetkili üstlenmedi", "henüz üstlenilmedi", "bilinmiyor"])

        return web.json_response({
            "success": True,
            "active": True,
            "total_messages": msg_count,
            "messages_html": messages_html,
            "channel_name": target_channel.name,
            "claimed_by_name": claimed_name or "Henüz Üstlenilmedi",
            "is_claimed": is_claimed
        })
    except Exception as e:
        return web.json_response({"success": False, "message": f"Senkronizasyon hatası: {e}"}, status=500)


async def handle_ticket_stream(request: web.Request) -> web.StreamResponse:
    """Canlı mesajlaşmayı SSE (Server-Sent Events) ile web paneline anında aktarır."""
    tid = request.match_info.get("id", "")
    auth_token = request.headers.get("X-Staff-Auth") or request.cookies.get("imza_staff_auth") or request.query.get("auth")
    if not auth_token or not await is_valid_staff_session(auth_token):
        return web.Response(status=403, text="Yetkisiz oturum.")

    index_data = load_transcript_index()
    record = index_data.get(tid, {})
    ch_id = record.get("channel_id")
    if not ch_id:
        return web.Response(status=404, text="Kanal kaydı bulunamadı.")

    resp = web.StreamResponse(
        status=200,
        reason='OK',
        headers={
            'Content-Type': 'text/event-stream; charset=utf-8',
            'Cache-Control': 'no-cache, no-transform',
            'Connection': 'keep-alive',
            'X-Accel-Buffering': 'no'
        }
    )
    await resp.prepare(request)

    q = asyncio.Queue()
    ticket_sse_listeners[int(ch_id)].append(q)

    try:
        await resp.write(b": keep-alive\n\n")
        while True:
            try:
                # Kanala yeni bir mesaj geldiğinde q tetiklenir
                await asyncio.wait_for(q.get(), timeout=15.0)

                tdata = load_tickets()
                ticket_info = tdata.get("active", {}).get(str(ch_id), record)
                target_channel = bot.get_channel(int(ch_id))
                if not target_channel:
                    try:
                        target_channel = await bot.fetch_channel(int(ch_id))
                    except Exception:
                        target_channel = None

                if target_channel:
                    await generate_html_transcript(target_channel, ticket_info, existing_slug_id=tid)
                    fpath = record.get("file_path")
                    messages_html = ""
                    msg_count = 0
                    if fpath and os.path.exists(fpath):
                        with open(fpath, "r", encoding="utf-8") as fh:
                            thtml = fh.read()
                        m = re.search(r'<div class="msg-stream" id="msgStream">\s*(.*?)\s*</div>\s*</section>', thtml, re.DOTALL)
                        if m:
                            messages_html = m.group(1)
                        mc = re.search(r'id="matchCounter"[^>]*>Toplam (\d+) mesaj</div>', thtml)
                        if mc:
                            msg_count = int(mc.group(1))

                    claimed_name = ticket_info.get("claimed_by_name") if ticket_info else None
                    is_claimed = bool(claimed_name and str(claimed_name).lower() not in ["üstlenilmedi", "yetkili üstlenmedi", "henüz üstlenilmedi", "bilinmiyor"])

                    payload = json.dumps({
                        "messages_html": messages_html,
                        "total_messages": msg_count,
                        "claimed_by_name": claimed_name or "Henüz Üstlenilmedi",
                        "is_claimed": is_claimed
                    })
                    await resp.write(f"data: {payload}\n\n".encode("utf-8"))
            except asyncio.TimeoutError:
                await resp.write(b": ping\n\n")
    except (asyncio.CancelledError, ConnectionResetError):
        pass
    finally:
        if int(ch_id) in ticket_sse_listeners and q in ticket_sse_listeners[int(ch_id)]:
            ticket_sse_listeners[int(ch_id)].remove(q)
    return resp


async def handle_ticket_delete_web(request: web.Request) -> web.Response:
    """Web portalından bileti sonlandırır, Discord kanalını siler veya arşivden tamamen temizler."""
    auth_token = request.headers.get("X-Staff-Auth") or request.cookies.get("imza_staff_auth")
    if not auth_token or not await is_valid_staff_session(auth_token):
        return web.json_response({"success": False, "message": "Yetkisiz işlem: Oturum geçersiz."}, status=403)

    session_data = staff_sessions.get(auth_token, {})
    staff_user_id = session_data.get("user_id")

    try:
        data = await request.json()
    except Exception:
        return web.json_response({"success": False, "message": "Geçersiz veri."}, status=400)

    ticket_id = str(data.get("ticket_id", "")).strip()
    slug = str(data.get("slug", "")).strip()

    if not ticket_id and not slug:
        return web.json_response({"success": False, "message": "Bilet ID veya slug belirtilmedi."}, status=400)

    staff_name = "Yetkili"
    guild = bot.guilds[0] if bot.guilds else None
    if staff_user_id and guild:
        m = guild.get_member(staff_user_id)
        if m:
            staff_name = m.display_name or m.name

    # 1. Aktif canlı biletlerde var mı kontrol et
    tdata = load_tickets()
    active_tickets = tdata.get("active", {})
    found_channel_id = None
    target_info = None

    clean_target = ticket_id.replace("#", "").strip().lower()
    for cid_str, info in list(active_tickets.items()):
        curr_id = str(info.get("id", "")).replace("#", "").strip().lower()
        if (clean_target and curr_id == clean_target) or str(cid_str) == ticket_id or (slug and slug == info.get("slug")) or (clean_target and slug and f"talep-{clean_target}" in slug):
            found_channel_id = int(cid_str)
            target_info = active_tickets.pop(cid_str)
            save_tickets(tdata)
            break

    # Canlı açık bilet ise Discord kanalını transkriptleyip sil
    if found_channel_id and guild:
        ch = guild.get_channel(found_channel_id)
        if ch:
            try:
                site_url, transcript_slug, secret_key, file_path = await generate_html_transcript(ch, target_info)
                log_ch_id = config.get("ticket_log_kanal_id")
                if log_ch_id:
                    log_ch = guild.get_channel(int(log_ch_id))
                    if log_ch:
                        owner_mention = f"<@{target_info.get('owner_id')}>" if target_info else "Bilinmiyor"
                        log_desc = (
                            f"**#{ch.name}** kanalı web portalı üzerinden yetkili tarafından silindi ve arşivlendi.\n\n"
                            f"• **Talep Sahibi:** {owner_mention}\n"
                            f"• **Silen Yetkili:** {staff_name} (`{staff_user_id}`)\n"
                            f"• **Kategori:** `{target_info.get('category', 'Destek') if target_info else 'Destek'}`\n\n"
                            f"*Web transkript kaydı arşive işlendi.*"
                        )
                        log_embed = discord.Embed(
                            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Destek Talebi Web'den Silindi",
                            description=log_desc,
                            color=0xed4245,
                            timestamp=datetime.now(timezone.utc)
                        )
                        view = TranscriptDynamicView(transcript_slug)
                        await log_ch.send(embed=log_embed, view=view)
                await ch.delete(reason=f"Web portalı üzerinden {staff_name} tarafından silindi.")
            except Exception as e:
                print(f"[Web Kanal Silme Hatası]: {e}", flush=True)

    # 2. Arşiv kaydı / index.json ve transkript dosyasından temizle
    index_data = load_transcript_index()
    removed_from_index = False
    for s_key, rec in list(index_data.items()):
        rec_id = str(rec.get("ticket_id", "")).replace("#", "").strip().lower()
        if (clean_target and rec_id == clean_target) or s_key == slug or (clean_target and f"talep-{clean_target}" in s_key):
            index_data.pop(s_key, None)
            removed_from_index = True
            html_file = os.path.join(TRANSCRIPTS_DIR, f"{s_key}.html")
            if os.path.exists(html_file):
                try:
                    os.remove(html_file)
                except Exception:
                    pass

    if removed_from_index:
        save_transcript_index(index_data)

    return web.json_response({
        "success": True,
        "message": f"{ticket_id} destek talebi başarıyla silindi.",
        "ticket_id": ticket_id
    })


async def handle_ticket_sync_check(request: web.Request) -> web.Response:
    """Web portalı için canlı bilet durum kontrolü ve arka plan senkronizasyonu."""
    auth_token = request.headers.get("X-Staff-Auth") or request.cookies.get("imza_staff_auth")
    if not auth_token or not await is_valid_staff_session(auth_token):
        return web.json_response({"success": False, "authenticated": False}, status=401)

    first_guild = bot.guilds[0] if bot.guilds else None
    tdata = load_tickets()
    active_tickets = tdata.get("active", {})
    tdata_dirty = False
    valid_active = {}

    for cid, act in list(active_tickets.items()):
        ch = None
        if first_guild:
            try:
                ch = first_guild.get_channel(int(cid))
                if not ch and bot.is_ready():
                    try:
                        ch = await bot.fetch_channel(int(cid))
                    except (discord.NotFound, discord.Forbidden):
                        ch = None
            except Exception:
                ch = None

        if first_guild and not ch:
            active_tickets.pop(cid, None)
            tdata_dirty = True
        else:
            valid_active[cid] = act

    if tdata_dirty:
        tdata["active"] = active_tickets
        save_tickets(tdata)

    index_data = load_transcript_index()
    all_tickets = []
    seen_ids = set()

    for cid, act in valid_active.items():
        t_id = act.get("id", "#0000")
        seen_ids.add(t_id)
        ch_name = f"talep-{t_id.replace('#', '')}-{act.get('owner_name', '').lower()}"
        if first_guild:
            ch_obj = first_guild.get_channel(int(cid))
            if ch_obj:
                ch_name = ch_obj.name

        slug = None
        for sid, rec in index_data.items():
            if rec.get("ticket_id") == t_id or str(rec.get("channel_id")) == str(cid):
                slug = sid
                break
        if not slug:
            for fn in os.listdir(TRANSCRIPTS_DIR):
                if fn.startswith(f"talep-{t_id.replace('#', '')}") and fn.endswith(".html"):
                    slug = fn[:-5]
                    break

        is_closed_status = (act.get("status") == "closed") or (ch_name.startswith("kilit-"))
        t_status = "closed" if is_closed_status else "open"

        all_tickets.append({
            "ticket_id": t_id,
            "channel_name": ch_name,
            "owner_name": act.get("owner_name", "Kullanıcı"),
            "owner_id": str(act.get("owner_id", "")),
            "category": act.get("category", "Genel Destek"),
            "subject": act.get("subject", ""),
            "claimed_by_name": act.get("claimed_by_name") or "Henüz Üstlenilmedi",
            "status": t_status,
            "created_at": act.get("created_at", ""),
            "slug": slug or f"talep-{t_id.replace('#', '')}"
        })

    for sid, rec in reversed(list(index_data.items())):
        t_id = rec.get("ticket_id", "#0000")
        if t_id in seen_ids:
            continue
        seen_ids.add(t_id)
        all_tickets.append({
            "ticket_id": t_id,
            "channel_name": rec.get("channel_name", sid),
            "owner_name": rec.get("owner_name", "Kullanıcı"),
            "owner_id": str(rec.get("owner_id", "")),
            "category": rec.get("category", "Genel Destek"),
            "subject": rec.get("subject", ""),
            "claimed_by_name": rec.get("claimed_by_name") or "Üstlenilmedi",
            "status": "closed",
            "created_at": rec.get("created_at", ""),
            "slug": sid
        })

    active_count = sum(1 for t in all_tickets if t["status"] == "open")
    closed_count = sum(1 for t in all_tickets if t["status"] == "closed")

    return web.json_response({
        "success": True,
        "active_count": active_count,
        "closed_count": closed_count,
        "total_count": len(all_tickets),
        "tickets": all_tickets
    })


async def handle_user_history(request: web.Request) -> web.Response:
    """Kullanıcının geçmiş bilet ve uyarı dökümünü getirir."""
    auth_token = request.headers.get("X-Staff-Auth") or request.cookies.get("imza_staff_auth")
    if not auth_token or not await is_valid_staff_session(auth_token):
        return web.json_response({"success": False, "message": "Yetkisiz işlem."}, status=403)

    user_id = str(request.query.get("user_id", "")).strip()
    if not user_id:
        return web.json_response({"success": False, "message": "Kullanıcı ID gerekli."}, status=400)

    index_data = load_transcript_index()
    user_tickets = []
    for sid, rec in index_data.items():
        if str(rec.get("owner_id")) == user_id:
            user_tickets.append({
                "slug_id": sid,
                "ticket_id": rec.get("ticket_id", "#0000"),
                "channel_name": rec.get("channel_name", ""),
                "category": rec.get("category", "Genel Destek"),
                "created_at": rec.get("created_at", ""),
                "status": rec.get("status", "closed")
            })

    tdata = load_tickets()
    for cid, act in tdata.get("active", {}).items():
        if str(act.get("owner_id")) == user_id:
            if not any(t["ticket_id"] == act.get("id") for t in user_tickets):
                user_tickets.insert(0, {
                    "slug_id": f"channel_{cid}",
                    "ticket_id": act.get("id", "#0000"),
                    "channel_name": f"talep-{act.get('id', '').replace('#', '')}",
                    "category": act.get("category", "Destek"),
                    "created_at": act.get("created_at", ""),
                    "status": "open"
                })

    user_warns_file = os.path.join(TRANSCRIPTS_DIR, f"{user_id}_warnings.json")
    warnings = []
    if os.path.exists(user_warns_file):
        try:
            with open(user_warns_file, "r", encoding="utf-8") as wf:
                warnings = json.load(wf)
        except Exception:
            warnings = []

    welcome_cfg_path = os.path.join(BASE_DIR, "..", "imza-welcome-bot", "config.json")
    guard_count = 0
    if os.path.exists(welcome_cfg_path):
        try:
            with open(welcome_cfg_path, "r", encoding="utf-8") as wcf:
                guard_count = int(json.load(wcf).get("guard_uyarilar", {}).get(user_id, 0))
        except Exception:
            guard_count = 0

    return web.json_response({
        "success": True,
        "user_id": user_id,
        "total_tickets": len(user_tickets),
        "tickets": user_tickets,
        "warnings": warnings,
        "guard_count": guard_count
    })


async def handle_active_tunnel_url(request: web.Request) -> web.Response:
    """Aktif ve doğrulanmış canlı web tüneli URL'sini döner."""
    url = get_public_web_url()
    return web.json_response({
        "success": True,
        "url": url,
        "is_trycloudflare": "trycloudflare.com" in url
    })

def get_user_warnings(user_id: int | str) -> list:
    """Kullanıcının kaydedilmiş tüm sicil ve uyarı geçmişini getirir."""
    user_warns_file = os.path.join(TRANSCRIPTS_DIR, f"{user_id}_warnings.json")
    if os.path.exists(user_warns_file):
        try:
            with open(user_warns_file, "r", encoding="utf-8") as wf:
                return json.load(wf)
        except Exception:
            return []
    return []

def add_user_warning(user_id: int | str, warn_data: dict) -> list:
    """Kullanıcının sicil dosyasına yeni bir uyarı/ceza kaydı ekler."""
    user_warns_file = os.path.join(TRANSCRIPTS_DIR, f"{user_id}_warnings.json")
    warns = get_user_warnings(user_id)
    warns.append(warn_data)
    try:
        with open(user_warns_file, "w", encoding="utf-8") as wf:
            json.dump(warns, wf, ensure_ascii=False, indent=2)
    except Exception:
        pass
    return warns

def clear_user_warnings(user_id: int | str) -> bool:
    """Kullanıcının tüm sicil ve uyarı dosyasını sıfırlar."""
    uid = str(user_id)
    user_warns_file = os.path.join(TRANSCRIPTS_DIR, f"{uid}_warnings.json")
    removed = False
    if os.path.exists(user_warns_file):
        try:
            os.remove(user_warns_file)
            removed = True
        except Exception:
            pass

    # Welcome-bot guard uyarısı varsa onu da temizle
    welcome_cfg_path = os.path.join(BASE_DIR, "..", "imza-welcome-bot", "config.json")
    if os.path.exists(welcome_cfg_path):
        try:
            with open(welcome_cfg_path, "r", encoding="utf-8") as wf:
                wcfg = json.load(wf)
            if "guard_uyarilar" in wcfg and uid in wcfg["guard_uyarilar"]:
                del wcfg["guard_uyarilar"][uid]
                with open(welcome_cfg_path, "w", encoding="utf-8") as wf:
                    json.dump(wcfg, wf, ensure_ascii=False, indent=2)
                removed = True
        except Exception:
            pass

    return True

def delete_user_warning_by_index(user_id: int | str, warn_index: int) -> bool:
    """Kullanıcının sicilinden belirli indeksteki tek bir uyarıyı siler."""
    uid = str(user_id)
    user_warns_file = os.path.join(TRANSCRIPTS_DIR, f"{uid}_warnings.json")
    warns = get_user_warnings(uid)
    if not warns or warn_index < 0 or warn_index >= len(warns):
        return False
    warns.pop(warn_index)
    try:
        if warns:
            with open(user_warns_file, "w", encoding="utf-8") as wf:
                json.dump(warns, wf, ensure_ascii=False, indent=2)
        else:
            if os.path.exists(user_warns_file):
                os.remove(user_warns_file)
        return True
    except Exception as e:
        print(f"[delete_user_warning_by_index Hata]: {e}", flush=True)
        return False

def delete_user_warnings_by_indices(user_id: int | str, indices: list) -> list:
    """Kullanıcının sicilinden belirtilen indekslerdeki uyarıları siler ve silinen kayıtları döndürür."""
    uid = str(user_id)
    user_warns_file = os.path.join(TRANSCRIPTS_DIR, f"{uid}_warnings.json")
    warns = get_user_warnings(uid)
    if not warns:
        return []
    sorted_indices = sorted(set(int(i) for i in indices), reverse=True)
    deleted = []
    for idx in sorted_indices:
        if 0 <= idx < len(warns):
            deleted.append(warns.pop(idx))
    try:
        if warns:
            with open(user_warns_file, "w", encoding="utf-8") as wf:
                json.dump(warns, wf, ensure_ascii=False, indent=2)
        else:
            if os.path.exists(user_warns_file):
                os.remove(user_warns_file)
    except Exception as e:
        print(f"[delete_user_warnings_by_indices Hata]: {e}", flush=True)
    return deleted


def get_user_sicil_display(user: Any, guild: Optional[discord.Guild] = None) -> tuple[str, str]:
    """Kullanıcının Discord sicil kaydını, kaç ceza aldığını ve neyden aldığını formatlar."""
    if hasattr(user, "id"):
        user_id = user.id
        member_obj = user if isinstance(user, discord.Member) else None
    else:
        try:
            user_id = int(user)
        except Exception:
            user_id = 0
        member_obj = guild.get_member(user_id) if (guild and user_id) else None

    warns = get_user_warnings(user_id)
    
    # Welcome bot guard uyarısı var mı kontrol et
    guard_count = 0
    welcome_cfg_path = os.path.join(BASE_DIR, "..", "imza-welcome-bot", "config.json")
    if os.path.exists(welcome_cfg_path):
        try:
            with open(welcome_cfg_path, "r", encoding="utf-8") as wf:
                wcfg = json.load(wf)
                guard_count = int(wcfg.get("guard_uyarilar", {}).get(str(user_id), 0))
        except Exception:
            pass

    is_timeout = False
    timeout_str = ""
    if member_obj and hasattr(member_obj, "is_timed_out") and member_obj.is_timed_out():
        is_timeout = True
        if member_obj.timed_out_until:
            timeout_str = f"⏳ **Aktif Timeout Cezası:** <t:{int(member_obj.timed_out_until.timestamp())}:R> sona eriyor"

    total_count = len(warns) + guard_count

    if total_count == 0 and not is_timeout:
        status_line = "🟢 `Temiz Profil` (0 İhtar / Ceza Kaydı)"
        details_line = "> ✅ Bu üyenin geçmişe ait herhangi bir ceza, ihtar veya kural ihlali kaydı bulunmamaktadır."
        return status_line, details_line

    if total_count >= 3:
        status_line = f"🔴 `Riskli Profil` — **{total_count}** Kayıt (İhlal Seviyesi Yüksek)"
    elif total_count > 0:
        status_line = f"🟡 `İhtarlı Profil` — **{total_count}** Kayıt Mevcut"
    else:
        status_line = f"🟠 `Kısıtlı Profil` — Aktif Ceza Uygulanmış"

    lines = []
    if is_timeout:
        lines.append(f"> 🚫 {timeout_str}")
    if guard_count > 0:
        lines.append(f"> 🛡️ **[Guard Koruması]:** Yetkisiz işlem sebebiyle `{guard_count}` guard ihlal uyarısı kaydedilmiş.")

    for idx, w in enumerate(reversed(warns[-6:]), 1):
        w_type = w.get("warn_type", "İhtar/Uyarı")
        w_reason = w.get("reason", "Sebep belirtilmedi")
        w_staff = w.get("staff_name", "Yetkili")
        w_time = w.get("timestamp", "")
        w_tid = w.get("ticket_id", "Manuel Sicil")
        
        lines.append(
            f"> ⚠️ **[{idx}] {w_type}** • `{w_time}`\n"
            f"> └ **Neyden Aldı:** {w_reason}\n"
            f"> └ **Yetkili:** `{w_staff}` • **Kaynak:** `{w_tid}`"
        )

    if len(warns) > 6:
        lines.append(f"> *... ve arşivde {len(warns) - 6} adet daha eski sicil kaydı bulunmaktadır.*")

    details_line = "\n".join(lines)
    if len(details_line) > 1024:
        details_line = details_line[:1015] + "\n> *...*"
        
    return status_line, details_line

def build_ticket_welcome_embed(ticket_info: dict, user: Any, guild: Optional[discord.Guild] = None) -> discord.Embed:
    """Destek talebi karşılama embed'ini sade, şık ve temiz olarak derler."""
    ticket_id = ticket_info.get("id", "#0000")
    cat_label = ticket_info.get("category", "Destek")
    claimed_by_id = ticket_info.get("claimed_by")
    claimed_by_name = ticket_info.get("claimed_by_name", "Henüz Üstlenilmedi")
    subject = ticket_info.get("subject", "Belirtilmedi")
    description = ticket_info.get("description", "Belirtilmedi")

    if claimed_by_id:
        claimed_val = f"<@{claimed_by_id}> (`{claimed_by_name}`)"
    else:
        claimed_val = "`Henüz Üstlenilmedi`"

    user_mention = user.mention if hasattr(user, "mention") else f"<@{ticket_info.get('owner_id')}>"
    user_name = user.name if hasattr(user, "name") else ticket_info.get("owner_name", "Kullanıcı")

    welcome_embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Destek Talebi {ticket_id}",
        description=(
            f"Merhaba {user_mention}, **{cat_label}** talebiniz oluşturuldu.\n"
            f"Yetkili ekibimiz en kısa sürede sizinle iletişime geçecektir.\n"
        ),
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    welcome_embed.add_field(name="Talep Sahibi", value=f"{user_mention} (`{user_name}`)", inline=True)
    welcome_embed.add_field(name="Kategori", value=f"`{cat_label}`", inline=True)
    welcome_embed.add_field(name="İlgilenen Yetkili", value=claimed_val, inline=True)
    welcome_embed.add_field(name="Konu", value=f"```{subject}```", inline=False)
    welcome_embed.add_field(name="Açıklama", value=f"```{description}```", inline=False)
    welcome_embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Bilet Yönetimi")

    if guild:
        logo = get_brand_logo_url(guild)
        if logo:
            welcome_embed.set_thumbnail(url=logo)

    return welcome_embed

def build_ticket_sicil_embed(user: Any, guild: Optional[discord.Guild] = None) -> tuple[discord.Embed, discord.ui.View]:
    """İlk görseldeki formatta bağımsız, şık ve butonlu Kullanıcı Sicil Bilgileri kartını üretir."""
    if hasattr(user, "id"):
        user_id = user.id
        member_obj = user if isinstance(user, discord.Member) else None
        user_mention = user.mention
        user_name = user.name
        avatar_url = user.display_avatar.url if hasattr(user, "display_avatar") and user.display_avatar else None
    else:
        try:
            user_id = int(user)
        except Exception:
            user_id = 0
        member_obj = guild.get_member(user_id) if (guild and user_id) else None
        user_mention = f"<@{user_id}>"
        user_name = member_obj.name if member_obj else f"Kullanici_{user_id}"
        avatar_url = member_obj.display_avatar.url if (member_obj and member_obj.display_avatar) else None

    warns = get_user_warnings(user_id)
    active_t, closed_t = get_user_tickets_summary(user_id)
    total_t = len(active_t) + len(closed_t)

    # Welcome-bot guard uyarısı
    guard_count = 0
    welcome_cfg_path = os.path.join(BASE_DIR, "..", "imza-welcome-bot", "config.json")
    if os.path.exists(welcome_cfg_path):
        try:
            with open(welcome_cfg_path, "r", encoding="utf-8") as wf:
                wcfg = json.load(wf)
                guard_count = int(wcfg.get("guard_uyarilar", {}).get(str(user_id), 0))
        except Exception:
            pass

    is_timeout = False
    timeout_text = "Temiz"
    if member_obj and hasattr(member_obj, "is_timed_out") and member_obj.is_timed_out():
        is_timeout = True
        if member_obj.timed_out_until:
            timeout_text = f"Aktif Timeout (<t:{int(member_obj.timed_out_until.timestamp())}:R> bitiyor)"

    total_count = len(warns) + guard_count

    if total_count == 0 and not is_timeout:
        status_text = "Temiz Profil (0 Kayıt)"
        quote_bar = "┃ Bu kullanıcının arşivinde herhangi bir ceza veya ihlal kaydı bulunmamaktadır."
        embed_color = 0x22c55e
    elif total_count >= 3:
        status_text = f"Riskli Profil ({total_count} Kayıt)"
        quote_bar = f"┃ Bu kullanıcıya ait toplam **{total_count}** adet sicil/ihlal kaydı tespit edildi!"
        embed_color = 0xef4444
    elif total_count > 0:
        status_text = f"İhtarlı Profil ({total_count} Kayıt)"
        quote_bar = f"┃ Bu kullanıcıya ait **{total_count}** adet sicil kaydı bulundu."
        embed_color = 0xf59e0b
    else:
        status_text = "Kısıtlı Profil (Aktif Ceza)"
        quote_bar = "┃ Bu kullanıcının aktif kısıtlaması bulunmaktadır."
        embed_color = 0xf97316

    created_str = f"<t:{int(member_obj.created_at.timestamp())}:D>" if member_obj and member_obj.created_at else "Bilinmiyor"
    joined_str = f"<t:{int(member_obj.joined_at.timestamp())}:D>" if member_obj and member_obj.joined_at else "Bilinmiyor"

    desc = (
        f"{quote_bar}\n\n"
        f"**Kullanıcı:** {user_mention} (`{user_name}`) · **ID:** `{user_id}`\n"
        f"**Sicil Durumu:** `{status_text}`\n"
        f"**Aktif Yaptırım:** {timeout_text}\n"
        f"**Destek Talepleri:** `{total_t}` Adet (`{len(active_t)}` Aktif, `{len(closed_t)}` Kapalı)\n"
        f"**Hesap Açılış:** {created_str} · **Katılım:** {joined_str}\n"
    )

    if guard_count > 0:
        desc += f"**Sunucu Koruma:** `{guard_count} Guard Güvenlik İhlali`\n"

    if warns:
        desc += "\n**Kayıtlı İhtar & Cezalar:**\n"
        for idx, w in enumerate(reversed(warns[-4:]), 1):
            w_type = w.get("warn_type", "Uyarı")
            w_reason = w.get("reason", "Belirtilmedi")
            w_staff = w.get("staff_name", "Yetkili")
            w_time = w.get("timestamp", "").split(" ")[0] if w.get("timestamp") else ""
            desc += f"> **[{idx}] {w_type}** · `{w_time}`\n"
            desc += f"> └ **Neyden Aldı:** `{w_reason}`\n"
            desc += f"> └ **Yetkili:** `{w_staff}` · **Kaynak:** `{w.get('ticket_id', 'Manuel')}`\n"
        if len(warns) > 4:
            desc += f"> *... ve arşivde {len(warns) - 4} adet daha eski sicil kaydı bulunmaktadır.*\n"
    else:
        desc += "\n**Kayıtlı İhtar & Cezalar:**\n> Kullanıcının arşivinde kayıtlı herhangi bir ceza bulunmamaktadır.\n"

    embed = discord.Embed(
        title="Kullanıcı Sicil & Profil Bilgileri",
        description=desc.strip(),
        color=embed_color,
        timestamp=datetime.now(timezone.utc)
    )
    if avatar_url:
        embed.set_thumbnail(url=avatar_url)

    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Resmi Sicil & Denetim Sistemi")

    base_url = get_public_web_url()
    sicil_web_url = f"{base_url}/sicil/{user_id}"

    view = discord.ui.View()
    view.add_item(discord.ui.Button(
        label="Sicil Dosyasını Görüntüle",
        url=sicil_web_url,
        style=discord.ButtonStyle.link
    ))
    view.add_item(discord.ui.Button(
        label="Destek Geçmişi",
        url=f"{sicil_web_url}#talepler",
        style=discord.ButtonStyle.link
    ))

    return embed, view

def render_public_user_sicil_html(
    user_id: int | str,
    member_obj: Optional[Any],
    warns: list,
    active_tickets: list,
    closed_tickets: list,
    guild: Optional[discord.Guild] = None,
    is_staff: bool = False,
    guard_count: int = 0
) -> str:
    """Kullanıcının kendi sicilini ve destek geçmişini görüntülediği modern, emojilerden arındırılmış web arayüzü."""
    bot_name = html.escape(config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ"))
    user_name = html.escape(member_obj.name if member_obj else f"Kullanici_{user_id}")
    user_display = html.escape(member_obj.display_name if hasattr(member_obj, "display_name") else user_name)
    avatar_url = member_obj.display_avatar.url if (member_obj and hasattr(member_obj, "display_avatar") and member_obj.display_avatar) else "https://cdn.discordapp.com/embed/avatars/0.png"
    logo_url = get_brand_logo_url(guild) or avatar_url

    total_records = len(warns) + guard_count
    total_tickets = len(active_tickets) + len(closed_tickets)

    created_str = member_obj.created_at.strftime("%d.%m.%Y %H:%M") if member_obj and hasattr(member_obj, "created_at") and member_obj.created_at else "Bilinmiyor"
    joined_str = member_obj.joined_at.strftime("%d.%m.%Y %H:%M") if member_obj and hasattr(member_obj, "joined_at") and member_obj.joined_at else "Bilinmiyor"

    is_timeout = False
    if member_obj and hasattr(member_obj, "is_timed_out") and member_obj.is_timed_out():
        is_timeout = True

    if total_records == 0 and not is_timeout:
        badge_class = "badge-clean"
        badge_text = "Temiz Profil (Güvenilirlik: Yüksek)"
        avatar_glow = "rgba(16, 185, 129, 0.35)"
        accent_color = "#10b981"
    elif total_records >= 3:
        badge_class = "badge-risky"
        badge_text = f"Riskli Profil ({total_records} Kayıt - Yüksek İhlal)"
        avatar_glow = "rgba(239, 68, 68, 0.35)"
        accent_color = "#ef4444"
    elif total_records > 0:
        badge_class = "badge-warned"
        badge_text = f"İhtarlı Profil ({total_records} Kayıt)"
        avatar_glow = "rgba(245, 158, 11, 0.35)"
        accent_color = "#f59e0b"
    else:
        badge_class = "badge-warned"
        badge_text = "Kısıtlı Profil (Aktif Ceza)"
        avatar_glow = "rgba(249, 115, 22, 0.35)"
        accent_color = "#f97316"

    staff_badge_html = ""
    if is_staff:
        staff_badge_html = """
        <div class="staff-tag-badge">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            <span>Yetkili Modu (0)</span>
        </div>
        """

    guard_html = ""
    if guard_count > 0:
        for g_idx in range(1, guard_count + 1):
            guard_html += f"""
            <div class="warn-card" style="border-color: rgba(239, 68, 68, 0.3); background: rgba(239, 68, 68, 0.04);">
                <div class="warn-top">
                    <div class="warn-badge-wrap">
                        <span class="warn-badge" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border-color: rgba(239, 68, 68, 0.3);">#G{g_idx} Guard Güvenlik İhlali</span>
                    </div>
                    <div class="warn-top-right">
                        <div class="warn-time">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                            <span>Otomatik Sistem</span>
                        </div>
                        {f'''<button type="button" class="btn-warn-delete" onclick="promptClearAll()" title="Tüm Sicil ve Guard Kaydını Sil (0)">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                            <span>Sicili Sil</span>
                        </button>''' if is_staff else ''}
                    </div>
                </div>
                <div class="warn-reason-box" style="border-color: rgba(239, 68, 68, 0.15);">
                    <div class="warn-reason-lbl" style="color: #fca5a5;">Neyden Sicil Aldı (Gerekçe)</div>
                    <div class="warn-reason-text">Sunucu koruma (Guard) sistemi tarafından güvenlik ihlali tespit edildi ve işlem uygulandı.</div>
                </div>
                <div class="warn-footer">
                    <span class="meta-chip">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        İşlem: <strong style="color: #fca5a5;">Welcome / Guard Bot</strong>
                    </span>
                    <span class="meta-chip">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/></svg>
                        Kaynak: <strong style="color: #818cf8;">Security Guard</strong>
                    </span>
                </div>
            </div>
            """

    normal_warns_html = ""
    if warns:
        for idx, w in enumerate(reversed(warns), 1):
            real_idx = len(warns) - idx
            w_type = html.escape(str(w.get("warn_type", "Uyarı / İhtar")))
            w_reason = html.escape(str(w.get("reason", "Gerekçe belirtilmedi.")))
            w_staff = html.escape(str(w.get("staff_name", "Yetkili")))
            w_time = html.escape(str(w.get("timestamp", "-")))
            w_ticket = html.escape(str(w.get("ticket_id", "Manuel Sicil")))
            normal_warns_html += f"""
            <div class="warn-card" id="warn-card-{real_idx}">
                <div class="warn-top">
                    <div class="warn-badge-wrap">
                        <span class="warn-badge">#{idx} {w_type}</span>
                    </div>
                    <div class="warn-top-right">
                        <div class="warn-time">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                            <span>{w_time}</span>
                        </div>
                        {f'''<button type="button" class="btn-warn-delete" onclick="promptDeleteWarn({real_idx})" title="Sicil Kaydını Sil (0)">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                            <span>Sicili Sil</span>
                        </button>''' if is_staff else ''}
                    </div>
                </div>
                <div class="warn-reason-box">
                    <div class="warn-reason-lbl">Neyden Sicil Aldı (Gerekçe)</div>
                    <div class="warn-reason-text">{w_reason}</div>
                </div>
                <div class="warn-footer">
                    <span class="meta-chip">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        İşlem Yapan: <strong>@{w_staff}</strong>
                    </span>
                    <span class="meta-chip">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/></svg>
                        Kaynak Bilet: <strong>{w_ticket}</strong>
                    </span>
                </div>
            </div>
            """

    if guard_html or normal_warns_html:
        warns_html = guard_html + normal_warns_html
    else:
        warns_html = """
        <div class="clean-state">
            <div class="clean-icon-wrap">
                <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                    <polyline points="9 12 11 14 15 10"/>
                </svg>
            </div>
            <h3>Sicil Dosyası Temiz</h3>
            <p>Bu kullanıcının sunucumuzda kayıtlı herhangi bir ceza, ihtar veya kural ihlali kaydı bulunmamaktadır.</p>
        </div>
        """

    tickets_rows = ""
    all_tickets = active_tickets + closed_tickets
    if all_tickets:
        for t in all_tickets:
            t_id = html.escape(str(t.get("ticket_id", "#0000")))
            t_cat = html.escape(str(t.get("category", "Destek")))
            t_date = html.escape(str(t.get("created_at", "-")))
            is_active = "channel_id" in t
            if is_active:
                status_badge = '<span class="pill-status pill-open"><span class="status-pulse-dot"></span>Açık / Aktif</span>'
            else:
                status_badge = '<span class="pill-status pill-closed">Arşivlendi</span>'
            tickets_rows += f"""
            <tr class="ticket-row" data-search="{t_id.lower()} {t_cat.lower()}">
                <td class="col-id">{t_id}</td>
                <td class="col-cat">{t_cat}</td>
                <td>{status_badge}</td>
                <td class="col-date">{t_date}</td>
            </tr>
            """
    else:
        tickets_rows = '<tr id="noTicketsRow"><td colspan="4" style="text-align:center; color:#94a3b8; padding:32px;">Kayıtlı destek talebi bulunmuyor.</td></tr>'

    return f"""<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{user_display} • Resmi Sicil Dosyası | {bot_name}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --bg-base: #08090d;
            --card-bg: rgba(15, 18, 28, 0.75);
            --card-border: rgba(255, 255, 255, 0.08);
            --card-border-hover: rgba(255, 255, 255, 0.16);
            --text-primary: #f8fafc;
            --text-secondary: #cbd5e1;
            --text-muted: #8492a6;
            --accent-main: #6366f1;
            --avatar-glow: {avatar_glow};
            --accent-state: {accent_color};
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            background: var(--bg-base);
            color: var(--text-primary);
            font-family: 'Plus Jakarta Sans', -apple-system, sans-serif;
            min-height: 100vh;
            padding: 40px 20px 80px;
            background-image: 
                radial-gradient(circle at 15% 10%, rgba(99, 102, 241, 0.10) 0%, transparent 45%),
                radial-gradient(circle at 85% 85%, rgba(139, 92, 246, 0.08) 0%, transparent 45%),
                radial-gradient(circle at 50% 50%, rgba(15, 23, 42, 0.6) 0%, transparent 70%);
            background-attachment: fixed;
            text-rendering: optimizeLegibility;
            -webkit-font-smoothing: antialiased;
        }}
        .container {{ max-width: 960px; margin: 0 auto; }}

        .top-nav {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 28px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--card-border);
        }}
        .brand {{ display: flex; align-items: center; gap: 14px; }}
        .brand-logo {{
            width: 44px;
            height: 44px;
            border-radius: 12px;
            object-fit: cover;
            border: 1px solid rgba(255, 255, 255, 0.12);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
        }}
        .brand-title {{
            font-size: 17px;
            font-weight: 800;
            letter-spacing: 0.5px;
            background: linear-gradient(135deg, #ffffff 40%, #94a3b8 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .brand-sub {{
            font-size: 12px;
            color: var(--text-muted);
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 6px;
        }}
        .brand-sub::before {{
            content: '';
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: #10b981;
            display: inline-block;
        }}
        .nav-actions {{ display: flex; gap: 10px; }}
        .btn-action {{
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 9px 18px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--card-border);
            color: var(--text-secondary);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
            text-decoration: none;
            backdrop-filter: blur(10px);
        }}
        .btn-action:hover {{
            background: rgba(255, 255, 255, 0.08);
            border-color: var(--card-border-hover);
            color: #ffffff;
            transform: translateY(-1px);
        }}
        .btn-action svg {{ stroke: currentColor; }}

        .profile-card {{
            background: var(--card-bg);
            backdrop-filter: blur(24px);
            border: 1px solid var(--card-border);
            border-radius: 24px;
            padding: 32px;
            margin-bottom: 32px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 16px 36px -10px rgba(0, 0, 0, 0.5);
        }}
        .profile-card::before {{
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; height: 3px;
            background: linear-gradient(90deg, #6366f1, #8b5cf6, #ec4899);
        }}
        .profile-header {{
            display: flex;
            align-items: center;
            gap: 24px;
            flex-wrap: wrap;
        }}
        .avatar-wrap {{ position: relative; }}
        .user-avatar {{
            width: 92px;
            height: 92px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.12);
            box-shadow: 0 0 28px var(--avatar-glow);
            object-fit: cover;
            display: block;
        }}
        .user-meta h1 {{
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -0.5px;
            margin-bottom: 6px;
            color: #ffffff;
        }}
        .user-handle {{
            font-family: 'JetBrains Mono', monospace;
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 14px;
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }}
        .id-badge {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(255, 255, 255, 0.05);
            padding: 3px 10px;
            border-radius: 6px;
            cursor: pointer;
            border: 1px solid rgba(255, 255, 255, 0.08);
            font-size: 12px;
            color: var(--text-secondary);
            transition: all 0.2s;
        }}
        .id-badge:hover {{
            background: rgba(255, 255, 255, 0.12);
            border-color: rgba(255, 255, 255, 0.2);
            color: #ffffff;
        }}
        .status-badge {{
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 0.2px;
        }}
        .badge-clean {{
            background: rgba(16, 185, 129, 0.12);
            color: #34d399;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }}
        .badge-warned {{
            background: rgba(245, 158, 11, 0.12);
            color: #fbbf24;
            border: 1px solid rgba(245, 158, 11, 0.3);
        }}
        .badge-risky {{
            background: rgba(239, 68, 68, 0.12);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }}
        .status-dot {{
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: currentColor;
            box-shadow: 0 0 8px currentColor;
        }}

        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-top: 28px;
            padding-top: 24px;
            border-top: 1px solid var(--card-border);
        }}
        .stat-box {{
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 14px;
            padding: 18px 20px;
            transition: all 0.2s ease;
        }}
        .stat-box:hover {{
            background: rgba(255, 255, 255, 0.04);
            border-color: rgba(255, 255, 255, 0.1);
            transform: translateY(-2px);
        }}
        .stat-top {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
        }}
        .stat-lbl {{
            font-size: 11px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.8px;
            font-weight: 700;
        }}
        .stat-icon-wrap {{
            width: 28px;
            height: 28px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.06);
            color: var(--text-muted);
        }}
        .stat-val {{
            font-size: 20px;
            font-weight: 800;
            font-family: 'JetBrains Mono', monospace;
            color: #ffffff;
        }}

        .section-header {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin: 36px 0 16px;
            flex-wrap: wrap;
            gap: 12px;
        }}
        .section-title {{
            font-size: 18px;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #ffffff;
            letter-spacing: -0.3px;
        }}
        .section-title svg {{ stroke: var(--text-muted); }}
        .count-pill {{
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.08);
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 12px;
            color: var(--text-muted);
            font-family: 'JetBrains Mono', monospace;
            font-weight: 600;
        }}

        .warn-card {{
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-left: 4px solid var(--accent-state);
            border-radius: 16px;
            padding: 22px;
            margin-bottom: 14px;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
        }}
        .warn-card:hover {{
            border-color: var(--card-border-hover);
            border-left-color: var(--accent-state);
            transform: translateX(3px);
        }}
        .warn-top {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 14px;
            flex-wrap: wrap;
            gap: 8px;
        }}
        .warn-badge {{
            font-size: 12px;
            font-weight: 700;
            padding: 4px 12px;
            border-radius: 8px;
            background: rgba(245, 158, 11, 0.15);
            color: #fbbf24;
            border: 1px solid rgba(245, 158, 11, 0.28);
            letter-spacing: 0.3px;
        }}
        .warn-time {{
            font-family: 'JetBrains Mono', monospace;
            font-size: 12px;
            color: var(--text-muted);
            display: flex;
            align-items: center;
            gap: 6px;
        }}
        .warn-reason-box {{
            background: rgba(10, 13, 22, 0.6);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 14px 18px;
            margin-bottom: 14px;
        }}
        .warn-reason-lbl {{
            font-size: 11px;
            text-transform: uppercase;
            color: var(--accent-state);
            font-weight: 800;
            letter-spacing: 0.6px;
            margin-bottom: 6px;
        }}
        .warn-reason-text {{
            font-size: 14px;
            line-height: 1.6;
            color: #f1f5f9;
            font-weight: 600;
        }}
        .warn-footer {{
            display: flex;
            align-items: center;
            gap: 14px;
            font-size: 12px;
            color: var(--text-muted);
            flex-wrap: wrap;
        }}
        .meta-chip {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.06);
            padding: 4px 10px;
            border-radius: 6px;
        }}
        .meta-chip strong {{ color: var(--text-secondary); }}

        .warn-top-right {{
            display: flex;
            align-items: center;
            gap: 12px;
        }}
        .btn-warn-delete {{
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: rgba(239, 68, 68, 0.12);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.28);
            border-radius: 7px;
            padding: 4px 10px;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s ease;
            font-family: inherit;
        }}
        .btn-warn-delete:hover {{
            background: rgba(239, 68, 68, 0.25);
            border-color: rgba(239, 68, 68, 0.55);
            color: #ffffff;
            transform: translateY(-1px);
        }}
        .btn-clear-all-sicil {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(239, 68, 68, 0.14);
            color: #fca5a5;
            border: 1px solid rgba(239, 68, 68, 0.32);
            border-radius: 8px;
            padding: 6px 13px;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s ease;
            font-family: inherit;
        }}
        .btn-clear-all-sicil:hover {{
            background: #ef4444;
            color: #ffffff;
            border-color: #dc2626;
            box-shadow: 0 4px 14px rgba(239, 68, 68, 0.35);
            transform: translateY(-1px);
        }}
        .staff-tag-badge {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(99, 102, 241, 0.14);
            border: 1px solid rgba(99, 102, 241, 0.3);
            border-radius: 20px;
            padding: 4px 12px;
            font-size: 11px;
            font-weight: 700;
            color: #a5b4fc;
            margin-top: 8px;
        }}
        .modal-overlay {{
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(8px);
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }}
        .modal-card {{
            background: #0f121c;
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 18px;
            width: 100%;
            max-width: 440px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6);
            overflow: hidden;
            animation: modalFadeIn 0.2s ease-out;
        }}
        @keyframes modalFadeIn {{
            from {{ opacity: 0; transform: scale(0.96) translateY(8px); }}
            to {{ opacity: 1; transform: scale(1) translateY(0); }}
        }}
        .modal-header {{
            padding: 18px 22px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        .modal-body {{
            padding: 22px;
        }}
        .modal-footer {{
            padding: 16px 22px;
            background: rgba(0, 0, 0, 0.25);
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 10px;
        }}
        .modal-perm-badge {{
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(239, 68, 68, 0.12);
            border: 1px solid rgba(239, 68, 68, 0.28);
            border-radius: 8px;
            padding: 10px 14px;
            margin-bottom: 16px;
            font-size: 12px;
            color: #fca5a5;
            line-height: 1.4;
        }}
        .modal-input {{
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 10px 14px;
            color: #fff;
            font-family: 'JetBrains Mono', monospace;
            font-size: 13px;
            outline: none;
            box-sizing: border-box;
            transition: border-color 0.2s;
        }}
        .modal-input:focus {{
            border-color: #6366f1;
        }}
        .btn-modal-cancel {{
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--text-secondary);
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }}
        .btn-modal-cancel:hover {{
            background: rgba(255, 255, 255, 0.12);
            color: #fff;
        }}
        .btn-modal-danger {{
            background: #ef4444;
            border: 1px solid #dc2626;
            color: #fff;
            border-radius: 8px;
            padding: 8px 18px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }}
        .btn-modal-danger:hover {{
            background: #dc2626;
            box-shadow: 0 4px 14px rgba(239, 68, 68, 0.4);
        }}

        .clean-state {{
            background: rgba(16, 185, 129, 0.05);
            border: 1px solid rgba(16, 185, 129, 0.2);
            border-radius: 20px;
            padding: 48px 32px;
            text-align: center;
            margin-bottom: 28px;
        }}
        .clean-icon-wrap {{
            width: 64px;
            height: 64px;
            margin: 0 auto 16px;
            border-radius: 16px;
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        .clean-state h3 {{
            font-size: 18px;
            font-weight: 800;
            color: #34d399;
            margin-bottom: 6px;
        }}
        .clean-state p {{
            color: var(--text-muted);
            font-size: 14px;
            max-width: 460px;
            margin: 0 auto;
            line-height: 1.5;
        }}

        .search-box-wrap {{
            position: relative;
            min-width: 240px;
        }}
        .search-input {{
            width: 100%;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--card-border);
            border-radius: 10px;
            padding: 8px 14px 8px 36px;
            color: #ffffff;
            font-size: 13px;
            font-family: inherit;
            outline: none;
            transition: all 0.2s;
        }}
        .search-input:focus {{
            background: rgba(255, 255, 255, 0.08);
            border-color: rgba(99, 102, 241, 0.5);
            box-shadow: 0 0 12px rgba(99, 102, 241, 0.2);
        }}
        .search-icon {{
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            stroke: var(--text-muted);
            pointer-events: none;
        }}
        .table-wrap {{
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: 18px;
            overflow: hidden;
            margin-bottom: 32px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }}
        th, td {{
            padding: 16px 20px;
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }}
        th {{
            background: rgba(255, 255, 255, 0.02);
            color: var(--text-muted);
            font-weight: 700;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.6px;
        }}
        tr:last-child td {{ border-bottom: none; }}
        .ticket-row:hover {{
            background: rgba(255, 255, 255, 0.03);
        }}
        .col-id {{
            font-family: 'JetBrains Mono', monospace;
            font-weight: 700;
            color: #818cf8;
        }}
        .col-cat {{ font-weight: 600; color: #f1f5f9; }}
        .col-date {{
            color: var(--text-muted);
            font-size: 12px;
            font-family: 'JetBrains Mono', monospace;
        }}
        .pill-status {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.2px;
        }}
        .pill-open {{
            background: rgba(16, 185, 129, 0.15);
            color: #34d399;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }}
        .pill-closed {{
            background: rgba(148, 163, 184, 0.12);
            color: #94a3b8;
            border: 1px solid rgba(148, 163, 184, 0.2);
        }}
        .status-pulse-dot {{
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: #34d399;
            box-shadow: 0 0 6px #34d399;
        }}

        .toast {{
            position: fixed;
            bottom: 24px;
            left: 50%;
            transform: translateX(-50%) translateY(100px);
            background: rgba(15, 23, 42, 0.92);
            border: 1px solid rgba(255, 255, 255, 0.15);
            color: #ffffff;
            padding: 12px 24px;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 600;
            backdrop-filter: blur(16px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            opacity: 0;
            pointer-events: none;
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            z-index: 9999;
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .toast.show {{
            transform: translateX(-50%) translateY(0);
            opacity: 1;
        }}

        .footer-note {{
            text-align: center;
            color: var(--text-muted);
            font-size: 12px;
            margin-top: 48px;
            line-height: 1.6;
        }}

        @media print {{
            body {{ background: #fff; color: #000; padding: 0; }}
            .btn-action, .top-nav .nav-actions, .search-box-wrap {{ display: none; }}
            .profile-card, .warn-card, .table-wrap {{ border: 1px solid #ddd; background: #fff; color: #000; box-shadow: none; }}
            .warn-reason-box {{ background: #f8fafc; border: 1px solid #e2e8f0; }}
            .col-id {{ color: #000; }}
        }}

        @media (max-width: 640px) {{
            .top-nav {{ flex-direction: column; align-items: flex-start; gap: 14px; }}
            .nav-actions {{ width: 100%; justify-content: flex-start; }}
            .profile-card {{ padding: 22px; }}
            .stats-grid {{ grid-template-columns: 1fr 1fr; }}
            .search-box-wrap {{ width: 100%; min-width: 100%; margin-top: 10px; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header class="top-nav">
            <div class="brand">
                <img src="{logo_url}" class="brand-logo" alt="{bot_name}">
                <div>
                    <div class="brand-title">{bot_name}</div>
                    <div class="brand-sub">Resmi Kullanıcı Denetim & Sicil Altyapısı</div>
                </div>
            </div>
            <div class="nav-actions">
                <button class="btn-action" onclick="refreshSicilPage(this)" title="Sicil Verilerini Yenile">
                    <svg id="sicilRefreshIcon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
                    Yenile
                </button>
                <button class="btn-action" onclick="copyLink()">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
                    Bağlantıyı Kopyala
                </button>
                <button class="btn-action" onclick="window.print()">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect width="12" height="8" x="6" y="14"/></svg>
                    Yazdır / PDF
                </button>
            </div>
        </header>

        <section class="profile-card">
            <div class="profile-header">
                <div class="avatar-wrap">
                    <img src="{avatar_url}" class="user-avatar" alt="{user_name}">
                </div>
                <div class="user-meta">
                    <h1>{user_display}</h1>
                    <div class="user-handle">
                        <span>@{user_name}</span>
                        <span class="id-badge" onclick="copyId('{user_id}')" title="Kopyalamak için tıklayın">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
                            ID: {user_id}
                        </span>
                    </div>
                    <div class="status-badge {badge_class}">
                        <span class="status-dot"></span>
                        <span>{badge_text}</span>
                    </div>
                    {staff_badge_html}
                </div>
            </div>

            <div class="stats-grid">
                <div class="stat-box">
                    <div class="stat-top">
                        <span class="stat-lbl">Toplam Ceza / İhtar</span>
                        <div class="stat-icon-wrap" style="color:#fbbf24;">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                        </div>
                    </div>
                    <div class="stat-val" style="color:#fbbf24;">{total_records} Kayıt</div>
                </div>
                <div class="stat-box">
                    <div class="stat-top">
                        <span class="stat-lbl">Toplam Destek Talebi</span>
                        <div class="stat-icon-wrap" style="color:#818cf8;">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/></svg>
                        </div>
                    </div>
                    <div class="stat-val" style="color:#818cf8;">{total_tickets} Adet</div>
                </div>
                <div class="stat-box">
                    <div class="stat-top">
                        <span class="stat-lbl">Sunucuya Katılış</span>
                        <div class="stat-icon-wrap" style="color:#34d399;">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
                        </div>
                    </div>
                    <div class="stat-val" style="font-size:15px;">{joined_str}</div>
                </div>
                <div class="stat-box">
                    <div class="stat-top">
                        <span class="stat-lbl">Discord Hesap Açılış</span>
                        <div class="stat-icon-wrap" style="color:#38bdf8;">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                        </div>
                    </div>
                    <div class="stat-val" style="font-size:15px;">{created_str}</div>
                </div>
            </div>
        </section>

        <div class="section-header">
            <div class="section-title">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                <span>Sicil & İhlal Kayıtları</span>
                <span class="count-pill">{total_records} Kayıt</span>
            </div>
            {f'''<button type="button" class="btn-clear-all-sicil" onclick="promptClearAll()" title="Tüm Sicil Kayıtlarını Temizle (0)">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                <span>Tüm Sicili Temizle</span>
            </button>''' if (is_staff and total_records > 0) else ''}
        </div>
        {warns_html}

        <div class="section-header" id="talepler" style="margin-top: 40px;">
            <div class="section-title">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/></svg>
                <span>Destek Talepleri Geçmişi</span>
                <span class="count-pill">{total_tickets} Adet</span>
            </div>
            <div class="search-box-wrap">
                <svg class="search-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                <input type="text" id="ticketSearch" class="search-input" placeholder="Bilet No veya Kategori ara..." onkeyup="filterTickets()">
            </div>
        </div>
        <div class="table-wrap">
            <table id="ticketsTable">
                <thead>
                    <tr>
                        <th>Talep No</th>
                        <th>Kategori</th>
                        <th>Durum</th>
                        <th>Tarih</th>
                    </tr>
                </thead>
                <tbody>
                    {tickets_rows}
                </tbody>
            </table>
        </div>

        <div class="footer-note">
            {bot_name} • Resmi Sicil & Denetim Altyapısı • Veriler Discord API ve Yerel Sistemden Doğrulanmaktadır.
        </div>
    </div>

    {f'''<!-- Sicil Silme Yetkili Onay ve PIN Modalı -->
    <div id="sicilModal" class="modal-overlay" style="display:none;">
        <div class="modal-card">
            <div class="modal-header">
                <div style="display:flex; align-items:center; gap:10px;">
                    <div style="width:32px; height:32px; border-radius:10px; background:rgba(239,68,68,0.15); display:flex; align-items:center; justify-content:center; color:#ef4444;">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    </div>
                    <div>
                        <div style="font-weight:800; font-size:15px; color:#fff;">Sicil Silme İşlemi</div>
                        <div style="font-size:11px; color:#94a3b8;">0 Yetkili Doğrulaması</div>
                    </div>
                </div>
                <button type="button" onclick="closeSicilModal()" style="background:none; border:none; color:#64748b; font-size:20px; cursor:pointer; padding:4px;">✕</button>
            </div>
            <div class="modal-body">
                <div class="modal-perm-badge">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    <div>Bu işlem yalnızca <strong>0</strong> yetkili rolüne sahip olanlar tarafından gerçekleştirilebilir.</div>
                </div>
                <p id="sicilModalPrompt" style="font-size:14px; color:#e2e8f0; line-height:1.5; margin-bottom:16px; font-weight:600;">Bu sicil kaydını silmek istediğinize emin misiniz?</p>
                
                <div id="sicilAuthInputs" style="display:{'none' if is_staff else 'block'}; margin-top:14px; padding-top:14px; border-top:1px solid rgba(255,255,255,0.08);">
                    <div style="margin-bottom:12px;">
                        <label style="display:block; font-size:11px; font-weight:700; color:#94a3b8; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:6px;">Yetkili Discord ID'niz</label>
                        <input type="text" id="modalStaffId" class="modal-input" placeholder="Örn: 0">
                    </div>
                    <div>
                        <label style="display:block; font-size:11px; font-weight:700; color:#94a3b8; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:6px;">6 Haneli Güvenlik PIN Kodu</label>
                        <input type="text" id="modalStaffPin" class="modal-input" maxlength="6" placeholder="Discord'da /kod ile aldığınız kod">
                        <div style="font-size:11px; color:#64748b; margin-top:4px;">Discord sunucusunda <code>/kod</code> yazarak aldığınız tek kullanımlık güvenlik kodunu girin.</div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-modal-cancel" onclick="closeSicilModal()">İptal</button>
                <button type="button" class="btn-modal-danger" id="btnConfirmDelete" onclick="executeSicilDelete()">Sicili Sil</button>
            </div>
        </div>
    </div>''' if is_staff else ''}

    <div id="toast" class="toast">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
        <span id="toastMsg">İşlem Başarılı</span>
    </div>

    <script>
        let activeDeletePayload = null;
        const currentTargetUserId = '{user_id}';
        const isStaffSessionActive = {'true' if is_staff else 'false'};

        function promptDeleteWarn(warnIdx) {{
            activeDeletePayload = {{
                user_id: currentTargetUserId,
                warn_index: warnIdx,
                clear_all: false
            }};
            document.getElementById('sicilModalPrompt').innerText = 'Bu sicil/ihlal kaydını sistemden kalıcı olarak silmek istediğinize emin misiniz?';
            openSicilModal();
        }}

        function promptClearAll() {{
            activeDeletePayload = {{
                user_id: currentTargetUserId,
                clear_all: true
            }};
            document.getElementById('sicilModalPrompt').innerText = 'Bu kullanıcının TÜM sicil dosyasını ve ihlal geçmişini sıfırlamak istediğinize emin misiniz?';
            openSicilModal();
        }}

        function openSicilModal() {{
            document.getElementById('sicilModal').style.display = 'flex';
        }}

        function closeSicilModal() {{
            document.getElementById('sicilModal').style.display = 'none';
            activeDeletePayload = null;
        }}

        async function executeSicilDelete() {{
            if (!activeDeletePayload) return;
            const btn = document.getElementById('btnConfirmDelete');
            btn.disabled = true;
            btn.innerText = 'Siliniyor...';

            const payload = {{ ...activeDeletePayload }};
            const staffIdInput = document.getElementById('modalStaffId');
            const staffPinInput = document.getElementById('modalStaffPin');

            if (staffIdInput && staffIdInput.value.trim()) {{
                payload.auth_user_id = staffIdInput.value.trim();
            }}
            if (staffPinInput && staffPinInput.value.trim()) {{
                payload.pin = staffPinInput.value.trim();
            }}

            try {{
                const res = await fetch('/api/sicil/delete', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify(payload)
                }});
                const data = await res.json();

                if (res.ok && data.success) {{
                    showToast(data.message || 'Sicil kaydı başarıyla silindi!');
                    closeSicilModal();
                    setTimeout(() => {{
                        window.location.reload();
                    }}, 800);
                }} else {{
                    if (res.status === 401 || (!data.success && data.message && data.message.includes('PIN'))) {{
                        document.getElementById('sicilAuthInputs').style.display = 'block';
                    }}
                    showToast(data.message || 'Sicil silinemedi!');
                }}
            }} catch (err) {{
                showToast('Bağlantı hatası: ' + err.message);
            }} finally {{
                btn.disabled = false;
                btn.innerText = 'Sicili Sil';
            }}
        }}

        function showToast(msg) {{
            const t = document.getElementById('toast');
            document.getElementById('toastMsg').innerText = msg;
            t.classList.add('show');
            setTimeout(() => {{
                t.classList.remove('show');
            }}, 2400);
        }}

        function refreshSicilPage(btn) {{
            const icon = document.getElementById('sicilRefreshIcon');
            if (icon) icon.style.animation = 'spin 0.8s linear infinite';
            window.location.reload();
        }}

        function copyLink() {{
            navigator.clipboard.writeText(window.location.href).then(() => {{
                showToast('Sicil dosyası bağlantısı panoya kopyalandı');
            }}).catch(() => {{
                showToast('Bağlantı kopyalanamadı');
            }});
        }}

        function copyId(id) {{
            navigator.clipboard.writeText(id).then(() => {{
                showToast('Kullanıcı ID panoya kopyalandı: ' + id);
            }}).catch(() => {{
                showToast('ID kopyalanamadı');
            }});
        }}

        function filterTickets() {{
            const query = document.getElementById('ticketSearch').value.toLowerCase().trim();
            const rows = document.querySelectorAll('#ticketsTable tbody tr.ticket-row');
            rows.forEach(r => {{
                const searchData = r.getAttribute('data-search') || '';
                if (!query || searchData.includes(query)) {{
                    r.style.display = '';
                }} else {{
                    r.style.display = 'none';
                }}
            }});
        }}
    </script>
</body>
</html>
"""

async def handle_public_sicil_page(request: web.Request) -> web.Response:
    """Kullanıcının kendi resmi sicil dosyasını ve destek geçmişini görüntülediği genel web sayfası."""
    user_id_raw = str(request.match_info.get("user_id", "") or request.query.get("id", "")).strip()
    if not user_id_raw or not user_id_raw.isdigit():
        return web.Response(
            text="<div style='background:#0a0b10;color:#fff;font-family:sans-serif;padding:60px;text-align:center;'><h2>Geçersiz Kullanıcı ID</h2><p>Lütfen geçerli bir kullanıcı ID belirtin.</p></div>",
            status=400,
            content_type="text/html",
            charset="utf-8"
        )

    user_id = int(user_id_raw)
    guild = bot.guilds[0] if bot.guilds else None
    member = guild.get_member(user_id) if guild else None
    if not member:
        try:
            member = await bot.fetch_user(user_id)
        except Exception:
            member = None

    # Ziyaretçinin 0 yetkili oturumu var mı kontrol et
    session_cookie = request.cookies.get("imza_staff_auth", "").strip()
    auth_query = request.query.get("auth", "").strip()
    token = auth_query or session_cookie
    is_staff = False
    if token and await is_valid_staff_session(token):
        is_staff = True

    warns = get_user_warnings(user_id)
    active_t, closed_t = get_user_tickets_summary(user_id)

    welcome_cfg_path = os.path.join(BASE_DIR, "..", "imza-welcome-bot", "config.json")
    guard_count = 0
    if os.path.exists(welcome_cfg_path):
        try:
            with open(welcome_cfg_path, "r", encoding="utf-8") as wcf:
                guard_count = int(json.load(wcf).get("guard_uyarilar", {}).get(str(user_id), 0))
        except Exception:
            guard_count = 0

    html_page = render_public_user_sicil_html(user_id, member, warns, active_t, closed_t, guild, is_staff=is_staff, guard_count=guard_count)
    resp = web.Response(text=html_page, content_type="text/html", charset="utf-8")
    if auth_query and is_staff:
        resp.set_cookie("imza_staff_auth", auth_query, max_age=86400 * 7, httponly=True)
    return resp

async def refresh_ticket_welcome_embed(channel_id: int):
    """Bilet kanalındaki karşılama mesajını ve ayrı sicil kartını güncel bilgilerle yeniler."""
    try:
        tdata = load_tickets()
        ticket_info = tdata.get("active", {}).get(str(channel_id))
        if not ticket_info:
            return
        channel = bot.get_channel(channel_id)
        if not channel:
            try:
                channel = await bot.fetch_channel(channel_id)
            except Exception:
                return

        owner_id = int(ticket_info.get("owner_id", 0))
        owner_user = channel.guild.get_member(owner_id) if channel.guild else None
        if not owner_user and owner_id:
            try:
                owner_user = await bot.fetch_user(owner_id)
            except Exception:
                owner_user = None

        target_user = owner_user or owner_id

        # 1. Ana bilet karşılama mesajını güncelle (sade & temiz)
        welcome_msg_id = ticket_info.get("welcome_message_id")
        if welcome_msg_id:
            try:
                msg = await channel.fetch_message(int(welcome_msg_id))
                if msg:
                    new_embed = build_ticket_welcome_embed(ticket_info, target_user, channel.guild)
                    await msg.edit(embed=new_embed)
            except Exception:
                pass

        # 2. Ayrı Sicil Kartını güncelle veya yoksa kanala ilk kez gönder
        sicil_msg_id = ticket_info.get("sicil_message_id")
        if sicil_msg_id:
            try:
                s_msg = await channel.fetch_message(int(sicil_msg_id))
                if s_msg:
                    s_embed, s_view = build_ticket_sicil_embed(target_user, channel.guild)
                    await s_msg.edit(embed=s_embed, view=s_view)
            except Exception:
                pass
        else:
            try:
                s_embed, s_view = build_ticket_sicil_embed(target_user, channel.guild)
                s_msg = await channel.send(embed=s_embed, view=s_view)
                ticket_info["sicil_message_id"] = s_msg.id
                save_tickets(tdata)
            except Exception as se:
                print(f"[Sicil Kartı Gönderme Hatası]: {se}", flush=True)
    except Exception as e:
        print(f"[Refresh Ticket Embeds Hata]: {e}", flush=True)

def get_user_tickets_summary(user_id: int | str) -> tuple[list, list]:
    """Kullanıcının aktif ve arşivlenmiş biletlerini ayrıştırılmış liste olarak döner."""
    uid = str(user_id)
    index_data = load_transcript_index()
    tdata = load_tickets()

    active_tickets = []
    closed_tickets = []

    for cid, act in tdata.get("active", {}).items():
        if str(act.get("owner_id")) == uid:
            active_tickets.append({
                "channel_id": cid,
                "ticket_id": act.get("id", f"#{cid}"),
                "category": act.get("category", "Destek"),
                "created_at": act.get("created_at", ""),
                "priority": act.get("priority", "normal")
            })

    for sid, rec in index_data.items():
        if str(rec.get("owner_id")) == uid:
            closed_tickets.append({
                "slug_id": sid,
                "ticket_id": rec.get("ticket_id", "#0000"),
                "category": rec.get("category", "Genel Destek"),
                "closed_at": rec.get("closed_at", rec.get("created_at", "")),
                "closed_by": rec.get("closed_by", "Bilinmiyor")
            })

    return active_tickets, closed_tickets

async def handle_sicil_delete(request: web.Request) -> web.Response:
    """Sicil silme endpoint'i. Yalnızca 0 rolüne sahip yetkililer gerçekleştirebilir."""
    try:
        data = await request.json()
    except Exception:
        return web.json_response({"success": False, "message": "Geçersiz istek formatı."}, status=400)

    target_user_id_raw = str(data.get("user_id", "")).strip()
    if not target_user_id_raw or not target_user_id_raw.isdigit():
        return web.json_response({"success": False, "message": "Geçersiz hedef kullanıcı ID."}, status=400)

    target_user_id = int(target_user_id_raw)
    clear_all = bool(data.get("clear_all", False))
    warn_index = data.get("warn_index")

    # Yetkili oturum veya PIN kontrolü
    session_cookie = request.cookies.get("imza_staff_auth", "").strip()
    auth_token = str(data.get("auth", "") or request.query.get("auth", "")).strip()
    token = auth_token or session_cookie

    staff_user_id = None
    if token and await is_valid_staff_session(token):
        staff_user_id = staff_sessions.get(token, {}).get("user_id")
    else:
        # PIN ile anlık kimlik doğrulama
        pin = str(data.get("pin", "")).strip()
        auth_uid_raw = str(data.get("auth_user_id", "")).strip()
        if pin and auth_uid_raw and auth_uid_raw.isdigit():
            auth_uid = int(auth_uid_raw)
            pin_rec = staff_pins.get(pin)
            if pin_rec and time.time() <= pin_rec["expires_at"] and pin_rec["user_id"] == auth_uid:
                if await check_user_has_staff_role(auth_uid):
                    staff_user_id = auth_uid
                    staff_pins.pop(pin, None)
                    token = create_staff_session(auth_uid)
                else:
                    return web.json_response({
                        "success": False,
                        "message": "Erişim Reddedildi: Hesabınızda 0 yetkili rolü bulunmuyor!"
                    }, status=403)
            else:
                return web.json_response({
                    "success": False,
                    "message": "Geçersiz veya süresi dolmuş yetkili PIN kodu!"
                }, status=401)

    if not staff_user_id or not await check_user_has_staff_role(staff_user_id):
        return web.json_response({
            "success": False,
            "message": "Erişim Reddedildi: Bu işlem yalnızca 0 yetkili rolüne sahip kişiler tarafından yapılabilir!"
        }, status=403)

    action_desc = ""
    if clear_all or warn_index is None:
        success = clear_user_warnings(target_user_id)
        action_desc = "Tüm sicil kayıtları temizlendi"
    else:
        try:
            w_idx = int(warn_index)
            success = delete_user_warning_by_index(target_user_id, w_idx)
            action_desc = f"{w_idx + 1}. sıradaki sicil kaydı silindi"
        except Exception as e:
            return web.json_response({"success": False, "message": f"Silme hatası: {e}"}, status=400)

    if not success:
        return web.json_response({"success": False, "message": "Silinecek sicil kaydı bulunamadı veya işlem başarısız oldu."}, status=404)

    # Aktif biletleri anında Discord'da güncelle
    try:
        tdata = load_tickets()
        for cid_str, act_info in tdata.get("active", {}).items():
            if str(act_info.get("owner_id")) == str(target_user_id):
                asyncio.create_task(refresh_ticket_welcome_embed(int(cid_str)))
    except Exception as te:
        print(f"[Sicil Silme Bilet Refresh Hatası]: {te}", flush=True)

    # Log kanalına bildir
    try:
        log_ch_id = config.get("ticket_log_kanal_id")
        guild = bot.guilds[0] if bot.guilds else None
        if log_ch_id and guild:
            log_ch = guild.get_channel(int(log_ch_id))
            if log_ch:
                staff_member = guild.get_member(staff_user_id)
                staff_mention = staff_member.mention if staff_member else f"<@{staff_user_id}>"
                target_member = guild.get_member(target_user_id)
                target_mention = target_member.mention if target_member else f"<@{target_user_id}>"
                log_embed = discord.Embed(
                    title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Sicil Kaydı Silindi",
                    description=(
                        f"Bir kullanıcının sicil kaydı silindi.\n\n"
                        f"• **Kullanıcı:** {target_mention} (`{target_user_id}`)\n"
                        f"• **Yetkili (0):** {staff_mention} (`{staff_user_id}`)\n"
                        f"• **İşlem:** {action_desc}\n"
                        f"• **Tarih:** <t:{int(time.time())}:F>"
                    ),
                    color=0x10b981,
                    timestamp=datetime.now(timezone.utc)
                )
                asyncio.create_task(log_ch.send(embed=log_embed))
    except Exception as le:
        print(f"[Sicil Silme Log Hatası]: {le}", flush=True)

    resp = web.json_response({
        "success": True,
        "message": f"Sicil kaydı başarıyla silindi ({action_desc})."
    })
    if token:
        resp.set_cookie("imza_staff_auth", token, max_age=86400 * 7, httponly=True)
    return resp

async def start_web_server():
    """Bilet transkript web sunucusunu aiohttp üzerinden başlatır ve Cloudflare tünelini açar."""
    app = web.Application()

    async def handle_health(request: web.Request) -> web.Response:
        return web.Response(text="OK", status=200)

    app.router.add_get("/api/health", handle_health)
    app.router.add_get("/health", handle_health)
    app.router.add_get("/", handle_home_page)
    app.router.add_get("/transcript/{id}", handle_web_transcript)
    app.router.add_get("/sicil/{user_id}", handle_public_sicil_page)
    app.router.add_get("/profil/{user_id}", handle_public_sicil_page)
    app.router.add_post("/api/sicil/delete", handle_sicil_delete)
    app.router.add_post("/api/verify-staff", handle_verify_staff)
    app.router.add_post("/api/ticket/send-message", handle_ticket_send_message)
    app.router.add_post("/api/ticket/warn-user", handle_ticket_warn_user)
    app.router.add_post("/api/ticket/add-note", handle_ticket_add_note)
    app.router.add_post("/api/staff/logout", handle_staff_logout)
    app.router.add_post("/api/ticket/claim", handle_ticket_claim_web)
    app.router.add_post("/api/ticket/close", handle_ticket_close_web)
    app.router.add_post("/api/ticket/set-priority", handle_ticket_set_priority)
    app.router.add_post("/api/ticket/sync", handle_ticket_sync)
    app.router.add_get("/api/ticket/stream/{id}", handle_ticket_stream)
    app.router.add_post("/api/ticket/delete", handle_ticket_delete_web)
    app.router.add_get("/api/user/history", handle_user_history)
    app.router.add_get("/api/ticket/sync-check", handle_ticket_sync_check)
    app.router.add_get("/api/active-tunnel-url", handle_active_tunnel_url)

    runner = web.AppRunner(app)
    await runner.setup()
    host = "0.0.0.0"
    port = int(config.get("web_port", 8080))
    site = web.TCPSite(runner, host, port)
    try:
        await site.start()
        print(f"[Web Sunucu] Transkript yerel dinleyici http://127.0.0.1:{port} adresinde aktif.", flush=True)
        await start_cloudflare_tunnel(port)
    except Exception as e:
        print(f"[Web Sunucu Başlatma Hatası]: {e}", flush=True)

# ─────────────────────────────────────────────
# TRANSKRİPT ÜRETİCİ (TEMİZ METİN - .TXT)
# ─────────────────────────────────────────────
async def generate_text_transcript(channel: discord.TextChannel, ticket_info: dict = None) -> tuple:
    """Bilet kanalındaki konuşmaları kodsuz, saf ve okunabilir metin formatında (.txt) döküme dönüştürür."""
    messages = [m async for m in channel.history(limit=1000, oldest_first=True)]
    
    clean_ch_name = channel.name.replace("🎫・", "").replace("🔒・", "").strip()
    ticket_id = ticket_info.get("id", f"#{channel.id}") if ticket_info else f"#{channel.id}"
    owner_name = ticket_info.get("owner_name", "Bilinmiyor") if ticket_info else "Bilinmiyor"
    owner_id = ticket_info.get("owner_id", "Bilinmiyor") if ticket_info else "Bilinmiyor"
    category = ticket_info.get("category", "Destek Talebi") if ticket_info else "Destek Talebi"
    subject = ticket_info.get("subject", "Belirtilmedi") if ticket_info else "Belirtilmedi"
    claimed_by_name = ticket_info.get("claimed_by_name", "Üstlenilmedi") if ticket_info else "Üstlenilmedi"
    created_at = ticket_info.get("created_at", datetime.now().strftime("%d.%m.%Y %H:%M:%S")) if ticket_info else datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    closed_at = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    
    lines = []
    lines.append("=" * 60)
    lines.append(f"         {config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ┊ Destek Talebi Mesaj Dökümü")
    lines.append("=" * 60)
    lines.append(f"Talep No:          {ticket_id}")
    lines.append(f"Kanal:             #{channel.name}")
    lines.append(f"Talep Sahibi:      {owner_name} (ID: {owner_id})")
    lines.append(f"Kategori:          {category}")
    lines.append(f"Konu:              {subject}")
    lines.append(f"İlgilenen Yetkili: {claimed_by_name}")
    lines.append(f"Açılış Tarihi:     {created_at}")
    lines.append(f"Döküm Tarihi:      {closed_at}")
    lines.append("=" * 60)
    lines.append("\n" + " " * 20 + "--- MESAJLAR ---\n")

    for msg in messages:
        timestamp = msg.created_at.strftime("%d.%m.%Y %H:%M:%S")
        author_name = msg.author.display_name
        prefix = "[BOT] " if msg.author.bot else ""
        
        content = msg.content or ""
        
        # Eğer mesaj sadece embed ise (hoş geldin mesajı vb.)
        if not content and msg.embeds:
            embed_texts = []
            for emb in msg.embeds:
                if emb.title:
                    embed_texts.append(f"[{emb.title}]")
                if emb.description:
                    embed_texts.append(emb.description.replace("\n", " "))
                for field in emb.fields:
                    embed_texts.append(f"{field.name}: {field.value.replace(chr(10), ' ')}")
            content = " ".join(embed_texts)
        
        # Resim veya dosya ekleri
        if msg.attachments:
            att_list = " [Ek: " + ", ".join(a.url for a in msg.attachments) + "]"
            content += att_list
            
        if not content.strip():
            content = "(İçerik yok)"

        lines.append(f"[{timestamp}] {prefix}{author_name}: {content}")

    lines.append("\n" + "=" * 60)
    lines.append(f"Bu döküm {config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} Destek Sistemi tarafından arşivlendi.")
    lines.append("=" * 60)

    filename = f"transkript_{clean_ch_name}.txt"
    file_path = os.path.join(TRANSCRIPTS_DIR, f"{clean_ch_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return file_path, filename

# ─────────────────────────────────────────────
# TRANSKRİPT ÜRETİCİ (GÖRSEL / RESİM - .PNG)
# ─────────────────────────────────────────────
def load_transcript_fonts():
    font_paths = [
        (r"C:\Windows\Fonts\segoeuib.ttf", r"C:\Windows\Fonts\segoeui.ttf"),
        (r"C:\Windows\Fonts\arialbd.ttf", r"C:\Windows\Fonts\arial.ttf"),
        ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    ]
    for bp, rp in font_paths:
        if os.path.exists(bp) and os.path.exists(rp):
            return (
                ImageFont.truetype(bp, 20),
                ImageFont.truetype(bp, 14),
                ImageFont.truetype(rp, 14),
                ImageFont.truetype(rp, 12)
            )
    d = ImageFont.load_default()
    return d, d, d, d

def wrap_transcript_text(text: str, font, max_width: int, draw: ImageDraw.ImageDraw) -> list:
    lines = []
    for paragraph in text.split("\n"):
        words = paragraph.split(" ")
        current_line = []
        for word in words:
            test_line = " ".join(current_line + [word])
            bbox = draw.textbbox((0, 0), test_line, font=font)
            if bbox[2] - bbox[0] <= max_width:
                current_line.append(word)
            else:
                if current_line:
                    lines.append(" ".join(current_line))
                    current_line = [word]
                else:
                    lines.append(word)
                    current_line = []
        if current_line:
            lines.append(" ".join(current_line))
        elif not paragraph:
            lines.append("")
    return lines

def sanitize_transcript_text(text: str) -> str:
    if not text:
        return ""
    replacements = {
        "✦": "•",
        "┊": "|",
        "›": ">",
        "🎫": "",
        "🔒": "",
        "👑": "[VIP]",
        "⚠️": "[!]",
        "✅": "[+]",
        "❌": "[-]",
        "🗑️": "",
        "📜": "",
        "💬": "",
        "💎": "",
    }
    for k, v in replacements.items():
        text = text.replace(k, v)
    return text.strip()

async def generate_image_transcripts(channel: discord.TextChannel, ticket_info: dict = None) -> list:
    """Bilet konuşmalarını optimal boyutlarda sayfalara bölerek (.png) görsel listesi üretir."""
    messages = [m async for m in channel.history(limit=1000, oldest_first=True)]
    
    clean_ch_name = channel.name.replace("🎫・", "").replace("🔒・", "").replace("🎫", "").replace("🔒", "").strip()
    ticket_id = ticket_info.get("id", f"#{channel.id}") if ticket_info else f"#{channel.id}"
    owner_name = ticket_info.get("owner_name", "Bilinmiyor") if ticket_info else "Bilinmiyor"
    owner_id = ticket_info.get("owner_id", "Bilinmiyor") if ticket_info else "Bilinmiyor"
    category = ticket_info.get("category", "Destek Talebi") if ticket_info else "Destek Talebi"
    claimed_by_name = ticket_info.get("claimed_by_name", "Üstlenilmedi") if ticket_info else "Üstlenilmedi"
    created_at = ticket_info.get("created_at", datetime.now().strftime("%d.%m.%Y %H:%M:%S")) if ticket_info else datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    closed_at = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    
    # Arka plan metin dosyasını da diskte arşivle
    try:
        await generate_text_transcript(channel, ticket_info)
    except Exception as e:
        print(f"[Metin Log Arşiv Hata]: {e}", flush=True)

    # Avatarları çek ve önbelleğe al
    avatar_cache = {}
    for msg in messages:
        uid = msg.author.id
        if uid not in avatar_cache:
            try:
                data = await asyncio.wait_for(msg.author.display_avatar.with_format("png").with_size(64).read(), timeout=1.5)
                bio = io.BytesIO(data)
                av_img = Image.open(bio).convert("RGBA").resize((42, 42), Image.Resampling.LANCZOS)
                avatar_cache[uid] = av_img
            except Exception:
                avatar_cache[uid] = None

    font_title, font_bold, font_regular, font_small = load_transcript_fonts()
    W = 950
    dummy = Image.new("RGB", (W, 100))
    d = ImageDraw.Draw(dummy)

    # Mesaj düzenlerini hesapla
    all_layouts = []
    for m in messages:
        raw_content = m.content or ""
        clean_content = sanitize_transcript_text(raw_content)
        
        wrapped_content = []
        h = 0
        if clean_content:
            wrapped_content = wrap_transcript_text(clean_content, font_regular, 810, d)
            h += len(wrapped_content) * 21
            
        embed_layout = None
        if m.embeds:
            for emb in m.embeds[:2]:
                et = sanitize_transcript_text(emb.title or "")
                ed = sanitize_transcript_text(emb.description or "")
                et_wrapped = wrap_transcript_text(et, font_bold, 780, d) if et else []
                ed_wrapped = wrap_transcript_text(ed, font_regular, 780, d) if ed else []
                ef_wrapped = []
                for f in emb.fields:
                    fn = sanitize_transcript_text(f.name)
                    fv = sanitize_transcript_text(f.value)
                    ef_wrapped.append((fn, wrap_transcript_text(fv, font_regular, 780, d)))
                
                emb_h = 16 + len(et_wrapped) * 20 + len(ed_wrapped) * 20
                for fn, flines in ef_wrapped:
                    emb_h += 20 + len(flines) * 20
                emb_h += 10
                embed_layout = (et_wrapped, ed_wrapped, ef_wrapped, emb_h)
                h += emb_h + 8
                break
                
        att_names = []
        if m.attachments:
            for att in m.attachments:
                att_names.append(att.filename)
            h += len(att_names) * 28

        if not wrapped_content and not embed_layout and not att_names:
            wrapped_content = ["(İçerik yok)"]
            h += 21

        total_msg_h = max(46, 24 + h) + 18
        all_layouts.append((m, wrapped_content, embed_layout, att_names, total_msg_h))

    # Mesajları sayfalara böl
    MAX_HEIGHT_P1 = 700
    MAX_HEIGHT_OTHER = 800

    pages_layouts = []
    curr_page = []
    curr_h = 0

    for item in all_layouts:
        mh = item[4]
        limit = MAX_HEIGHT_P1 if len(pages_layouts) == 0 else MAX_HEIGHT_OTHER
        if curr_page and (curr_h + mh > limit):
            pages_layouts.append(curr_page)
            curr_page = [item]
            curr_h = mh
        else:
            curr_page.append(item)
            curr_h += mh

    if curr_page:
        pages_layouts.append(curr_page)

    if not pages_layouts:
        pages_layouts = [[]]

    total_pages = len(pages_layouts)
    timestamp_str = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_files = []

    for page_idx, p_items in enumerate(pages_layouts):
        is_first_page = (page_idx == 0)
        header_h = 190 if is_first_page else 75

        page_msgs_h = sum(item[4] for item in p_items)
        page_total_h = max(header_h + 30 + page_msgs_h + 70, 420)

        img = Image.new("RGB", (W, page_total_h), (17, 18, 24))
        draw = ImageDraw.Draw(img)

        # Header Çizimi
        if is_first_page:
            draw.rounded_rectangle([(30, 25), (W - 30, header_h)], radius=12, fill=(24, 26, 36), outline=(45, 49, 66), width=1)
            page_text = f"  •  SAYFA 1 / {total_pages}" if total_pages > 1 else ""
            draw.text((50, 45), f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  DESTEK TALEBİ MESAJ DÖKÜMÜ{page_text}", font=font_title, fill=(255, 255, 255))
            draw.line([(50, 80), (W - 50, 80)], fill=(45, 49, 66), width=1)

            info_lines = [
                ("Talep No:", ticket_id, "Kategori:", category),
                ("Talep Sahibi:", f"{owner_name} (ID: {owner_id})", "Kanal:", f"#{channel.name}"),
                ("Açılış Tarihi:", created_at, "Kapanış Tarihi:", closed_at)
            ]
            iy = 95
            for c1_l, c1_v, c2_l, c2_v in info_lines:
                draw.text((50, iy), c1_l, font=font_bold, fill=(148, 155, 164))
                draw.text((160, iy), str(c1_v)[:40], font=font_regular, fill=(255, 255, 255))
                draw.text((520, iy), c2_l, font=font_bold, fill=(148, 155, 164))
                draw.text((650, iy), str(c2_v)[:40], font=font_regular, fill=(255, 255, 255))
                iy += 26
        else:
            draw.rounded_rectangle([(30, 18), (W - 30, header_h)], radius=10, fill=(24, 26, 36), outline=(45, 49, 66), width=1)
            draw.text((50, 32), f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  DESTEK TALEBİ DÖKÜMÜ  •  SAYFA {page_idx + 1} / {total_pages}", font=font_title, fill=(255, 255, 255))
            draw.text((W - 200, 34), f"Talep: {ticket_id}", font=font_bold, fill=(88, 101, 242))

        # Mesajların Çizimi
        curr_y = header_h + 30
        for m, wrapped_content, embed_layout, att_names, mh in p_items:
            av_img = avatar_cache.get(m.author.id)
            if av_img:
                mask = Image.new("L", (42, 42), 0)
                mask_draw = ImageDraw.Draw(mask)
                mask_draw.ellipse((0, 0, 42, 42), fill=255)
                img.paste(av_img, (35, curr_y), mask)
            else:
                color = (88, 101, 242) if not m.author.bot else (87, 242, 135)
                draw.ellipse([(35, curr_y), (77, curr_y + 42)], fill=color)
                initial = (m.author.display_name[0] if m.author.display_name else "U").upper()
                ibox = draw.textbbox((0, 0), initial, font=font_bold)
                iw = ibox[2] - ibox[0]
                ih = ibox[3] - ibox[1]
                draw.text((35 + (42 - iw)//2, curr_y + (42 - ih)//2 - 2), initial, font=font_bold, fill=(255, 255, 255))

            author_name = m.author.display_name
            draw.text((92, curr_y), author_name, font=font_bold, fill=(255, 255, 255))
            abox = draw.textbbox((0, 0), author_name, font=font_bold)
            aw = abox[2] - abox[0]
            offset_x = 92 + aw + 10

            if m.author.bot:
                draw.rounded_rectangle([(offset_x, curr_y + 1), (offset_x + 36, curr_y + 17)], radius=3, fill=(88, 101, 242))
                draw.text((offset_x + 5, curr_y + 2), "BOT", font=font_small, fill=(255, 255, 255))
                offset_x += 44

            time_str = m.created_at.strftime("%H:%M")
            draw.text((offset_x, curr_y + 2), time_str, font=font_small, fill=(148, 155, 164))

            ty = curr_y + 24
            for line in wrapped_content:
                draw.text((92, ty), line, font=font_regular, fill=(220, 221, 222))
                ty += 21

            for att in att_names:
                att_text = f"[Ek Dosya]: {att}"
                draw.rounded_rectangle([(92, ty + 2), (92 + 280, ty + 24)], radius=5, fill=(35, 38, 52), outline=(55, 60, 80), width=1)
                draw.text((102, ty + 4), att_text, font=font_small, fill=(88, 101, 242))
                ty += 28

            if embed_layout:
                et_wrapped, ed_wrapped, ef_wrapped, emb_h = embed_layout
                draw.rounded_rectangle([(92, ty + 4), (880, ty + 4 + emb_h)], radius=6, fill=(28, 30, 42), outline=(42, 45, 62), width=1)
                draw.rounded_rectangle([(92, ty + 4), (96, ty + 4 + emb_h)], radius=2, fill=(88, 101, 242))
                
                ey = ty + 12
                for eline in et_wrapped:
                    draw.text((108, ey), eline, font=font_bold, fill=(255, 255, 255))
                    ey += 20
                ey += 2
                for eline in ed_wrapped:
                    draw.text((108, ey), eline, font=font_regular, fill=(200, 204, 215))
                    ey += 20
                for fn, flines in ef_wrapped:
                    ey += 4
                    draw.text((108, ey), fn, font=font_bold, fill=(148, 155, 164))
                    ey += 20
                    for fline in flines:
                        draw.text((108, ey), fline, font=font_regular, fill=(220, 221, 222))
                        ey += 20
                ty += emb_h + 8

            curr_y += mh

        # Alt Bilgi (Footer)
        draw.line([(30, page_total_h - 55), (W - 30, page_total_h - 55)], fill=(45, 49, 66), width=1)
        footer_page_text = f"Sayfa {page_idx + 1} / {total_pages}  •  " if total_pages > 1 else ""
        draw.text((50, page_total_h - 40), f"{footer_page_text}{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} Destek Sistemi • Bu resim resmi bilet arşividir.", font=font_small, fill=(148, 155, 164))
        draw.text((W - 250, page_total_h - 40), "discord.gg/imzapriw", font=font_small, fill=(148, 155, 164))

        if total_pages == 1:
            fn = f"transkript_{clean_ch_name}.png"
            fp = os.path.join(TRANSCRIPTS_DIR, f"{clean_ch_name}_{timestamp_str}.png")
        else:
            fn = f"transkript_{clean_ch_name}_parca_{page_idx + 1}.png"
            fp = os.path.join(TRANSCRIPTS_DIR, f"{clean_ch_name}_{timestamp_str}_p{page_idx + 1}.png")

        img.save(fp, "PNG", optimize=True)
        output_files.append((fp, fn))

    return output_files

# ─────────────────────────────────────────────
# TRANSKRİPT SAYFA KAYDIRMA (PAGINATOR VIEW)
# ─────────────────────────────────────────────
class TranscriptPaginatorView(discord.ui.View):
    def __init__(self, page_files: list, channel_name: str, ticket_id: str, timeout: float = 600):
        super().__init__(timeout=timeout)
        self.page_files = page_files  # [(path, filename), ...]
        self.channel_name = channel_name
        self.ticket_id = ticket_id
        self.current_page = 0
        self.update_buttons()

    def update_buttons(self):
        total = len(self.page_files)
        self.btn_prev.disabled = (self.current_page == 0)
        self.btn_next.disabled = (self.current_page >= total - 1)
        self.btn_indicator.label = f"Sayfa {self.current_page + 1} / {total}"

    @discord.ui.button(label="Yukarı Kaydır", style=discord.ButtonStyle.secondary)
    async def btn_prev(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.current_page > 0:
            self.current_page -= 1
            await self.render_page(interaction)
        else:
            await interaction.response.defer()

    @discord.ui.button(label="1 / 1", style=discord.ButtonStyle.secondary, disabled=True)
    async def btn_indicator(self, interaction: discord.Interaction, button: discord.ui.Button):
        pass

    @discord.ui.button(label="Aşağı Kaydır", style=discord.ButtonStyle.primary)
    async def btn_next(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.current_page < len(self.page_files) - 1:
            self.current_page += 1
            await self.render_page(interaction)
        else:
            await interaction.response.defer()

    @discord.ui.button(label="Tüm Sayfaları Gönder", style=discord.ButtonStyle.success)
    async def btn_all(self, interaction: discord.Interaction, button: discord.ui.Button):
        is_ephem = bool(interaction.message and interaction.message.flags.ephemeral)
        await interaction.response.defer(ephemeral=is_ephem)
        all_embeds = []
        all_files = []
        total = len(self.page_files)
        for idx, (path, fn) in enumerate(self.page_files, 1):
            emb = discord.Embed(
                title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ┊ Destek Dökümü — Sayfa {idx}/{total}",
                color=get_embed_color()
            )
            emb.set_image(url=f"attachment://{fn}")
            all_embeds.append(emb)
            all_files.append(discord.File(path, filename=fn))

        if len(all_embeds) <= 10:
            await interaction.followup.send(embeds=all_embeds, files=all_files, ephemeral=is_ephem)
        else:
            for i in range(0, len(all_embeds), 5):
                await interaction.followup.send(embeds=all_embeds[i:i+5], files=all_files[i:i+5], ephemeral=is_ephem)

    async def render_page(self, interaction: discord.Interaction):
        self.update_buttons()
        total = len(self.page_files)
        target_fn = self.page_files[self.current_page][1]

        att_url = None
        if interaction.message and interaction.message.attachments:
            for att in interaction.message.attachments:
                if att.filename == target_fn:
                    att_url = att.url
                    break
            if not att_url and len(interaction.message.attachments) > self.current_page:
                att_url = interaction.message.attachments[self.current_page].url

        if not att_url:
            att_url = f"attachment://{target_fn}"

        embed = interaction.message.embeds[0]
        embed.set_image(url=att_url)
        embed.set_footer(text=f"Sayfa {self.current_page + 1} / {total} • Aşağı / yukarı kaydırmak için butonları kullanın")
        await interaction.response.edit_message(embed=embed, view=self)
# EMBED & GÖRSEL PANEL ÜRETİCİLER
# ─────────────────────────────────────────────
def render_ticket_panel_card(logo_bytes: bytes = None) -> io.BytesIO:
    W, H = 950, 480
    img = Image.new('RGBA', (W, H), (10, 11, 15, 255))
    draw = ImageDraw.Draw(img)

    # Dış kart çerçevesi ve arka plan
    draw.rounded_rectangle([(10, 10), (W - 10, H - 10)], radius=20, fill=(16, 17, 23, 255), outline=(32, 35, 48, 255), width=2)
    draw.line([(35, 12), (W - 35, 12)], fill=(48, 52, 70, 180), width=1)

    # Font yükleme fonksiyonu
    font_paths_bold = ["C:/Windows/Fonts/segoeuib.ttf", "C:/Windows/Fonts/arialbd.ttf"]
    font_paths_reg = ["C:/Windows/Fonts/segoeui.ttf", "C:/Windows/Fonts/arial.ttf"]

    def load_f(paths, size):
        for p in paths:
            if os.path.exists(p):
                try:
                    return ImageFont.truetype(p, size)
                except Exception:
                    pass
        return ImageFont.load_default()

    font_brand = load_f(font_paths_bold, 28)
    font_title = load_f(font_paths_bold, 18)
    font_desc = load_f(font_paths_reg, 14)
    font_cat_title = load_f(font_paths_bold, 15)
    font_cat_desc = load_f(font_paths_reg, 13)
    font_warning = load_f(font_paths_reg, 12)
    font_watermark = load_f(font_paths_bold, 12)

    # Üst Başlık
    draw.text((40, 28), 'ɨ̇ ʍ ʐ ǟ', fill=(255, 255, 255, 255), font=font_brand)
    draw.text((145, 36), '|   DESTEK & TALEP SİSTEMİ', fill=(180, 186, 205, 255), font=font_title)

    # Sağ Üst Logo/İkon
    icon_size = 50
    ix, iy = W - 40 - icon_size, 20
    mask = Image.new('L', (icon_size, icon_size), 0)
    md = ImageDraw.Draw(mask)
    md.ellipse((0, 0, icon_size, icon_size), fill=255)

    if logo_bytes:
        try:
            logo_raw = Image.open(io.BytesIO(logo_bytes)).convert('RGBA')
            logo_raw = logo_raw.resize((icon_size, icon_size), Image.Resampling.LANCZOS)
            logo_raw.putalpha(mask)
            img.paste(logo_raw, (ix, iy), logo_raw)
            draw.ellipse([(ix - 2, iy - 2), (ix + icon_size + 2, iy + icon_size + 2)], outline=(60, 65, 85, 255), width=2)
        except Exception:
            logo_bytes = None

    if not logo_bytes:
        logo_box = Image.new('RGBA', (icon_size, icon_size), (30, 33, 44, 255))
        ld = ImageDraw.Draw(logo_box)
        font_icon = load_f(font_paths_bold, 16)
        ld.text((12, 14), 'IM', fill=(255, 255, 255, 255), font=font_icon)
        logo_box.putalpha(mask)
        img.paste(logo_box, (ix, iy), logo_box)
        draw.ellipse([(ix - 2, iy - 2), (ix + icon_size + 2, iy + icon_size + 2)], outline=(60, 65, 85, 255), width=2)

    # Açıklama Kutusu
    desc_y = 74
    draw.rounded_rectangle([(40, desc_y), (W - 40, desc_y + 40)], radius=8, fill=(22, 24, 33, 255), outline=(38, 41, 56, 255), width=1)
    draw.rounded_rectangle([(40, desc_y), (44, desc_y + 40)], radius=2, fill=(88, 101, 242, 255))
    draw.text((56, desc_y + 11), 'Yetkili ekibimizle güvenli ve hızlı bir şekilde iletişime geçmek için aşağıdaki menüden talebinize uygun kategoriyi seçiniz.', fill=(160, 166, 185, 255), font=font_desc)

    # Destek Kategorileri
    cats_start_y = 126
    cat_h = 48
    cat_spacing = 9

    categories = [
        ('Genel Destek & Soru', 'Sunucu işleyişi, genel sorular ve danışma', (46, 204, 113, 255)),
        ('Yetkili Başvurusu', 'Yönetim kadrosuna katılım talepleri', (88, 101, 242, 255)),
        ('VIP / Rol & Satın Alım', 'Özel roller, boost ayrıcalıkları ve işlemler', (241, 196, 15, 255)),
        ('Şikayet & Bildiri', 'Kural ihlali ve kullanıcı bildirimleri', (237, 66, 69, 255)),
        ('Özel Görüşme (Yönetim)', 'Üst yönetim ile birebir görüşme', (235, 69, 158, 255))
    ]

    for i, (ctitle, cdesc, accent) in enumerate(categories):
        cy = cats_start_y + i * (cat_h + cat_spacing)
        draw.rounded_rectangle([(40, cy), (W - 40, cy + cat_h)], radius=10, fill=(22, 24, 33, 255), outline=(36, 39, 52, 255), width=1)
        draw.rounded_rectangle([(52, cy + 14), (56, cy + 34)], radius=2, fill=accent)
        draw.text((68, cy + 13), ctitle, fill=(255, 255, 255, 255), font=font_cat_title)
        title_w = int(draw.textlength(ctitle, font=font_cat_title))
        draw.text((68 + title_w + 10, cy + 13), '—', fill=(75, 80, 100, 255), font=font_cat_title)
        draw.text((68 + title_w + 28, cy + 14), cdesc, fill=(135, 141, 158, 255), font=font_cat_desc)

    # Alt Uyarı & Filigran
    notice_y = 422
    draw.text((42, notice_y), 'Talebinizi oluşturduktan sonra lütfen yetkili ekibimizin yanıt vermesini bekleyiniz. Gereksiz talep açmak yaptırım sebebidir.', fill=(115, 122, 142, 255), font=font_warning)
    draw.text((W - 250, notice_y), 'ɨ̇ ʍ ʐ ǟ  •  RESMİ DESTEK SİSTEMİ', fill=(75, 80, 100, 255), font=font_watermark)

    out = io.BytesIO()
    img.save(out, format='PNG')
    out.seek(0)
    return out

def render_rules_card(logo_bytes: bytes = None) -> io.BytesIO:
    """Priv sunucu kuralları için estetik obsidyen görsel banner üretir."""
    W, H = 960, 520
    img = Image.new('RGBA', (W, H), (14, 16, 23, 255))
    draw = ImageDraw.Draw(img)

    # Arka plan ve kenarlık
    draw.rectangle([(0, 0), (W, H)], fill=(14, 16, 23, 255))
    draw.rounded_rectangle([(1, 1), (W - 2, H - 2)], radius=16, outline=(34, 38, 54, 255), width=2)
    draw.rounded_rectangle([(20, 3), (W - 20, 6)], radius=2, fill=(88, 101, 242, 255))

    font_paths_bold = ["C:/Windows/Fonts/segoeuib.ttf", "C:/Windows/Fonts/arialbd.ttf"]
    font_paths_reg = ["C:/Windows/Fonts/segoeui.ttf", "C:/Windows/Fonts/arial.ttf"]

    def load_f(paths, size):
        for p in paths:
            if os.path.exists(p):
                try:
                    return ImageFont.truetype(p, size)
                except Exception:
                    pass
        return ImageFont.load_default()

    font_brand = load_f(font_paths_bold, 28)
    font_subbrand = load_f(font_paths_bold, 17)
    font_badge = load_f(font_paths_bold, 11)
    font_rule_num = load_f(font_paths_bold, 13)
    font_rule_title = load_f(font_paths_bold, 14)
    font_rule_desc = load_f(font_paths_reg, 12)
    font_footer = load_f(font_paths_reg, 11.5)
    font_watermark = load_f(font_paths_bold, 11.5)

    # Üst Marka Başlığı
    draw.text((40, 24), 'ɨ̇ ʍ ʐ ǟ', fill=(255, 255, 255, 255), font=font_brand)
    draw.text((142, 32), '|   PRİW TOPLULUK VE SUNUCU KURALLARI', fill=(199, 210, 254, 255), font=font_subbrand)

    # Sağ Üst Logo veya Rozet
    icon_size = 40
    ix, iy = W - 40 - icon_size, 18
    mask = Image.new('L', (icon_size, icon_size), 0)
    md = ImageDraw.Draw(mask)
    md.ellipse((0, 0, icon_size, icon_size), fill=255)

    if logo_bytes:
        try:
            logo_raw = Image.open(io.BytesIO(logo_bytes)).convert('RGBA')
            logo_raw = logo_raw.resize((icon_size, icon_size), Image.Resampling.LANCZOS)
            logo_raw.putalpha(mask)
            img.paste(logo_raw, (ix, iy), logo_raw)
            draw.ellipse([(ix - 1, iy - 1), (ix + icon_size + 1, iy + icon_size + 1)], outline=(60, 65, 85, 255), width=1)
            draw.rounded_rectangle([(W - 275, 24), (ix - 12, 52)], radius=6, fill=(22, 26, 40, 255), outline=(48, 54, 80, 255), width=1)
            draw.text((W - 263, 30), 'RESMİ YÖNETMELİK  •  PRİW', fill=(129, 140, 248, 255), font=font_badge)
        except Exception:
            logo_bytes = None

    if not logo_bytes:
        draw.rounded_rectangle([(W - 240, 24), (W - 40, 52)], radius=6, fill=(22, 26, 40, 255), outline=(48, 54, 80, 255), width=1)
        draw.text((W - 228, 30), 'RESMİ YÖNETMELİK  •  PRİW', fill=(129, 140, 248, 255), font=font_badge)

    # Bilgilendirme Kutusu
    info_y = 68
    draw.rounded_rectangle([(40, info_y), (W - 40, info_y + 36)], radius=8, fill=(20, 23, 34, 255), outline=(34, 38, 54, 255), width=1)
    draw.rounded_rectangle([(40, info_y), (44, info_y + 36)], radius=2, fill=(168, 85, 247, 255))
    draw.text((56, info_y + 10), 'Sunucuya katılan, kanallarda bulunan ve bilet açan her üye aşağıdaki kuralları peşinen okumuş ve kabul etmiş sayılır.', fill=(160, 166, 185, 255), font=font_rule_desc)

    # 6 Temel Priv Kuralı
    rules = [
        (
            '01',
            'Mahremiyet & Priv Gizliliği',
            'Sunucu içi yazışmalar, özel sohbetler, ses/ekran kayıtları ve medya içerikleri dışarıya sızdırılamaz. İhlali derhal kalıcı ban sebebidir.',
            (168, 85, 247, 255)
        ),
        (
            '02',
            'Saygı & Rahatsız Edici Davranışlar',
            'Kişisel taciz, küçük düşürücü ağır hakaret, din/dil/ırk ayrımcılığı, kışkırtma ve huzur bozucu toxic davranışlar kesinlikle yasaktır.',
            (239, 68, 68, 255)
        ),
        (
            '03',
            'Reklam & İzinsiz DM İhlali',
            'Genel sohbetlerde veya üyelere özel mesaj (DM) yoluyla sunucu linki, satış veya tanıtım mesajı iletmek süresiz ban ile sonuçlanır.',
            (245, 158, 11, 255)
        ),
        (
            '04',
            'Ses Kanalları & Medya / Bas Düzeni',
            'Ses odalarında earrape, ses değiştirici (bass/soundpad) spamı yapmak ve kullanıcıları kasıtlı rahatsız etmek yasaktır.',
            (14, 165, 233, 255)
        ),
        (
            '05',
            'Hesap Güvenliği & Multi / Yan Hesap',
            'Sunucuya yan/troll hesap sokmak, hesap paylaşımı yapmak veya sistem açıklarını suistimal etmeye çalışmak yasaktır.',
            (236, 72, 153, 255)
        ),
        (
            '06',
            'Destek Sistemi & Yetkili İletişimi',
            'Talepleri gereksiz yere açmak, yetkilileri sebepsiz etiketlemek ve spam yapmak yasaktır. Sorunlar açık ve net iletilmelidir.',
            (16, 185, 129, 255)
        )
    ]

    rule_start_y = 116
    rule_h = 52
    rule_gap = 8

    for i, (num, title, desc, color) in enumerate(rules):
        ry = rule_start_y + i * (rule_h + rule_gap)
        draw.rounded_rectangle([(40, ry), (W - 40, ry + rule_h)], radius=10, fill=(20, 23, 34, 255), outline=(32, 36, 52, 255), width=1)
        draw.rounded_rectangle([(48, ry + 12), (52, ry + rule_h - 12)], radius=2, fill=color)
        draw.rounded_rectangle([(62, ry + 13), (88, ry + 39)], radius=6, fill=(28, 32, 48, 255), outline=(44, 50, 72, 255), width=1)
        draw.text((68, ry + 18), num, fill=color, font=font_rule_num)
        draw.text((100, ry + 11), title, fill=(255, 255, 255, 255), font=font_rule_title)
        draw.text((100, ry + 30), desc, fill=(148, 155, 175, 255), font=font_rule_desc)

    footer_y = 482
    draw.text((42, footer_y), 'İhlallerde yetki durumuna göre: Uyarı, Susturma (Timeout), Rol Geri Alımı ve İhraç (Ban) cezaları uygulanır.', fill=(120, 128, 148, 255), font=font_footer)
    draw.text((W - 255, footer_y), 'ɨ̇ ʍ ʐ ǟ  •  RESMİ TOPLULUK PROTOKOLÜ', fill=(88, 98, 128, 255), font=font_watermark)

    out = io.BytesIO()
    img.save(out, format='PNG')
    out.seek(0)
    return out

async def get_rules_file_and_embed(guild: discord.Guild = None) -> tuple[discord.File, discord.Embed]:
    """Priv kurallar görseli ve Discord embedini hazırlar."""
    logo_bytes = None
    if guild and guild.icon:
        try:
            logo_bytes = await guild.icon.with_format('png').with_size(128).read()
        except Exception:
            pass

    img_buf = await asyncio.to_thread(render_rules_card, logo_bytes)
    file = discord.File(fp=img_buf, filename="kurallar_banner.png")

    embed = discord.Embed(
        title="ɨ̇ ʍ ʐ ǟ  •  PRİW TOPLULUK VE SUNUCU KURALLARI",
        description=(
            "Bu sunucu özel (priv) bir topluluk olup, içerideki huzur, gizlilik ve güvenliğin korunması esastır.\n\n"
            "`1.` **Mahremiyet & Priv Gizliliği:**\n"
            "Sunucu içi yazışmalar, özel sohbetler, ses/ekran kayıtları ve paylaşılan dökümanlar sunucu dışına kesinlikle sızdırılamaz. İhlali kalıcı ihraç ve karaliste (Blacklist) sebebidir.\n\n"
            "`2.` **Saygı & İletişim Standartları:**\n"
            "Kişisel sınırları aşan ağır hakaret, tehdit, ifşa, trolleme, toxic davranışlar ve huzur bozucu kışkırtmalar tolere edilmez.\n\n"
            "`3.` **Reklam & İzinsiz DM İhlali:**\n"
            "Sunucu kanallarında veya üyelere izinsiz özel mesajla (DM) başka sunucu linki, satış veya reklam göndermek süresiz ban ile sonuçlanır.\n\n"
            "`4.` **Ses Kanalları & Medya / Bas Düzeni:**\n"
            "Ses odalarında earrape, rahatsız edici bas/soundpad açmak veya mikrofon basarak odadaki üyeleri rahatsız etmek yasaktır.\n\n"
            "`5.` **Hesap & Topluluk Güvenliği:**\n"
            "Sunucuya yan (multi/troll) hesap sokmak, hesap paylaşımı yapmak veya sistem kurallarının açığını aramak yasaktır.\n\n"
            "`6.` **Destek Sistemi & Yetkili İletişimi:**\n"
            "Gereksiz destek bileti açmak ve yetkilileri sebepsiz yere spamla etiketlemek yasaktır. Destek talepleri yalnızca gerçek konular içindir.\n\n"
            "*Yaptırımlar:* İhlalin ağırlığına göre Yetkili Uyarısı, Susturma (Timeout), Rol Geri Alımı ve İhraç (Ban) cezaları uygulanır."
        ),
        color=get_embed_color()
    )
    embed.set_image(url="attachment://kurallar_banner.png")
    embed.set_footer(text="ɨ̇ ʍ ʐ ǟ  •  Resmi Topluluk Yönetmeliği  •  discord.gg/imzapriw")
    return file, embed

class RulesApprovalView(discord.ui.View):
    """Kullanıcıların kuralları okuyup onayladığını kaydeden kalıcı buton görünümü."""
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Kuralları Okudum ve Onaylıyorum",
        style=discord.ButtonStyle.secondary,
        custom_id="imza_rules_approve_btn"
    )
    async def approve_rules_callback(self, interaction: discord.Interaction, button: discord.ui.Button):
        msg = (
            "**ɨ̇ ʍ ʐ ǟ  •  Topluluk & Priv Protokolü Onaylandı**\n\n"
            "Sunucu kurallarını okuduğunuz ve gizlilik ilkelerine uymayı kabul ettiğiniz sisteme kaydedildi.\n"
            "ɨ̇ ʍ ʐ ǟ bünyesinde huzurlu ve keyifli vakit geçirmenizi dileriz."
        )
        await interaction.response.send_message(msg, ephemeral=True)

async def get_ticket_panel_file_and_embed(guild: discord.Guild = None) -> tuple[discord.File, discord.Embed]:
    logo_bytes = None
    if guild and guild.icon:
        try:
            logo_bytes = await guild.icon.with_format('png').with_size(128).read()
        except Exception:
            pass

    img_buf = await asyncio.to_thread(render_ticket_panel_card, logo_bytes)
    file = discord.File(fp=img_buf, filename="ticket_panel.png")
    embed = discord.Embed(color=get_embed_color())
    embed.set_image(url="attachment://ticket_panel.png")
    return file, embed

def build_ticket_panel_embed(guild: discord.Guild = None) -> discord.Embed:
    bot_name = config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')
    embed = discord.Embed(
        title=f"{bot_name}  |  Destek & Talep Sistemi",
        description=(
            "> Yetkili ekibimizle güvenli ve hızlı bir şekilde iletişime geçmek için aşağıdaki menüden talebinize uygun kategoriyi seçiniz.\n\n"
            "**DESTEK KATEGORİLERİ**\n"
            "• **Genel Destek & Soru** — Sunucu işleyişi, genel sorular ve danışma\n"
            "• **Yetkili Başvurusu** — Yönetim kadrosuna katılım talepleri\n"
            "• **VIP / Rol & Satın Alım** — Özel roller, boost ayrıcalıkları ve işlemler\n"
            "• **Şikayet & Bildiri** — Kural ihlali ve kullanıcı bildirimleri\n"
            "• **Özel Görüşme (Yönetim)** — Üst yönetim ile birebir görüşme\n\n"
            "*Talebinizi oluşturduktan sonra lütfen yetkili ekibimizin yanıt vermesini bekleyiniz. Gereksiz talep açmak yaptırım sebebidir.*"
        ),
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_footer(text=f"{bot_name} • Resmi Destek Sistemi")
    return embed

# ─────────────────────────────────────────────
# TICKET OLUŞTURMA MODAL FORMU
# ─────────────────────────────────────────────
class TicketCreateModal(discord.ui.Modal):
    def __init__(self, cat_key: str):
        self.cat_key = cat_key
        cat_info = TICKET_CATEGORIES.get(cat_key, {})
        title_txt = f"Talep: {cat_info.get('label', 'Destek Talebi')}"[:45]
        super().__init__(title=title_txt)

        self.subject = discord.ui.TextInput(
            label="Talebinizin Konusu / Başlığı",
            placeholder="Örn: Bilgi almak istiyorum",
            min_length=3,
            max_length=100,
            required=True
        )
        self.add_item(self.subject)

        self.description_input = discord.ui.TextInput(
            label="Detaylı Açıklama / Sorunuz",
            style=discord.TextStyle.paragraph,
            placeholder="Lütfen talebinizi veya sorununuzu detaylı açıklayınız...",
            min_length=10,
            max_length=1000,
            required=True
        )
        self.add_item(self.description_input)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        user = interaction.user

        # Zaten açık bileti var mı kontrol et
        existing_ch, _ = get_user_open_ticket(guild, user.id)
        if existing_ch:
            await interaction.followup.send(
                f"Zaten açık bir destek talebiniz bulunuyor: {existing_ch.mention}\n"
                f"Yeni bir talep açabilmek için mevcut talebinizi sonlandırmalısınız.",
                ephemeral=True
            )
            return

        cat_info = TICKET_CATEGORIES.get(self.cat_key, {})
        data = load_tickets()
        counter = data.get("counter", 0) + 1
        data["counter"] = counter

        channel_name = f"talep-{counter:04d}-{user.name}"[:30]

        # Kategori tespiti
        target_category = None
        cfg_cat_id = config.get("ticket_kategori_id")
        if cfg_cat_id:
            target_category = guild.get_channel(int(cfg_cat_id))

        staff_role = None
        cfg_role_id = config.get("ticket_yetkili_rol_id")
        if cfg_role_id:
            staff_role = guild.get_role(int(cfg_role_id))

        # İzinler
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                attach_files=True,
                embed_links=True
            ),
            guild.me: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                manage_channels=True,
                manage_messages=True,
                embed_links=True,
                attach_files=True
            )
        }

        if staff_role:
            overwrites[staff_role] = discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                attach_files=True,
                embed_links=True,
                manage_messages=True
            )

        try:
            ticket_channel = await guild.create_text_channel(
                name=channel_name,
                category=target_category,
                overwrites=overwrites,
                topic=f"Talep Sahibi: {user.name} ({user.id}) | Konu: {self.subject.value[:100]}",
                reason=f"Destek talebi açıldı: {user.display_name}"
            )

            # Ticket bilgisini kaydet
            ticket_data = {
                "id": f"#{counter:04d}",
                "channel_id": ticket_channel.id,
                "owner_id": user.id,
                "owner_name": user.display_name,
                "category": cat_info.get("label", "Destek"),
                "subject": self.subject.value,
                "description": self.description_input.value,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "claimed_by": None,
                "claimed_by_name": "Üstlenilmedi",
                "status": "open"
            }
            data.setdefault("active", {})[str(ticket_channel.id)] = ticket_data
            save_tickets(data)

            # Hoş geldin embedi (kullanıcı sicil kaydı ve ihlal detaylarıyla birlikte)
            welcome_embed = build_ticket_welcome_embed(ticket_data, user, guild)

            # Sabit yetkili rol ID'si (her zaman bu rol etiketlensin)
            hardcoded_staff_role = guild.get_role(0)
            ping_parts = []
            if hardcoded_staff_role:
                ping_parts.append(hardcoded_staff_role.mention)
            elif staff_role:
                ping_parts.append(staff_role.mention)
            ping_parts.append(user.mention)
            ping_text = " ".join(ping_parts)

            welcome_msg = await ticket_channel.send(content=ping_text, embed=welcome_embed, view=TicketControlView())

            # welcome_message_id kaydet (embed daha sonra güncellenebilsin)
            ticket_data["welcome_message_id"] = welcome_msg.id

            # Kullanıcı Sicil & Profil Kartı (Bağımsız kart ve web link butonları)
            try:
                sicil_embed, sicil_view = build_ticket_sicil_embed(user, guild)
                sicil_msg = await ticket_channel.send(embed=sicil_embed, view=sicil_view)
                ticket_data["sicil_message_id"] = sicil_msg.id
            except Exception as se:
                print(f"[Ticket Sicil Kartı Gönderme Hatası]: {se}", flush=True)

            data.setdefault("active", {})[str(ticket_channel.id)] = ticket_data
            save_tickets(data)

            await interaction.followup.send(f"Destek talebiniz açıldı: {ticket_channel.mention}", ephemeral=True)
            print(f"[Ticket] Yeni talep: {ticket_channel.name} ({user.display_name} - {cat_info.get('label')})")
        except Exception as e:
            await interaction.followup.send(f"Talep oluşturulurken bir hata oluştu: {e}", ephemeral=True)
            print(f"[Ticket Hata]: {e}")

# ─────────────────────────────────────────────
# ANA TICKET PANEL VIEW (KALICI SEÇİM MENÜSÜ)
# ─────────────────────────────────────────────
class TicketSelectMenu(discord.ui.Select):
    def __init__(self):
        options = []
        for key, cat in TICKET_CATEGORIES.items():
            options.append(
                discord.SelectOption(
                    label=cat["label"],
                    value=key,
                    description=cat["description"]
                )
            )
        super().__init__(
            placeholder="Destek talebi açmak için kategori seçiniz...",
            min_values=1,
            max_values=1,
            custom_id="imza:ticket_category_select",
            options=options
        )

    async def callback(self, interaction: discord.Interaction):
        selected_key = self.values[0]
        modal = TicketCreateModal(selected_key)
        await interaction.response.send_modal(modal)

class TicketPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketSelectMenu())

# ─────────────────────────────────────────────
# TICKET İÇİ KONTROL PANELİ VIEW (BUTONLAR)
# ─────────────────────────────────────────────
class TicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Kapat", style=discord.ButtonStyle.secondary, custom_id="imza:btn_ticket_close")
    async def close_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await handle_ticket_close(interaction)

    @discord.ui.button(label="Üstlen", style=discord.ButtonStyle.primary, custom_id="imza:btn_ticket_claim")
    async def claim_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await handle_ticket_claim(interaction)

    @discord.ui.button(label="Transkript", style=discord.ButtonStyle.secondary, custom_id="imza:btn_ticket_transcript")
    async def transcript_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await handle_ticket_transcript(interaction)

    @discord.ui.button(label="Sil", style=discord.ButtonStyle.danger, custom_id="imza:btn_ticket_delete")
    async def delete_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await handle_ticket_delete(interaction)

# ─────────────────────────────────────────────
# KAPATILMIŞ TICKET KONTROL PANELİ
# ─────────────────────────────────────────────
class ClosedTicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Yeniden Aç", style=discord.ButtonStyle.success, custom_id="imza:btn_ticket_reopen")
    async def reopen_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await handle_ticket_reopen(interaction)

    @discord.ui.button(label="Transkript Al", style=discord.ButtonStyle.secondary, custom_id="imza:btn_ticket_closed_transcript")
    async def transcript_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await handle_ticket_transcript(interaction)

    @discord.ui.button(label="Talebi Sil", style=discord.ButtonStyle.danger, custom_id="imza:btn_ticket_closed_delete")
    async def delete_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await handle_ticket_delete(interaction)

# ─────────────────────────────────────────────
# TICKET AKSİYONLARI (KAPAT, ÜSTLEN, SİL, VB.)
# ─────────────────────────────────────────────
async def handle_ticket_claim(interaction: discord.Interaction):
    """Yetkilinin bileti üstlenmesini sağlar."""
    member = interaction.user
    if not is_ticket_staff(member):
        await interaction.response.send_message("Bu bileti yalnızca yetkili kadrosundaki kişiler üstlenebilir.", ephemeral=True)
        return

    data = load_tickets()
    ticket_info = data.get("active", {}).get(str(interaction.channel_id))
    if not ticket_info:
        await interaction.response.send_message("Bu kanal kayıtlı bir bilet kanalı değil.", ephemeral=True)
        return

    current_claim = ticket_info.get("claimed_by")
    if current_claim:
        claimer = interaction.guild.get_member(current_claim)
        name = claimer.display_name if claimer else f"<@{current_claim}>"
        await interaction.response.send_message(f"Bu talep zaten **{name}** tarafından üstlenilmiş.", ephemeral=True)
        return

    ticket_info["claimed_by"] = member.id
    ticket_info["claimed_by_name"] = member.display_name
    save_tickets(data)

    # 1. Transcript index kaydını güncelle
    index_data = load_transcript_index()
    target_slug = None
    for sid, rec in index_data.items():
        if str(rec.get("channel_id")) == str(interaction.channel_id):
            rec["claimed_by_name"] = member.display_name
            rec["claimed_by_id"] = str(member.id)
            target_slug = sid
            break
    save_transcript_index(index_data)

    # 2. HTML dosyasını anında yeniden derle
    try:
        await generate_html_transcript(interaction.channel, ticket_info, existing_slug_id=target_slug)
    except Exception as e:
        print(f"[Claim HTML Update Hatası]: {e}", flush=True)

    # 3. Welcome embed'i güncelle (İlgilenen Yetkili ve güncel sicil durumu)
    await refresh_ticket_welcome_embed(interaction.channel_id)

    # 4. SSE dinleyicilerini tetikle (açık olan web ekranları salisesinde güncellensin)
    ch_id_int = int(interaction.channel_id)
    if ch_id_int in ticket_sse_listeners:
        for q in list(ticket_sse_listeners[ch_id_int]):
            try:
                q.put_nowait(True)
            except Exception:
                pass

    embed = discord.Embed(
        description=f"Bu destek talebi yetkili {member.mention} tarafından **üstlenildi**.",
        color=0x5865f2
    )
    await interaction.channel.send(embed=embed)
    try:
        if not interaction.response.is_done():
            await interaction.response.send_message("Talep üzerinize atandı.", ephemeral=True)
        else:
            await interaction.followup.send("Talep üzerinize atandı.", ephemeral=True)
    except Exception:
        pass
    print(f"[Ticket] {interaction.channel.name} yetkili {member.display_name} tarafından üstlenildi.")

async def handle_ticket_close(interaction: discord.Interaction):
    """Bileti kilitler ve kapatılmış moduna alır."""
    member = interaction.user
    data = load_tickets()
    ticket_info = data.get("active", {}).get(str(interaction.channel_id))
    
    if not ticket_info:
        await interaction.response.send_message("Bu kanal kayıtlı bir bilet kanalı değil.", ephemeral=True)
        return

    owner_id = ticket_info.get("owner_id")
    if member.id != owner_id and not is_ticket_staff(member):
        await interaction.response.send_message("Bu bileti yalnızca bilet sahibi veya yetkililer kapatabilir.", ephemeral=True)
        return

    if ticket_info.get("status") == "closed":
        await interaction.response.send_message("Bu bilet zaten kapatılmış durumda.", ephemeral=True)
        return

    await interaction.response.defer()

    ticket_info["status"] = "closed"
    ticket_info["closed_by"] = member.id
    ticket_info["closed_by_name"] = member.display_name
    ticket_info["closed_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    save_tickets(data)

    channel = interaction.channel
    owner = interaction.guild.get_member(owner_id)

    # Talep sahibinin yazma iznini kapat (sadece okuyabilir)
    if owner:
        await channel.set_permissions(owner, view_channel=True, send_messages=False, read_message_history=True)

    # İsim güncelleme (emojisiz)
    try:
        clean_name = channel.name.replace("talep-", "").replace("kilit-", "").replace("🎫・", "").replace("🔒・", "").strip()
        await channel.edit(name=f"kilit-{clean_name}"[:30])
    except Exception:
        pass

    close_embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Destek Talebi Kapatıldı",
        description=(
            f"Bu destek talebi {member.mention} tarafından **kapatıldı**.\n\n"
            f"• **Talep Sahibi:** <@{owner_id}>\n"
            f"• **Kapatan:** {member.mention}\n"
            f"• **Kapanış Tarihi:** `{ticket_info['closed_at']}`\n\n"
            "*Aşağıdaki butonları kullanarak talebi silebilir veya yeniden açabilirsiniz.*"
        ),
        color=0xed4245,
        timestamp=datetime.now(timezone.utc)
    )
    await channel.send(embed=close_embed, view=ClosedTicketControlView())

    # Log kanalına bildir
    log_ch_id = config.get("ticket_log_kanal_id")
    if log_ch_id:
        log_ch = interaction.guild.get_channel(int(log_ch_id))
        if log_ch:
            log_embed = discord.Embed(
                title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Talep Kapatıldı",
                description=f"• **Kanal:** {channel.name}\n• **Açan:** <@{owner_id}>\n• **Kapatan:** {member.mention}",
                color=0xed4245,
                timestamp=datetime.now(timezone.utc)
            )
            await log_ch.send(embed=log_embed)

async def handle_ticket_reopen(interaction: discord.Interaction):
    """Kapatılmış bileti tekrar açar."""
    member = interaction.user
    if not is_ticket_staff(member):
        await interaction.response.send_message("Bu bileti yalnızca yetkililer yeniden açabilir.", ephemeral=True)
        return

    data = load_tickets()
    ticket_info = data.get("active", {}).get(str(interaction.channel_id))
    if not ticket_info:
        await interaction.response.send_message("Bu kanal kayıtlı bir bilet kanalı değil.", ephemeral=True)
        return

    await interaction.response.defer()

    ticket_info["status"] = "open"
    save_tickets(data)

    channel = interaction.channel
    owner_id = ticket_info.get("owner_id")
    owner = interaction.guild.get_member(owner_id)

    if owner:
        await channel.set_permissions(owner, view_channel=True, send_messages=True, read_message_history=True)

    try:
        clean_name = channel.name.replace("kilit-", "").replace("talep-", "").replace("🔒・", "").replace("🎫・", "").strip()
        await channel.edit(name=f"talep-{clean_name}"[:30])
    except Exception:
        pass

    embed = discord.Embed(
        description=f"Destek talebi {member.mention} tarafından **yeniden açıldı**.",
        color=0x57f287
    )
    await channel.send(embed=embed, view=TicketControlView())

class DynamicTranscriptButton(discord.ui.DynamicItem[discord.ui.Button], template=r"tr:slug:(?P<slug>[a-zA-Z0-9_\-]+)"):
    def __init__(self, slug: str):
        super().__init__(
            discord.ui.Button(
                label="Web Transkriptini Aç",
                style=discord.ButtonStyle.primary,
                custom_id=f"tr:slug:{slug}"
            )
        )
        self.slug = slug

    @classmethod
    async def from_custom_id(cls, interaction: discord.Interaction, item: discord.ui.Button, match: re.Match[str]):
        slug = match.group("slug")
        return cls(slug)

    async def callback(self, interaction: discord.Interaction):
        if not is_ticket_staff(interaction.user):
            await interaction.response.send_message(
                "Erişim Reddedildi: Bu web transkriptini yalnızca 0 yetkili rolüne sahip kişiler açabilir.",
                ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)
        base_url = await ensure_public_web_url()
        direct_url = f"{base_url}/transcript/{self.slug}"

        view = DirectLinkView(direct_url)
        await interaction.followup.send(
            content=(
                "**Yetkili Web Portalı Bağlantısı** (Rol: `0`)\n\n"
                "Aşağıdaki butona tıklayarak transkript sayfasına gidebilirsiniz.\n"
                "Giriş yapmak için Discord'da `/yetkili-kod` komutunu yazarak 6 haneli tek kullanımlık giriş kodunuzu alabilirsiniz."
            ),
            view=view,
            ephemeral=True
        )

class TranscriptDynamicView(discord.ui.View):
    def __init__(self, slug: str):
        super().__init__(timeout=None)
        self.add_item(DynamicTranscriptButton(slug))

class DirectLinkView(discord.ui.View):
    def __init__(self, url: str):
        super().__init__(timeout=600)
        self.add_item(discord.ui.Button(
            label="Web Transkriptine Git",
            url=url,
            style=discord.ButtonStyle.link
        ))

async def handle_ticket_transcript(interaction: discord.Interaction):
    """Biletin yetkili web sitesi döküm linkini oluşturur ve gönderir."""
    member = interaction.user
    if not is_ticket_staff(member):
        await interaction.response.send_message(
            "Bu transkript dökümünü yalnızca yetkili rolüne (0) sahip kişiler görüntüleyebilir.",
            ephemeral=True
        )
        return

    await interaction.response.defer(ephemeral=True)
    channel = interaction.channel
    data = load_tickets()
    ticket_info = data.get("active", {}).get(str(channel.id))
    ticket_id = ticket_info.get("id", f"#{channel.id}") if ticket_info else f"#{channel.id}"

    try:
        site_url, slug_id, secret_key, file_path = await generate_html_transcript(channel, ticket_info)

        embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Yetkili Web Transkripti",
            description=(
                f"**{channel.name}** konuşma dökümü özel web sitesi olarak hazırlandı.\n\n"
                f"• **Web Portalı:** [Transkript Sitesine Git]({site_url})\n\n"
                "**Giriş Güvenliği:**\n"
                "Bu portal yalnızca **0** yetkili rolüne açıktır.\n"
                "Siteye giriş yapabilmek için Discord'da `/yetkili-kod` komutunu yazıp aldığınız 6 haneli kodu ve Discord ID'nizi giriniz."
            ),
            color=get_embed_color(),
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"{ticket_id} • Yetkili Giriş Kapısı (0)")
        logo = get_brand_logo_url(interaction.guild)
        if logo:
            embed.set_thumbnail(url=logo)

        view = DirectLinkView(site_url)
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)
    except Exception as e:
        await interaction.followup.send(f"Transkript oluşturulurken bir hata oluştu: {e}", ephemeral=True)

async def handle_ticket_delete(interaction: discord.Interaction):
    """Bileti sonlandırır, web transkriptini arşivler ve log kanalına linki iletir."""
    member = interaction.user
    if not is_ticket_staff(member):
        await interaction.response.send_message("Bu bileti yalnızca yetkililer silebilir.", ephemeral=True)
        return

    await interaction.response.send_message("Bilet siliniyor... Web transkripti hazırlanıyor ve arşivleniyor.", ephemeral=False)

    channel = interaction.channel
    guild = interaction.guild
    data = load_tickets()
    active_dict = data.get("active", {})
    ticket_info = active_dict.pop(str(channel.id), None)
    if not ticket_info:
        for cid_k, v in list(active_dict.items()):
            if str(cid_k) == str(channel.id) or v.get("channel_id") == channel.id or (v.get("id") and v.get("id").replace("#", "") in channel.name):
                ticket_info = active_dict.pop(cid_k, None)
                break
    save_tickets(data)

    ticket_id = ticket_info.get("id", f"#{channel.id}") if ticket_info else f"#{channel.id}"

    # 1. Web Transkriptini oluştur
    try:
        site_url, slug_id, secret_key, file_path = await generate_html_transcript(channel, ticket_info)

        # 2. Log kanalına gönder (Yalnızca yetkililerin gördüğü kanala)
        log_ch_id = config.get("ticket_log_kanal_id")
        if log_ch_id:
            log_ch = guild.get_channel(int(log_ch_id))
            if log_ch:
                owner_mention = f"<@{ticket_info.get('owner_id')}>" if ticket_info else "Bilinmiyor"
                log_desc = (
                    f"**{channel.name}** kanalı silindi ve arşivlendi.\n\n"
                    f"• **Talep Sahibi:** {owner_mention}\n"
                    f"• **Silen Yetkili:** {member.mention}\n"
                    f"• **Kategori:** `{ticket_info.get('category', 'Destek') if ticket_info else 'Destek'}`\n"
                    f"• **Konu:** `{ticket_info.get('subject', 'Belirtilmedi') if ticket_info else 'Belirtilmedi'}`\n\n"
                    f"*Aşağıdaki butona tıklayarak web transkriptini açabilirsiniz.*\n"
                    f"*(Yalnızca 0 rolüne sahip yetkililer açabilir.)*"
                )

                log_embed = discord.Embed(
                    title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Destek Talebi Silindi",
                    description=log_desc,
                    color=get_embed_color(),
                    timestamp=datetime.now(timezone.utc)
                )
                log_embed.set_footer(text=f"{ticket_id} • Web Arşivi (0)")
                logo = get_brand_logo_url(guild)
                if logo:
                    log_embed.set_thumbnail(url=logo)

                view = TranscriptDynamicView(slug_id)
                await log_ch.send(embed=log_embed, view=view)

        # 3. Talep sahibine DM GİTMEYECEK:
        # Kullanıcı talebi: 'diğer kisilere dm den gitmicek yani'
        # Bu nedenle üyelere transkript DM'si gönderilmez.
    except Exception as e:
        print(f"[Transkript Hata]: {e}", flush=True)

    # Geri sayım ve kanalı sil
    await asyncio.sleep(4)
    try:
        await channel.delete(reason=f"Bilet {member.display_name} tarafından silindi.")
    except Exception as e:
        print(f"[Kanal Silme Hatası]: {e}", flush=True)

# ─────────────────────────────────────────────
# ARKA PLAN GÖREVLERİ (SABİT SES & YAYINDA DURUMU)
# ─────────────────────────────────────────────
@tasks.loop(seconds=10)
async def keep_voice_connection():
    """Botu belirtilen ses kanalında (kulaklık kapalı, mic açık) 7/24 bağlı tutar."""
    target_ch_id = config.get("sabit_ses_kanal_id", 0)
    if not target_ch_id:
        return

    try:
        channel = bot.get_channel(int(target_ch_id))
        if not channel:
            try:
                channel = await bot.fetch_channel(int(target_ch_id))
            except Exception:
                return
        if not channel or not isinstance(channel, (discord.VoiceChannel, discord.StageChannel)):
            return

        guild = channel.guild
        vc = guild.voice_client

        if vc is not None:
            if vc.is_connected() and vc.channel and vc.channel.id == channel.id:
                me_vs = guild.me.voice if guild.me else None
                if me_vs and (not me_vs.self_deaf or me_vs.self_mute):
                    try:
                        await guild.change_voice_state(channel=channel, self_mute=False, self_deaf=True)
                    except Exception:
                        pass
                return
            elif vc.is_connected() and vc.channel and vc.channel.id != channel.id:
                try:
                    await vc.move_to(channel)
                    await guild.change_voice_state(channel=channel, self_mute=False, self_deaf=True)
                    print(f"[Sabit Ses] Bot sabit kanala ({channel.name}) taşındı.", flush=True)
                    return
                except Exception:
                    pass

            # Ses istemcisi takılı veya kopmuşsa güvenle kapat
            try:
                await vc.disconnect(force=True)
            except Exception:
                pass
            await asyncio.sleep(1)

        # Kanala bağlan ve kulaklık kapalı, mikrofon açık ayarla
        try:
            await channel.connect(self_deaf=True, self_mute=False, reconnect=True)
            await asyncio.sleep(0.5)
            await guild.change_voice_state(channel=channel, self_mute=False, self_deaf=True)
            print(f"[Sabit Ses] {channel.name} kanalına bağlanıldı (Kulaklık: Kapalı, Mic: Açık).", flush=True)
        except Exception as e:
            print(f"[Sabit Ses Bağlantı Hatası]: {e}", flush=True)
    except Exception as e:
        print(f"[Sabit Ses Genel Hata]: {e}", flush=True)

@tasks.loop(seconds=20)
async def presence_rotation():
    """Botun durumunu 'Yayında' (Streaming - Mor Rozet) olarak dönerek günceller."""
    await bot.wait_until_ready()
    bot_adi = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    stream_url = config.get("stream_url", "https://www.twitch.tv/imzapriw")

    try:
        active_count = len(load_tickets().get("active", {}))
        activity1 = discord.Streaming(
            name=f"{active_count} Aktif Destek | {bot_adi}",
            url=stream_url
        )
        await bot.change_presence(activity=activity1)
    except Exception as e:
        print(f"[Presence Hata 1]: {e}", flush=True)

    await asyncio.sleep(10)

    try:
        activity2 = discord.Streaming(
            name=f"discord.gg/imzapriw | {bot_adi}",
            url=stream_url
        )
        await bot.change_presence(activity=activity2)
    except Exception as e:
        print(f"[Presence Hata 2]: {e}", flush=True)

@bot.event
async def on_voice_state_update(member, before, after):
    """Bot kanaldan düşürülürse veya taşınırsa otomatik olarak sabit kanala geri sokar."""
    target_ch_id = config.get("sabit_ses_kanal_id", 0)
    if target_ch_id and member.id == bot.user.id:
        if after.channel is None or after.channel.id != int(target_ch_id):
            await asyncio.sleep(1)
            target_ch = member.guild.get_channel(int(target_ch_id))
            if target_ch:
                vc = member.guild.voice_client
                try:
                    if vc and vc.is_connected():
                        await vc.move_to(target_ch)
                    else:
                        await target_ch.connect(self_deaf=True, self_mute=False, reconnect=True)
                    await member.guild.change_voice_state(channel=target_ch, self_mute=False, self_deaf=True)
                except Exception:
                    pass

@bot.event
async def on_message(message: discord.Message):
    if not message.guild:
        return
    await bot.process_commands(message)

    ch_id = message.channel.id
    # Bu kanala bağlı web SSE dinleyicileri varsa hemen yeni mesajı ilet
    if ch_id in ticket_sse_listeners and ticket_sse_listeners[ch_id]:
        queues = list(ticket_sse_listeners[ch_id])
        for q in queues:
            try:
                q.put_nowait(True)
            except Exception:
                pass

@bot.event
async def on_guild_channel_delete(channel: discord.abc.GuildChannel):
    """Bir bilet kanalı Discord üzerinden silindiğinde tickets.json aktif listesinden anında temizler."""
    try:
        cid_str = str(channel.id)
        tdata = load_tickets()
        active = tdata.get("active", {})
        dirty = False
        if cid_str in active:
            active.pop(cid_str, None)
            dirty = True
        else:
            for cid_k, v in list(active.items()):
                if str(cid_k) == cid_str or v.get("channel_id") == channel.id or (v.get("id") and str(v.get("id")).replace("#", "") in channel.name):
                    active.pop(cid_k, None)
                    dirty = True
                    break
        if dirty:
            save_tickets(tdata)
            print(f"[Channel Delete Event] Kanal #{channel.name} ({cid_str}) silindi, tickets.json aktif bilet listesinden temizlendi.", flush=True)
    except Exception as e:
        print(f"[on_guild_channel_delete Hata]: {e}", flush=True)

@tasks.loop(seconds=60)
async def tunnel_watchdog():
    """Cloudflare tünelinin canlı kalmasını 7/24 denetler ve koparsa otomatik ayağa kaldırır."""
    cfg_url = str(config.get("web_base_url", "")).strip()
    if cfg_url and cfg_url.lower() != "auto" and not any(h in cfg_url for h in ["localhost", "127.0.0.1", "192.168."]):
        return
    global cloudflared_proc, active_tunnel_url
    is_alive = cloudflared_proc and cloudflared_proc.poll() is None
    if not is_alive or not active_tunnel_url or not await is_tunnel_healthy(active_tunnel_url):
        print("[Cloudflare Watchdog] Tünel bağlantısı düştü veya yanıt vermiyor, otomatik yenileniyor...", flush=True)
        port = int(config.get("web_port", 8080))
        await start_cloudflare_tunnel(port)

# ─────────────────────────────────────────────
# BOT EVENTLERİ & ON_READY
# ─────────────────────────────────────────────
@bot.event
async def on_ready():
    bot_name = str(bot.user) if bot.user else "IMZA Ticket Bot"
    guild_count = len(bot.guilds)
    banner = f"""
    +----------------------------------------------------------+
    |                     IMZA TICKET SYSTEM                   |
    |          Gelismis Destek & Bilet Yonetim Botu            |
    +----------------------------------------------------------+
    |  Bot Ismi: {bot_name:<46}|
    |  Sunucu:   {guild_count:<46}|
    |  Durum:    Aktif & Kalici Menuler Yuklendi               |
    +----------------------------------------------------------+
    """
    print(banner, flush=True)

    # Kalıcı View'leri ve Dinamik Butonları kaydet (bot yeniden başlayınca butonlar ve menü bozulmaz)
    bot.add_view(TicketPanelView())
    bot.add_view(RulesApprovalView())
    bot.add_view(TicketControlView())
    bot.add_view(ClosedTicketControlView())
    bot.add_dynamic_items(DynamicTranscriptButton)

    # Web Transkript Sunucusunu başlat (arka planda anında açılır)
    bot.loop.create_task(start_web_server())

    # Mevcut destek paneli varsa otomatik yeni tasarımla güncelle
    panel_ch_id = config.get("ticket_panel_kanal_id")
    panel_msg_id = config.get("ticket_panel_mesaj_id")
    if panel_ch_id and panel_msg_id:
        try:
            panel_ch = bot.get_channel(int(panel_ch_id))
            if panel_ch:
                panel_msg = await panel_ch.fetch_message(int(panel_msg_id))
                if panel_msg:
                    file, embed = await get_ticket_panel_file_and_embed(panel_ch.guild)
                    await panel_msg.edit(embed=embed, attachments=[file], view=TicketPanelView())
                    print("[Panel] Mevcut destek paneli yeni görsel tasarımla güncellendi.", flush=True)
        except Exception as e:
            print(f"[Panel Otomatik Güncelleme Hatası]: {e}", flush=True)

    # Arka plan görevlerini başlat
    if not keep_voice_connection.is_running():
        keep_voice_connection.start()
    if not presence_rotation.is_running():
        presence_rotation.start()
    if not tunnel_watchdog.is_running():
        tunnel_watchdog.start()

    # Slash komutlarını senkronize et (arka planda çalışsın)
    async def sync_slash_bg():
        try:
            synced = await bot.tree.sync()
            print(f"[Slash] {len(synced)} slash komutu senkronize edildi.", flush=True)
        except Exception as e:
            print(f"[Slash Hata]: {e}", flush=True)
    bot.loop.create_task(sync_slash_bg())

    # Açılışta tüm aktif destek taleplerinin karşılama mesajlarını güncel sicil ile yenile
    async def refresh_active_tickets_bg():
        await asyncio.sleep(2)
        try:
            tdata = load_tickets()
            for cid in list(tdata.get("active", {}).keys()):
                await refresh_ticket_welcome_embed(int(cid))
            print("[Ticket] Aktif destek talepleri kullanıcı sicil bilgileriyle güncellendi.", flush=True)
        except Exception as e:
            print(f"[Ticket Açılış Güncelleme Hatası]: {e}", flush=True)
    bot.loop.create_task(refresh_active_tickets_bg())

    # İlk durum (Yayında - Mor Rozet)
    bot_adi = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    stream_url = config.get("stream_url", "https://www.twitch.tv/imzapriw")
    try:
        await bot.change_presence(activity=discord.Streaming(name=f"Destek & Bilet | {bot_adi}", url=stream_url))
    except Exception as e:
        print(f"[Presence Açılış Hatası]: {e}", flush=True)

@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return
    # Hem ! hem de . öneklerini (örn: .sicil, !sicil) otomatik işle
    content = message.content.strip()
    if content.startswith("."):
        cmd_candidate = content[1:].strip().lower()
        if cmd_candidate.startswith(("sicil", "sicil-bak", "sicili")):
            message.content = "!" + content[1:]
    await bot.process_commands(message)



# ─────────────────────────────────────────────
# SLASH KOMUTLARI
# ─────────────────────────────────────────────

# 1. /ticket-kur (Yönetici)
@bot.tree.command(name="ticket-kur", description="Destek kategorisini, yetkili rolünü, log kanalını ve paneli kurar.")
@app_commands.default_permissions(administrator=True)
async def slash_ticket_kur(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild

    try:
        # 1. Yetkili rolünü kontrol et veya oluştur
        staff_role = None
        role_id = config.get("ticket_yetkili_rol_id")
        if role_id:
            staff_role = guild.get_role(int(role_id))
        if not staff_role:
            staff_role = discord.utils.get(guild.roles, name="Destek Ekibi")
            if not staff_role:
                staff_role = await guild.create_role(
                    name="Destek Ekibi",
                    color=discord.Color.from_rgb(88, 101, 242),
                    reason="Ticket botu için destek yetkili rolü oluşturuldu."
                )

        # 2. Kategori oluştur
        cat_name = f"━━━ {config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} DESTEK ━━━"
        category = discord.utils.get(guild.categories, name=cat_name)
        if not category:
            category = await guild.create_category(name=cat_name, reason="Ticket kategorisi oluşturuldu.")

        # 3. Log Kanalını oluştur (Sadece yetkililer görür)
        log_overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            staff_role: discord.PermissionOverwrite(view_channel=True, send_messages=False),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, embed_links=True, attach_files=True)
        }
        log_channel = discord.utils.get(guild.text_channels, name="ticket-log")
        if not log_channel:
            log_channel = await guild.create_text_channel(
                name="ticket-log",
                category=category,
                overwrites=log_overwrites,
                reason="Ticket log kanalı oluşturuldu."
            )

        # 4. Destek Paneli Kanalını oluştur
        panel_overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=True, read_message_history=True, send_messages=False),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, embed_links=True, manage_messages=True)
        }
        panel_channel = discord.utils.get(guild.text_channels, name="destek-talebi")
        if not panel_channel:
            panel_channel = await guild.create_text_channel(
                name="destek-talebi",
                category=category,
                overwrites=panel_overwrites,
                reason="Ticket kontrol paneli kanalı oluşturuldu."
            )

        # 5. Paneli kanala gönder
        file, panel_embed = await get_ticket_panel_file_and_embed(guild)
        panel_msg = await panel_channel.send(embed=panel_embed, file=file, view=TicketPanelView())

        # 6. Config'e kaydet
        config["ticket_kategori_id"] = category.id
        config["ticket_log_kanal_id"] = log_channel.id
        config["ticket_yetkili_rol_id"] = staff_role.id
        config["ticket_panel_kanal_id"] = panel_channel.id
        config["ticket_panel_mesaj_id"] = panel_msg.id
        save_config(config)

        res_embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Ticket Sistemi Kuruldu",
            description=(
                "**Ticket Sistemi Başarıyla Kuruldu**\n\n"
                f"• **Kategori:** `{category.name}`\n"
                f"• **Panel Kanalı:** {panel_channel.mention}\n"
                f"• **Log Kanalı:** {log_channel.mention}\n"
                f"• **Yetkili Rolü:** {staff_role.mention}\n\n"
                "**İşleyiş:**\n"
                f"1. Üyeler {panel_channel.mention} kanalındaki menüden kategorisini seçer.\n"
                "2. Açılan pencereye konusunu ve açıklamasını yazar.\n"
                "3. Özel destek kanalı açılır ve yetkililere bildirim gider.\n"
                "4. İşlem bitince bilet kapatılıp görsel dökümü otomatik arşivlenir."
            ),
            color=get_embed_color(),
            timestamp=datetime.now(timezone.utc)
        )
        logo = get_brand_logo_url(guild)
        if logo:
            res_embed.set_thumbnail(url=logo)
        res_embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Destek Sistemi")

        await interaction.followup.send(embed=res_embed, ephemeral=True)
        print(f"[Ticket Setup] Kurulum tamamlandı: Kategori={category.name}, Panel={panel_channel.name}, Log={log_channel.name}")
    except Exception as e:
        await interaction.followup.send(f"Kurulum sırasında hata: {e}", ephemeral=True)

# 2. /ticket-panel-gonder (Yönetici)
# 5. /kurallar-gonder (Yönetici)
@bot.tree.command(name="kurallar-gonder", description="Bulunulan kanala resimli Priv Sunucu Kuralları panelini gönderir.")
@app_commands.default_permissions(administrator=True)
async def slash_kurallar_gonder(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    file, embed = await get_rules_file_and_embed(interaction.guild)
    msg = await interaction.channel.send(embed=embed, file=file, view=RulesApprovalView())
    config["rules_panel_kanal_id"] = interaction.channel_id
    config["rules_panel_mesaj_id"] = msg.id
    save_config(config)
    await interaction.followup.send("Priv Sunucu Kuralları görsel tasarımıyla bu kanala gönderildi.", ephemeral=True)

# 6. /kurallar-kur (Yönetici)
@bot.tree.command(name="kurallar-kur", description="Otomatik olarak #kurallar kanalı oluşturup kuralları yayınlar.")
@app_commands.default_permissions(administrator=True)
async def slash_kurallar_kur(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild
    if not guild:
        await interaction.followup.send("Sunucu bulunamadı.", ephemeral=True)
        return

    # #kurallar kanalı var mı kontrol et
    target_channel = None
    for c in guild.text_channels:
        if c.name.lower() in ["kurallar", "rules", "sunucu-kurallari"]:
            target_channel = c
            break

    if not target_channel:
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=False,
                add_reactions=False,
                create_public_threads=False,
                create_private_threads=False
            ),
            guild.me: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                embed_links=True,
                attach_files=True,
                manage_channels=True,
                manage_messages=True
            )
        }
        try:
            target_channel = await guild.create_text_channel(
                name="kurallar",
                overwrites=overwrites,
                position=0,
                topic="ɨ̇ ʍ ʐ ǟ Resmi Topluluk ve Priv Sunucu Kuralları",
                reason="Kurallar kanalı otomatik oluşturuldu."
            )
        except Exception as e:
            await interaction.followup.send(f"Kanal oluşturulamadı: {e}", ephemeral=True)
            return

    file, embed = await get_rules_file_and_embed(guild)
    msg = await target_channel.send(embed=embed, file=file, view=RulesApprovalView())
    config["rules_panel_kanal_id"] = target_channel.id
    config["rules_panel_mesaj_id"] = msg.id
    save_config(config)
    await interaction.followup.send(f"Kurallar {target_channel.mention} kanalına başarıyla gönderildi ve yayınlandı!", ephemeral=True)

@bot.tree.command(name="ticket-panel-gonder", description="Bulunduğun kanala Ticket Destek Panelini gönderir.")
@app_commands.default_permissions(administrator=True)
async def slash_ticket_panel_gonder(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    file, embed = await get_ticket_panel_file_and_embed(interaction.guild)
    msg = await interaction.channel.send(embed=embed, file=file, view=TicketPanelView())
    config["ticket_panel_kanal_id"] = interaction.channel_id
    config["ticket_panel_mesaj_id"] = msg.id
    save_config(config)
    await interaction.followup.send("**Destek Paneli görsel tasarımıyla bu kanala gönderildi.**", ephemeral=True)

# 3. /bilet-ekle [kullanici]
@bot.tree.command(name="bilet-ekle", description="Açık olan destek talebine bir arkadaşınızı veya üyeyi ekler.")
@app_commands.describe(kullanici="Talebe dahil edilecek kullanıcı")
async def slash_bilet_ekle(interaction: discord.Interaction, kullanici: discord.Member):
    data = load_tickets()
    ticket_info = data.get("active", {}).get(str(interaction.channel_id))
    if not ticket_info:
        await interaction.response.send_message("Bu komut yalnızca bir destek talebi kanalında kullanılabilir.", ephemeral=True)
        return

    if interaction.user.id != ticket_info.get("owner_id") and not is_ticket_staff(interaction.user):
        await interaction.response.send_message("Bu bilete kişi ekleme yetkiniz yok.", ephemeral=True)
        return

    channel = interaction.channel
    await channel.set_permissions(kullanici, view_channel=True, send_messages=True, read_message_history=True, attach_files=True)
    await interaction.response.send_message(f"{kullanici.mention} bu destek talebine dahil edildi.")

# 4. /bilet-cikar [kullanici]
@bot.tree.command(name="bilet-cikar", description="Destek talebinden bir üyeyi çıkarır.")
@app_commands.describe(kullanici="Talepten çıkarılacak kullanıcı")
async def slash_bilet_cikar(interaction: discord.Interaction, kullanici: discord.Member):
    data = load_tickets()
    ticket_info = data.get("active", {}).get(str(interaction.channel_id))
    if not ticket_info:
        await interaction.response.send_message("Bu komut yalnızca bir destek talebi kanalında kullanılabilir.", ephemeral=True)
        return

    if interaction.user.id != ticket_info.get("owner_id") and not is_ticket_staff(interaction.user):
        await interaction.response.send_message("Bu biletten kişi çıkarma yetkiniz yok.", ephemeral=True)
        return

    if kullanici.id == ticket_info.get("owner_id"):
        await interaction.response.send_message("Talep sahibini biletten çıkaramazsınız.", ephemeral=True)
        return

    channel = interaction.channel
    await channel.set_permissions(kullanici, overwrite=None)
    await interaction.response.send_message(f"{kullanici.mention} destek talebinden çıkarıldı.")

# 5. /bilet-kapat
@bot.tree.command(name="bilet-kapat", description="Bulunduğun destek talebini sonlandırır.")
async def slash_bilet_kapat(interaction: discord.Interaction):
    await handle_ticket_close(interaction)

# 6. /bilet-ustlen
@bot.tree.command(name="bilet-ustlen", description="Bulunduğun destek talebini üstlenir.")
async def slash_bilet_ustlen(interaction: discord.Interaction):
    await handle_ticket_claim(interaction)

# 7. /bilet-sil
@bot.tree.command(name="bilet-sil", description="Bulunduğun destek talebini arşivleyip siler.")
@app_commands.default_permissions(manage_channels=True)
async def slash_bilet_sil(interaction: discord.Interaction):
    await handle_ticket_delete(interaction)

# 8. /transkript
@bot.tree.command(name="transkript", description="Bulunduğun biletin yetkili web sitesi döküm linkini oluşturur.")
async def slash_transkript(interaction: discord.Interaction):
    await handle_ticket_transcript(interaction)

# 9. /bilet-transkript
@bot.tree.command(name="bilet-transkript", description="Bulunduğun biletin yetkili web sitesi döküm linkini oluşturur.")
async def slash_bilet_transkript(interaction: discord.Interaction):
    await handle_ticket_transcript(interaction)

# 10. /yetkili-kod
@bot.tree.command(name="yetkili-kod", description="Web transkript paneli için 6 haneli tek kullanımlık giriş kodu üretir.")
async def slash_yetkili_kod(interaction: discord.Interaction):
    if not is_ticket_staff(interaction.user):
        await interaction.response.send_message(
            "Bu komut yalnızca 0 yetkili rolüne sahip kişiler tarafından kullanılabilir.",
            ephemeral=True
        )
        return

    await interaction.response.defer(ephemeral=True)
    pin = f"{secrets.randbelow(900000) + 100000}"
    staff_pins[pin] = {
        "user_id": interaction.user.id,
        "expires_at": time.time() + 600
    }

    base_url = await ensure_public_web_url()
    session_token = create_staff_session(interaction.user.id)
    portal_direct_url = f"{base_url}/?auth={session_token}"

    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Yetkili Doğrulama Kodu",
        description=(
            f"Web sitesi transkript doğrulaması için tek kullanımlık kodunuz:\n\n"
            f"# **`{pin}`**\n\n"
            f"• **Discord ID'niz:** `{interaction.user.id}`\n"
            f"• **Geçerlilik Süresi:** 10 dakika\n"
            f"• **Yetkili Rolü:** `0`\n"
            f"• **Canlı Portal Adresi:** `{base_url}`\n\n"
            "*Aşağıdaki butona tıklayarak doğrudan tek tıkla şifresiz giriş yapabilir veya web kapısına ID ve PIN kodunuzu yazabilirsiniz.*"
        ),
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    view = discord.ui.View()
    view.add_item(discord.ui.Button(label="Bilet Portalına Git (Tek Tıkla Giriş)", url=portal_direct_url, style=discord.ButtonStyle.link))

    try:
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)
    except Exception as e:
        print(f"[/yetkili-kod yanıt hatası]: {e}", flush=True)

# 11. /portal & /bilet-portal
@bot.tree.command(name="portal", description="Bilet Yönetim Paneline doğrudan tek tıkla giriş linki üretir.")
async def slash_portal(interaction: discord.Interaction):
    if not is_ticket_staff(interaction.user):
        await interaction.response.send_message(
            "Bu komut yalnızca 0 yetkili rolüne sahip kişiler tarafından kullanılabilir.",
            ephemeral=True
        )
        return

    await interaction.response.defer(ephemeral=True)
    session_token = create_staff_session(interaction.user.id)
    base_url = await ensure_public_web_url()
    portal_url = f"{base_url}/?auth={session_token}"

    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Bilet Yönetim Portalı",
        description=(
            "**Bilet Yönetim Paneli Hazır**\n\n"
            "Aşağıdaki butona tıklayarak doğrudan hesabınız doğrulanmış şekilde portala giriş yapabilirsiniz.\n\n"
            f"• **Güncel Web Adresi:** `{base_url}`\n"
            f"• **Oturum Süresi:** 7 Gün\n"
            f"• **Yetkili:** `{interaction.user}`\n\n"
            "*Bu bağlantı size özel üretilmiştir, başkalarıyla paylaşmayınız.*"
        ),
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    view = discord.ui.View()
    view.add_item(discord.ui.Button(label="Bilet Portalını Aç", url=portal_url, style=discord.ButtonStyle.link))
    await interaction.followup.send(embed=embed, view=view, ephemeral=True)

@bot.tree.command(name="bilet-portal", description="Bilet Yönetim Paneline doğrudan tek tıkla giriş linki üretir.")
async def slash_bilet_portal(interaction: discord.Interaction):
    await slash_portal(interaction)

# ─────────────────────────────────────────────
# SİCİL GRAFİK KARTI ÜRETİM MODÜLÜ (PIL / HIGH-RES INFOGRAPHIC)
# ─────────────────────────────────────────────
def get_sicil_font(font_name: str, size: int, bold: bool = False):
    """Sistemde yüklü fontları dener, bulunamazsa Pillow varsayılan fontuna döner."""
    candidates = []
    if bold:
        candidates = [
            f"C:/Windows/Fonts/{font_name}bd.ttf",
            f"C:/Windows/Fonts/{font_name}b.ttf",
            f"C:/Windows/Fonts/{font_name}Bold.ttf",
            "C:/Windows/Fonts/segoeuib.ttf",
            "C:/Windows/Fonts/arialbd.ttf",
            "C:/Windows/Fonts/calibrib.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
        ]
    else:
        candidates = [
            f"C:/Windows/Fonts/{font_name}.ttf",
            "C:/Windows/Fonts/segoeui.ttf",
            "C:/Windows/Fonts/arial.ttf",
            "C:/Windows/Fonts/calibri.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
        ]
    for p in candidates:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    try:
        return ImageFont.load_default(size=size)
    except Exception:
        return ImageFont.load_default()

def format_sicil_date_tr(dt) -> str:
    """Tarihi Türkçe ay ismi ve göreceli zaman farkı ile formatlar."""
    if not dt:
        return "Bilinmiyor"
    months = ["", "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
    try:
        day = dt.day
        month = months[dt.month] if 1 <= dt.month <= 12 else str(dt.month)
        year = dt.year
        now = datetime.now(timezone.utc)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        diff = now - dt
        days = diff.days
        if days < 1:
            rel = "Bugün"
        elif days < 30:
            rel = f"{days} gün önce"
        elif days < 365:
            rel = f"{days // 30} ay önce"
        else:
            rel = f"{days // 365} yıl önce"
        return f"{day:02d} {month} {year} ({rel})"
    except Exception:
        return str(dt)[:10]

async def fetch_avatar_image(avatar_url: str) -> Optional[Image.Image]:
    """Discord CDN'den kullanıcının avatarını asenkron olarak indirir."""
    if not avatar_url:
        return None
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(avatar_url, timeout=aiohttp.ClientTimeout(total=4)) as resp:
                if resp.status == 200:
                    data = await resp.read()
                    return Image.open(io.BytesIO(data))
    except Exception:
        pass
    return None

def draw_sicil_radial_glow(im: Image.Image, center_x: int, center_y: int, radius: int, color_rgb: tuple, max_alpha: int = 50):
    """Yumuşak neon ortam ışığı (ambient radial glow) çizer."""
    glow_box_size = radius * 2
    glow_im = Image.new("RGBA", (glow_box_size, glow_box_size), (0, 0, 0, 0))
    glow_draw = ImageDraw.Draw(glow_im)
    r, g, b = color_rgb
    steps = 16
    for i in range(steps, 0, -1):
        cur_r = int(radius * (i / steps))
        alpha = int(max_alpha * ((1 - (i / steps)) ** 1.6))
        if alpha <= 0:
            continue
        bbox = [radius - cur_r, radius - cur_r, radius + cur_r, radius + cur_r]
        glow_draw.ellipse(bbox, fill=(r, g, b, alpha))
    glow_im = glow_im.filter(ImageFilter.GaussianBlur(radius=radius // 5))
    im.alpha_composite(glow_im, (center_x - radius, center_y - radius))

def draw_sicil_check_icon(draw: ImageDraw.ImageDraw, cx: int, cy: int, size: int, color: tuple, width: int = 3):
    """Vektörel onay işareti çizer."""
    p1 = (cx - size // 2, cy)
    p2 = (cx - size // 6, cy + size // 3)
    p3 = (cx + size // 2, cy - size // 2)
    draw.line([p1, p2, p3], fill=color, width=width, joint="curve")

def draw_sicil_avatar_placeholder(draw: ImageDraw.ImageDraw, av_cx: int, av_cy: int, av_size: int):
    """Avatar olmadığında estetik vektörel kullanıcı silüeti çizer."""
    draw.ellipse([av_cx - av_size // 2, av_cy - av_size // 2, av_cx + av_size // 2, av_cy + av_size // 2], fill=(24, 32, 54))
    head_r = av_size // 5
    draw.ellipse([av_cx - head_r, av_cy - head_r - 8, av_cx + head_r, av_cy + head_r - 8], fill=(90, 105, 138))
    draw.chord([av_cx - av_size // 3, av_cy + 2, av_cx + av_size // 3, av_cy + av_size // 2 + 10], 180, 360, fill=(90, 105, 138))

def generate_sicil_card_bytes(
    user_data: dict,
    warns: list,
    active_tickets: list,
    closed_tickets: list,
    avatar_image: Optional[Image.Image] = None
) -> io.BytesIO:
    """Pillow ile yüksek çözünürlüklü, siber lüks sicil kartı görseli oluşturur."""
    W, H = 1200, 720
    im = Image.new("RGBA", (W, H), (12, 16, 28, 255))

    w_count = len(warns)
    total_tickets = len(active_tickets) + len(closed_tickets)

    if w_count == 0:
        theme_title = "TEMİZ SİCİL // KUSURSUZ"
        theme_color = (52, 211, 153)       # Bright Emerald #34d399
        theme_glow = (16, 185, 129)
        theme_badge = "GÜVENİLİR ÜYE // CLASS-A"
        theme_tint = (16, 42, 34)          # Deep Emerald BG
        theme_border = (20, 83, 45)        # Dark Emerald Border
        security_score = 100
        score_label = "KUSURSUZ GÜVENLİK"
        grade_letter = "A+"
    elif w_count <= 2:
        theme_title = "İHTARLI // DİKKAT"
        theme_color = (251, 191, 36)       # Bright Amber #fbbf24
        theme_glow = (245, 158, 11)
        theme_badge = "DİKKAT // İHTAR KAYITLI"
        theme_tint = (46, 32, 14)          # Deep Amber BG
        theme_border = (120, 75, 18)
        security_score = 65
        score_label = "DÜŞÜK GÜVENİLİRLİK"
        grade_letter = "B-"
    else:
        theme_title = "YÜKSEK RİSKLİ"
        theme_color = (248, 113, 113)      # Bright Red #f87171
        theme_glow = (239, 68, 68)
        theme_badge = "TEHLİKE // RİSKLİ ŞAHIS"
        theme_tint = (50, 18, 24)          # Deep Red BG
        theme_border = (130, 28, 38)
        security_score = 20
        score_label = "AĞIR İHLAL KAYDI"
        grade_letter = "F"

    # 1. Ortam Neon Işıkları (Ambient Glows)
    draw_sicil_radial_glow(im, 200, 200, 260, theme_glow, max_alpha=35)
    draw_sicil_radial_glow(im, 1050, 140, 260, (88, 101, 242), max_alpha=30)
    draw_sicil_radial_glow(im, 850, 600, 280, (30, 42, 74), max_alpha=40)

    # 2. Siber Izgara ve Bezel Çerçevesi
    grid_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    g_draw = ImageDraw.Draw(grid_layer)
    for gx in range(36, W - 36, 32):
        for gy in range(36, H - 36, 32):
            g_draw.point((gx, gy), fill=(255, 255, 255, 14))

    g_draw.rounded_rectangle([18, 18, W - 18, H - 18], radius=24, outline=(40, 52, 78), width=1)
    g_draw.line([(36, 18), (W - 36, 18)], fill=(*theme_color, 240), width=3)
    g_draw.line([(50, 21), (W - 50, 21)], fill=(*theme_color, 90), width=1)
    im.alpha_composite(grid_layer)

    draw = ImageDraw.Draw(im)

    # Font tanımları
    f_brand = get_sicil_font("segoeui", 26, bold=True)
    f_name = get_sicil_font("segoeui", 24, bold=True)
    f_uname = get_sicil_font("segoeui", 14, bold=False)
    f_badge = get_sicil_font("segoeui", 11, bold=True)
    f_card_title = get_sicil_font("segoeui", 13, bold=True)
    f_num_big = get_sicil_font("segoeui", 38, bold=True)
    f_num_lbl = get_sicil_font("segoeui", 12, bold=False)
    f_label = get_sicil_font("segoeui", 11, bold=False)
    f_value = get_sicil_font("segoeui", 13, bold=True)
    f_body = get_sicil_font("segoeui", 12, bold=False)
    f_mono = get_sicil_font("consola", 11, bold=False)
    f_mono_b = get_sicil_font("consola", 13, bold=True)
    f_grade = get_sicil_font("segoeui", 42, bold=True)

    CARD_BG = (18, 24, 40)
    CARD_BORDER = (38, 48, 72)
    INNER_BG = (23, 30, 50)
    INNER_BORDER = (44, 56, 84)

    # 3. Üst Header Bar
    draw.rounded_rectangle([36, 32, W - 36, 96], radius=16, fill=CARD_BG, outline=CARD_BORDER, width=1)
    bot_name_str = str(config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ"))
    draw.text((56, 44), bot_name_str, font=f_brand, fill=(255, 255, 255))
    draw.line([(155, 48), (155, 80)], fill=(50, 64, 94), width=1)
    draw.text((172, 47), "RESMİ KULLANICI SİCİL ARŞİVİ", font=f_card_title, fill=(241, 245, 249))
    draw.text((172, 67), "GÜVENLİK, DİSİPLİN & BİLET DENETİM SİSTEMİ", font=f_label, fill=(148, 163, 184))

    uid_short = str(user_data.get("id", "000000"))[-6:]
    now_str = datetime.now().strftime("%d.%m.%Y • %H:%M")
    draw.rounded_rectangle([W - 325, 42, W - 52, 86], radius=10, fill=theme_tint, outline=theme_border, width=1)
    draw.ellipse([W - 308, 58, W - 298, 68], fill=theme_color)
    draw.text((W - 286, 49), f"DOSYA: #SICIL-{uid_short}", font=f_mono_b, fill=(255, 255, 255))
    draw.text((W - 286, 67), f"SENKRONİZE: {now_str}", font=f_mono, fill=(180, 195, 215))

    # 4. Sol Panel: Kullanıcı Kimlik Kartı
    LP_X0, LP_Y0, LP_X1, LP_Y1 = 36, 114, 390, H - 56
    draw.rounded_rectangle([LP_X0, LP_Y0, LP_X1, LP_Y1], radius=18, fill=CARD_BG, outline=CARD_BORDER, width=1)
    draw.rounded_rectangle([LP_X0 + 1, LP_Y0 + 1, LP_X1 - 1, LP_Y0 + 6], radius=4, fill=theme_color)

    av_size = 114
    av_cx = LP_X0 + (LP_X1 - LP_X0) // 2
    av_cy = LP_Y0 + 82
    av_x = av_cx - av_size // 2
    av_y = av_cy - av_size // 2

    draw.ellipse([av_x - 5, av_y - 5, av_x + av_size + 5, av_y + av_size + 5], outline=theme_border, width=2)
    draw.ellipse([av_x - 1, av_y - 1, av_x + av_size + 1, av_y + av_size + 1], outline=theme_color, width=2)

    if avatar_image:
        try:
            av_resized = avatar_image.resize((av_size, av_size), Image.Resampling.LANCZOS).convert("RGBA")
            mask = Image.new("L", (av_size, av_size), 0)
            m_draw = ImageDraw.Draw(mask)
            m_draw.ellipse((0, 0, av_size, av_size), fill=255)
            im.paste(av_resized, (av_x, av_y), mask)
        except Exception:
            draw_sicil_avatar_placeholder(draw, av_cx, av_cy, av_size)
    else:
        draw_sicil_avatar_placeholder(draw, av_cx, av_cy, av_size)

    disp_name = user_data.get("display_name", "Kullanıcı")
    if len(disp_name) > 17:
        disp_name = disp_name[:16] + "…"
    uname = "@" + str(user_data.get("name", "user"))

    nbb = draw.textbbox((0, 0), disp_name, font=f_name)
    nw = nbb[2] - nbb[0]
    draw.text((LP_X0 + (LP_X1 - LP_X0 - nw) // 2, LP_Y0 + 154), disp_name, font=f_name, fill=(255, 255, 255))

    ubb = draw.textbbox((0, 0), uname, font=f_uname)
    uw = ubb[2] - ubb[0]
    draw.text((LP_X0 + (LP_X1 - LP_X0 - uw) // 2, LP_Y0 + 188), uname, font=f_uname, fill=(148, 163, 184))

    bbb = draw.textbbox((0, 0), theme_badge, font=f_badge)
    bw = bbb[2] - bbb[0] + 28
    bx = LP_X0 + (LP_X1 - LP_X0 - bw) // 2
    draw.rounded_rectangle([bx, LP_Y0 + 218, bx + bw, LP_Y0 + 246], radius=14, fill=theme_tint, outline=theme_border, width=1)
    draw.text((bx + 14, LP_Y0 + 224), theme_badge, font=f_badge, fill=theme_color)

    id_val = f"UID: {user_data.get('id', 'Bilinmiyor')}"
    ibb = draw.textbbox((0, 0), id_val, font=f_mono)
    iw = ibb[2] - ibb[0] + 24
    ix = LP_X0 + (LP_X1 - LP_X0 - iw) // 2
    draw.rounded_rectangle([ix, LP_Y0 + 258, ix + iw, LP_Y0 + 282], radius=6, fill=INNER_BG, outline=INNER_BORDER, width=1)
    draw.text((ix + 12, LP_Y0 + 264), id_val, font=f_mono, fill=(203, 213, 225))

    draw.line([(LP_X0 + 24, LP_Y0 + 298), (LP_X1 - 24, LP_Y0 + 298)], fill=(40, 50, 72), width=1)

    created_str = user_data.get("created_at_str", "Bilinmiyor")
    joined_str = user_data.get("joined_at_str", "Bilinmiyor")

    draw.rounded_rectangle([LP_X0 + 20, LP_Y0 + 312, LP_X1 - 20, LP_Y0 + 368], radius=10, fill=INNER_BG, outline=INNER_BORDER, width=1)
    draw.text((LP_X0 + 34, LP_Y0 + 322), "HESAP AÇILIŞ TARİHİ", font=f_label, fill=(148, 163, 184))
    draw.text((LP_X0 + 34, LP_Y0 + 340), created_str, font=f_value, fill=(241, 245, 249))

    draw.rounded_rectangle([LP_X0 + 20, LP_Y0 + 380, LP_X1 - 20, LP_Y0 + 436], radius=10, fill=INNER_BG, outline=INNER_BORDER, width=1)
    draw.text((LP_X0 + 34, LP_Y0 + 390), "SUNUCUYA KATILIŞ TARİHİ", font=f_label, fill=(148, 163, 184))
    draw.text((LP_X0 + 34, LP_Y0 + 408), joined_str, font=f_value, fill=(241, 245, 249))

    draw.rounded_rectangle([LP_X0 + 20, LP_Y0 + 450, LP_X1 - 20, LP_Y1 - 20], radius=12, fill=theme_tint, outline=theme_border, width=1)
    draw.text((LP_X0 + 36, LP_Y0 + 460), grade_letter, font=f_grade, fill=theme_color)
    draw.text((LP_X0 + 104, LP_Y0 + 462), score_label, font=f_card_title, fill=(255, 255, 255))
    draw.text((LP_X0 + 104, LP_Y0 + 482), f"Güvenlik İndeksi: %{security_score}", font=f_body, fill=theme_color)
    draw.text((LP_X0 + 104, LP_Y0 + 500), "İmza Bot Güvenlik Protokolü v4.2", font=f_label, fill=(148, 163, 184))

    # 5. Sağ Taraf: KPI İstatistik Blokları
    RP_X0, RP_X1 = 410, W - 36
    kpi_w = (RP_X1 - RP_X0 - 24) // 3

    kpis = [
        ("TOPLAM İHTAR", str(w_count), "Kayıtlı Disiplin Suçu", theme_color, theme_border),
        ("AKTİF BİLET", str(len(active_tickets)), "Şu Anda Açık Destek", (56, 189, 248), (20, 70, 110)),
        ("ARŞİV BİLET", str(len(closed_tickets)), "Çözümlenen Geçmiş", (168, 85, 247), (70, 35, 115)),
    ]

    for idx, (k_title, k_num, k_desc, k_col, k_br) in enumerate(kpis):
        kx0 = RP_X0 + idx * (kpi_w + 12)
        kx1 = kx0 + kpi_w
        draw.rounded_rectangle([kx0, 114, kx1, 218], radius=14, fill=CARD_BG, outline=k_br, width=1)
        draw.line([(kx0 + 14, 115), (kx1 - 14, 115)], fill=k_col, width=2)
        draw.text((kx0 + 18, 126), k_title, font=f_label, fill=(148, 163, 184))
        draw.text((kx0 + 18, 144), k_num, font=f_num_big, fill=k_col)
        draw.text((kx0 + 18, 192), k_desc, font=f_num_lbl, fill=(203, 213, 225))

    # 6. Sağ Orta: İhtar & Ceza Dosyası
    WAR_Y0, WAR_Y1 = 232, 442
    draw.rounded_rectangle([RP_X0, WAR_Y0, RP_X1, WAR_Y1], radius=16, fill=CARD_BG, outline=CARD_BORDER, width=1)
    draw.text((RP_X0 + 20, WAR_Y0 + 16), "DİSİPLİN & CEZA DOSYASI", font=f_card_title, fill=(255, 255, 255))

    c_badge_text = f"{w_count} ADET KAYIT" if w_count > 0 else "TEMİZ (0 CEZA)"
    cbb = draw.textbbox((0, 0), c_badge_text, font=f_badge)
    cbw = cbb[2] - cbb[0] + 20
    draw.rounded_rectangle([RP_X1 - cbw - 20, WAR_Y0 + 14, RP_X1 - 20, WAR_Y0 + 36], radius=6, fill=theme_tint, outline=theme_border, width=1)
    draw.text((RP_X1 - cbw - 10, WAR_Y0 + 18), c_badge_text, font=f_badge, fill=theme_color)

    draw.line([(RP_X0 + 20, WAR_Y0 + 44), (RP_X1 - 20, WAR_Y0 + 44)], fill=(35, 45, 68), width=1)

    if w_count == 0:
        clean_box_y0 = WAR_Y0 + 56
        clean_box_y1 = WAR_Y1 - 18
        draw.rounded_rectangle([RP_X0 + 20, clean_box_y0, RP_X1 - 20, clean_box_y1], radius=12, fill=theme_tint, outline=theme_border, width=1)
        
        badge_sz = 60
        bx0 = RP_X0 + 40
        by0 = clean_box_y0 + (clean_box_y1 - clean_box_y0 - badge_sz) // 2
        draw.ellipse([bx0, by0, bx0 + badge_sz, by0 + badge_sz], fill=(20, 54, 42), outline=theme_color, width=2)
        draw_sicil_check_icon(draw, bx0 + badge_sz // 2, by0 + badge_sz // 2, 26, theme_color, width=3)

        draw.text((bx0 + badge_sz + 24, by0 + 4), "ARŞİVDE HERHANGİ BİR CEZA VEYA İHTAR BULUNMAMAKTADIR", font=f_card_title, fill=(255, 255, 255))
        draw.text((bx0 + badge_sz + 24, by0 + 26), "Bu kullanıcı topluluk kurallarına eksiksiz uymuş olup tertemiz bir sicil geçmişine sahiptir.", font=f_body, fill=(180, 195, 215))
        draw.text((bx0 + badge_sz + 24, by0 + 46), "• Tam Güvenilirlik Sertifikalı   • Yetkili Onaylı Doğrulanmış Profil   • Disiplin Skoru: Kusursuz", font=f_badge, fill=theme_color)
    else:
        w_y = WAR_Y0 + 54
        for w_item in warns[:2]:
            reason = str(w_item.get("reason", "Belirtilmedi"))
            staff_txt = str(w_item.get("staff_name", "Yetkili"))
            w_date = str(w_item.get("date", "Bilinmiyor"))
            w_type = str(w_item.get("type", "UYARI")).upper()
            
            is_ban = "BAN" in w_type or "AĞIR" in w_type
            w_col = (248, 113, 113) if is_ban else (251, 191, 36)
            w_tint = (50, 18, 24) if is_ban else (46, 32, 14)
            w_br = (130, 28, 38) if is_ban else (120, 75, 18)

            draw.rounded_rectangle([RP_X0 + 20, w_y, RP_X1 - 20, w_y + 64], radius=10, fill=INNER_BG, outline=INNER_BORDER, width=1)
            draw.rounded_rectangle([RP_X0 + 32, w_y + 16, RP_X0 + 104, w_y + 48], radius=8, fill=w_tint, outline=w_br, width=1)
            draw.text((RP_X0 + 40, w_y + 24), w_type[:7], font=f_badge, fill=w_col)
            
            if len(reason) > 52:
                reason = reason[:50] + "…"
            draw.text((RP_X0 + 118, w_y + 14), reason, font=f_value, fill=(241, 245, 249))
            draw.text((RP_X0 + 118, w_y + 36), f"Yetkili: {staff_txt}  •  Tarih: {w_date}", font=f_label, fill=(148, 163, 184))
            w_y += 72

    # 7. Sağ Alt: Son Destek & Bilet Talepleri
    TIC_Y0, TIC_Y1 = 456, H - 56
    draw.rounded_rectangle([RP_X0, TIC_Y0, RP_X1, TIC_Y1], radius=16, fill=CARD_BG, outline=CARD_BORDER, width=1)
    draw.text((RP_X0 + 20, TIC_Y0 + 16), "SON DESTEK & TİCKET TALEPLERİ", font=f_card_title, fill=(255, 255, 255))

    t_count_badge = f"{total_tickets} TOPLAM TALEP"
    draw.rounded_rectangle([RP_X1 - 130, TIC_Y0 + 14, RP_X1 - 20, TIC_Y0 + 36], radius=6, fill=(28, 35, 60), outline=(50, 65, 110), width=1)
    draw.text((RP_X1 - 120, TIC_Y0 + 18), t_count_badge, font=f_badge, fill=(165, 180, 252))

    draw.line([(RP_X0 + 20, TIC_Y0 + 44), (RP_X1 - 20, TIC_Y0 + 44)], fill=(35, 45, 68), width=1)

    recent_tickets = []
    for at in active_tickets[:2]:
        recent_tickets.append({"id": at.get("id", "#TICKET"), "cat": at.get("category", "Genel Destek"), "status": "AÇIK"})
    for ct in closed_tickets[:2]:
        if len(recent_tickets) < 3:
            recent_tickets.append({"id": ct.get("id", "#TICKET"), "cat": ct.get("category", "Destek Talebi"), "status": "KAPALI"})

    if not recent_tickets:
        draw.text((RP_X0 + 30, TIC_Y0 + 64), "Kullanıcıya ait herhangi bir destek talebi kaydı bulunamadı.", font=f_body, fill=(148, 163, 184))
    else:
        t_y = TIC_Y0 + 52
        for t_item in recent_tickets[:3]:
            is_open = t_item["status"] == "AÇIK"
            tag_col = (52, 211, 153) if is_open else (148, 163, 184)
            tag_bg = (16, 42, 34) if is_open else (23, 30, 50)
            tag_br = (20, 83, 45) if is_open else (44, 56, 84)
            
            draw.rounded_rectangle([RP_X0 + 20, t_y, RP_X1 - 20, t_y + 44], radius=8, fill=INNER_BG, outline=INNER_BORDER, width=1)
            draw.rounded_rectangle([RP_X0 + 30, t_y + 10, RP_X0 + 94, t_y + 34], radius=6, fill=tag_bg, outline=tag_br, width=1)
            draw.text((RP_X0 + 42, t_y + 14), t_item["status"], font=f_badge, fill=tag_col)

            draw.text((RP_X0 + 106, t_y + 12), t_item["id"], font=f_mono_b, fill=(255, 255, 255))
            cat_name = t_item["cat"]
            if len(cat_name) > 45:
                cat_name = cat_name[:43] + "…"
            draw.text((RP_X0 + 180, t_y + 14), f"—  {cat_name}", font=f_body, fill=(203, 213, 225))
            t_y += 50

    # 8. Alt Footer Çubuğu
    draw.rounded_rectangle([36, H - 46, W - 36, H - 18], radius=8, fill=(14, 19, 32), outline=CARD_BORDER, width=1)
    draw.text((50, H - 36), "IMZA CYBERNETIC AUDIT SYSTEM // SEC-PROTOCOL v4", font=f_mono, fill=(148, 163, 184))
    draw.text((W // 2 - 120, H - 36), "•  RESMİ DİJİTAL SİCİL DOSYASI  •", font=f_mono, fill=(100, 116, 139))
    draw.text((W - 270, H - 36), "DOĞRULANMIŞ ARŞİV BELGESİ", font=f_mono, fill=theme_color)

    buf = io.BytesIO()
    im.save(buf, format="PNG", optimize=True)
    buf.seek(0)
    return buf

# 12. /sicil & /sicil-bak (Görsel Sicil Dosyası Gösterme)
@bot.tree.command(name="sicil", description="Bir kullanıcının veya kendinizin detaylı resimli sicil ve bilet geçmişini görüntüler.")
@app_commands.describe(kullanici="Siciline bakılacak kullanıcı (Belirtilmezse kendiniz)")
async def slash_sicil(interaction: discord.Interaction, kullanici: Optional[discord.Member] = None):
    target = kullanici or interaction.user
    is_staff = is_ticket_staff(interaction.user)

    if target.id != interaction.user.id and not is_staff:
        await interaction.response.send_message("Yalnızca yetkililer diğer üyelerin sicil kayıtlarını sorgulayabilir.", ephemeral=True)
        return

    # Kendi sicilini veya kanaldaki sorguyu yönet
    is_ephemeral = True if (target.id != interaction.user.id and not is_staff) else False
    await interaction.response.defer(ephemeral=is_ephemeral)

    warns = get_user_warnings(target.id)
    active_t, closed_t = get_user_tickets_summary(target.id)

    user_data = {
        "id": target.id,
        "name": target.name,
        "display_name": target.display_name,
        "created_at_str": format_sicil_date_tr(getattr(target, "created_at", None)),
        "joined_at_str": format_sicil_date_tr(getattr(target, "joined_at", None)),
    }

    view = discord.ui.View()
    base_url = await ensure_public_web_url()
    if is_staff:
        session_token = create_staff_session(interaction.user.id)
        portal_url = f"{base_url}/?auth={session_token}&search={target.id}"
        sicil_url = f"{base_url}/sicil/{target.id}?auth={session_token}"
        view.add_item(discord.ui.Button(label="Bilet Portalında İncele", url=portal_url, style=discord.ButtonStyle.link, emoji="🔍"))
        view.add_item(discord.ui.Button(label="Web Sicil Dosyası", url=sicil_url, style=discord.ButtonStyle.link, emoji="📁"))
    else:
        sicil_url = f"{base_url}/sicil/{target.id}"
        view.add_item(discord.ui.Button(label="Web Sicil Dosyası", url=sicil_url, style=discord.ButtonStyle.link, emoji="📁"))

    try:
        avatar_img = await fetch_avatar_image(target.display_avatar.url if target.display_avatar else None)
        card_buf = await asyncio.to_thread(
            generate_sicil_card_bytes,
            user_data,
            warns,
            active_t,
            closed_t,
            avatar_img
        )
        file = discord.File(fp=card_buf, filename=f"sicil_{target.id}.png")
        await interaction.followup.send(file=file, view=view, ephemeral=is_ephemeral)
    except Exception as e:
        print(f"[Sicil Kartı Hatası]: {e}", flush=True)
        # Hata durumunda güvenli yedek embed
        w_count = len(warns)
        total_tickets = len(active_t) + len(closed_t)
        embed_color = 0x57f287 if w_count == 0 else (0xfee75c if w_count <= 2 else 0xed4245)
        embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Kullanıcı Sicil Kaydı",
            color=embed_color,
            timestamp=datetime.now(timezone.utc)
        )
        if target.display_avatar:
            embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(
            name="Kullanıcı Kimliği",
            value=f"• **Üye:** {target.mention} (`{target.name}`)\n• **ID:** `{target.id}`\n• **Hesap:** {user_data['created_at_str']}\n• **Katılış:** {user_data['joined_at_str']}",
            inline=False
        )
        embed.add_field(
            name="Sicil & Güvenlik Durumu",
            value=f"• **İhtar Sayısı:** `{w_count}` adet\n• **Toplam Bilet:** `{total_tickets}` adet (`{len(active_t)}` aktif, `{len(closed_t)}` arşiv)",
            inline=False
        )
        await interaction.followup.send(embed=embed, view=view, ephemeral=is_ephemeral)

@bot.tree.command(name="sicil-bak", description="Bir kullanıcının detaylı resimli sicil ve uyarı geçmişini görüntüler.")
@app_commands.describe(kullanici="Siciline bakılacak kullanıcı")
async def slash_sicil_bak(interaction: discord.Interaction, kullanici: Optional[discord.Member] = None):
    await slash_sicil(interaction, kullanici)

@bot.command(name="sicil", aliases=["sicil-bak", "sicili"])
async def cmd_prefix_sicil(ctx: commands.Context, kullanici: Optional[Union[discord.Member, discord.User]] = None):
    """Metin mesajı olarak !sicil veya .sicil yazıldığında resimli sicil kartı gönderir."""
    target = kullanici or ctx.author
    is_staff = is_ticket_staff(ctx.author)

    if target.id != ctx.author.id and not is_staff:
        await ctx.reply("Yalnızca yetkililer diğer üyelerin sicil kayıtlarını sorgulayabilir.", mention_author=False)
        return

    warns = get_user_warnings(target.id)
    active_t, closed_t = get_user_tickets_summary(target.id)

    user_data = {
        "id": target.id,
        "name": target.name,
        "display_name": getattr(target, "display_name", target.name),
        "created_at_str": format_sicil_date_tr(getattr(target, "created_at", None)),
        "joined_at_str": format_sicil_date_tr(getattr(target, "joined_at", None)),
    }

    view = discord.ui.View()
    base_url = await ensure_public_web_url()
    if is_staff:
        session_token = create_staff_session(ctx.author.id)
        portal_url = f"{base_url}/?auth={session_token}&search={target.id}"
        sicil_url = f"{base_url}/sicil/{target.id}?auth={session_token}"
        view.add_item(discord.ui.Button(label="Bilet Portalında İncele", url=portal_url, style=discord.ButtonStyle.link, emoji="🔍"))
        view.add_item(discord.ui.Button(label="Web Sicil Dosyası", url=sicil_url, style=discord.ButtonStyle.link, emoji="📁"))
    else:
        sicil_url = f"{base_url}/sicil/{target.id}"
        view.add_item(discord.ui.Button(label="Web Sicil Dosyası", url=sicil_url, style=discord.ButtonStyle.link, emoji="📁"))

    async with ctx.typing():
        try:
            avatar_img = await fetch_avatar_image(target.display_avatar.url if target.display_avatar else None)
            card_buf = await asyncio.to_thread(
                generate_sicil_card_bytes,
                user_data,
                warns,
                active_t,
                closed_t,
                avatar_img
            )
            file = discord.File(fp=card_buf, filename=f"sicil_{target.id}.png")
            await ctx.reply(file=file, view=view, mention_author=False)
        except Exception as e:
            print(f"[Prefix Sicil Kartı Hatası]: {e}", flush=True)
            await ctx.reply(f"Sicil kartı oluşturulurken hata: {e}", mention_author=False)

# 13. /sicil-ekle (Yetkili Tarafından Sicil Kaydı / Uyarı Ekleme)
@bot.tree.command(name="sicil-ekle", description="Bir kullanıcının siciline resmi uyarı, ihtar veya ihlal kaydı ekler.")
@app_commands.describe(
    kullanici="Siciline kayıt işlenecek kullanıcı",
    tur="İşlenecek ceza veya uyarının türü",
    sebep="Kayıt gerekçesi / açıklaması",
    dm_bildir="Kullanıcıya DM üzerinden bildirim gönderilsin mi? (Varsayılan: Evet)"
)
@app_commands.choices(tur=[
    app_commands.Choice(name="Resmi Uyarı", value="Resmi Uyarı"),
    app_commands.Choice(name="İhtar", value="İhtar"),
    app_commands.Choice(name="Kural İhlali", value="Kural İhlali"),
    app_commands.Choice(name="Destek Suistimali / Spam", value="Destek Suistimali / Spam"),
    app_commands.Choice(name="Yetkiliye Saygısızlık", value="Yetkiliye Saygısızlık"),
    app_commands.Choice(name="Gizlilik & Priv İhlali", value="Gizlilik & Priv İhlali"),
    app_commands.Choice(name="Destek Suistimali", value="Destek Suistimali")
])
async def slash_sicil_ekle(
    interaction: discord.Interaction,
    kullanici: discord.Member,
    tur: str,
    sebep: str,
    dm_bildir: bool = True
):
    is_staff = is_ticket_staff(interaction.user)
    if not is_staff:
        await interaction.response.send_message(
            "Bu komut yalnızca 0 yetkili rolüne sahip kişiler tarafından kullanılabilir.",
            ephemeral=True
        )
        return

    timestamp_str = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    record = {
        "ticket_id": "Manuel Sicil",
        "warn_type": tur,
        "reason": sebep,
        "staff_name": interaction.user.display_name or interaction.user.name,
        "staff_id": interaction.user.id,
        "timestamp": timestamp_str
    }

    all_warns = add_user_warning(kullanici.id, record)
    w_count = len(all_warns)

    # Kullanıcının aktif bilet kanallarındaki karşılama embedini güncel sicil ile tazele
    tdata_active = load_tickets()
    for cid_str, act_info in tdata_active.get("active", {}).items():
        if str(act_info.get("owner_id")) == str(kullanici.id):
            asyncio.create_task(refresh_ticket_welcome_embed(int(cid_str)))

    dm_status = False
    if dm_bildir:
        try:
            dm_embed = discord.Embed(
                title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  {tur}",
                description=(
                    f"Sayın {kullanici.mention},\n\n"
                    f"Sunucu yetkili yönetimimiz tarafından resmi sicil kaydınıza yeni bir **{tur}** işlenmiştir.\n\n"
                    f"• **İşlem Türü:** `{tur}`\n"
                    f"• **Gerekçe:** {sebep}\n"
                    f"• **Yetkili:** {interaction.user.display_name}\n"
                    f"• **Tarih:** <t:{int(time.time())}:F>\n"
                    f"• **Güncel Sicil Puanınız:** `{w_count}` kayıt\n\n"
                    f"*Lütfen topluluk kurallarına ve destek sistemi düzenine riayet ediniz.*"
                ),
                color=0xed4245,
                timestamp=datetime.now(timezone.utc)
            )
            dm_embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  •  Resmi Denetim")
            await kullanici.send(embed=dm_embed)
            dm_status = True
        except Exception:
            dm_status = False

    log_ch_id = config.get("ticket_log_kanal_id")
    if log_ch_id and interaction.guild:
        log_ch = interaction.guild.get_channel(int(log_ch_id))
        if log_ch:
            log_embed = discord.Embed(
                title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Sicil Kaydı İşlendi",
                description=(
                    f"Bir kullanıcıya yetkili tarafından manuel sicil kaydı girildi.\n\n"
                    f"• **İşlem Yapılan Üye:** {kullanici.mention} (`{kullanici.id}`)\n"
                    f"• **Kayıt Türü:** `{tur}`\n"
                    f"• **Gerekçe:** {sebep}\n"
                    f"• **İşlemi Yapan Yetkili:** {interaction.user.mention} (`{interaction.user.id}`)\n"
                    f"• **DM Durumu:** {'İletildi' if dm_status else 'İletilemedi (DM Kapalı)'}\n"
                    f"• **Toplam Sicil Kaydı:** `{w_count}` adet\n"
                    f"• **Tarih:** <t:{int(time.time())}:F>"
                ),
                color=0xed4245,
                timestamp=datetime.now(timezone.utc)
            )
            try:
                await log_ch.send(embed=log_embed)
            except Exception:
                pass

    resp_embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Sicil Kaydı Başarıyla Eklendi",
        description=(
            f"{kullanici.mention} kullanıcısının siciline yeni kayıt işlendi.\n\n"
            f"• **Tür:** `{tur}`\n"
            f"• **Gerekçe:** {sebep}\n"
            f"• **Toplam Ceza/İhtar Sayısı:** `{w_count}`\n"
            f"• **DM Bildirimi:** {'Kullanıcıya özelden iletildi' if dm_status else 'DM kapalı olduğu için iletilemedi'}"
        ),
        color=0xed4245,
        timestamp=datetime.now(timezone.utc)
    )
    await interaction.response.send_message(embed=resp_embed, ephemeral=True)

# 14. /sicil-temizle & /sicil-sil (Seçimli Sicil Temizleme Sistemi)
class SicilSelectMenu(discord.ui.Select):
    def __init__(self, target_user: discord.Member, warns: list):
        self.target_user = target_user
        self.warns = warns

        options = []
        display_warns = warns[:25]
        for idx, w in enumerate(display_warns):
            w_type = str(w.get("warn_type", "Ceza"))[:20]
            w_reason = str(w.get("reason", "Belirtilmedi"))[:45]
            w_time = str(w.get("timestamp", ""))[:16]
            label = f"#{idx + 1} - {w_type}"
            desc = f"{w_reason} ({w_time})" if w_time else w_reason
            options.append(discord.SelectOption(
                label=label[:100],
                description=desc[:100],
                value=str(idx),
                emoji="⚠️"
            ))

        super().__init__(
            placeholder="Silmek istediğiniz sicil kayıtlarını seçin...",
            min_values=1,
            max_values=len(options),
            options=options,
            row=0
        )

    async def callback(self, interaction: discord.Interaction):
        view = self.view
        if not view or interaction.user.id != getattr(view, "author_id", None):
            await interaction.response.send_message("Bu menüyü yalnızca komutu kullanan yetkili kullanabilir.", ephemeral=True)
            return

        selected_indices = [int(v) for v in self.values]
        deleted_records = delete_user_warnings_by_indices(self.target_user.id, selected_indices)
        remaining_warns = get_user_warnings(self.target_user.id)

        tdata_active = load_tickets()
        for cid_str, act_info in tdata_active.get("active", {}).items():
            if str(act_info.get("owner_id")) == str(self.target_user.id):
                asyncio.create_task(refresh_ticket_welcome_embed(int(cid_str)))

        log_ch_id = config.get("ticket_log_kanal_id")
        if log_ch_id and interaction.guild:
            log_ch = interaction.guild.get_channel(int(log_ch_id))
            if log_ch:
                silinen_ozet = "\n".join([
                    f"• **{r.get('warn_type', 'Ceza')}**: {r.get('reason', 'Belirtilmedi')} (Yetkili: {r.get('staff_name', '-')})"
                    for r in deleted_records[:10]
                ])
                if len(deleted_records) > 10:
                    silinen_ozet += f"\n*...ve {len(deleted_records) - 10} kayıt daha.*"

                log_embed = discord.Embed(
                    title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Sicil Kayıtları Silindi",
                    description=(
                        f"Bir kullanıcının seçilen sicil kayıtları yetkili tarafından silindi.\n\n"
                        f"• **Kullanıcı:** {self.target_user.mention} (`{self.target_user.id}`)\n"
                        f"• **Yetkili:** {interaction.user.mention} (`{interaction.user.id}`)\n"
                        f"• **Silinen Kayıt Sayısı:** **{len(deleted_records)}**\n"
                        f"• **Kalan Sicil Kaydı:** **{len(remaining_warns)}**\n\n"
                        f"**Silinen Kayıtlar:**\n{silinen_ozet}\n\n"
                        f"• **Tarih:** <t:{int(time.time())}:F>"
                    ),
                    color=0x57f287,
                    timestamp=datetime.now(timezone.utc)
                )
                try:
                    await log_ch.send(embed=log_embed)
                except Exception:
                    pass

        silinen_list = "\n".join([
            f"• **{r.get('warn_type', 'Ceza')}**: {r.get('reason', 'Belirtilmedi')} `({r.get('timestamp', '-')})`"
            for r in deleted_records[:10]
        ])
        if len(deleted_records) > 10:
            silinen_list += f"\n*...ve {len(deleted_records) - 10} kayıt daha.*"

        resp_embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Seçilen Sicil Kayıtları Silindi",
            description=(
                f"{self.target_user.mention} kullanıcısına ait **{len(deleted_records)}** adet sicil kaydı başarıyla silindi.\n\n"
                f"**Silinen Kayıtlar:**\n{silinen_list}\n\n"
                f"📊 **Kalan Aktif Sicil:** **{len(remaining_warns)}** adet kayıt."
            ),
            color=0x57f287,
            timestamp=datetime.now(timezone.utc)
        )
        await interaction.response.edit_message(embed=resp_embed, view=None)
        view.stop()


class SicilTemizleView(discord.ui.View):
    def __init__(self, author_id: int, target_user: discord.Member, warns: list):
        super().__init__(timeout=120)
        self.author_id = author_id
        self.target_user = target_user
        self.warns = warns
        self.add_item(SicilSelectMenu(target_user, warns))

    @discord.ui.button(label="Tüm Sicili Sıfırla", style=discord.ButtonStyle.danger, emoji="🗑️", row=1)
    async def btn_clear_all(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("Bu butonu yalnızca komutu kullanan yetkili kullanabilir.", ephemeral=True)
            return

        clear_user_warnings(self.target_user.id)

        tdata_active = load_tickets()
        for cid_str, act_info in tdata_active.get("active", {}).items():
            if str(act_info.get("owner_id")) == str(self.target_user.id):
                asyncio.create_task(refresh_ticket_welcome_embed(int(cid_str)))

        log_ch_id = config.get("ticket_log_kanal_id")
        if log_ch_id and interaction.guild:
            log_ch = interaction.guild.get_channel(int(log_ch_id))
            if log_ch:
                log_embed = discord.Embed(
                    title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Sicil Sıfırlandı",
                    description=(
                        f"Bir kullanıcının tüm sicil kayıtları yetkili tarafından temizlendi.\n\n"
                        f"• **Sıfırlanan Üye:** {self.target_user.mention} (`{self.target_user.id}`)\n"
                        f"• **Yetkili:** {interaction.user.mention} (`{interaction.user.id}`)\n"
                        f"• **Tarih:** <t:{int(time.time())}:F>"
                    ),
                    color=0x57f287,
                    timestamp=datetime.now(timezone.utc)
                )
                try:
                    await log_ch.send(embed=log_embed)
                except Exception:
                    pass

        embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Sicil Sıfırlandı",
            description=f"{self.target_user.mention} kullanıcısına ait tüm uyarı ve ihlal kayıtları sistemden tamamen temizlendi.",
            color=0x57f287,
            timestamp=datetime.now(timezone.utc)
        )
        await interaction.response.edit_message(embed=embed, view=None)
        self.stop()

    @discord.ui.button(label="İptal Et", style=discord.ButtonStyle.secondary, emoji="✖️", row=1)
    async def btn_cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("Bu butonu yalnızca komutu kullanan yetkili kullanabilir.", ephemeral=True)
            return

        embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  İşlem İptal Edildi",
            description="Sicil temizleme işlemi iptal edildi. Hiçbir kayıt silinmedi.",
            color=0x95a5a6,
            timestamp=datetime.now(timezone.utc)
        )
        await interaction.response.edit_message(embed=embed, view=None)
        self.stop()


@bot.tree.command(name="sicil-temizle", description="Bir kullanıcının sicil kayıtlarını seçerek veya toplu temizler.")
@app_commands.describe(kullanici="Sicili yönetilecek kullanıcı")
async def slash_sicil_temizle(interaction: discord.Interaction, kullanici: discord.Member):
    STAFF_ROLE_ID = 0
    is_admin = interaction.user.guild_permissions.administrator if interaction.guild else False
    is_staff = any(r.id == STAFF_ROLE_ID for r in getattr(interaction.user, "roles", [])) or is_admin
    if not is_staff:
        await interaction.response.send_message("Erişim Reddedildi: Yalnızca yetkililer sicil temizleyebilir!", ephemeral=True)
        return

    warns = get_user_warnings(kullanici.id)
    if not warns:
        embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Sicil Kaydı Bulunamadı",
            description=f"{kullanici.mention} kullanıcısına ait silinebilecek herhangi bir ceza veya ihlal kaydı bulunmuyor.",
            color=0x57f287,
            timestamp=datetime.now(timezone.utc)
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    records_preview = []
    for idx, w in enumerate(warns[:15]):
        w_type = w.get("warn_type", "Ceza")
        w_reason = w.get("reason", "Belirtilmedi")
        w_staff = w.get("staff_name", "Yetkili")
        w_time = w.get("timestamp", "-")
        records_preview.append(f"**#{idx + 1} - {w_type}**\n• Gerekçe: `{w_reason}`\n• Yetkili: `{w_staff}` | Tarih: `{w_time}`")

    records_text = "\n\n".join(records_preview)
    if len(warns) > 15:
        records_text += f"\n\n*... ve {len(warns) - 15} adet daha eski kayıt mevcut.*"

    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Sicil Temizleme & Seçim Menüsü",
        description=(
            f"{kullanici.mention} kullanıcısına ait toplam **{len(warns)}** adet kayıt listelendi.\n\n"
            f"Aşağıdaki açılır menüden **silmek istediğiniz sicilleri seçiniz**.\n"
            f"*(Tek seferde birden fazla sicil seçebilirsiniz)*\n\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📋 **Mevcut Sicil Kayıtları:**\n\n"
            f"{records_text}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━"
        ),
        color=0xfee75c,
        timestamp=datetime.now(timezone.utc)
    )
    embed.set_footer(text="Silmek istediğiniz kayıtları menüden seçin veya 'Tüm Sicili Sıfırla' butonuna basın.")

    view = SicilTemizleView(interaction.user.id, kullanici, warns)
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


@bot.tree.command(name="sicil-sil", description="Bir kullanıcının sicil kayıtlarını seçerek veya toplu temizler.")
@app_commands.describe(kullanici="Sicili silinecek kullanıcı")
async def slash_sicil_sil(interaction: discord.Interaction, kullanici: discord.Member):
    await slash_sicil_temizle(interaction, kullanici)


# 15. /yardim
@bot.tree.command(name="yardim", description="Ticket botunun komutlarını gösterir.")
async def slash_yardim(interaction: discord.Interaction):
    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Destek Botu Komutları",
        description="Gelişmiş priv destek sistemi komut listesi:\n",
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    embed.add_field(
        name="Yönetici Komutları",
        value=(
            "`/ticket-kur` -> Kategori, yetkili rolü, log kanalı ve paneli otomatik kurar.\n"
            "`/ticket-panel-gonder` -> Bulunulan kanala ticket panelini gönderir.\n"
            "`/kurallar-kur` -> Otomatik #kurallar kanalı oluşturup kuralları yayınlar.\n"
            "`/kurallar-gonder` -> Bulunulan kanala resimli kuralları gönderir.\n"
            "`/sicil-temizle [üye]` -> Kullanıcının sicilini sıfırlar (Yönetici).\n"
        ),
        inline=False
    )
    embed.add_field(
        name="Bilet Yönetimi",
        value=(
            "`/bilet-ekle [üye]` -> Bilete bir üyeyi ekler.\n"
            "`/bilet-cikar [üye]` -> Biletten bir üyeyi çıkarır.\n"
            "`/bilet-ustlen` -> Bileti yetkili üstlenir.\n"
            "`/bilet-kapat` -> Bulunulan bileti kilitler.\n"
            "`/bilet-sil` -> Bileti arşivleyip siler.\n"
            "`/transkript` -> Biletin web sitesi döküm bağlantısını oluşturur.\n"
            "`/portal` -> Bilet portalına tek tıkla şifresiz giriş linki üretir.\n"
            "`/yetkili-kod` -> Web portalı için 6 haneli giriş kodu üretir.\n"
        ),
        inline=False
    )
    embed.add_field(
        name="Sicil & Denetim Sistemi",
        value=(
            "`/sicil [üye]` -> Kullanıcının veya kendinizin sicil ve ceza dökümüne bakar.\n"
            "`/sicil-ekle [üye] [tür] [sebep]` -> Kullanıcının siciline resmi uyarı/ceza ekler.\n"
        ),
        inline=False
    )
    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Destek Sistemi")
    logo = get_brand_logo_url(interaction.guild)
    if logo:
        embed.set_thumbnail(url=logo)
    await interaction.response.send_message(embed=embed)

# ─────────────────────────────────────────────
# BAŞLATMA
# ─────────────────────────────────────────────
def main():
    token = config.get("bot_token", "").strip()
    if not token or token == "BOT_TOKENINI_BURAYA_YAZIN":
        print("\n" + "="*60)
        print(" [!] DIKKAT: IMZA Ticket Botu icin bot tokeni girilmedi!")
        print(" Lutfen config.json dosyasindan 'bot_token' alanini kontrol edin.")
        print("="*60 + "\n")
        input("Devam etmek icin Enter tusuna basin...")
        sys.exit(1)

    # ----------------------------------------------------
    # 🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ (Açılış Kilidi)
    # ----------------------------------------------------
    from closy_license_client import verify_license_sync, setup_license_guard
    _lic_key = config.get("lisans_anahtari", "").strip()
    _lic_api = config.get("lisans_api_url", "http://localhost:5050").strip()

    print("\n" + "=" * 60)
    print("  🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ")
    print(f"  🔑 Lisans Anahtarı : {_lic_key or 'GİRİLMEDİ'}")
    print(f"  🌐 Lisans Sunucusu : {_lic_api}")
    print("=" * 60)

    _lic_res = verify_license_sync(_lic_key, api_url=_lic_api)
    if not _lic_res.get("valid"):
        print("\n" + "!" * 65)
        print("  [LİSANS HATASI] ⛔ BOT BAŞLATILAMADI!")
        print(f"  Sebep: {_lic_res.get('reason', 'Geçersiz Lisans')}")
        print("  Lütfen config.json dosyasındaki 'lisans_anahtari' alanına")
        print("  satın aldığınız geçerli lisansı giriniz.")
        print("  Lisans Satın Almak veya Yenilemek İçin: https://discord.gg/imzapriw")
        print("!" * 65 + "\n")
        try:
            input("Kapatmak için Enter tuşuna basınız...")
        except Exception:
            pass
        sys.exit(1)

    print(f"  [LİSANS ONAYLANDI] 🟢 {_lic_res.get('message', 'Lisans aktif.')}")
    print(f"  [BİLGİ] Lisans Sahibi: {_lic_res.get('owner_discord', 'Müşteri')} | Kalan: {_lic_res.get('days_left')} Gün")
    print("=" * 60 + "\n")
    setup_license_guard(bot, license_key=_lic_key, api_url=_lic_api)

    try:
        bot.run(token)
    except Exception as e:
        print(f"\n[HATA] Bot baslatilirken hata olustu: {e}\n")
        input("Cikmak icin Enter'a basin...")

if __name__ == "__main__":
    main()
