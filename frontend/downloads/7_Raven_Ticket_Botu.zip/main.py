import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import asyncio
import io
from datetime import datetime

# ─────────────────────────────────────────────
#  AYARLAR (config.json'dan okunur)
# ─────────────────────────────────────────────
def load_config():
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

config = load_config()

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree

# ─────────────────────────────────────────────
#  VERİTABANI (JSON Tabanlı Kayıt Sistemi)
# ─────────────────────────────────────────────
DATA_FILE = "ticket_data.json"

def load_data() -> dict:
    if not os.path.exists(DATA_FILE):
        return {"sayac": 1, "aktif_biletler": {}}
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_data(data: dict):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_sayac() -> int:
    return load_data().get("sayac", 1)

def arttir_sayac() -> int:
    data = load_data()
    s = data.get("sayac", 1)
    data["sayac"] = s + 1
    save_data(data)
    return s

def kaydet_bilet(kanal_id: int, user_id: int, kategori: str, bilet_no: int):
    data = load_data()
    data["aktif_biletler"][str(kanal_id)] = {
        "user_id": user_id,
        "kategori": kategori,
        "bilet_no": bilet_no,
        "acilis_zamani": datetime.now().isoformat(),
        "ustlenen_id": None
    }
    save_data(data)

def sil_bilet(kanal_id: int) -> dict:
    data = load_data()
    bilet = data["aktif_biletler"].pop(str(kanal_id), None)
    save_data(data)
    return bilet

def get_bilet(kanal_id: int) -> dict:
    data = load_data()
    return data["aktif_biletler"].get(str(kanal_id))

def get_user_aktif_bilet_sayisi(user_id: int) -> int:
    data = load_data()
    return sum(1 for b in data["aktif_biletler"].values() if b["user_id"] == user_id)

def yetkili_mi(member: discord.Member) -> bool:
    if member.guild_permissions.administrator:
        return True
    yetkili_rol_id = config.get("yetkili_rol_id")
    return any(r.id == yetkili_rol_id for r in member.roles)


# ─────────────────────────────────────────────
#  TRANSKRİPT OLUŞTURUCU
# ─────────────────────────────────────────────
async def transkript_olustur(channel: discord.TextChannel, bilet_bilgi: dict) -> io.BytesIO:
    messages = []
    async for msg in channel.history(limit=1000, oldest_first=True):
        zaman = msg.created_at.strftime("%d.%m.%Y %H:%M:%S")
        yazar = f"{msg.author.name} ({msg.author.id})"
        icerik = msg.content if msg.content else "[İçerik Yok]"
        
        ekler = ""
        if msg.attachments:
            ekler = " | Ekler: " + ", ".join(a.url for a in msg.attachments)
            
        messages.append(f"[{zaman}] {yazar}: {icerik}{ekler}")

    bilet_no = bilet_bilgi.get("bilet_no", "Bilinmiyor") if bilet_bilgi else "Bilinmiyor"
    kategori = bilet_bilgi.get("kategori", "Genel") if bilet_bilgi else "Genel"
    
    header = (
        f"=====================================================\n"
        f"          RAVEN TICKET TRANSKRİPTİ #{bilet_no}       \n"
        f"=====================================================\n"
        f"Kanal: #{channel.name} (ID: {channel.id})\n"
        f"Kategori: {kategori}\n"
        f"Oluşturulma Tarihi: {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}\n"
        f"Built by 6Closy | Raven\n"
        f"=====================================================\n\n"
    )
    
    tam_metin = header + "\n".join(messages)
    buf = io.BytesIO(tam_metin.encode("utf-8"))
    buf.seek(0)
    return buf


# ─────────────────────────────────────────────
#  TİCKET OLUŞTURMA MODALI
# ─────────────────────────────────────────────
class TicketAcilisModali(discord.ui.Modal):
    def __init__(self, kategori: str):
        super().__init__(title=f"Raven  |  {kategori}")
        self.kategori = kategori

        self.sebep = discord.ui.TextInput(
            label="Talebinizin Konusu / Açıklama",
            style=discord.TextStyle.paragraph,
            placeholder="Lütfen yardım almak istediğiniz konuyu detaylıca açıklayınız...",
            min_length=10,
            max_length=600,
            required=True
        )
        self.add_item(self.sebep)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        user = interaction.user
        guild = interaction.guild
        cfg = load_config()

        # Limit kontrolü
        limit = cfg.get("bilet_limiti", 1)
        if get_user_aktif_bilet_sayisi(user.id) >= limit:
            await interaction.followup.send(
                f"Zaten aktif bir destek talebiniz bulunmaktadır. Lütfen önce mevcut talebinizi sonuçlandırın.",
                ephemeral=True
            )
            return

        # Kategori kontrolü
        kategori_id = cfg.get("kategori_id")
        discord_kategori = guild.get_channel(kategori_id) if kategori_id else None

        yetkili_rol_id = cfg.get("yetkili_rol_id")
        yetkili_rol = guild.get_role(yetkili_rol_id) if yetkili_rol_id else None

        # Kanal izinleri
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                attach_files=True,
                embed_links=True,
                read_message_history=True
            ),
            guild.me: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                manage_channels=True,
                manage_messages=True,
                attach_files=True,
                embed_links=True,
                read_message_history=True
            )
        }

        if yetkili_rol:
            overwrites[yetkili_rol] = discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                attach_files=True,
                embed_links=True,
                read_message_history=True
            )

        bilet_no = arttir_sayac()
        kanal_adi = f"destek-{bilet_no:04d}"

        try:
            ticket_kanali = await guild.create_text_channel(
                name=kanal_adi,
                category=discord_kategori if isinstance(discord_kategori, discord.CategoryChannel) else None,
                overwrites=overwrites,
                topic=f"Kullanıcı: {user.name} ({user.id}) | Kategori: {self.kategori} | Bilet #{bilet_no}"
            )
        except Exception as e:
            await interaction.followup.send(f"Kanal oluşturulurken bir hata oluştu: {e}", ephemeral=True)
            return

        # Kaydet
        kaydet_bilet(ticket_kanali.id, user.id, self.kategori, bilet_no)

        # Karşılama Embed'i
        embed = discord.Embed(
            title=f"Destek Talebi  |  #{bilet_no:04d}",
            description=(
                f"Merhaba {user.mention}, Raven destek talebiniz başarıyla açıldı.\n"
                f"Yetkili kadromuz en kısa sürede sizinle iletişime geçecektir.\n\n"
                f"**Kullanıcı Bilgileri**\n"
                f"— Kullanıcı: {user.mention} (`{user.name}`)\n"
                f"— Kullanıcı ID: `{user.id}`\n\n"
                f"**Talep Detayları**\n"
                f"— Kategori: **{self.kategori}**\n"
                f"— Açıklama: {self.sebep.value}\n\n"
                f"**Durum:** Beklemede (Yetkili Bekleniyor)"
            ),
            color=discord.Color.from_str(cfg.get("embed_renk", "#9B59B6")),
            timestamp=datetime.now()
        )
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_footer(text=f"Built by 6Closy  |  {guild.name}")

        view = TicketKontrolView()
        msg = await ticket_kanali.send(
            content=f"{user.mention} {yetkili_rol.mention if yetkili_rol else ''}",
            embed=embed,
            view=view
        )

        # Bildirim pini sil
        try:
            await msg.edit(content=None)
        except Exception:
            pass

        await interaction.followup.send(
            f"Destek talebiniz başarıyla oluşturuldu: {ticket_kanali.mention}",
            ephemeral=True
        )


# ─────────────────────────────────────────────
#  TİCKET İÇİ KONTROL BUTONLARI (Kalıcı View)
# ─────────────────────────────────────────────
class TicketKontrolView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Talebi Kapat",
        style=discord.ButtonStyle.danger,
        custom_id="ticket_kapat_btn"
    )
    async def kapat(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(TicketKapatmaModali())

    @discord.ui.button(
        label="Talebi Üstlen",
        style=discord.ButtonStyle.success,
        custom_id="ticket_ustlen_btn"
    )
    async def ustlen(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not yetkili_mi(interaction.user):
            await interaction.response.send_message("Bu işlemi sadece yetkililer yapabilir.", ephemeral=True)
            return

        bilet = get_bilet(interaction.channel.id)
        if not bilet:
            await interaction.response.send_message("Bu kanal bir aktif ticket olarak kaydedilmemiş.", ephemeral=True)
            return

        data = load_data()
        data["aktif_biletler"][str(interaction.channel.id)]["ustlenen_id"] = interaction.user.id
        save_data(data)

        button.disabled = True
        button.label = f"Üstlendi: {interaction.user.name}"
        await interaction.message.edit(view=self)

        embed = discord.Embed(
            description=f"Bu destek talebi {interaction.user.mention} tarafından üstlenildi. Sizinle ilgileniyor.",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.set_footer(text=f"Built by 6Closy  |  {interaction.guild.name}")
        await interaction.channel.send(embed=embed)
        await interaction.response.send_message("Destek talebini üstlendiniz.", ephemeral=True)

    @discord.ui.button(
        label="Üye Ekle",
        style=discord.ButtonStyle.secondary,
        custom_id="ticket_uye_ekle_btn"
    )
    async def uye_ekle(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not yetkili_mi(interaction.user):
            await interaction.response.send_message("Bu işlemi sadece yetkililer yapabilir.", ephemeral=True)
            return
        await interaction.response.send_modal(UyeEkleModali(cikar=False))

    @discord.ui.button(
        label="Üye Çıkar",
        style=discord.ButtonStyle.secondary,
        custom_id="ticket_uye_cikar_btn"
    )
    async def uye_cikar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not yetkili_mi(interaction.user):
            await interaction.response.send_message("Bu işlemi sadece yetkililer yapabilir.", ephemeral=True)
            return
        await interaction.response.send_modal(UyeEkleModali(cikar=True))


# ─────────────────────────────────────────────
#  KAPATMA MODALI
# ─────────────────────────────────────────────
class TicketKapatmaModali(discord.ui.Modal, title="Destek Talebini Kapat"):
    sebep = discord.ui.TextInput(
        label="Kapatma Sebebi",
        style=discord.TextStyle.paragraph,
        placeholder="Sorun çözüldü, kullanıcı ayrıldı vb...",
        min_length=3,
        max_length=300,
        required=True
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer()

        channel = interaction.channel
        guild = interaction.guild
        cfg = load_config()
        bilet_bilgi = sil_bilet(channel.id)

        # Transkript hazırla
        transkript_buf = await transkript_olustur(channel, bilet_bilgi)
        dosya = discord.File(transkript_buf, filename=f"transkript-{channel.name}.txt")

        kapatan = interaction.user
        sahip_id = bilet_bilgi.get("user_id") if bilet_bilgi else None
        bilet_sahibi = guild.get_member(sahip_id) if sahip_id else None
        bilet_no = bilet_bilgi.get("bilet_no", "Bilinmiyor") if bilet_bilgi else "Bilinmiyor"
        kategori = bilet_bilgi.get("kategori", "Genel") if bilet_bilgi else "Genel"

        # Log Embed'i
        log_embed = discord.Embed(
            title=f"Destek Talebi Kapatıldı  |  #{bilet_no:04d}",
            description=(
                f"**Talep Detayları**\n"
                f"— Talep Sahibi: {bilet_sahibi.mention if bilet_sahibi else f'`ID: {sahip_id}`'}\n"
                f"— Kapatan Yetkili: {kapatan.mention}\n"
                f"— Kategori: **{kategori}**\n"
                f"— Kapatma Sebebi: {self.sebep.value}\n"
                f"— Kanal: `#{channel.name}`"
            ),
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        log_embed.set_footer(text=f"Built by 6Closy  |  {guild.name}")

        # Log kanalına yolla
        log_kanal_id = cfg.get("ticket_log_kanal_id")
        log_kanali = guild.get_channel(log_kanal_id)
        if log_kanali and isinstance(log_kanali, discord.TextChannel):
            try:
                await log_kanali.send(embed=log_embed, file=dosya)
            except Exception as e:
                print(f"Log kanalına gönderme hatası: {e}")

        # Kullanıcıya DM gönder
        if bilet_sahibi:
            try:
                transkript_buf.seek(0)
                dm_dosya = discord.File(transkript_buf, filename=f"transkript-{channel.name}.txt")
                dm_embed = discord.Embed(
                    title=f"Destek Talebiniz Sonuçlandı  |  Raven",
                    description=(
                        f"Raven sunucusunda açmış olduğunuz **#{bilet_no:04d}** numaralı destek "
                        f"talebi yetkili kadromuz tarafından kapatılmıştır.\n\n"
                        f"**Kapatan Yetkili:** {kapatan.mention}\n"
                        f"**Kapatma Sebebi:** {self.sebep.value}\n\n"
                        f"Görüşme transkripti ekteki dosyada yer almaktadır. Bizi tercih ettiğiniz için teşekkür ederiz."
                    ),
                    color=discord.Color.from_str(cfg.get("embed_renk", "#9B59B6")),
                    timestamp=datetime.now()
                )
                dm_embed.set_footer(text=f"Built by 6Closy  |  {guild.name}")
                await bilet_sahibi.send(embed=dm_embed, file=dm_dosya)
            except Exception:
                pass

        # Geri sayım ve kanalı silme
        await channel.send("Bu destek talebi kapatıldı. Kanal **5 saniye** içerisinde silinecektir...")
        await asyncio.sleep(5)
        try:
            await channel.delete(reason=f"Ticket kapatıldı: {self.sebep.value}")
        except Exception:
            pass


# ─────────────────────────────────────────────
#  ÜYE EKLEME / ÇIKARMA MODALI
# ─────────────────────────────────────────────
class UyeEkleModali(discord.ui.Modal):
    def __init__(self, cikar: bool = False):
        self.cikar = cikar
        baslik = "Talepten Üye Çıkar" if cikar else "Talebe Üye Ekle"
        super().__init__(title=baslik)

        self.kullanici_input = discord.ui.TextInput(
            label="Kullanıcı ID veya @Etiket",
            placeholder="Örn: 122520589412860198",
            min_length=2,
            max_length=50,
            required=True
        )
        self.add_item(self.kullanici_input)

    async def on_submit(self, interaction: discord.Interaction):
        raw_val = self.kullanici_input.value.strip("<@!>")
        try:
            target_id = int(raw_val)
            target = interaction.guild.get_member(target_id)
        except ValueError:
            target = discord.utils.get(interaction.guild.members, name=self.kullanici_input.value)

        if not target:
            await interaction.response.send_message("Kullanıcı sunucuda bulunamadı.", ephemeral=True)
            return

        channel = interaction.channel
        if self.cikar:
            await channel.set_permissions(target, overwrite=None)
            await interaction.response.send_message(f"{target.mention} destek talebinden çıkarıldı.")
        else:
            await channel.set_permissions(
                target,
                view_channel=True,
                send_messages=True,
                attach_files=True,
                embed_links=True,
                read_message_history=True
            )
            await interaction.response.send_message(f"{target.mention} destek talebine eklendi.")


# ─────────────────────────────────────────────
#  ANA PANEL SELECT MENÜSÜ & VIEW
# ─────────────────────────────────────────────
class TicketKategoriSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(
                label="Genel Destek",
                description="Sunucu içi soru, yardım ve teknik problemler.",
                value="Genel Destek"
            ),
            discord.SelectOption(
                label="Yetkili / Ekip İletişim",
                description="Yönetim kadrosu ile doğrudan görüşme.",
                value="Yetkili İletişim"
            ),
            discord.SelectOption(
                label="Şikayet & Bildiri",
                description="Kural ihlali, haksızlık veya öneri bildirimleri.",
                value="Şikayet & Bildiri"
            ),
            discord.SelectOption(
                label="Ortaklık & Sponsorluk",
                description="Partnerlik ve iş birliği talepleri.",
                value="Ortaklık & Sponsorluk"
            ),
        ]
        super().__init__(
            placeholder="Destek almak istediğiniz kategoriyi seçiniz...",
            min_values=1,
            max_values=1,
            custom_id="ticket_kategori_select",
            options=options
        )

    async def callback(self, interaction: discord.Interaction):
        kategori = self.values[0]
        await interaction.response.send_modal(TicketAcilisModali(kategori=kategori))


class TicketPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketKategoriSelect())


# ─────────────────────────────────────────────
#  SLASH KOMUTLAR
# ─────────────────────────────────────────────
@tree.command(name="ticket-panel", description="Destek talebi panelini bu kanala gönderir. (Yönetici)")
@app_commands.default_permissions(administrator=True)
async def ticket_panel_gonder(interaction: discord.Interaction):
    cfg = load_config()
    embed = discord.Embed(
        title="Raven  |  Destek & İletişim Merkezi",
        description=(
            "### Bir problem veya sorunuz mu var?\n\n"
            "Raven destek ekibi olarak sizlere yardımcı olmaktan memnuniyet duyarız. "
            "Aşağıdaki menüden durumunuza en uygun kategoriyi seçerek anında özel "
            "bir destek talebi oluşturabilirsiniz.\n\n"
            "> **Bilgilendirme & Kurallar:**\n"
            "> — Gereksiz ve trol amaçlı talep açmak cezai işlem sebebidir.\n"
            "> — Talebinizi oluşturduktan sonra sorununuzu detaylıca yazıp bekleyiniz.\n"
            "> — Yetkili ekibimiz en kısa sürede talebinize dönüş sağlayacaktır.\n\n"
            "**Destek almak için aşağıdaki menüden kategori seçiniz:**"
        ),
        color=discord.Color.from_str(cfg.get("embed_renk", "#9B59B6"))
    )
    if interaction.guild.icon:
        embed.set_thumbnail(url=interaction.guild.icon.url)
    embed.set_footer(text=f"Built by 6Closy  |  {interaction.guild.name}")

    await interaction.channel.send(embed=embed, view=TicketPanelView())
    await interaction.response.send_message("Ticket paneli başarıyla gönderildi.", ephemeral=True)


@tree.command(name="ticket-kapat", description="Mevcut destek talebini kapatır.")
async def ticket_kapat_cmd(interaction: discord.Interaction, sebep: str = "Sorun Çözüldü"):
    bilet = get_bilet(interaction.channel.id)
    if not bilet:
        await interaction.response.send_message("Bu komut sadece aktif destek talebi kanallarında kullanılabilir.", ephemeral=True)
        return

    await interaction.response.defer()
    channel = interaction.channel
    guild = interaction.guild
    cfg = load_config()
    bilet_bilgi = sil_bilet(channel.id)

    transkript_buf = await transkript_olustur(channel, bilet_bilgi)
    dosya = discord.File(transkript_buf, filename=f"transkript-{channel.name}.txt")

    kapatan = interaction.user
    sahip_id = bilet_bilgi.get("user_id") if bilet_bilgi else None
    bilet_sahibi = guild.get_member(sahip_id) if sahip_id else None
    bilet_no = bilet_bilgi.get("bilet_no", "Bilinmiyor") if bilet_bilgi else "Bilinmiyor"
    kategori = bilet_bilgi.get("kategori", "Genel") if bilet_bilgi else "Genel"

    log_embed = discord.Embed(
        title=f"Destek Talebi Kapatıldı  |  #{bilet_no:04d}",
        description=(
            f"**Talep Detayları**\n"
            f"— Talep Sahibi: {bilet_sahibi.mention if bilet_sahibi else f'`ID: {sahip_id}`'}\n"
            f"— Kapatan Yetkili: {kapatan.mention}\n"
            f"— Kategori: **{kategori}**\n"
            f"— Kapatma Sebebi: {sebep}\n"
            f"— Kanal: `#{channel.name}`"
        ),
        color=discord.Color.red(),
        timestamp=datetime.now()
    )
    log_embed.set_footer(text=f"Built by 6Closy  |  {guild.name}")

    log_kanal_id = cfg.get("ticket_log_kanal_id")
    log_kanali = guild.get_channel(log_kanal_id)
    if log_kanali and isinstance(log_kanali, discord.TextChannel):
        try:
            await log_kanali.send(embed=log_embed, file=dosya)
        except Exception:
            pass

    if bilet_sahibi:
        try:
            transkript_buf.seek(0)
            dm_dosya = discord.File(transkript_buf, filename=f"transkript-{channel.name}.txt")
            dm_embed = discord.Embed(
                title="Destek Talebiniz Sonuçlandı  |  Raven",
                description=(
                    f"Raven sunucusundaki **#{bilet_no:04d}** numaralı destek talebiniz kapatılmıştır.\n\n"
                    f"**Kapatan Yetkili:** {kapatan.mention}\n"
                    f"**Kapatma Sebebi:** {sebep}\n\n"
                    f"Transkript dosyanız ekte yer almaktadır."
                ),
                color=discord.Color.from_str(cfg.get("embed_renk", "#9B59B6")),
                timestamp=datetime.now()
            )
            dm_embed.set_footer(text=f"Built by 6Closy  |  {guild.name}")
            await bilet_sahibi.send(embed=dm_embed, file=dm_dosya)
        except Exception:
            pass

    await channel.send("Bu destek talebi kapatıldı. Kanal **5 saniye** içerisinde silinecektir...")
    await asyncio.sleep(5)
    try:
        await channel.delete(reason=f"Ticket kapatıldı: {sebep}")
    except Exception:
        pass


@tree.command(name="ticket-ekle", description="Destek talebine bir kullanıcı ekler.")
@app_commands.describe(kullanici="Eklenecek kullanıcı")
async def ticket_ekle_cmd(interaction: discord.Interaction, kullanici: discord.Member):
    if not yetkili_mi(interaction.user):
        await interaction.response.send_message("Bu komutu sadece yetkililer kullanabilir.", ephemeral=True)
        return

    bilet = get_bilet(interaction.channel.id)
    if not bilet:
        await interaction.response.send_message("Bu komut sadece aktif bir ticket kanalında kullanılabilir.", ephemeral=True)
        return

    await interaction.channel.set_permissions(
        kullanici,
        view_channel=True,
        send_messages=True,
        attach_files=True,
        embed_links=True,
        read_message_history=True
    )
    await interaction.response.send_message(f"{kullanici.mention} bu destek talebine başarıyla eklendi.")


@tree.command(name="ticket-cikar", description="Destek talebinden bir kullanıcıyı çıkarır.")
@app_commands.describe(kullanici="Çıkarılacak kullanıcı")
async def ticket_cikar_cmd(interaction: discord.Interaction, kullanici: discord.Member):
    if not yetkili_mi(interaction.user):
        await interaction.response.send_message("Bu komutu sadece yetkililer kullanabilir.", ephemeral=True)
        return

    bilet = get_bilet(interaction.channel.id)
    if not bilet:
        await interaction.response.send_message("Bu komut sadece aktif bir ticket kanalında kullanılabilir.", ephemeral=True)
        return

    await interaction.channel.set_permissions(kullanici, overwrite=None)
    await interaction.response.send_message(f"{kullanici.mention} bu destek talebinden çıkarıldı.")


# ─────────────────────────────────────────────
#  BOT OLAYLARI
# ─────────────────────────────────────────────
@bot.event
async def on_ready():
    print(f"✅ {bot.user} olarak giriş yapıldı!")
    print(f"   Sunucu sayısı: {len(bot.guilds)}")

    # Kalıcı View'ları kaydet (Bot yeniden başlasa bile butonlar çalışır)
    bot.add_view(TicketPanelView())
    bot.add_view(TicketKontrolView())

    # Slash komutları senkronize et
    try:
        synced = await tree.sync()
        print(f"   {len(synced)} slash komut senkronize edildi.")
    except Exception as e:
        print(f"   Slash sync hatası: {e}")

    # Mor Yayın İzliyor / Streaming Durumu
    await bot.change_presence(
        status=discord.Status.online,
        activity=discord.Streaming(
            name="Built by 6Closy",
            url="https://www.twitch.tv/discord"
        )
    )

    # Ses kanalına sessizce gir ve bekle (0)
    ses_kanal_id = config.get("ses_kanal_id", 0)
    for guild in bot.guilds:
        ses_kanali = guild.get_channel(ses_kanal_id)
        if ses_kanali and isinstance(ses_kanali, discord.VoiceChannel):
            try:
                if guild.voice_client:
                    await guild.voice_client.disconnect(force=True)
                vc = await ses_kanali.connect(self_deaf=True, self_mute=True)
                print(f"   Ses kanalına girildi: {ses_kanali.name} ({guild.name})")
            except Exception as e:
                print(f"   Ses kanalına bağlanılamadı: {e}")


# ─────────────────────────────────────────────
#  BAŞLAT
# ─────────────────────────────────────────────
if __name__ == "__main__":
    TOKEN = config.get("token")
    if not TOKEN or TOKEN == "BOT_TOKEN_BURAYA":
        print("❌ HATA: config.json dosyasına bot tokenını girmeyi unutma!")
        exit(1)
    # ----------------------------------------------------
    # 🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ (Açılış Kilidi)
    # ----------------------------------------------------
    from closy_license_client import verify_license_sync, setup_license_guard
    _lic_key = config.get("lisans_anahtari", "").strip()
    _lic_api = config.get("lisans_api_url", "http://localhost:5050").strip()

    print("\n" + "=" * 60)
    print("  🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ")
    print(f"  🔑 Lisans Anahtarı : {_lic_key or 'GİRİLMEDİ'}")
    print(f"  🌐 Lisans Sunucusu : {_lic_api}")
    print("=" * 60)

    _lic_res = verify_license_sync(_lic_key, api_url=_lic_api)
    if not _lic_res.get("valid"):
        print("\n" + "!" * 65)
        print("  [LİSANS HATASI] ⛔ BOT BAŞLATILAMADI!")
        print(f"  Sebep: {_lic_res.get('reason', 'Geçersiz Lisans')}")
        print("  Lütfen config.json dosyasındaki 'lisans_anahtari' alanına")
        print("  satın aldığınız geçerli lisansı giriniz.")
        print("  Lisans Satın Almak veya Yenilemek İçin: https://discord.gg/imzapriw")
        print("!" * 65 + "\n")
        try:
            input("Kapatmak için Enter tuşuna basınız...")
        except Exception:
            pass
        sys.exit(1)

    print(f"  [LİSANS ONAYLANDI] 🟢 {_lic_res.get('message', 'Lisans aktif.')}")
    print(f"  [BİLGİ] Lisans Sahibi: {_lic_res.get('owner_discord', 'Müşteri')} | Kalan: {_lic_res.get('days_left')} Gün")
    print("=" * 60 + "\n")
    setup_license_guard(bot, license_key=_lic_key, api_url=_lic_api)

    bot.run(TOKEN)
