import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import asyncio
import re
from datetime import datetime, timedelta, timezone
from collections import defaultdict

# ─────────────────────────────────────────────
#  AYARLAR (config.json'dan okunur)
# ─────────────────────────────────────────────
def load_config() -> dict:
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def save_config(cfg: dict):
    with open("config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

config = load_config()

intents = discord.Intents.default()
intents.members = True
intents.message_content = True
intents.guilds = True

bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree

# ─────────────────────────────────────────────
#  GÜVENLİK SAYAÇLARI & LİMİT TAKİBİ
# ─────────────────────────────────────────────
# user_id -> {"ban": [times], "kick": [times], "kanal": [times], "rol": [times]}
islem_gecmisi = defaultdict(lambda: defaultdict(list))
mesaj_gecmisi = defaultdict(list)

def guvenli_mi(member: discord.Member) -> bool:
    if member.id == member.guild.owner_id:
        return True
    if member.id == bot.user.id:
        return True
    cfg = load_config()
    return member.id in cfg.get("guvenli_kullanicilar", [])

def limit_asti_mi(user_id: int, eylem: str, maks_adet: int, sure_saniye: int = 60) -> bool:
    now = datetime.now()
    gecmis = islem_gecmisi[user_id][eylem]
    # Süresi geçmişleri temizle
    gecmis = [t for t in gecmis if (now - t).total_seconds() < sure_saniye]
    gecmis.append(now)
    islem_gecmisi[user_id][eylem] = gecmis
    return len(gecmis) > maks_adet


# ─────────────────────────────────────────────
#  UYARI & VERİTABANI YÖNETİMİ (2 Uyarı Kuralı)
# ─────────────────────────────────────────────
GUARD_DATA_FILE = "guard_data.json"

def load_guard_data() -> dict:
    if not os.path.exists(GUARD_DATA_FILE):
        return {"uyarilar": {}}
    with open(GUARD_DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_guard_data(data: dict):
    with open(GUARD_DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_uyari(user_id: int) -> int:
    data = load_guard_data()
    return data.get("uyarilar", {}).get(str(user_id), 0)

def arttir_uyari(user_id: int) -> int:
    data = load_guard_data()
    if "uyarilar" not in data:
        data["uyarilar"] = {}
    u = data["uyarilar"].get(str(user_id), 0) + 1
    data["uyarilar"][str(user_id)] = u
    save_guard_data(data)
    return u

def sifirla_uyari(user_id: int):
    data = load_guard_data()
    data.get("uyarilar", {}).pop(str(user_id), None)
    save_guard_data(data)


async def ihlal_yonetimi(member: discord.Member, eylem_tipi: str, detay: str):
    """
    İzinsiz işlem yapan yetkili için 2 uyarı sistemi:
    - 1. ve 2. ihlal: DM'den uyarı gönderir, yetkileri almaz.
    - 3. ihlal: Uyarı hakkı dolar, tüm yetkileri alır ve cezalandırır.
    """
    if guvenli_mi(member):
        return

    mevcut_uyari = arttir_uyari(member.id)
    guild = member.guild

    if mevcut_uyari <= 2:
        # DM'den uyarı gönder
        try:
            dm_embed = discord.Embed(
                title="Raven Guard  |  Güvenlik Uyarısı",
                description=(
                    f"Sayın **{member.name}**, Raven sunucusunda izinsiz bir işlem gerçekleştirdiniz.\n\n"
                    f"**Engellenen Eylem:** {detay}\n"
                    f"**Uyarı Durumu:** **{mevcut_uyari} / 2**\n\n"
                    f"⚠️ Sunucu güvenliği gereği işleminiz anında engellenmiş / iptal edilmiştir.\n"
                    f"Lütfen bir daha izinsiz işlem yapmayınız! Toplam **2 uyarı hakkınız** bulunmaktadır.\n"
                    f"Bir sonraki ihlalinizde **tüm yetkileriniz kalıcı olarak geri alınacaktır!**"
                ),
                color=discord.Color.gold(),
                timestamp=datetime.now()
            )
            dm_embed.set_footer(text=f"Built by 6Closy  |  {guild.name}")
            await member.send(embed=dm_embed)
        except Exception:
            pass

        # Log kanalına sarı uyarı bildirimi
        await guard_log_gonder(
            guild=guild,
            baslik=f"Yetkili Uyarıldı ({mevcut_uyari}/2)",
            aciklama=(
                f"**İhlal Yapan Yetkili:** {member.mention} (`{member.name}` - `{member.id}`)\n"
                f"**Eylem:** {detay}\n"
                f"**Mevcut Uyarı:** **{mevcut_uyari} / 2**\n"
                f"**Sonuç:** Eylem engellendi, yetkiliye DM ile **{mevcut_uyari}. uyarı** gönderildi (Yetkileri alınmadı)."
            ),
            renk=discord.Color.gold()
        )
    else:
        # 3. ihlal -> Yetkileri al ve cezalandır!
        try:
            dm_embed = discord.Embed(
                title="Raven Guard  |  Yetkileriniz Geri Alındı!",
                description=(
                    f"Sayın **{member.name}**, Raven sunucusunda 2 uyarı hakkınızı doldurmanıza rağmen "
                    f"izinsiz işlem yapmaya devam ettiğiniz için **tüm yetkileriniz geri alınmıştır.**\n\n"
                    f"**Son İhlal:** {detay}\n\n"
                    f"Konu hakkında sunucu yönetimi ile iletişime geçebilirsiniz."
                ),
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            dm_embed.set_footer(text=f"Built by 6Closy  |  {guild.name}")
            await member.send(embed=dm_embed)
        except Exception:
            pass

        await cezalandir(member, f"2 uyarı hakkını doldurdu ({detay})")


# ─────────────────────────────────────────────
#  CEZALANDIRMA FONKSİYONU (Yetkileri Alma)
# ─────────────────────────────────────────────
async def cezalandir(member: discord.Member, sebep: str):
    if guvenli_mi(member):
        return

    guild = member.guild
    cfg = load_config()
    alinan_roller = []

    # Tehlikeli yetkileri olan rolleri al
    tehlikeli_yetkiler = [
        "administrator", "manage_guild", "manage_roles",
        "manage_channels", "ban_members", "kick_members", "manage_webhooks"
    ]

    for role in member.roles:
        if role.is_default():
            continue
        perms = role.permissions
        if any(getattr(perms, p, False) for p in tehlikeli_yetkiler):
            try:
                await member.remove_roles(role, reason=f"Raven Guard Koruma: {sebep}")
                alinan_roller.append(role.name)
            except Exception:
                pass

    # Varsa cezalı rolünü ver
    cezali_rol_id = cfg.get("cezali_rol_id", 0)
    if cezali_rol_id:
        c_rol = guild.get_role(cezali_rol_id)
        if c_rol:
            try:
                await member.add_roles(c_rol, reason=f"Raven Guard: {sebep}")
            except Exception:
                pass

    # Log gönder
    await guard_log_gonder(
        guild=guild,
        baslik="Yetki Suistimali Engellendi",
        aciklama=(
            f"**İhlal Yapan Kullanıcı:** {member.mention} (`{member.name}` - `{member.id}`)\n"
            f"**Sebep:** {sebep}\n"
            f"**Uygulanan İşlem:** Tehlikeli rolleri alındı ({', '.join(alinan_roller) if alinan_roller else 'Rol alınamadı/yok'})."
        ),
        renk=discord.Color.red()
    )


# ─────────────────────────────────────────────
#  LOG GÖNDERME YARDIMCISI
# ─────────────────────────────────────────────
async def guard_log_gonder(guild: discord.Guild, baslik: str, aciklama: str, renk: discord.Color):
    cfg = load_config()
    log_kanal_id = cfg.get("guard_log_kanal_id")
    if not log_kanal_id:
        return

    kanal = guild.get_channel(log_kanal_id)
    if not kanal or not isinstance(kanal, discord.TextChannel):
        return

    embed = discord.Embed(
        title=f"Raven Guard  |  {baslik}",
        description=aciklama,
        color=renk,
        timestamp=datetime.now()
    )
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    embed.set_footer(text=f"Built by 6Closy  |  {guild.name}")

    try:
        await kanal.send(embed=embed)
    except Exception as e:
        print(f"Guard log gönderme hatası: {e}")


async def rol_log_gonder(guild: discord.Guild, baslik: str, aciklama: str, renk: discord.Color, user: discord.abc.User = None):
    cfg = load_config()
    log_kanal_id = cfg.get("rol_log_kanal_id") or cfg.get("guard_log_kanal_id")
    if not log_kanal_id:
        return

    kanal = guild.get_channel(log_kanal_id)
    if not kanal or not isinstance(kanal, discord.TextChannel):
        return

    embed = discord.Embed(
        title=f"Raven Guard  |  {baslik}",
        description=aciklama,
        color=renk,
        timestamp=datetime.now()
    )
    if user and user.display_avatar:
        embed.set_thumbnail(url=user.display_avatar.url)
    elif guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    embed.set_footer(text=f"Built by 6Closy  |  {guild.name}")

    try:
        await kanal.send(embed=embed)
    except Exception as e:
        print(f"Rol log gönderme hatası: {e}")


# ─────────────────────────────────────────────
#  1. KANAL KORUMASI (Oluşturma & Silme)
# ─────────────────────────────────────────────
@bot.event
async def on_guild_channel_delete(channel: discord.abc.GuildChannel):
    cfg = load_config()
    if not cfg.get("korumalar", {}).get("kanal_koruma", True):
        return

    guild = channel.guild
    async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete):
        yapan = entry.user
        if not yapan or guvenli_mi(yapan):
            return

        # 1. Silinen kanalı DERHAL AYNI İZİNLERLE GERİ OLUŞTUR (Sildirtme!)
        try:
            if isinstance(channel, discord.TextChannel):
                await guild.create_text_channel(
                    name=channel.name,
                    category=channel.category,
                    topic=channel.topic,
                    slowmode_delay=channel.slowmode_delay,
                    nsfw=channel.nsfw,
                    overwrites=channel.overwrites,
                    reason="Raven Guard: Silinen kanal geri yüklendi."
                )
            elif isinstance(channel, discord.VoiceChannel):
                await guild.create_voice_channel(
                    name=channel.name,
                    category=channel.category,
                    bitrate=channel.bitrate,
                    user_limit=channel.user_limit,
                    overwrites=channel.overwrites,
                    reason="Raven Guard: Silinen ses kanalı geri yüklendi."
                )
        except Exception as e:
            print(f"Kanal geri yükleme hatası: {e}")

        # 2. Yetkili için 2 uyarı sistemini işlet (1 ve 2'de DM uyarı, 3'te yetki alma)
        await ihlal_yonetimi(yapan, "Kanal Silme", f"İzinsiz kanal silme: `#{channel.name}`")
        break


@bot.event
async def on_guild_channel_create(channel: discord.abc.GuildChannel):
    cfg = load_config()
    if not cfg.get("korumalar", {}).get("kanal_koruma", True):
        return

    guild = channel.guild
    async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_create):
        yapan = entry.user
        if not yapan or guvenli_mi(yapan):
            return

        # 1. İzinsiz açılan kanalı DERHAL SİL (Açtırma!)
        try:
            await channel.delete(reason="Raven Guard: İzinsiz açılan kanal silindi.")
        except Exception as e:
            print(f"Kanal silme hatası: {e}")

        # 2. Yetkili için 2 uyarı sistemini işlet (1 ve 2'de DM uyarı, 3'te yetki alma)
        await ihlal_yonetimi(yapan, "Kanal Açma", f"İzinsiz kanal açma: `#{channel.name}`")
        break


# ─────────────────────────────────────────────
#  2. ROL KORUMASI (Oluşturma, Silme, Düzenleme)
# ─────────────────────────────────────────────
@bot.event
async def on_guild_role_delete(role: discord.Role):
    cfg = load_config()
    if not cfg.get("korumalar", {}).get("rol_koruma", True):
        return

    guild = role.guild
    async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.role_delete):
        yapan = entry.user
        if not yapan or guvenli_mi(yapan):
            return

        maks = cfg.get("limitler", {}).get("dakika_basina_maks_rol_silme", 2)
        if limit_asti_mi(yapan.id, "rol", maks):
            await cezalandir(yapan, f"Çok hızlı rol silme eylemi ({maks}+ rol)")

        # Rolü aynı isim ve renkle geri oluştur
        try:
            yeni_rol = await guild.create_role(
                name=role.name,
                permissions=role.permissions,
                color=role.color,
                hoist=role.hoist,
                mentionable=role.mentionable,
                reason="Raven Guard: Silinen rol geri oluşturuldu."
            )
            await cezalandir(yapan, f"İzinsiz rol silme: @{role.name}")
            await guard_log_gonder(
                guild=guild,
                baslik="İzinsiz Rol Silme Engellendi",
                aciklama=(
                    f"**Silen Yetkili:** {yapan.mention} (`{yapan.name}` - `{yapan.id}`)\n"
                    f"**Silinen Rol:** `@{role.name}`\n"
                    f"**Sonuç:** Rol tekrar oluşturuldu ve yetkilinin rolleri alındı."
                ),
                renk=discord.Color.red()
            )
        except Exception as e:
            print(f"Rol geri yükleme hatası: {e}")
        break


@bot.event
async def on_guild_role_update(before: discord.Role, after: discord.Role):
    cfg = load_config()
    if not cfg.get("korumalar", {}).get("rol_koruma", True):
        return

    guild = after.guild
    # Eğer role sonradan Administrator veya tehlikeli yetki verildiyse geri al
    tehlikeli = ["administrator", "manage_guild", "manage_roles", "ban_members"]
    yetki_acildi = any(
        getattr(after.permissions, p) and not getattr(before.permissions, p)
        for p in tehlikeli
    )

    if yetki_acildi:
        async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.role_update):
            yapan = entry.user
            if not yapan or guvenli_mi(yapan):
                return

            try:
                # Yetkiyi eski haline çek
                await after.edit(permissions=before.permissions, reason="Raven Guard: İzinsiz yetki açma engellendi.")
                await cezalandir(yapan, f"Role izinsiz yönetici/yetki ekleme: @{after.name}")
            except Exception as e:
                print(f"Rol yetkisi geri alma hatası: {e}")
            break


# ─────────────────────────────────────────────
#  2.1. SAĞ-TIK ROL / YETKİ VERME & ALMA LOGU VE KORUMASI
# ─────────────────────────────────────────────
@bot.event
async def on_member_update(before: discord.Member, after: discord.Member):
    guild = after.guild
    cfg = load_config()

    # 1. Rol Değişiklikleri Kontrolü (Sağ tık rol verme / alma)
    if before.roles != after.roles:
        added_roles = [r for r in after.roles if r not in before.roles]
        removed_roles = [r for r in before.roles if r not in after.roles]

        if added_roles or removed_roles:
            # Audit log'un Discord tarafından yazılması için kısa bir bekleme
            await asyncio.sleep(0.6)
            yapan = None
            try:
                async for entry in guild.audit_logs(limit=6, action=discord.AuditLogAction.member_role_update):
                    if entry.target and entry.target.id == after.id:
                        now_utc = datetime.now(timezone.utc)
                        diff = abs((now_utc - entry.created_at).total_seconds())
                        if diff < 12:
                            yapan = entry.user
                            break
            except Exception as e:
                print(f"Audit log çekme hatası (member_role_update): {e}")

            # Botun kendi ceza/rol işlemlerini tekrar loglamasını engelle
            if yapan and yapan.id == bot.user.id:
                return

            tehlikeli_yetkiler = [
                "administrator", "manage_guild", "manage_roles",
                "manage_channels", "ban_members", "kick_members", "manage_webhooks"
            ]
            tehlikeli_verilenler = [
                r for r in added_roles
                if any(getattr(r.permissions, p, False) for p in tehlikeli_yetkiler)
            ]

            # KORUMA: Eğer güvenli listede olmayan biri tehlikeli yetki verirse engelle
            if tehlikeli_verilenler and cfg.get("korumalar", {}).get("sag_tik_yetki_koruma", True):
                if yapan and not guvenli_mi(yapan):
                    try:
                        await after.remove_roles(*tehlikeli_verilenler, reason="Raven Guard: İzinsiz sağ-tık yetki verme engellendi.")
                    except Exception as e:
                        print(f"Tehlikeli rol geri alma hatası: {e}")

                    await cezalandir(yapan, f"İzinsiz sağ-tık yetki verme: {after.name} ({', '.join(r.name for r in tehlikeli_verilenler)})")

                    await guard_log_gonder(
                        guild=guild,
                        baslik="İzinsiz Yetki Verme Engellendi!",
                        aciklama=(
                            f"**İşlemi Yapan Yetkili:** {yapan.mention} (`{yapan.name}` - `{yapan.id}`)\n"
                            f"**Hedef Kullanıcı:** {after.mention} (`{after.name}` - `{after.id}`)\n"
                            f"**Verilmeye Çalışılan Yetkili Rol(ler):** {', '.join(r.mention for r in tehlikeli_verilenler)}\n"
                            f"**Uygulanan İşlem:** Yetki kullanıcıdan derhal geri alındı ve izinsiz işlem yapan yetkilinin tüm rolleri alındı."
                        ),
                        renk=discord.Color.red()
                    )
                    return

            # LOGLAMA: Normal veya yetkili tarafından yapılan işlemler
            if cfg.get("korumalar", {}).get("sag_tik_rol_log", True):
                yapan_metin = f"{yapan.mention} (`{yapan.name}` - `{yapan.id}`)" if yapan else "*Bilinmiyor (Audit Log bulunamadı)*"
                hedef_metin = f"{after.mention} (`{after.name}` - `{after.id}`)"

                if added_roles and not removed_roles:
                    baslik = "Sağ Tık Rol / Yetki Verildi"
                    renk = discord.Color.green()
                    roller_metin = "\n".join([f"**+** {r.mention} (`{r.name}`)" for r in added_roles])
                    aciklama = (
                        f"**İşlemi Yapan Yetkili:** {yapan_metin}\n"
                        f"**Rol Verilen Kullanıcı:** {hedef_metin}\n\n"
                        f"**Verilen Rol(ler):**\n{roller_metin}"
                    )
                    if tehlikeli_verilenler:
                        aciklama += "\n\n⚠️ **Not:** Verilen roller arasında kritik yönetim/yetki izinleri bulunmaktadır (Yetkili onaylı)."

                elif removed_roles and not added_roles:
                    baslik = "Sağ Tık Rol / Yetki Alındı"
                    renk = discord.Color.orange()
                    roller_metin = "\n".join([f"**-** {r.mention} (`{r.name}`)" for r in removed_roles])
                    aciklama = (
                        f"**İşlemi Yapan Yetkili:** {yapan_metin}\n"
                        f"**Rolü Alınan Kullanıcı:** {hedef_metin}\n\n"
                        f"**Alınan Rol(ler):**\n{roller_metin}"
                    )

                else:
                    baslik = "Sağ Tık Rol / Yetki Güncellendi"
                    renk = discord.Color.from_rgb(155, 89, 182)  # Raven moru
                    eklenen_metin = "\n".join([f"**+** {r.mention} (`{r.name}`)" for r in added_roles])
                    cikarilan_metin = "\n".join([f"**-** {r.mention} (`{r.name}`)" for r in removed_roles])
                    aciklama = (
                        f"**İşlemi Yapan Yetkili:** {yapan_metin}\n"
                        f"**Kullanıcı:** {hedef_metin}\n\n"
                        f"**Verilen Rol(ler):**\n{eklenen_metin}\n\n"
                        f"**Alınan Rol(ler):**\n{cikarilan_metin}"
                    )
                    if tehlikeli_verilenler:
                        aciklama += "\n\n⚠️ **Not:** Verilen roller arasında kritik yönetim/yetki izinleri bulunmaktadır (Yetkili onaylı)."

                await rol_log_gonder(guild=guild, baslik=baslik, aciklama=aciklama, renk=renk, user=after)

    # 2. Zamanaşımı (Timeout) Kontrolü (Sağ tık susturma)
    if before.timed_out_until != after.timed_out_until:
        await asyncio.sleep(0.5)
        yapan_to = None
        sebep_to = "Belirtilmedi"
        try:
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.member_update):
                if entry.target and entry.target.id == after.id:
                    now_utc = datetime.now(timezone.utc)
                    diff = abs((now_utc - entry.created_at).total_seconds())
                    if diff < 12:
                        yapan_to = entry.user
                        if entry.reason:
                            sebep_to = entry.reason
                        break
        except Exception:
            pass

        if yapan_to and yapan_to.id == bot.user.id:
            return

        yapan_to_str = f"{yapan_to.mention} (`{yapan_to.name}` - `{yapan_to.id}`)" if yapan_to else "*Bilinmiyor*"
        hedef_to_str = f"{after.mention} (`{after.name}` - `{after.id}`)"

        if after.is_timed_out():
            bitis = discord.utils.format_dt(after.timed_out_until, style="f") if after.timed_out_until else "Belirtilmedi"
            kalan = discord.utils.format_dt(after.timed_out_until, style="R") if after.timed_out_until else ""
            aciklama = (
                f"**İşlemi Yapan Yetkili:** {yapan_to_str}\n"
                f"**Susturulan Kullanıcı:** {hedef_to_str}\n"
                f"**Bitiş Tarihi:** {bitis} ({kalan})\n"
                f"**Sebep:** {sebep_to}"
            )
            await rol_log_gonder(guild=guild, baslik="Sağ Tık Zamanaşımı (Susturuldu)", aciklama=aciklama, renk=discord.Color.red(), user=after)
        elif before.is_timed_out() and not after.is_timed_out():
            aciklama = (
                f"**İşlemi Yapan Yetkili:** {yapan_to_str}\n"
                f"**Kullanıcı:** {hedef_to_str}\n"
                f"**Durum:** Kullanıcının zamanaşımı (susturulması) erken kaldırıldı."
            )
            await rol_log_gonder(guild=guild, baslik="Sağ Tık Zamanaşımı Kaldırıldı", aciklama=aciklama, renk=discord.Color.green(), user=after)


# ─────────────────────────────────────────────
#  3. BOT KORUMASI (İzinsiz Bot Sokma)
# ─────────────────────────────────────────────
@bot.event
async def on_member_join(member: discord.Member):
    if not member.bot:
        return

    cfg = load_config()
    if not cfg.get("korumalar", {}).get("bot_koruma", True):
        return

    guild = member.guild
    async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.bot_add):
        ekleyen = entry.user
        if not ekleyen or guvenli_mi(ekleyen):
            return

        # Eklenen botu anında banla
        try:
            await member.ban(reason="Raven Guard: İzinsiz eklenen bot sunucudan yasaklandı.")
            await cezalandir(ekleyen, f"İzinsiz bot ekleme: {member.name}")
            await guard_log_gonder(
                guild=guild,
                baslik="İzinsiz Bot Ekleme Engellendi",
                aciklama=(
                    f"**Botu Ekleyen:** {ekleyen.mention} (`{ekleyen.name}` - `{ekleyen.id}`)\n"
                    f"**Eklenen Bot:** {member.mention} (`{member.name}`)\n"
                    f"**Sonuç:** Bot anında banlandı ve ekleyen kişinin yetkileri alındı."
                ),
                renk=discord.Color.red()
            )
        except Exception as e:
            print(f"Bot banlama hatası: {e}")
        break


# ─────────────────────────────────────────────
#  4. SAĞ-TIK BAN & KICK KORUMASI (Mass Action)
# ─────────────────────────────────────────────
@bot.event
async def on_member_ban(guild: discord.Guild, user: discord.User):
    cfg = load_config()
    if not cfg.get("korumalar", {}).get("mass_ban_koruma", True):
        return

    async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.ban):
        yapan = entry.user
        if not yapan or guvenli_mi(yapan):
            return

        maks = cfg.get("limitler", {}).get("dakika_basina_maks_ban", 3)
        if limit_asti_mi(yapan.id, "ban", maks):
            await cezalandir(yapan, f"Hızlı ban atma limiti aşıldı ({maks}+ ban/dk)")
        break


@bot.event
async def on_member_remove(member: discord.Member):
    cfg = load_config()
    if not cfg.get("korumalar", {}).get("mass_kick_koruma", True):
        return

    guild = member.guild
    async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.kick):
        yapan = entry.user
        if not yapan or guvenli_mi(yapan):
            return

        maks = cfg.get("limitler", {}).get("dakika_basina_maks_kick", 3)
        if limit_asti_mi(yapan.id, "kick", maks):
            await cezalandir(yapan, f"Hızlı kick atma limiti aşıldı ({maks}+ kick/dk)")
        break


# ─────────────────────────────────────────────
#  5. WEBHOOK KORUMASI
# ─────────────────────────────────────────────
@bot.event
async def on_webhooks_update(channel: discord.abc.GuildChannel):
    cfg = load_config()
    if not cfg.get("korumalar", {}).get("webhook_koruma", True):
        return

    guild = channel.guild
    async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.webhook_create):
        yapan = entry.user
        if not yapan or guvenli_mi(yapan):
            return

        # Webhook'ları sil
        try:
            webhooks = await channel.webhooks()
            for wh in webhooks:
                await wh.delete(reason="Raven Guard: İzinsiz webhook silindi.")
            await cezalandir(yapan, f"İzinsiz webhook oluşturma (#{channel.name})")
        except Exception as e:
            print(f"Webhook silme hatası: {e}")
        break


# ─────────────────────────────────────────────
#  6. CHAT REKLAM & SPAM ENGELİ
# ─────────────────────────────────────────────
INVITE_REGEX = re.compile(r"(discord\.gg/|discord\.com/invite/|discordapp\.com/invite/)[a-zA-Z0-9]+")

@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or not message.guild:
        return

    cfg = load_config()

    # Güvenli mi kontrolü
    if guvenli_mi(message.author):
        await bot.process_commands(message)
        return

    # 1. Reklam Koruması
    if cfg.get("korumalar", {}).get("reklam_koruma", True):
        if INVITE_REGEX.search(message.content):
            try:
                await message.delete()
                await message.channel.send(
                    f"{message.author.mention}, bu sunucuda Discord davet linki paylaşmak yasaktır!",
                    delete_after=5
                )
                await guard_log_gonder(
                    guild=message.guild,
                    baslik="Reklam Engellendi",
                    aciklama=(
                        f"**Kullanıcı:** {message.author.mention} (`{message.author.id}`)\n"
                        f"**Kanal:** {message.channel.mention}\n"
                        f"**Mesaj İçeriği:** ||{message.content}||"
                    ),
                    renk=discord.Color.gold()
                )
                return
            except Exception:
                pass

    # 2. Spam Koruması (3 saniyede 5+ mesaj)
    if cfg.get("korumalar", {}).get("spam_koruma", True):
        now = datetime.now()
        mesajlar = mesaj_gecmisi[message.author.id]
        mesajlar = [t for t in mesajlar if (now - t).total_seconds() < 3]
        mesajlar.append(now)
        mesaj_gecmisi[message.author.id] = mesajlar

        if len(mesajlar) >= 5:
            try:
                # 5 dakika timeout at
                await message.author.timeout(timedelta(minutes=5), reason="Raven Guard: Hızlı mesaj spamı.")
                await message.channel.send(
                    f"{message.author.mention}, çok hızlı mesaj yazdığınız için 5 dakika susturuldunuz.",
                    delete_after=6
                )
                mesaj_gecmisi[message.author.id] = []
            except Exception:
                pass

    await bot.process_commands(message)


# ─────────────────────────────────────────────
#  SLASH MODERASYON & GUARD KOMUTLARI
# ─────────────────────────────────────────────
@tree.command(name="guard-durum", description="Raven Guard aktif koruma modüllerini gösterir.")
@app_commands.default_permissions(administrator=True)
async def guard_durum_cmd(interaction: discord.Interaction):
    cfg = load_config()
    korumalar = cfg.get("korumalar", {})
    limitler = cfg.get("limitler", {})
    guvenliler = cfg.get("guvenli_kullanicilar", [])

    embed = discord.Embed(
        title="Raven Guard  |  Sistem Güvenlik Durumu",
        description=(
            "Raven sunucusu için aktif olan koruma kalkanları ve güvenlik limitleri aşağıda listelenmiştir.\n\n"
            f"**Koruma Modülleri**\n"
            f"— Kanal Koruması: {'✅ Açık' if korumalar.get('kanal_koruma') else '❌ Kapalı'}\n"
            f"— Rol Koruması: {'✅ Açık' if korumalar.get('rol_koruma') else '❌ Kapalı'}\n"
            f"— Sağ-Tık Rol / Yetki Logu: {'✅ Açık' if korumalar.get('sag_tik_rol_log', True) else '❌ Kapalı'}\n"
            f"— Sağ-Tık Yetki Koruması: {'✅ Açık' if korumalar.get('sag_tik_yetki_koruma', True) else '❌ Kapalı'}\n"
            f"— Bot Koruması: {'✅ Açık' if korumalar.get('bot_koruma') else '❌ Kapalı'}\n"
            f"— Webhook Koruması: {'✅ Açık' if korumalar.get('webhook_koruma') else '❌ Kapalı'}\n"
            f"— Mass Ban/Kick Koruması: {'✅ Açık' if korumalar.get('mass_ban_koruma') else '❌ Kapalı'}\n"
            f"— Reklam Engeli: {'✅ Açık' if korumalar.get('reklam_koruma') else '❌ Kapalı'}\n"
            f"— Spam Koruması: {'✅ Açık' if korumalar.get('spam_koruma') else '❌ Kapalı'}\n\n"
            f"**Güvenlik Limitleri (Dakika Başına)**\n"
            f"— Maksimum Ban: `{limitler.get('dakika_basina_maks_ban', 3)}`\n"
            f"— Maksimum Kick: `{limitler.get('dakika_basina_maks_kick', 3)}`\n"
            f"— Maksimum Kanal Silme: `{limitler.get('dakika_basina_maks_kanal_silme', 2)}`\n"
            f"— Maksimum Rol Silme: `{limitler.get('dakika_basina_maks_rol_silme', 2)}`\n\n"
            f"**Güvenli Liste (Whitelist):** {len(guvenliler)} kullanıcı kayıtlı."
        ),
        color=discord.Color.from_str(cfg.get("embed_renk", "#9B59B6")),
        timestamp=datetime.now()
    )
    embed.set_footer(text=f"Built by 6Closy  |  {interaction.guild.name}")
    await interaction.response.send_message(embed=embed, ephemeral=True)


@tree.command(name="guvenli-ekle", description="Bir kullanıcıyı guard güvenli listesine (whitelist) ekler.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kullanici="Güvenli listeye eklenecek kullanıcı")
async def guvenli_ekle_cmd(interaction: discord.Interaction, kullanici: discord.Member):
    cfg = load_config()
    guvenliler = cfg.get("guvenli_kullanicilar", [])
    if kullanici.id in guvenliler:
        await interaction.response.send_message(f"{kullanici.mention} zaten güvenli listede bulunuyor.", ephemeral=True)
        return

    guvenliler.append(kullanici.id)
    cfg["guvenli_kullanicilar"] = guvenliler
    save_config(cfg)
    await interaction.response.send_message(f"✅ {kullanici.mention} güvenli listeye başarıyla eklendi.", ephemeral=True)


@tree.command(name="guvenli-cikar", description="Bir kullanıcıyı guard güvenli listesinden (whitelist) çıkarır.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kullanici="Güvenli listeden çıkarılacak kullanıcı")
async def guvenli_cikar_cmd(interaction: discord.Interaction, kullanici: discord.Member):
    cfg = load_config()
    guvenliler = cfg.get("guvenli_kullanicilar", [])
    if kullanici.id not in guvenliler:
        await interaction.response.send_message(f"{kullanici.mention} güvenli listede değil.", ephemeral=True)
        return

    guvenliler.remove(kullanici.id)
    cfg["guvenli_kullanicilar"] = guvenliler
    save_config(cfg)
    await interaction.response.send_message(f"❌ {kullanici.mention} güvenli listeden çıkarıldı.", ephemeral=True)


@tree.command(name="uyari-sifirla", description="Bir yetkilinin guard uyarılarını sıfırlar.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kullanici="Uyarıları sıfırlanacak yetkili")
async def uyari_sifirla_cmd(interaction: discord.Interaction, kullanici: discord.Member):
    sifirla_uyari(kullanici.id)
    await interaction.response.send_message(f"✅ {kullanici.mention} kullanıcısının guard uyarıları sıfırlandı.", ephemeral=True)


@tree.command(name="uyarilar", description="Bir yetkilinin mevcut guard uyarı sayısını gösterir.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kullanici="Uyarı sayısı görüntülenecek yetkili")
async def uyarilar_cmd(interaction: discord.Interaction, kullanici: discord.Member):
    u = get_uyari(kullanici.id)
    await interaction.response.send_message(f"ℹ️ {kullanici.mention} yetkilisinin guard uyarı durumu: **{u} / 2**", ephemeral=True)


@tree.command(name="sil", description="Belirtilen miktarda mesajı kanaldan temizler.")
@app_commands.default_permissions(manage_messages=True)
@app_commands.describe(adet="Silinecek mesaj sayısı (1-100 arası)")
async def sil_cmd(interaction: discord.Interaction, adet: int):
    if adet < 1 or adet > 100:
        await interaction.response.send_message("Lütfen 1 ile 100 arasında bir sayı girin.", ephemeral=True)
        return

    await interaction.response.defer(ephemeral=True)
    silinen = await interaction.channel.purge(limit=adet)
    await interaction.followup.send(f"🧹 Başarıyla **{len(silinen)}** adet mesaj temizlendi.", ephemeral=True)


@tree.command(name="sustur", description="Bir kullanıcıyı belirtilen süre kadar susturur (Timeout).")
@app_commands.default_permissions(moderate_members=True)
@app_commands.describe(kullanici="Susturulacak kullanıcı", dakika="Susturma süresi (dakika)", sebep="Susturma sebebi")
async def sustur_cmd(interaction: discord.Interaction, kullanici: discord.Member, dakika: int, sebep: str = "Belirtilmedi"):
    if kullanici.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("Senden üst veya eşit roldeki birini susturamazsın.", ephemeral=True)
        return

    await kullanici.timeout(timedelta(minutes=dakika), reason=f"{interaction.user.name}: {sebep}")
    await interaction.response.send_message(f"🔇 {kullanici.mention} kullanıcısı **{dakika} dakika** susturuldu. Sebep: `{sebep}`")


@tree.command(name="sustur-kaldir", description="Bir kullanıcının susturmasını kaldırır.")
@app_commands.default_permissions(moderate_members=True)
@app_commands.describe(kullanici="Susturması kaldırılacak kullanıcı")
async def sustur_kaldir_cmd(interaction: discord.Interaction, kullanici: discord.Member):
    await kullanici.timeout(None, reason=f"{interaction.user.name} tarafından kaldırıldı.")
    await interaction.response.send_message(f"🔊 {kullanici.mention} kullanıcısının susturması kaldırıldı.")


@tree.command(name="yasakla", description="Bir kullanıcıyı sunucudan yasaklar (Ban).")
@app_commands.default_permissions(ban_members=True)
@app_commands.describe(kullanici="Yasaklanacak kullanıcı", sebep="Yasaklama gerekçesi")
async def yasakla_cmd(interaction: discord.Interaction, kullanici: discord.Member, sebep: str = "Belirtilmedi"):
    if kullanici.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("Senden üst veya eşit roldeki birini banlayamazsın.", ephemeral=True)
        return

    await kullanici.ban(reason=f"{interaction.user.name}: {sebep}")
    await interaction.response.send_message(f"🔨 {kullanici.mention} sunucudan yasaklandı. Sebep: `{sebep}`")


@tree.command(name="at", description="Bir kullanıcıyı sunucudan atar (Kick).")
@app_commands.default_permissions(kick_members=True)
@app_commands.describe(kullanici="Atılacak kullanıcı", sebep="Atılma gerekçesi")
async def at_cmd(interaction: discord.Interaction, kullanici: discord.Member, sebep: str = "Belirtilmedi"):
    if kullanici.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("Senden üst veya eşit roldeki birini atamazsın.", ephemeral=True)
        return

    await kullanici.kick(reason=f"{interaction.user.name}: {sebep}")
    await interaction.response.send_message(f"👢 {kullanici.mention} sunucudan atıldı. Sebep: `{sebep}`")


# ─────────────────────────────────────────────
#  BOT OLAYLARI
# ─────────────────────────────────────────────
@bot.event
async def on_ready():
    print(f"✅ Raven Guard: {bot.user} olarak giriş yapıldı!")
    print(f"   Sunucu sayısı: {len(bot.guilds)}")

    # Slash komutları senkronize et
    try:
        synced = await tree.sync()
        print(f"   {len(synced)} slash komut senkronize edildi.")
    except Exception as e:
        print(f"   Slash sync hatası: {e}")

    # Mor Yayın İzliyor / Streaming Durumu
    await bot.change_presence(
        status=discord.Status.online,
        activity=discord.Streaming(
            name="Built by 6Closy",
            url="https://www.twitch.tv/discord"
        )
    )

    # Ses kanalına sessizce gir ve bekle (0)
    ses_kanal_id = config.get("ses_kanal_id", 0)
    for guild in bot.guilds:
        ses_kanali = guild.get_channel(ses_kanal_id)
        if ses_kanali and isinstance(ses_kanali, discord.VoiceChannel):
            try:
                if guild.voice_client:
                    await guild.voice_client.disconnect(force=True)
                await ses_kanali.connect(self_deaf=True, self_mute=True)
                print(f"   Ses kanalına girildi: {ses_kanali.name} ({guild.name})")
            except Exception as e:
                print(f"   Ses kanalına bağlanılamadı: {e}")


# ─────────────────────────────────────────────
#  BAŞLAT
# ─────────────────────────────────────────────
if __name__ == "__main__":
    TOKEN = config.get("token")
    if not TOKEN or TOKEN == "BOT_TOKEN_BURAYA":
        print("❌ HATA: config.json dosyasına bot tokenını girmeyi unutma!")
        exit(1)
    # ----------------------------------------------------
    # 🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ (Açılış Kilidi)
    # ----------------------------------------------------
    from closy_license_client import verify_license_sync, setup_license_guard
    _lic_key = config.get("lisans_anahtari", "").strip()
    _lic_api = config.get("lisans_api_url", "http://localhost:5050").strip()

    print("\n" + "=" * 60)
    print("  🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ")
    print(f"  🔑 Lisans Anahtarı : {_lic_key or 'GİRİLMEDİ'}")
    print(f"  🌐 Lisans Sunucusu : {_lic_api}")
    print("=" * 60)

    _lic_res = verify_license_sync(_lic_key, api_url=_lic_api)
    if not _lic_res.get("valid"):
        print("\n" + "!" * 65)
        print("  [LİSANS HATASI] ⛔ BOT BAŞLATILAMADI!")
        print(f"  Sebep: {_lic_res.get('reason', 'Geçersiz Lisans')}")
        print("  Lütfen config.json dosyasındaki 'lisans_anahtari' alanına")
        print("  satın aldığınız geçerli lisansı giriniz.")
        print("  Lisans Satın Almak veya Yenilemek İçin: https://discord.gg/imzapriw")
        print("!" * 65 + "\n")
        try:
            input("Kapatmak için Enter tuşuna basınız...")
        except Exception:
            pass
        sys.exit(1)

    print(f"  [LİSANS ONAYLANDI] 🟢 {_lic_res.get('message', 'Lisans aktif.')}")
    print(f"  [BİLGİ] Lisans Sahibi: {_lic_res.get('owner_discord', 'Müşteri')} | Kalan: {_lic_res.get('days_left')} Gün")
    print("=" * 60 + "\n")
    setup_license_guard(bot, license_key=_lic_key, api_url=_lic_api)

    bot.run(TOKEN)
