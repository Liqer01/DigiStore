"""
============================================================
  👑 CLOSY LICENSE CLIENT MODULE (Anti-Piracy & Protection)
  Geliştirici: 6Closy (discord.gg/imzapriw)
============================================================
"""
import sys
import json
import urllib.request
import asyncio
import datetime
import aiohttp
from typing import Optional, Dict, Any

def verify_license_sync(license_key: str, guild_id: str = "", api_url: str = "http://localhost:5050") -> Dict[str, Any]:
    """Senkron pre-flight lisans kontrolü (Bot açılmadan önce ilk çalışan kilit)."""
    if not license_key or "BURAYA" in license_key.upper() or len(license_key.strip()) < 5:
        return {
            "valid": False,
            "reason": "Lisans anahtarı config.json dosyasına girilmemiş! Lütfen geçerli lisansınızı girin."
        }

    clean_url = api_url.rstrip("/") + "/api/license/verify"
    payload = json.dumps({
        "license_key": license_key.strip().upper(),
        "guild_id": str(guild_id).strip() if guild_id else ""
    }).encode("utf-8")

    req = urllib.request.Request(clean_url, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as he:
        try:
            return json.loads(he.read().decode("utf-8"))
        except Exception:
            return {"valid": False, "reason": f"Lisans sunucusu yanıt vermedi (HTTP {he.code})"}
    except Exception as e:
        return {"valid": False, "reason": "Lisans doğrulama sunucusuna bağlanılamadı! Lütfen lisans sunucu adresini kontrol edin."}


async def verify_license(
    license_key: str,
    guild_id: Optional[str] = None,
    api_url: str = "http://localhost:5050"
) -> Dict[str, Any]:
    """Asenkron lisans kontrolü (Bot çalışırken periyodik denetim)."""
    if not license_key or "BURAYA" in license_key.upper() or len(license_key.strip()) < 5:
        return {
            "valid": False,
            "reason": "Lisans anahtarı config.json dosyasına girilmemiş! Lütfen lisans anahtarınızı girin."
        }

    clean_url = api_url.rstrip("/") + "/api/license/verify"
    payload = {
        "license_key": license_key.strip().upper(),
        "guild_id": str(guild_id).strip() if guild_id else ""
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(clean_url, json=payload, timeout=aiohttp.ClientTimeout(total=6)) as resp:
                if resp.status == 200:
                    return await resp.json()
                else:
                    return {
                        "valid": False,
                        "reason": f"Lisans sunucusu yanıt vermedi (HTTP {resp.status})"
                    }
    except Exception as e:
        return {
            "valid": False,
            "reason": f"Doğrulama hatası: {e}"
        }

def setup_license_guard(
    bot,
    license_key: str,
    target_guild_id: Optional[str] = None,
    api_url: str = "http://localhost:5050",
    check_interval_minutes: int = 60
):
    async def guard_task():
        await bot.wait_until_ready()
        nonlocal target_guild_id
        if not target_guild_id and bot.guilds:
            target_guild_id = str(bot.guilds[0].id)

        while not bot.is_closed():
            await asyncio.sleep(check_interval_minutes * 60)
            res = await verify_license(license_key, target_guild_id, api_url)
            if not res.get("valid"):
                reason = res.get("reason", "Lisans süreniz doldu veya iptal edildi!")
                print("\n" + "!" * 65)
                print("  [LİSANS HATASI] ⛔ LİSANS SÜRENİZ BİTTİ, BOT DURDURULUYOR!")
                print(f"  Sebep: {reason}")
                print("  Lisans Satın Almak veya Yenilemek İçin: https://discord.gg/imzapriw")
                print("!" * 65 + "\n")
                await bot.close()
                sys.exit(1)

    @bot.listen("on_ready")
    async def _on_ready_license_guard():
        asyncio.create_task(guard_task())
