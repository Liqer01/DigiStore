﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
title IMZA - Yeni Nesil Ticket Destek Botu v14
echo ======================================================
echo       IMZA YENI NESIL TICKET BOTU BASLATILIYOR
echo ======================================================
echo.
echo [1/2] Gerekli Python paketleri kontrol ediliyor...
python -m pip install -r requirements.txt
echo.
echo [2/2] Bot baslatiliyor...
python main.py

if %errorlevel% neq 0 (
    echo.
    echo ======================================================
    echo [HATA] Bot calisirken bir hata olustu veya kapandi!
    echo ======================================================
    pause
)
pause