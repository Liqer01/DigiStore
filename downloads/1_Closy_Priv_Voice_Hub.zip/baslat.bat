@echo off
chcp 65001 >nul
title Closy Priv Voice Hub
color 0b
echo ======================================================
echo          Closy Priv Voice Hub
echo ======================================================
echo.
echo [1/2] Gerekli Python kutuphaneleri kontrol ediliyor...
python -m pip install -r requirements.txt
echo.
echo [2/2] Bot baslatiliyor...
echo.
python main.py
if %errorlevel% neq 0 (
    echo.
    echo ======================================================
    echo [HATA] Bot durdu veya baslatilamadi!
    echo - config.json dosyasina bot tokeninizi ve lisans anahtarinizi girdiginizden emin olun.
    echo - Discord Developer Portal'da 'Privileged Gateway Intents'
    echo   (Presence, Server Members, Message Content) acik olmali!
    echo ======================================================
)
pause
