# -*- coding: utf-8 -*-
"""
╭────────────────────────────────────────────────────────╮
│                       ɨ̇ ʍ ʐ ǟ                          │
│     Priv Discord List & Ses Botu (Slash Commands)      │
╰────────────────────────────────────────────────────────╯
"""

import os
import sys
import json
import asyncio
import io
from datetime import datetime, timezone
import subprocess
import re
import time
import urllib.request
import shutil
import aiohttp
from aiohttp import web
import secrets
import random
import discord
from discord.ext import commands, tasks
from discord import app_commands
from PIL import Image, ImageDraw, ImageFont, ImageFilter

def get_card_font(bold: bool = False, size: int = 16):
    paths = [
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
    ]
    for p in paths:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

# ─────────────────────────────────────────────
# CONFIG YÜKLEME & KAYDETME
# ─────────────────────────────────────────────
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")

def load_config() -> dict:
    if not os.path.exists(CONFIG_FILE):
        default_cfg = {
            "bot_token": "BOT_TOKENINIZI_BURAYA_YAZIN",
            "bot_adi": "ɨ̇ ʍ ʐ ǟ",
            "embed_renk": "0x111216",
            "panel_kanal_id": None,
            "panel_mesaj_id": None,
            "oto_guncelleme_saniye": 15
        }
        save_config(default_cfg)
        return default_cfg
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_config(cfg: dict):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

config = load_config()

def get_embed_color() -> discord.Color:
    raw_color = config.get("embed_renk", "0x111216")
    try:
        if isinstance(raw_color, str):
            if raw_color.startswith("#"):
                return discord.Color(int(raw_color[1:], 16))
            return discord.Color(int(raw_color, 16))
        return discord.Color(int(raw_color))
    except Exception:
        return discord.Color.dark_embed()

# ─────────────────────────────────────────────
# INTENTS & BOT TANIMI (Tamamen Slash Odaklı)
# ─────────────────────────────────────────────
intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.voice_states = True
intents.message_content = True
intents.presences = True

bot = commands.Bot(
    command_prefix=[],
    intents=intents,
    help_command=None
)

# ─────────────────────────────────────────────
# YARDIMCI GÖRSEL & FORMATLAYICI FONKSİYONLAR
# ─────────────────────────────────────────────
def get_brand_logo_url(guild: discord.Guild = None) -> str:
    """Embedlerde ve web panelinde gösterilecek logoyu döndürür (öncelik: sunucu logosu > config.logo_url > bot profil resmi > yerel imza logosu)."""
    target_guild = guild or (bot.guilds[0] if bot.guilds else None)
    if target_guild and target_guild.icon:
        return target_guild.icon.url
    custom_logo = config.get("logo_url")
    if custom_logo and str(custom_logo).strip():
        return str(custom_logo).strip()
    if bot.user and bot.user.display_avatar:
        return bot.user.display_avatar.url
    return "/static/logo.png"

def format_voice_member(member: discord.Member) -> str:
    """Üyenin ses durumuna göre özel priv ikonlarıyla formatlar."""
    badges = []
    vs = member.voice

    if vs:
        if vs.self_mute or vs.mute:
            badges.append("🔇")
        else:
            badges.append("🎙️")

        if vs.self_deaf or vs.deaf:
            badges.append("🎧")

        if vs.self_video:
            badges.append("📹")

        if vs.self_stream:
            badges.append("🔴")

    badge_str = "".join(badges) if badges else "🎙️"
    display_name = member.display_name.replace("`", "")
    return f"{badge_str} `{display_name}`"

def build_voice_embed(guild: discord.Guild) -> discord.Embed:
    """Sunucudaki ses kanallarını ve üyeleri detaylı analiz eden embed üretir."""
    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ┊ Ses Analizi",
        description="**Sunucudaki aktif ses odaları ve anlık döküm:**\n",
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )

    total_voice_count = 0
    channel_data = []

    for channel in guild.voice_channels:
        members = channel.members
        count = len(members)
        if count > 0:
            total_voice_count += count
            user_list = [format_voice_member(m) for m in members]
            limit_str = f"/{channel.user_limit}" if channel.user_limit else ""
            channel_data.append((channel.name, count, limit_str, user_list))

    # Sahne (Stage) kanalları
    for channel in guild.stage_channels:
        members = channel.members
        count = len(members)
        if count > 0:
            total_voice_count += count
            user_list = [format_voice_member(m) for m in members]
            channel_data.append((f"🎭 {channel.name}", count, "", user_list))

    if total_voice_count == 0:
        embed.description += (
            "```yaml\n"
            "Durum: Aktif ses kanalı bulunamadı.\n"
            "Sesteki Üye: 0 kişi\n"
            "```\n"
            "*Şu anda hiçbir ses kanalında üye bulunmuyor.*"
        )
    else:
        embed.description += f"⚡ **Sesteki Toplam Kişi:** `{total_voice_count}`\n\n"
        for ch_name, count, limit_str, users in channel_data:
            users_text = " • " + " • ".join(users)
            if len(users_text) > 1024:
                users_text = users_text[:1000] + "... *(ve dahası)*"
            embed.add_field(
                name=f"🔊 {ch_name} ─ [{count}{limit_str}]",
                value=users_text,
                inline=False
            )

    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Priv Ses Takipçisi")
    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_thumbnail(url=logo)

    return embed

def draw_ambient_glow(img: Image.Image, cx: int, cy: int, radius: int, color_rgb: tuple):
    overlay = Image.new('RGBA', img.size, (0, 0, 0, 0))
    odraw = ImageDraw.Draw(overlay)
    r_val, g_val, b_val = color_rgb
    for r in range(radius, 0, -8):
        alpha = int(22 * (1.0 - (r / radius)) ** 2)
        if alpha > 0:
            odraw.ellipse([(cx - r, cy - r), (cx + r, cy + r)], fill=(r_val, g_val, b_val, alpha))
    img.alpha_composite(overlay)

def render_stats_card(
    guild_name: str = "ɨ̇ ʍ ʐ ǟ #PRİV",
    total_members: int = 0,
    humans: int = 0,
    bots: int = 0,
    active_count: int = 0,
    online: int = 0,
    idle: int = 0,
    dnd: int = 0,
    offline: int = 0,
    total_voice: int = 0,
    mic_off: int = 0,
    deaf_off: int = 0,
    streaming: int = 0,
    boost_level: int = 0,
    boost_count: int = 0,
    logo_bytes: bytes = None
) -> io.BytesIO:
    """Priv sunucu istatistikleri ve genel sayım için ultra modern obsidyen grafik banner üretir."""
    W, H = 960, 480
    img = Image.new('RGBA', (W, H), (9, 11, 17, 255))

    # Yumuşak arka plan neon atmosferi (Ambient glows)
    draw_ambient_glow(img, 140, 60, 220, (56, 189, 248))   # Cyan glow sol üst
    draw_ambient_glow(img, 820, 420, 240, (168, 85, 247))  # Violet glow sağ alt
    draw_ambient_glow(img, 800, 100, 180, (52, 211, 153))  # Emerald glow sağ üst

    draw = ImageDraw.Draw(img)

    # Dış kart çerçevesi ve obsidyen gövde
    draw.rounded_rectangle([(10, 10), (W - 10, H - 10)], radius=22, fill=(13, 16, 25, 245), outline=(36, 42, 62, 255), width=2)
    # Üst aydınlatma gradyan çizgisi (Indigo/Cyan)
    draw.line([(35, 12), (W - 35, 12)], fill=(99, 102, 241, 230), width=1)
    draw.line([(80, 12), (320, 12)], fill=(56, 189, 248, 255), width=2)

    # Fontlar
    font_brand = get_card_font(bold=True, size=13)
    font_title = get_card_font(bold=True, size=26)
    font_sub = get_card_font(bold=False, size=13)
    font_pill = get_card_font(bold=True, size=12)

    font_card_head = get_card_font(bold=True, size=13)
    font_card_big = get_card_font(bold=True, size=32)
    font_card_unit = get_card_font(bold=False, size=13.5)
    font_chip_label = get_card_font(bold=False, size=11.5)
    font_chip_val = get_card_font(bold=True, size=12.5)

    font_footer = get_card_font(bold=False, size=11.5)
    font_watermark = get_card_font(bold=True, size=11.5)

    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")

    # 1. HEADER (Logo, Başlık, Rozet)
    text_x = 38
    logo_size = 64
    if logo_bytes:
        try:
            l_raw = Image.open(io.BytesIO(logo_bytes)).convert('RGBA')
            l_raw = l_raw.resize((logo_size, logo_size), Image.Resampling.LANCZOS)
            l_mask = Image.new('L', (logo_size, logo_size), 0)
            l_draw = ImageDraw.Draw(l_mask)
            l_draw.rounded_rectangle([(0, 0), (logo_size, logo_size)], radius=18, fill=255)
            l_raw.putalpha(l_mask)
            img.paste(l_raw, (38, 26), l_raw)
            draw.rounded_rectangle([(36, 24), (38 + logo_size + 2, 26 + logo_size + 2)], radius=20, outline=(99, 102, 241, 200), width=2)
            text_x = 38 + logo_size + 18
        except Exception:
            text_x = 38
    else:
        fb_size = 64
        draw.rounded_rectangle([(38, 26), (38 + fb_size, 26 + fb_size)], radius=18, fill=(24, 29, 48, 255), outline=(88, 101, 242, 180), width=2)
        draw.text((38 + 14, 26 + 16), "ɨ̇ ʍ", fill=(255, 255, 255, 255), font=get_card_font(bold=True, size=20))
        text_x = 38 + fb_size + 18

    # Header Metinleri
    draw.text((text_x, 26), f'{bot_name}  •  MERKEZİ SUNUCU METRİKLERİ', fill=(129, 140, 248, 255), font=font_brand)
    clean_guild_name = (guild_name or "PRİV SUNUCU")[:26].upper()
    draw.text((text_x, 46), f'{clean_guild_name} İSTATİSTİKLERİ', fill=(255, 255, 255, 255), font=font_title)
    draw.text((text_x, 80), 'Gerçek zamanlı üye dökümü, ses odaları ve topluluk durumu', fill=(148, 156, 178, 255), font=font_sub)

    # Sağ Üst Rozet
    pill_text = 'CANLI RAPOR'
    pw = int(draw.textlength(pill_text, font=font_pill)) + 38
    px = W - 38 - pw
    py = 36
    draw.rounded_rectangle([(px, py), (px + pw, py + 34)], radius=17, fill=(22, 27, 44, 255), outline=(88, 101, 242, 180), width=1)
    draw.ellipse([(px + 12, py + 12), (px + 20, py + 20)], fill=(34, 197, 94, 255))
    draw.text((px + 26, py + 9), pill_text, fill=(224, 231, 255, 255), font=font_pill)

    # Header Ayırıcı Çizgi
    draw.line([(38, 108), (W - 38, 108)], fill=(28, 33, 48, 255), width=1)

    # 2. 4 KART - 2x2 GRID
    col_w = (W - 38 * 2 - 20) // 2   # 432 px
    card_h = 154
    r1_y = 120
    r2_y = 288

    human_pct = int((humans / max(1, total_members)) * 100)
    bot_pct = 100 - human_pct
    active_pct = int((active_count / max(1, total_members)) * 100)

    # --- KART 1: ÜYE DAĞILIMI (Sol Üst) ---
    c1_x, c1_y = 38, r1_y
    draw.rounded_rectangle([(c1_x, c1_y), (c1_x + col_w, c1_y + card_h)], radius=16, fill=(17, 21, 33, 255), outline=(38, 46, 68, 255), width=1)
    draw.rounded_rectangle([(c1_x + 14, c1_y + 2), (c1_x + col_w - 14, c1_y + 4)], radius=2, fill=(56, 189, 248, 255))
    
    # İkon rozeti
    draw.rounded_rectangle([(c1_x + 16, c1_y + 14), (c1_x + 44, c1_y + 42)], radius=8, fill=(24, 38, 56, 255), outline=(56, 189, 248, 160), width=1)
    draw.ellipse([(c1_x + 25, c1_y + 19), (c1_x + 35, c1_y + 29)], fill=(56, 189, 248, 255))
    draw.arc([(c1_x + 21, c1_y + 28), (c1_x + 39, c1_y + 42)], start=180, end=0, fill=(56, 189, 248, 255), width=2)
    
    draw.text((c1_x + 52, c1_y + 15), 'ÜYE DAĞILIMI', fill=(56, 189, 248, 255), font=font_card_head)
    draw.text((c1_x + 52, c1_y + 32), f'{total_members}', fill=(255, 255, 255, 255), font=font_card_big)
    tw = int(draw.textlength(str(total_members), font=font_card_big))
    draw.text((c1_x + 52 + tw + 10, c1_y + 45), 'Toplam Üye', fill=(148, 163, 184, 255), font=font_card_unit)

    # İlerleme Çubuğu (Bar)
    bar_x = c1_x + 16
    bar_y = c1_y + 78
    bar_w = col_w - 32
    bar_h = 8
    draw.rounded_rectangle([(bar_x, bar_y), (bar_x + bar_w, bar_y + bar_h)], radius=4, fill=(28, 34, 50, 255))
    human_bar_w = max(4, int(bar_w * (human_pct / 100)))
    draw.rounded_rectangle([(bar_x, bar_y), (bar_x + human_bar_w, bar_y + bar_h)], radius=4, fill=(56, 189, 248, 255))
    if human_bar_w < bar_w - 4:
        draw.rounded_rectangle([(bar_x + human_bar_w, bar_y), (bar_x + bar_w, bar_y + bar_h)], radius=4, fill=(168, 85, 247, 255))

    # Alt Çipler
    chip_y = c1_y + 98
    sub_w = (col_w - 32 - 10) // 2
    draw.rounded_rectangle([(c1_x + 16, chip_y), (c1_x + 16 + sub_w, chip_y + 40)], radius=8, fill=(23, 29, 44, 255), outline=(42, 52, 76, 255), width=1)
    draw.text((c1_x + 26, chip_y + 6), 'Gerçek Kişi', fill=(148, 163, 184, 255), font=font_chip_label)
    draw.text((c1_x + 26, chip_y + 20), f'{humans} üye  (%{human_pct})', fill=(241, 245, 249, 255), font=font_chip_val)
    
    c2_chip_x = c1_x + 16 + sub_w + 10
    draw.rounded_rectangle([(c2_chip_x, chip_y), (c2_chip_x + sub_w, chip_y + 40)], radius=8, fill=(23, 29, 44, 255), outline=(42, 52, 76, 255), width=1)
    draw.text((c2_chip_x + 10, chip_y + 6), 'Sistem Botları', fill=(148, 163, 184, 255), font=font_chip_label)
    draw.text((c2_chip_x + 10, chip_y + 20), f'{bots} bot  (%{bot_pct})', fill=(196, 181, 253, 255), font=font_chip_val)

    # --- KART 2: AKTİFLİK DURUMU (Sağ Üst) ---
    c2_x, c2_y = 38 + col_w + 20, r1_y
    draw.rounded_rectangle([(c2_x, c2_y), (c2_x + col_w, c2_y + card_h)], radius=16, fill=(17, 21, 33, 255), outline=(38, 46, 68, 255), width=1)
    draw.rounded_rectangle([(c2_x + 14, c2_y + 2), (c2_x + col_w - 14, c2_y + 4)], radius=2, fill=(52, 211, 153, 255))
    
    draw.rounded_rectangle([(c2_x + 16, c2_y + 14), (c2_x + 44, c2_y + 42)], radius=8, fill=(20, 42, 34, 255), outline=(52, 211, 153, 160), width=1)
    draw.polygon([(c2_x + 31, c2_y + 18), (c2_x + 23, c2_y + 29), (c2_x + 29, c2_y + 29), (c2_x + 27, c2_y + 38), (c2_x + 36, c2_y + 26), (c2_x + 30, c2_y + 26)], fill=(52, 211, 153, 255))

    draw.text((c2_x + 52, c2_y + 15), 'AKTİFLİK DURUMU', fill=(52, 211, 153, 255), font=font_card_head)
    draw.text((c2_x + 52, c2_y + 32), f'{active_count}', fill=(255, 255, 255, 255), font=font_card_big)
    tw = int(draw.textlength(str(active_count), font=font_card_big))
    draw.text((c2_x + 52 + tw + 10, c2_y + 45), f'Aktif Üye  (%{active_pct})', fill=(148, 163, 184, 255), font=font_card_unit)

    st_chips = [
        ("Çevrimiçi", str(online), (167, 243, 208, 255), (34, 197, 94, 255)),
        ("Rahatsız Etmeyin", str(dnd), (254, 202, 202, 255), (239, 68, 68, 255)),
        ("Boşta", str(idle), (254, 240, 138, 255), (234, 179, 8, 255)),
        ("Çevrimdışı", str(offline), (148, 163, 184, 255), (100, 116, 139, 255))
    ]
    chip_w = (col_w - 32 - 10) // 2
    for idx, (clabel, cval, colr, dot) in enumerate(st_chips):
        ci = idx % 2
        ri = idx // 2
        cx = c2_x + 16 + ci * (chip_w + 10)
        cy = c2_y + 78 + ri * 32
        draw.rounded_rectangle([(cx, cy), (cx + chip_w, cy + 28)], radius=6, fill=(23, 29, 44, 255), outline=(42, 52, 76, 255), width=1)
        draw.ellipse([(cx + 8, cy + 9), (cx + 18, cy + 19)], fill=dot)
        draw.text((cx + 24, cy + 6), clabel, fill=(148, 156, 178, 255), font=font_chip_label)
        vw = int(draw.textlength(cval, font=font_chip_val))
        draw.text((cx + chip_w - vw - 10, cy + 6), cval, fill=colr, font=font_chip_val)

    # --- KART 3: SES KANALLARI (Sol Alt) ---
    c3_x, c3_y = 38, r2_y
    draw.rounded_rectangle([(c3_x, c3_y), (c3_x + col_w, c3_y + card_h)], radius=16, fill=(17, 21, 33, 255), outline=(38, 46, 68, 255), width=1)
    draw.rounded_rectangle([(c3_x + 14, c3_y + 2), (c3_x + col_w - 14, c3_y + 4)], radius=2, fill=(251, 146, 60, 255))

    draw.rounded_rectangle([(c3_x + 16, c3_y + 14), (c3_x + 44, c3_y + 42)], radius=8, fill=(46, 32, 22, 255), outline=(251, 146, 60, 160), width=1)
    draw.polygon([(c3_x + 22, c3_y + 25), (c3_x + 26, c3_y + 25), (c3_x + 32, c3_y + 20), (c3_x + 32, c3_y + 36), (c3_x + 26, c3_y + 31), (c3_x + 22, c3_y + 31)], fill=(251, 146, 60, 255))
    draw.arc([(c3_x + 30, c3_y + 22), (c3_x + 38, c3_y + 34)], start=300, end=60, fill=(251, 146, 60, 255), width=2)

    draw.text((c3_x + 52, c3_y + 15), 'SES KANALLARI', fill=(251, 146, 60, 255), font=font_card_head)
    draw.text((c3_x + 52, c3_y + 32), f'{total_voice}', fill=(255, 255, 255, 255), font=font_card_big)
    tw = int(draw.textlength(str(total_voice), font=font_card_big))
    draw.text((c3_x + 52 + tw + 10, c3_y + 45), 'Sesteki Toplam Üye', fill=(148, 163, 184, 255), font=font_card_unit)

    voice_chips = [
        ("Mikrofon Kapalı", str(mic_off), (254, 215, 170, 255)),
        ("Kulaklık Kapalı", str(deaf_off), (254, 215, 170, 255)),
        ("Yayında / Kamera", str(streaming), (216, 180, 254, 255))
    ]
    v_chip_w = (col_w - 32 - 16) // 3
    for idx, (clabel, cval, colr) in enumerate(voice_chips):
        cx = c3_x + 16 + idx * (v_chip_w + 8)
        cy = c3_y + 88
        draw.rounded_rectangle([(cx, cy), (cx + v_chip_w, cy + 46)], radius=8, fill=(23, 29, 44, 255), outline=(42, 52, 76, 255), width=1)
        draw.text((cx + 10, cy + 8), clabel, fill=(148, 156, 178, 255), font=get_card_font(bold=False, size=10.5))
        draw.text((cx + 10, cy + 24), cval, fill=colr, font=font_card_big if len(cval) <= 2 else font_chip_val)

    # --- KART 4: SUNUCU TAKVİYESİ (Sağ Alt) ---
    c4_x, c4_y = 38 + col_w + 20, r2_y
    draw.rounded_rectangle([(c4_x, c4_y), (c4_x + col_w, c4_y + card_h)], radius=16, fill=(17, 21, 33, 255), outline=(38, 46, 68, 255), width=1)
    draw.rounded_rectangle([(c4_x + 14, c4_y + 2), (c4_x + col_w - 14, c4_y + 4)], radius=2, fill=(168, 85, 247, 255))

    draw.rounded_rectangle([(c4_x + 16, c4_y + 14), (c4_x + 44, c4_y + 42)], radius=8, fill=(40, 26, 56, 255), outline=(168, 85, 247, 160), width=1)
    draw.polygon([(c4_x + 30, c4_y + 19), (c4_x + 38, c4_y + 25), (c4_x + 30, c4_y + 37), (c4_x + 22, c4_y + 25)], fill=(192, 132, 252, 255))

    draw.text((c4_x + 52, c4_y + 15), 'SUNUCU TAKVİYESİ', fill=(192, 132, 252, 255), font=font_card_head)
    draw.text((c4_x + 52, c4_y + 32), f'Seviye {boost_level}', fill=(255, 255, 255, 255), font=font_card_big)
    tw = int(draw.textlength(f'Seviye {boost_level}', font=font_card_big))
    draw.text((c4_x + 52 + tw + 10, c4_y + 45), f'({boost_count} Boost)', fill=(148, 163, 184, 255), font=font_card_unit)

    b_chip_w = (col_w - 32 - 10) // 2
    # Chip 1 (Takviye)
    draw.rounded_rectangle([(c4_x + 16, c4_y + 88), (c4_x + 16 + b_chip_w, c4_y + 88 + 46)], radius=8, fill=(23, 29, 44, 255), outline=(42, 52, 76, 255), width=1)
    draw.text((c4_x + 20, c4_y + 94), 'Toplam Takviye', fill=(148, 163, 184, 255), font=font_chip_label)
    draw.text((c4_x + 20, c4_y + 110), f'{boost_count} Boost', fill=(233, 213, 255, 255), font=get_card_font(bold=True, size=16))

    # Chip 2 (Sunucu Statüsü)
    c4_chip2_x = c4_x + 16 + b_chip_w + 10
    draw.rounded_rectangle([(c4_chip2_x, c4_y + 88), (c4_chip2_x + b_chip_w, c4_y + 88 + 46)], radius=8, fill=(23, 29, 44, 255), outline=(42, 52, 76, 255), width=1)
    draw.text((c4_chip2_x + 20, c4_y + 94), 'Topluluk Statüsü', fill=(148, 163, 184, 255), font=font_chip_label)
    draw.text((c4_chip2_x + 20, c4_y + 110), 'PRİV AKTİF', fill=(110, 231, 183, 255), font=get_card_font(bold=True, size=16))

    # 3. FOOTER
    draw.line([(38, 452), (W - 38, 452)], fill=(24, 28, 40, 255), width=1)
    draw.text((38, 460), f'{bot_name}  •  Priv List & Ses Takip Sistemi  •  discord.gg/imzapriw', fill=(110, 118, 140, 255), font=font_footer)
    draw.text((W - 170, 460), 'RESMİ PRİV RAPORU', fill=(99, 102, 241, 255), font=font_watermark)

    buf = io.BytesIO()
    img.save(buf, format='PNG', optimize=True)
    buf.seek(0)
    return buf


def render_voice_stats_card(
    guild_name: str = "ɨ̇ ʍ ʐ ǟ #PRİV",
    total_voice: int = 0,
    mic_off: int = 0,
    deaf_off: int = 0,
    streaming: int = 0,
    active_channels: list = None,
    logo_bytes: bytes = None,
    bot_name: str = "ɨ̇ ʍ ʐ ǟ"
) -> io.BytesIO:
    """Sadece ses kanalları ve sesteki üyelerin analizi için ultra modern obsidyen grafik afişi üretir."""
    if active_channels is None:
        active_channels = []

    W, H = 960, 440
    img = Image.new('RGBA', (W, H), (9, 11, 17, 255))

    # Yumuşak neon arka plan atmosferi (Ambient glows)
    draw_ambient_glow(img, 140, 60, 220, (251, 146, 60))   # Amber/Orange sol üst
    draw_ambient_glow(img, 520, 150, 240, (249, 115, 22))  # Orange orta
    draw_ambient_glow(img, 850, 360, 240, (168, 85, 247))  # Violet sağ alt
    draw_ambient_glow(img, 820, 80, 180, (56, 189, 248))   # Cyan sağ üst

    draw = ImageDraw.Draw(img)

    # Dış kart çerçevesi ve obsidyen gövde
    draw.rounded_rectangle([(10, 10), (W - 10, H - 10)], radius=22, fill=(13, 16, 25, 245), outline=(36, 42, 62, 255), width=2)
    # Üst aydınlatma gradyan çizgisi (Amber / Indigo)
    draw.line([(35, 12), (W - 35, 12)], fill=(99, 102, 241, 230), width=1)
    draw.line([(80, 12), (340, 12)], fill=(251, 146, 60, 255), width=2)

    # Fontlar
    font_brand = get_card_font(bold=True, size=13)
    font_title = get_card_font(bold=True, size=25)
    font_sub = get_card_font(bold=False, size=13)
    font_pill = get_card_font(bold=True, size=12)

    font_hero_head = get_card_font(bold=True, size=13)
    font_hero_big = get_card_font(bold=True, size=46)
    font_hero_unit = get_card_font(bold=True, size=17)
    font_hero_sub = get_card_font(bold=False, size=13)

    font_card_head = get_card_font(bold=True, size=12.5)
    font_card_big = get_card_font(bold=True, size=28)
    font_card_sub = get_card_font(bold=False, size=11.5)

    font_room_num = get_card_font(bold=True, size=11)
    font_room_name = get_card_font(bold=True, size=12)
    font_room_val = get_card_font(bold=True, size=11.5)

    font_footer = get_card_font(bold=False, size=11.5)
    font_watermark = get_card_font(bold=True, size=11.5)

    # 1. HEADER
    text_x = 38
    logo_size = 64
    if logo_bytes:
        try:
            l_raw = Image.open(io.BytesIO(logo_bytes)).convert('RGBA')
            l_raw = l_raw.resize((logo_size, logo_size), Image.Resampling.LANCZOS)
            l_mask = Image.new('L', (logo_size, logo_size), 0)
            l_draw = ImageDraw.Draw(l_mask)
            l_draw.rounded_rectangle([(0, 0), (logo_size, logo_size)], radius=18, fill=255)
            l_raw.putalpha(l_mask)
            img.paste(l_raw, (38, 26), l_raw)
            draw.rounded_rectangle([(36, 24), (38 + logo_size + 2, 26 + logo_size + 2)], radius=20, outline=(251, 146, 60, 200), width=2)
            text_x = 38 + logo_size + 18
        except Exception:
            text_x = 38
    else:
        fb_size = 64
        draw.rounded_rectangle([(38, 26), (38 + fb_size, 26 + fb_size)], radius=18, fill=(28, 33, 48, 255), outline=(251, 146, 60, 180), width=2)
        draw.text((38 + 14, 26 + 16), "ɨ̇ ʍ", fill=(255, 255, 255, 255), font=get_card_font(bold=True, size=20))
        text_x = 38 + fb_size + 18

    # Header Metinleri
    draw.text((text_x, 26), f'{bot_name}  •  SES KANALLARI RAPORU', fill=(251, 146, 60, 255), font=font_brand)
    clean_guild_name = (guild_name or "PRİV SUNUCU")[:26].upper()
    draw.text((text_x, 46), f'{clean_guild_name} SES DURUMU', fill=(255, 255, 255, 255), font=font_title)
    draw.text((text_x, 80), 'Sesteki toplam üyeler, mikrofon/kulaklık istatistikleri ve aktif kanallar', fill=(148, 156, 178, 255), font=font_sub)

    # Sağ Üst Rozet
    pill_text = 'CANLI SES'
    pw = int(draw.textlength(pill_text, font=font_pill)) + 38
    px = W - 38 - pw
    py = 36
    draw.rounded_rectangle([(px, py), (px + pw, py + 34)], radius=17, fill=(36, 24, 18, 255), outline=(251, 146, 60, 180), width=1)
    draw.ellipse([(px + 12, py + 12), (px + 20, py + 20)], fill=(249, 115, 22, 255))
    draw.text((px + 26, py + 9), pill_text, fill=(254, 215, 170, 255), font=font_pill)

    # Header Ayırıcı Çizgi
    draw.line([(38, 108), (W - 38, 108)], fill=(28, 33, 48, 255), width=1)

    # 2. HERO CARD - SESTEKİ TOPLAM KULLANICI (y = 118 to 226)
    hero_x = 38
    hero_y = 118
    hero_w = W - 76
    hero_h = 108
    draw.rounded_rectangle([(hero_x, hero_y), (hero_x + hero_w, hero_y + hero_h)], radius=16, fill=(17, 21, 33, 255), outline=(38, 46, 68, 255), width=1)
    draw.rounded_rectangle([(hero_x + 14, hero_y + 2), (hero_x + hero_w - 14, hero_y + 4)], radius=2, fill=(251, 146, 60, 255))

    # İkon kutucuğu
    draw.rounded_rectangle([(hero_x + 16, hero_y + 16), (hero_x + 88, hero_y + 88)], radius=14, fill=(46, 30, 20, 255), outline=(251, 146, 60, 180), width=1)
    # Ses ikonu çizimi
    draw.polygon([(hero_x + 34, hero_y + 53), (hero_x + 42, hero_y + 53), (hero_x + 55, hero_y + 38), (hero_x + 55, hero_y + 68), (hero_x + 42, hero_y + 60), (hero_x + 34, hero_y + 60)], fill=(251, 146, 60, 255))
    draw.arc([(hero_x + 50, hero_y + 42), (hero_x + 68, hero_y + 64)], start=300, end=60, fill=(251, 146, 60, 255), width=3)
    draw.arc([(hero_x + 54, hero_y + 36), (hero_x + 76, hero_y + 70)], start=300, end=60, fill=(253, 186, 116, 255), width=2)

    # Hero Başlık ve Sayı
    draw.text((hero_x + 106, hero_y + 16), 'SESTEKİ TOPLAM ÜYE', fill=(251, 146, 60, 255), font=font_hero_head)
    draw.text((hero_x + 106, hero_y + 34), f'{total_voice}', fill=(255, 255, 255, 255), font=font_hero_big)
    tw = int(draw.textlength(str(total_voice), font=font_hero_big))
    draw.text((hero_x + 106 + tw + 12, hero_y + 52), 'Kişi Canlı Seste', fill=(241, 245, 249, 255), font=font_hero_unit)

    active_rooms_cnt = len(active_channels)
    if total_voice > 0:
        draw.text((hero_x + 106, hero_y + 84), f'Şu anda {active_rooms_cnt} farklı ses kanalında aktif üye bulunmaktadır.', fill=(148, 163, 184, 255), font=font_hero_sub)
    else:
        draw.text((hero_x + 106, hero_y + 84), 'Şu anda ses kanallarında aktif üye bulunmamaktadır.', fill=(148, 163, 184, 255), font=font_hero_sub)

    # Hero sağdaki iki mini rozet
    mic_on = max(0, total_voice - mic_off)
    deaf_on = max(0, total_voice - deaf_off)
    r_chip_w = 175
    r_chip_h = 72
    rc_y = hero_y + 18

    # Rozet 1 (Konuşabilir)
    rc1_x = hero_x + hero_w - (r_chip_w * 2 + 28)
    draw.rounded_rectangle([(rc1_x, rc_y), (rc1_x + r_chip_w, rc_y + r_chip_h)], radius=12, fill=(23, 29, 44, 255), outline=(42, 52, 76, 255), width=1)
    draw.text((rc1_x + 16, rc_y + 12), 'Mikrofonu Açık', fill=(148, 163, 184, 255), font=font_card_sub)
    draw.text((rc1_x + 16, rc_y + 32), f'{mic_on} Aktif', fill=(52, 211, 153, 255), font=get_card_font(bold=True, size=18))

    # Rozet 2 (Dinliyor)
    rc2_x = rc1_x + r_chip_w + 12
    draw.rounded_rectangle([(rc2_x, rc_y), (rc2_x + r_chip_w, rc_y + r_chip_h)], radius=12, fill=(23, 29, 44, 255), outline=(42, 52, 76, 255), width=1)
    draw.text((rc2_x + 16, rc_y + 12), 'Kulaklığı Açık', fill=(148, 163, 184, 255), font=font_card_sub)
    draw.text((rc2_x + 16, rc_y + 32), f'{deaf_on} Dinliyor', fill=(56, 189, 248, 255), font=get_card_font(bold=True, size=18))

    # 3. 4 DETAY KARTI (y = 238 to 388, h = 150)
    card_y = 238
    card_h = 150
    gap = 14
    total_w = W - 76
    c_w = (total_w - (gap * 3)) // 4  # ~209 px

    # --- Kart 1: MİKROFON DURUMU ---
    c1_x = 38
    draw.rounded_rectangle([(c1_x, card_y), (c1_x + c_w, card_y + card_h)], radius=14, fill=(17, 21, 33, 255), outline=(38, 46, 68, 255), width=1)
    draw.rounded_rectangle([(c1_x + 10, card_y + 2), (c1_x + c_w - 10, card_y + 4)], radius=2, fill=(239, 68, 68, 255))
    draw.text((c1_x + 14, card_y + 16), 'MİKROFON', fill=(239, 68, 68, 255), font=font_card_head)
    draw.text((c1_x + 14, card_y + 36), f'{mic_off}', fill=(255, 255, 255, 255), font=font_card_big)
    draw.text((c1_x + 14, card_y + 72), 'Mikrofonu Kapalı', fill=(148, 163, 184, 255), font=font_card_sub)
    draw.rounded_rectangle([(c1_x + 12, card_y + 98), (c1_x + c_w - 12, card_y + 134)], radius=8, fill=(23, 29, 44, 255), outline=(42, 52, 76, 255), width=1)
    draw.text((c1_x + 20, card_y + 108), f'{mic_on} Üye Konuşabilir', fill=(52, 211, 153, 255), font=font_room_val)

    # --- Kart 2: KULAKLIK DURUMU ---
    c2_x = c1_x + c_w + gap
    draw.rounded_rectangle([(c2_x, card_y), (c2_x + c_w, card_y + card_h)], radius=14, fill=(17, 21, 33, 255), outline=(38, 46, 68, 255), width=1)
    draw.rounded_rectangle([(c2_x + 10, card_y + 2), (c2_x + c_w - 10, card_y + 4)], radius=2, fill=(168, 85, 247, 255))
    draw.text((c2_x + 14, card_y + 16), 'KULAKLIK', fill=(168, 85, 247, 255), font=font_card_head)
    draw.text((c2_x + 14, card_y + 36), f'{deaf_off}', fill=(255, 255, 255, 255), font=font_card_big)
    draw.text((c2_x + 14, card_y + 72), 'Kulaklığı Kapalı', fill=(148, 163, 184, 255), font=font_card_sub)
    draw.rounded_rectangle([(c2_x + 12, card_y + 98), (c2_x + c_w - 12, card_y + 134)], radius=8, fill=(23, 29, 44, 255), outline=(42, 52, 76, 255), width=1)
    draw.text((c2_x + 20, card_y + 108), f'{deaf_on} Üye Dinliyor', fill=(196, 181, 253, 255), font=font_room_val)

    # --- Kart 3: YAYIN & KAMERA ---
    c3_x = c2_x + c_w + gap
    draw.rounded_rectangle([(c3_x, card_y), (c3_x + c_w, card_y + card_h)], radius=14, fill=(17, 21, 33, 255), outline=(38, 46, 68, 255), width=1)
    draw.rounded_rectangle([(c3_x + 10, card_y + 2), (c3_x + c_w - 10, card_y + 4)], radius=2, fill=(56, 189, 248, 255))
    draw.text((c3_x + 14, card_y + 16), 'CANLI YAYIN', fill=(56, 189, 248, 255), font=font_card_head)
    draw.text((c3_x + 14, card_y + 36), f'{streaming}', fill=(255, 255, 255, 255), font=font_card_big)
    draw.text((c3_x + 14, card_y + 72), 'Ekran / Kamera Açık', fill=(148, 163, 184, 255), font=font_card_sub)
    draw.rounded_rectangle([(c3_x + 12, card_y + 98), (c3_x + c_w - 12, card_y + 134)], radius=8, fill=(23, 29, 44, 255), outline=(42, 52, 76, 255), width=1)
    draw.text((c3_x + 20, card_y + 108), 'Canlı Akış Aktif' if streaming > 0 else 'Aktif Yayın Yok', fill=(56, 189, 248, 255) if streaming > 0 else (148, 163, 184, 255), font=font_room_val)

    # --- Kart 4: EN AKTİF ODALAR ---
    c4_x = c3_x + c_w + gap
    draw.rounded_rectangle([(c4_x, card_y), (c4_x + c_w, card_y + card_h)], radius=14, fill=(17, 21, 33, 255), outline=(38, 46, 68, 255), width=1)
    draw.rounded_rectangle([(c4_x + 10, card_y + 2), (c4_x + c_w - 10, card_y + 4)], radius=2, fill=(52, 211, 153, 255))
    draw.text((c4_x + 14, card_y + 16), 'AKTİF ODALAR', fill=(52, 211, 153, 255), font=font_card_head)

    if active_channels:
        room_y = card_y + 42
        for idx, (r_name, r_cnt) in enumerate(active_channels[:3], 1):
            trunc_name = (r_name[:12] + '..') if len(r_name) > 12 else r_name
            draw.text((c4_x + 14, room_y), f'{idx}.', fill=(52, 211, 153, 255), font=font_room_num)
            draw.text((c4_x + 28, room_y), f'{trunc_name}', fill=(226, 232, 240, 255), font=font_room_name)
            cnt_str = f'{r_cnt} üye'
            cw = int(draw.textlength(cnt_str, font=font_room_val))
            draw.text((c4_x + c_w - cw - 14, room_y), cnt_str, fill=(52, 211, 153, 255), font=font_room_val)
            room_y += 28
    else:
        draw.text((c4_x + 14, card_y + 50), 'Aktif ses kanalı', fill=(148, 163, 184, 255), font=font_card_sub)
        draw.text((c4_x + 14, card_y + 70), 'bulunmuyor.', fill=(148, 163, 184, 255), font=font_card_sub)

    # 4. FOOTER
    draw.line([(38, 402), (W - 38, 402)], fill=(24, 28, 40, 255), width=1)
    draw.text((38, 412), f'{bot_name}  •  Priv Ses Takip Sistemi  •  discord.gg/imzapriw', fill=(110, 118, 140, 255), font=font_footer)
    draw.text((W - 170, 412), 'CANLI SES RAPORU', fill=(251, 146, 60, 255), font=font_watermark)

    buf = io.BytesIO()
    img.save(buf, format='PNG', optimize=True)
    buf.seek(0)
    return buf


async def get_voice_say_file_and_embed(guild: discord.Guild) -> tuple[discord.File, discord.Embed]:
    """Sadece ses verilerini (sesteki kişi sayısı, mikrofon/kulaklık, yayın ve aktif odalar) hesaplar,
    özel ses grafik kartı üretir ve modern çizgisiz embed döner."""
    voice_members = [m for m in guild.members if m.voice and m.voice.channel]
    total_voice = len(voice_members)
    mic_off = sum(1 for m in voice_members if m.voice.self_mute or m.voice.mute)
    deaf_off = sum(1 for m in voice_members if m.voice.self_deaf or m.voice.deaf)
    streaming = sum(1 for m in voice_members if m.voice.self_stream or m.voice.self_video)

    active_channels = []
    for ch in (guild.voice_channels + guild.stage_channels):
        cnt = len(ch.members)
        if cnt > 0:
            active_channels.append((ch.name, cnt))
    active_channels.sort(key=lambda x: x[1], reverse=True)
    active_channels_count = len(active_channels)

    logo_bytes = None
    if guild and guild.icon:
        try:
            logo_bytes = await guild.icon.with_format('png').with_size(128).read()
        except Exception:
            pass

    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")

    img_buf = await asyncio.to_thread(
        render_voice_stats_card,
        guild.name,
        total_voice,
        mic_off,
        deaf_off,
        streaming,
        active_channels,
        logo_bytes,
        bot_name
    )

    filename = "ses_sayim.png"
    file = discord.File(fp=img_buf, filename=filename)

    embed = discord.Embed(
        title=f"{bot_name} ┊ Ses Kanalları Sayımı",
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )

    lines = [
        f"**{guild.name}** ses kanallarının canlı anlık dökümü:\n",
        f"🔊 **Sesteki Toplam Üye**",
        f"Toplam: **`{total_voice} kişi`**  •  Aktif Kanal: **`{active_channels_count} oda`**\n",
        f"🎙️ **Mikrofon & Kulaklık Durumu**",
        f"Mikrofon Kapalı: **`{mic_off}`**  •  Kulaklık Kapalı: **`{deaf_off}`**\n",
        f"🔴 **Ekran Paylaşımı & Kamera**",
        f"Yayında / Kamerada: **`{streaming} kişi`**"
    ]

    if active_channels:
        lines.append("\n📌 **En Aktif Ses Odaları**")
        for idx, (ch_name, count) in enumerate(active_channels[:5], 1):
            lines.append(f"**`{idx}.`** **{ch_name}**: **`{count} kişi`**")
    elif total_voice == 0:
        lines.append("\n*Şu anda hiçbir ses kanalında üye bulunmamaktadır.*")

    embed.description = "\n".join(lines)
    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_image(url=f"attachment://{filename}")
    embed.set_footer(text=f"{bot_name} • Priv Ses Takipçisi")

    return file, embed


async def get_say_file_and_embed(guild: discord.Guild) -> tuple[discord.File, discord.Embed]:
    """Sunucu üye, ses, aktiflik ve takviye istatistiklerini hesaplar, afiş görseli üretir ve embed döner."""
    total_members = guild.member_count or len(guild.members)
    humans = sum(1 for m in guild.members if not m.bot)
    bots = sum(1 for m in guild.members if m.bot)

    # Aktiflik durumları
    online = sum(1 for m in guild.members if m.status == discord.Status.online)
    idle = sum(1 for m in guild.members if m.status == discord.Status.idle)
    dnd = sum(1 for m in guild.members if m.status == discord.Status.dnd)
    offline = sum(1 for m in guild.members if m.status == discord.Status.offline)
    active_count = online + idle + dnd

    # Ses durumu
    voice_members = [m for m in guild.members if m.voice and m.voice.channel]
    total_voice = len(voice_members)
    mic_off = sum(1 for m in voice_members if m.voice.self_mute or m.voice.mute)
    deaf_off = sum(1 for m in voice_members if m.voice.self_deaf or m.voice.deaf)
    streaming = sum(1 for m in voice_members if m.voice.self_stream or m.voice.self_video)

    # Takviye durumu
    boost_count = guild.premium_subscription_count or 0
    boost_level = guild.premium_tier

    human_pct = int((humans / max(1, total_members)) * 100)
    active_pct = int((active_count / max(1, total_members)) * 100)

    logo_bytes = None
    if guild and guild.icon:
        try:
            logo_bytes = await guild.icon.with_format('png').with_size(128).read()
        except Exception:
            pass

    img_buf = await asyncio.to_thread(
        render_stats_card,
        guild.name,
        total_members,
        humans,
        bots,
        active_count,
        online,
        idle,
        dnd,
        offline,
        total_voice,
        mic_off,
        deaf_off,
        streaming,
        boost_level,
        boost_count,
        logo_bytes
    )

    filename = "sunucu_istatistik.png"
    file = discord.File(fp=img_buf, filename=filename)

    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ┊ Sunucu İstatistikleri",
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )

    desc = (
        f"**{guild.name}** sunucusunun anlık canlı verileri:\n\n"
        f"👥 **Üye Dağılımı**\n"
        f"Toplam: **`{total_members}`**  •  Gerçek: **`{humans}`** `(%{human_pct})`  •  Bot: **`{bots}`**\n\n"
        f"⚡ **Aktiflik Durumu**\n"
        f"Toplam Aktif: **`{active_count}`** `(%{active_pct})`\n"
        f"🟢 **`{online}`**  •  ⛔ **`{dnd}`**  •  🌙 **`{idle}`**  •  ⚫ **`{offline}`**\n\n"
        f"🔊 **Ses Kanalları**\n"
        f"Sesteki Toplam: **`{total_voice} kişi`**  •  🔇 **`{mic_off}`**  •  🎧 **`{deaf_off}`**  •  🔴 **`{streaming}`**\n\n"
        f"💎 **Sunucu Takviyesi**\n"
        f"Seviye: **`{boost_level}. Seviye`**  •  Toplam: **`{boost_count} Boost`**  •  **`Priv Aktif`**"
    )

    embed.description = desc
    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_image(url=f"attachment://{filename}")
    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Priv List Sistemi")

    return file, embed


def build_say_embed(guild: discord.Guild) -> discord.Embed:
    """Sunucu üye, ses, aktiflik ve takviye istatistiklerini hesaplar."""
    total_members = guild.member_count or len(guild.members)
    humans = sum(1 for m in guild.members if not m.bot)
    bots = sum(1 for m in guild.members if m.bot)

    # Aktiflik durumları
    online = sum(1 for m in guild.members if m.status == discord.Status.online)
    idle = sum(1 for m in guild.members if m.status == discord.Status.idle)
    dnd = sum(1 for m in guild.members if m.status == discord.Status.dnd)
    offline = sum(1 for m in guild.members if m.status == discord.Status.offline)
    active_count = online + idle + dnd

    # Ses durumu
    voice_members = [m for m in guild.members if m.voice and m.voice.channel]
    total_voice = len(voice_members)
    mic_off = sum(1 for m in voice_members if m.voice.self_mute or m.voice.mute)
    deaf_off = sum(1 for m in voice_members if m.voice.self_deaf or m.voice.deaf)
    streaming = sum(1 for m in voice_members if m.voice.self_stream or m.voice.self_video)

    # Takviye durumu
    boost_count = guild.premium_subscription_count or 0
    boost_level = guild.premium_tier

    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ┊ Sunucu İstatistikleri",
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )

    human_pct = int((humans / max(1, total_members)) * 100)
    active_pct = int((active_count / max(1, total_members)) * 100)

    desc = (
        f"**{guild.name}** sunucusunun anlık canlı verileri:\n\n"
        f"👥 **Üye Dağılımı**\n"
        f"Toplam: **`{total_members}`**  •  Gerçek: **`{humans}`** `(%{human_pct})`  •  Bot: **`{bots}`**\n\n"
        f"⚡ **Aktiflik Durumu**\n"
        f"Toplam Aktif: **`{active_count}`** `(%{active_pct})`\n"
        f"🟢 **`{online}`**  •  ⛔ **`{dnd}`**  •  🌙 **`{idle}`**  •  ⚫ **`{offline}`**\n\n"
        f"🔊 **Ses Kanalları**\n"
        f"Sesteki Toplam: **`{total_voice} kişi`**  •  🔇 **`{mic_off}`**  •  🎧 **`{deaf_off}`**  •  🔴 **`{streaming}`**\n\n"
        f"💎 **Sunucu Takviyesi**\n"
        f"Seviye: **`{boost_level}. Seviye`**  •  Toplam: **`{boost_count} Boost`**  •  **`Priv Aktif`**"
    )

    embed.description = desc
    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Priv List Sistemi")
    return embed

def get_user_voice_embed(target: discord.Member) -> discord.Embed:
    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ┊ Kullanıcı Konumu",
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    if target.display_avatar:
        embed.set_thumbnail(url=target.display_avatar.url)

    vs = target.voice
    if not vs or not vs.channel:
        embed.description = f"❌ {target.mention} şu anda **herhangi bir ses kanalında bulunmuyor**."
    else:
        channel = vs.channel
        channel_members = len(channel.members)
        state_list = []
        if vs.self_mute or vs.mute:
            state_list.append("🔇 Mikrofon Kapalı")
        else:
            state_list.append("🎙️ Mikrofon Açık")

        if vs.self_deaf or vs.deaf:
            state_list.append("🎧 Kulaklık Kapalı")
        else:
            state_list.append("🎧 Kulaklık Açık")

        if vs.self_video:
            state_list.append("📹 Kamera Açık")
        if vs.self_stream:
            state_list.append("🔴 Yayında")

        embed.description = (
            f"👤 **Kullanıcı:** {target.mention} (`{target.display_name}`)\n"
            f"🔊 **Bulunduğu Kanal:** {channel.mention} (`{channel.name}`)\n"
            f"👥 **Odaki Kişi Sayısı:** `{channel_members}` üye\n\n"
            f"**Durum Bilgileri:**\n" + "\n".join(f"• {s}" for s in state_list)
        )
    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Priv Konum Bulucu")
    return embed

def build_help_embed() -> discord.Embed:
    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ┊ Slash Komutları",
        description="Priv sunucun için özel olarak kodlanmış ses ve istatistik botu.\nTüm komutlar **Slash (`/`)** olarak çalışır.\n",
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )

    embed.add_field(
        name="🔊 Ses Komutları",
        value=(
            "`/ses`\n"
            "└ Seste kaç kişi olduğunu ve odalardaki üyeleri anlık dökümle listeler.\n\n"
            "`/nerede [kullanıcı]`\n"
            "└ Belirtilen kullanıcının hangi ses kanalında olduğunu ve durumunu gösterir.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="📊 İstatistik & Sayım",
        value=(
            "`/say`\n"
            "└ Seste kaç kişi olduğunu, mikrofon/kulaklık/yayın durumlarını ve aktif odaları resimli gösterir.\n\n"
            "`/liste`\n"
            "└ Sunucu üye sayısı, aktiflik (çevrimiçi/boşta/dnd), boost ve genel istatistik dökümü.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="⚡ Canlı Ses Paneli",
        value=(
            "`/panel` *(Yönetici)*\n"
            "└ Bulunduğun kanala her 15 saniyede veya ses odalarında hareket olduğunda canlı güncellenen takip paneli kurar.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="🏷️ Otomatik Durum Rolü",
        value=(
            "Kullanıcılar durumuna `/imzapriw` veya `discord.gg/imzapriw` yazdığında otomatik rol verilir, sildiklerinde geri alınır.\n"
            "`/durum-tara` *(Yönetici)* ➔ Tüm sunucuyu anında tarar.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="🔒 Secret (Özel) Ses Odası",
        value=(
            "`/secret-oda-kur` *(Yönetici)* ➔ Kategori, kalıcı panel kanalı ve giriş kanalını kurar.\n"
            "`/secret-panel-gonder` *(Yönetici)* ➔ Bulunduğun metin kanalına kalıcı Secret Paneli gönderir.\n"
            "└ Kullanıcılar odalarında otururken panel kanalındaki butonlara basarak odalarını yönetir.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="👑 VIP Sistemi & Yönetimi",
        value=(
            "`/vip [kullanıcı] (sebep)` *(Yetkili)*\n"
            "└ Belirtilen üyeye VIP rolü (`👑 VIP`) tanımlar.\n\n"
            "`/vip-al [kullanıcı] (sebep)` *(Yetkili)*\n"
            "└ Belirtilen üyeden VIP rolünü geri alır.\n\n"
            "`/vip-kanal-kur (kanal)` *(Yönetici)*\n"
            "└ VIP ayrıcalıklarını ve butonla doğrudan yönetilebilen VIP kontrol panelini kurar.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="🧹 Temizleme",
        value=(
            "`/sil [miktar]` *(Yönetici)*\n"
            "└ Belirtilen sayıda mesajı sohbetten temizler.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="🎵 Spotify Kartı",
        value=(
            "`/spotify [kullanıcı]` veya `/spo [kullanıcı]`\n"
            "└ Dinlediğin (veya belirtilen üyenin) şarkısını, albüm kapağını ve süresini gösteren özel estetik kart oluşturur.\n"
        ),
        inline=False
    )

    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Gelişmiş Priv Sistemleri")
    logo = get_brand_logo_url()
    if logo:
        embed.set_thumbnail(url=logo)
    return embed

# ─────────────────────────────────────────────
# ETKİLEŞİMLİ BUTONLAR (VIEW)
# ─────────────────────────────────────────────
class VoiceRefreshView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Yenile", style=discord.ButtonStyle.secondary, emoji="🔄", custom_id="imza:btn_refresh_voice")
    async def refresh_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = build_voice_embed(interaction.guild)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Ses Sayımı", style=discord.ButtonStyle.success, emoji="🔊", custom_id="imza:btn_show_voice_say")
    async def voice_say_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        file, embed = await get_voice_say_file_and_embed(interaction.guild)
        await interaction.followup.send(file=file, embed=embed, ephemeral=True)

    @discord.ui.button(label="Genel Sayım", style=discord.ButtonStyle.primary, emoji="📊", custom_id="imza:btn_show_say")
    async def say_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        file, embed = await get_say_file_and_embed(interaction.guild)
        await interaction.followup.send(file=file, embed=embed, ephemeral=True)

# ─────────────────────────────────────────────
# SECRET (ÖZEL) ODA SİSTEMİ VERİLERİ & MODALLARI
# ─────────────────────────────────────────────
SECRET_ROOMS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "secret_rooms.json")

def load_secret_rooms() -> dict:
    if os.path.exists(SECRET_ROOMS_FILE):
        try:
            with open(SECRET_ROOMS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return {int(k): v for k, v in data.items()}
        except Exception:
            pass
    return {}

def save_secret_rooms(data: dict):
    try:
        with open(SECRET_ROOMS_FILE, "w", encoding="utf-8") as f:
            json.dump({str(k): v for k, v in data.items()}, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

secret_rooms = load_secret_rooms()
VIP_CAT_COOLDOWN = {}
ROOM_RENAME_HISTORY = {}

def get_room_data(channel_id: int) -> dict:
    global secret_rooms
    fresh = load_secret_rooms()
    secret_rooms.update(fresh)
    return secret_rooms.get(int(channel_id)) or secret_rooms.get(str(channel_id)) or {}

def set_room_data(channel_id: int, **kwargs):
    global secret_rooms
    secret_rooms = load_secret_rooms()
    ch_key = int(channel_id)
    if ch_key not in secret_rooms:
        secret_rooms[ch_key] = {}
    secret_rooms[ch_key].update(kwargs)
    save_secret_rooms(secret_rooms)

def remove_room_data(channel_id: int):
    global secret_rooms
    secret_rooms = load_secret_rooms()
    secret_rooms.pop(int(channel_id), None)
    secret_rooms.pop(str(channel_id), None)
    save_secret_rooms(secret_rooms)

def get_room_token(channel_id: int) -> str:
    """Oda için geçerli web erişim anahtarını (token) döner, yoksa üretip kaydeder."""
    data = get_room_data(channel_id)
    token = data.get("web_token")
    if not token:
        token = secrets.token_urlsafe(16)
        set_room_data(channel_id, web_token=token)
    return token

ACTIVE_WEB_URL = None
SERVER_PUBLIC_IP = None

def get_server_public_ip_url() -> str:
    global SERVER_PUBLIC_IP
    port = int(config.get("secret_web_port", 8082))
    if not SERVER_PUBLIC_IP:
        try:
            with urllib.request.urlopen("https://api.ipify.org", timeout=2) as resp:
                SERVER_PUBLIC_IP = resp.read().decode('utf-8').strip()
        except Exception:
            SERVER_PUBLIC_IP = "188.119.11.236"
    return f"http://{SERVER_PUBLIC_IP}:{port}"

def get_room_web_url(channel_id: int, user_id: int = None) -> str:
    """Odaya ait tam web kontrol paneli URL'sini üretir (Cloudflare HTTPS veya Public IP)."""
    global ACTIVE_WEB_URL
    base_url = ACTIVE_WEB_URL
    if not base_url or "localhost" in base_url or "127.0.0.1" in base_url:
        saved = config.get("secret_web_base_url", "").strip()
        if saved and "trycloudflare.com" not in saved and "localhost" not in saved and "127.0.0.1" not in saved:
            base_url = saved
        else:
            base_url = get_server_public_ip_url()
    token = get_room_token(channel_id)
    uid_param = f"&uid={user_id}" if user_id else ""
    return f"{base_url.rstrip('/')}/secret/{channel_id}?token={token}{uid_param}"

SECRET_ADMIN_TOKEN = None
ADMIN_USER_SESSIONS = {}

def get_secret_admin_token() -> str:
    """Tüm secret odaları yöneten master admin için güvenli erişim anahtarı."""
    global SECRET_ADMIN_TOKEN
    if not SECRET_ADMIN_TOKEN:
        token = config.get("secret_admin_token")
        if not token:
            token = secrets.token_urlsafe(24)
            config["secret_admin_token"] = token
            save_config(config)
        SECRET_ADMIN_TOKEN = token
    return SECRET_ADMIN_TOKEN

def create_user_admin_token(user_id: int) -> str:
    """Belirli bir yönetici kullanıcısına özel token üretir."""
    token = secrets.token_urlsafe(24)
    ADMIN_USER_SESSIONS[token] = {
        "user_id": int(user_id),
        "created_at": time.time()
    }
    return token

async def validate_admin_access(token: str, uid_override: int = None) -> tuple[bool, str]:
    """Token ve kullanıcının yetkisini doğrular. Yetkisi çekilmişse False döner."""
    if not token:
        return False, "Erişim anahtarı eksik."
    
    sess = ADMIN_USER_SESSIONS.get(token)
    user_id = uid_override or (sess.get("user_id") if sess else None)
    
    master_token = get_secret_admin_token()
    is_master = (token == master_token)
    
    if not sess and not is_master:
        return False, "Geçersiz veya süresi dolmuş erişim anahtarı."
        
    # Kullanıcı sunucuda hâlâ yetkili mi?
    if user_id and bot.guilds:
        guild = bot.guilds[0]
        member = guild.get_member(int(user_id))
        if not member:
            try:
                member = await guild.fetch_member(int(user_id))
            except Exception:
                member = None
        if not member or not is_secret_admin(member):
            ADMIN_USER_SESSIONS.pop(token, None)
            return False, "Yönetici yetkiniz (<@&0>) Discord üzerinden kaldırıldığı için oturumunuz otomatik olarak sonlandırıldı."

    return True, "Yetkili"

def get_secret_admin_web_url(user_id: int = None) -> str:
    """Tüm secret odaları gösteren canlı Master Yönetici Hub'ı URL'sini üretir."""
    global ACTIVE_WEB_URL
    base_url = ACTIVE_WEB_URL
    if not base_url or "localhost" in base_url or "127.0.0.1" in base_url:
        saved = config.get("secret_web_base_url", "").strip()
        if saved and "trycloudflare.com" not in saved and "localhost" not in saved and "127.0.0.1" not in saved:
            base_url = saved
        else:
            base_url = get_server_public_ip_url()
    token = create_user_admin_token(user_id) if user_id else get_secret_admin_token()
    uid_param = f"&uid={user_id}" if user_id else ""
    return f"{base_url.rstrip('/')}/secret-admin?token={token}{uid_param}"

def get_secret_admin_direct_ip_url(user_id: int = None) -> str:
    """Yönetici için doğrudan sunucu IP adresiyle erişim linki döner (Yedek)."""
    pub_url = get_server_public_ip_url()
    token = create_user_admin_token(user_id) if user_id else get_secret_admin_token()
    uid_param = f"&uid={user_id}" if user_id else ""
    return f"{pub_url.rstrip('/')}/secret-admin?token={token}{uid_param}"

def is_secret_admin(user: discord.Member) -> bool:
    """Kullanıcının 0 rolüne sahip veya yönetici olup olmadığını denetler."""
    if not user or not isinstance(user, discord.Member):
        return False
    if user.guild_permissions.administrator or (user.guild and user.id == user.guild.owner_id):
        return True
    admin_role_id = int(config.get("secret_admin_rol_id", 0))
    return any(r.id == admin_role_id for r in user.roles)

def is_secret_room(channel: discord.VoiceChannel) -> bool:
    """Bir ses kanalının Secret Oda olup olmadığını denetler."""
    if not channel or not isinstance(channel, (discord.VoiceChannel, discord.StageChannel)):
        return False
    data = load_secret_rooms()
    if channel.id in data or str(channel.id) in data:
        return True
    cat_id = config.get("secret_kategori_id")
    vip_cat_id = config.get("vip_kategori_id")
    giris_id = config.get("secret_giris_kanal_id")
    if cat_id and channel.category_id == int(cat_id):
        if not giris_id or channel.id != int(giris_id):
            return True
    if vip_cat_id and channel.category_id == int(vip_cat_id):
        return True
    return False

def is_room_controller(channel: discord.VoiceChannel, user: discord.Member) -> bool:
    """Kullanıcının odayı açan kişi, devralan kişi veya odanın özel izinli yöneticisi olup olmadığını doğrular."""
    if not channel or not user:
        return False

    room_info = get_room_data(channel.id)

    # 1. Devralan veya aktif sahip mi?
    active_owner = room_info.get("transferred_to") or room_info.get("owner_id")
    if active_owner and int(user.id) == int(active_owner):
        return True

    # 2. Henüz devredilmemişse odayı ilk açan kişi mi?
    transferred_to = room_info.get("transferred_to")
    if not transferred_to or int(transferred_to) == int(user.id):
        creator_id = room_info.get("creator_id")
        if creator_id and int(user.id) == int(creator_id):
            return True

    # 3. Kanal özel izinlerinde (overwrites) kullanıcıya ait özel izin var mı?
    # (Oda sahibinin web panelinden veya Discord'dan 'Özel İzin' verdiği üyeler)
    for target, target_ow in channel.overwrites.items():
        if isinstance(target, (discord.Member, discord.User)) and target.id == user.id:
            # Engellenmişse (connect=False) kesinlikle yetkili değildir
            if target_ow.connect is False:
                return False
            # Özel izin verilmişse (connect, view, manage, move) yetkilidir
            if (target_ow.connect is True or target_ow.view_channel is True or 
                target_ow.manage_channels is True or target_ow.move_members is True):
                return True

    return False

def render_secret_panel_card(logo_bytes: bytes = None) -> io.BytesIO:
    """Pillow motoruyla HD çözünürlükte Priv Secret Oda Web Kontrol Paneli görseli çizer."""
    W, H = 960, 440
    img = Image.new('RGBA', (W, H), (8, 10, 16, 255))
    draw = ImageDraw.Draw(img)

    # Dış çerçeve ve koyu priv arka plan
    draw.rounded_rectangle([(10, 10), (W - 10, H - 10)], radius=20, fill=(13, 16, 26, 255), outline=(42, 50, 75, 255), width=2)
    draw.line([(35, 12), (W - 35, 12)], fill=(99, 102, 241, 240), width=2)

    font_tag = get_card_font(bold=True, size=11)
    font_title = get_card_font(bold=True, size=24)
    font_sub = get_card_font(bold=False, size=13)
    font_pill = get_card_font(bold=True, size=11)
    font_cat = get_card_font(bold=True, size=13)
    font_badge = get_card_font(bold=True, size=10)
    font_desc = get_card_font(bold=False, size=11)
    font_note_bold = get_card_font(bold=True, size=12)
    font_note = get_card_font(bold=False, size=12)

    # Logo / Avatar
    text_x = 38
    logo_size = 56
    if logo_bytes:
        try:
            l_raw = Image.open(io.BytesIO(logo_bytes)).convert('RGBA')
            l_raw = l_raw.resize((logo_size, logo_size), Image.Resampling.LANCZOS)
            l_mask = Image.new('L', (logo_size, logo_size), 0)
            l_draw = ImageDraw.Draw(l_mask)
            l_draw.rounded_rectangle([(0, 0), (logo_size, logo_size)], radius=14, fill=255)
            l_raw.putalpha(l_mask)
            img.paste(l_raw, (38, 26), l_raw)
            draw.rounded_rectangle([(36, 24), (38 + logo_size + 2, 26 + logo_size + 2)], radius=16, outline=(99, 102, 241, 180), width=2)
            text_x = 38 + logo_size + 16
        except Exception:
            text_x = 38

    # Başlık Alanı
    draw.text((text_x, 26), 'SECRET VOICE CONTROL CENTER', fill=(148, 163, 184, 255), font=font_tag)
    draw.text((text_x, 44), 'SECRET CONTROL PANEL', fill=(255, 255, 255, 255), font=font_title)
    draw.text((38, 86), 'Odanızı aşağıdaki Web Paneli butonuna tıklayarak canlı siteden özelleştirebilir ve yönetebilirsiniz.', fill=(148, 156, 178, 255), font=font_sub)

    # Sağ Rozet (Yeşil Canlı Gösterge)
    pill_text = 'CANLI WEB DASHBOARD'
    pw = int(draw.textlength(pill_text, font=font_pill)) + 36
    px = W - 38 - pw
    py = 35
    draw.rounded_rectangle([(px, py), (px + pw, py + 30)], radius=15, fill=(16, 185, 129, 25), outline=(16, 185, 129, 120))
    draw.ellipse([(px + 12, py + 11), (px + 20, py + 19)], fill=(52, 211, 153, 255))
    draw.text((px + 27, py + 7), pill_text, fill=(52, 211, 153, 255), font=font_pill)

    # Ayırıcı Çizgi
    draw.line([(38, 114), (W - 38, 114)], fill=(28, 34, 52, 255), width=1)

    # 3 Özellik Kolonu
    cols = [
        ('ODA AYARLARI', (56, 189, 248), (22, 36, 52), [
            ('İSİM DEĞİŞTİR', 'Oda ismini tarayıcıdan anında değiştirin'),
            ('KİŞİ LİMİTİ', 'Limitsiz veya özel kişi sınırı belirleyin'),
            ('KİLİT & GİZLE', 'Odayı tek tıkla kilitleyin veya gizleyin')
        ]),
        ('ERİŞİM & GÜVENLİK', (52, 211, 153), (20, 42, 36), [
            ('ÜYE ARAMA', 'Sunucudaki arkadaşlarınızı canlı arayın'),
            ('ÖZEL İZİN', 'Seçilen kişilere odaya özel giriş hakkı verin'),
            ('ENGELLE & AT', 'İstenmeyen üyeleri anında atıp yasaklayin')
        ]),
        ('HIZLI KONTROLLER', (251, 146, 60), (44, 32, 24), [
            ('DAVET LİNKİ', 'Anlık davet bağlantısı üretip kopyalayın'),
            ('DEVRET', 'Oda sahipliğini arkadaşınıza aktarın'),
            ('ODAYI KAPAT', 'Odanızı ve ses kanalını anında sonlandırın')
        ])
    ]

    start_x = 38
    col_w = 282
    spacing = 19
    card_y = 126
    card_h = 222

    for i, (ct, cc, cbg, items) in enumerate(cols):
        cx = start_x + i * (col_w + spacing)
        draw.rounded_rectangle([(cx, card_y), (cx + col_w, card_y + card_h)], radius=14, fill=(18, 22, 34, 255), outline=(35, 42, 62, 255), width=1)
        
        # Kolon Başlık Barı
        draw.rounded_rectangle([(cx + 2, card_y + 2), (cx + col_w - 2, card_y + 38)], radius=12, fill=cbg)
        draw.line([(cx + 12, card_y + 11), (cx + 12, card_y + 29)], fill=cc, width=3)
        draw.text((cx + 22, card_y + 11), ct, fill=cc, font=font_cat)

        for j, (it, idesc) in enumerate(items):
            iy = card_y + 46 + j * 56
            draw.rounded_rectangle([(cx + 8, iy), (cx + col_w - 8, iy + 48)], radius=8, fill=(14, 17, 26, 255), outline=(26, 31, 46, 255), width=1)
            bw = int(draw.textlength(it, font=font_badge)) + 12
            draw.rounded_rectangle([(cx + 14, iy + 6), (cx + 14 + bw, iy + 20)], radius=4, fill=(24, 29, 44, 255))
            draw.text((cx + 20, iy + 7), it, fill=cc, font=font_badge)
            draw.text((cx + 14, iy + 25), idesc, fill=(185, 194, 212, 255), font=font_desc)

    # Alt Bilgi Notu Kutusu
    note_y = 360
    note_h = 56
    draw.rounded_rectangle([(38, note_y), (W - 38, note_y + note_h)], radius=12, fill=(18, 22, 34, 255), outline=(36, 42, 64, 255), width=1)
    draw.rounded_rectangle([(38, note_y), (42, note_y + note_h)], radius=2, fill=(99, 102, 241, 255))

    draw.text((56, note_y + 11), 'KULLANIM REHBERİ:', fill=(99, 102, 241, 255), font=font_note_bold)
    draw.text((200, note_y + 11), 'Aşağıdaki [Web Paneli] butonuna tıklayarak odanızı tarayıcıda anında açabilirsiniz.', fill=(205, 212, 230, 255), font=font_note)
    draw.text((56, note_y + 32), 'Kanal izinleri ve oda durumu Web Dashboard ile Discord arasında anlık senkronize edilir.', fill=(130, 140, 165, 255), font=font_desc)

    out = io.BytesIO()
    img.save(out, format='PNG')
    out.seek(0)
    return out

def render_web_dashboard_preview_card(room_name: str, owner_name: str, room_id: int, web_url: str) -> io.BytesIO:
    """Web kontrol panelinin Discord embedleri için ultra lüks mockup görselini çizer."""
    W, H = 960, 520
    img = Image.new('RGBA', (W, H), (8, 10, 16, 255))
    draw = ImageDraw.Draw(img)

    # Dış kart çerçevesi ve parıltı
    draw.rounded_rectangle([(10, 10), (W - 10, H - 10)], radius=22, fill=(13, 16, 26, 255), outline=(42, 50, 75, 220), width=2)
    draw.line([(35, 12), (W - 35, 12)], fill=(99, 102, 241, 240), width=2)

    # Tarayıcı pencere başlığı
    draw.rounded_rectangle([(24, 24), (W - 24, 68)], radius=14, fill=(18, 22, 36, 255), outline=(32, 40, 62, 255), width=1)
    draw.ellipse([(42, 42), (52, 52)], fill=(239, 68, 68, 255))
    draw.ellipse([(60, 42), (70, 52)], fill=(245, 158, 11, 255))
    draw.ellipse([(78, 42), (88, 52)], fill=(16, 185, 129, 255))

    f_title = get_card_font(bold=True, size=24)
    f_sub = get_card_font(bold=False, size=13)
    f_badge = get_card_font(bold=True, size=11)
    f_card_t = get_card_font(bold=True, size=15)
    f_code = get_card_font(bold=False, size=12)

    clean_url = web_url.split('?')[0] if '?' in web_url else web_url
    if len(clean_url) > 55:
        clean_url = clean_url[:55] + '...'

    draw.rounded_rectangle([(110, 34), (W - 140, 58)], radius=8, fill=(11, 13, 20, 255), outline=(38, 46, 68, 255), width=1)
    draw.text((125, 38), clean_url, fill=(148, 163, 184, 255), font=f_code)

    draw.rounded_rectangle([(W - 125, 35), (W - 36, 57)], radius=8, fill=(16, 185, 129, 35), outline=(16, 185, 129, 120))
    draw.ellipse([(W - 116, 43), (W - 110, 49)], fill=(52, 211, 153, 255))
    draw.text((W - 104, 38), 'CANLI', fill=(52, 211, 153, 255), font=f_badge)

    # Oda Hero Kartı
    draw.rounded_rectangle([(24, 80), (W - 24, 188)], radius=16, fill=(19, 24, 40, 255), outline=(38, 46, 72, 255), width=1)

    # Equalizer Ses Kutusu
    draw.rounded_rectangle([(40, 96), (104, 160)], radius=14, fill=(26, 32, 54, 255), outline=(99, 102, 241, 160), width=1)
    bcolors = [(6, 182, 212), (99, 102, 241), (168, 85, 247), (16, 185, 129), (6, 182, 212)]
    bh = [20, 36, 28, 42, 22]
    for idx, (bc, h) in enumerate(zip(bcolors, bh)):
        bx = 49 + idx * 10
        draw.rounded_rectangle([(bx, 150 - h), (bx + 5, 150)], radius=3, fill=bc)

    clean_room_name = room_name.replace('🔒', '').replace('🔓', '').strip()
    draw.text((122, 98), f"{clean_room_name} Priv Ses Odasi", fill=(255, 255, 255, 255), font=f_title)
    draw.text((122, 133), f"Oda Sahibi: {owner_name}   |   Kapasite: Limitsiz   |   ID: {room_id}", fill=(148, 163, 184, 255), font=f_sub)

    # Rozetler
    draw.rounded_rectangle([(122, 156), (225, 178)], radius=6, fill=(16, 185, 129, 30), outline=(16, 185, 129, 100))
    draw.text((132, 160), 'HERKESE ACIK', fill=(52, 211, 153, 255), font=f_badge)

    draw.rounded_rectangle([(235, 156), (325, 178)], radius=6, fill=(56, 189, 248, 30), outline=(56, 189, 248, 100))
    draw.text((248, 160), 'GORUNUR', fill=(56, 189, 248, 255), font=f_badge)

    draw.rounded_rectangle([(335, 156), (460, 178)], radius=6, fill=(99, 102, 241, 30), outline=(99, 102, 241, 100))
    draw.text((345, 160), 'CANLI SES AKTIF', fill=(165, 180, 252, 255), font=f_badge)

    # Sağ Hızlı Buton
    draw.rounded_rectangle([(W - 230, 105), (W - 42, 155)], radius=12, fill=(99, 102, 241, 240))
    draw.text((W - 210, 120), 'WEB DASHBOARD', fill=(255, 255, 255, 255), font=f_card_t)

    # 3 Kolon
    cols = [
        ('ODA AYARLARI', (56, 189, 248), [
            ('ISIM DEGISTIR', 'Oda ismini tarayicidan yazip aninda degistirin'),
            ('KISI LIMITI', 'Limitsiz, 2, 5, 10 kisi veya slider ile secin'),
            ('KILIT & GIZLE', 'Odayi tek tikla kilitleyin veya listede gizleyin')
        ]),
        ('ERISIM & IZINLER', (52, 211, 153), [
            ('UYE ARAMA', 'Sunucudaki arkadaslarini hizli arayip bulun'),
            ('OZEL IZIN', 'Secilen kisilere odaya ozel giris hakki verin'),
            ('ENGELLE & AT', 'Istenmeyen kisileri aninda atip yasaklayin')
        ]),
        ('HIZLI ISLEMLER', (251, 146, 60), [
            ('DAVET LINKI', 'Anlik davet linki uretip tek tikla panoya kopyalayin'),
            ('DEVRET', 'Oda sahipligini odadaki arkadasiniza aktarin'),
            ('ODAYI KAPAT', 'Odayi ve ses kanalini tek tikla sonlandirin')
        ])
    ]
    cw = 288
    for i, (ct, cc, items) in enumerate(cols):
        cx = 24 + i * (cw + 24)
        draw.rounded_rectangle([(cx, 202), (cx + cw, 465)], radius=14, fill=(16, 20, 32, 255), outline=(32, 38, 58, 255), width=1)
        draw.rounded_rectangle([(cx + 2, 204), (cx + cw - 2, 244)], radius=12, fill=(24, 30, 48, 255))
        draw.line([(cx + 14, 214), (cx + 14, 234)], fill=cc, width=3)
        draw.text((cx + 24, 215), ct, fill=cc, font=f_card_t)

        for j, (it, idesc) in enumerate(items):
            iy = 255 + j * 66
            draw.rounded_rectangle([(cx + 10, iy), (cx + cw - 10, iy + 56)], radius=10, fill=(20, 25, 40, 255), outline=(32, 38, 60, 255), width=1)
            bw = int(draw.textlength(it, font=f_badge)) + 12
            draw.rounded_rectangle([(cx + 18, iy + 8), (cx + 18 + bw, iy + 24)], radius=4, fill=(28, 34, 54, 255))
            draw.text((cx + 24, iy + 10), it, fill=cc, font=f_badge)
            draw.text((cx + 18, iy + 32), idesc[:36], fill=(160, 174, 192, 255), font=f_sub)

    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    draw.text((36, 483), f'{bot_name}  -  SECRET VOICE WEB CONTROL HUB  -  7/24 CANLI WEB YONETIMI', fill=(100, 116, 139, 255), font=f_badge)

    out = io.BytesIO()
    img.save(out, format='PNG')
    out.seek(0)
    return out

async def get_web_dashboard_preview_file(room_name: str, owner_name: str, room_id: int, web_url: str) -> discord.File:
    img_buf = await asyncio.to_thread(render_web_dashboard_preview_card, room_name, owner_name, room_id, web_url)
    return discord.File(fp=img_buf, filename="web_dashboard_preview.png")

async def get_secret_panel_card_file(guild: discord.Guild = None) -> discord.File:
    """Sunucu logosunu da dahil ederek görsel kart dosyasını asenkron üretir."""
    logo_bytes = None
    if guild:
        logo_url = get_brand_logo_url(guild)
        if logo_url:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(str(logo_url), timeout=aiohttp.ClientTimeout(total=4)) as resp:
                        if resp.status == 200:
                            logo_bytes = await resp.read()
            except Exception as e:
                print(f"[Secret Panel Logo Hatası]: {e}", flush=True)

    img_buf = await asyncio.to_thread(render_secret_panel_card, logo_bytes)
    return discord.File(fp=img_buf, filename="secret_control_panel.png")

def build_permanent_secret_panel_embed(guild: discord.Guild) -> discord.Embed:
    """Metin kanalında durabilecek estetik ɨ̇ ʍ ʐ ǟ Secret Oda kontrol paneli embedi."""
    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    embed = discord.Embed(
        title=f"🌐 {bot_name} ✦ SECRET KONTROL MERKEZİ",
        description=(
            "> **Özel ses odanızı** aşağıdaki **[Web Paneli]** butonuna tıklayarak tarayıcınızdan canlı ve görsel olarak yönetebilirsiniz.\n\n"
            "### 💎 CANLI WEB DASHBOARD ÖZELLİKLERİ\n"
            "› ✏️ **Oda Ayarları:** Odanızın ismini ve kişi limitini tarayıcıdan anında değiştirin.\n"
            "› 🔒 **Kilit & Gizlilik:** Odanızı tek tıkla kilitleyin veya listede diğer üyelerden gizleyin.\n"
            "› 👥 **Erişim & İzinler:** Sunucudaki arkadaşlarınızı arayıp özel giriş izni verin veya engelleyin.\n"
            "› 👑 **Oda Devri & Davet:** Tek tıkla davet bağlantısı oluşturun veya oda sahipliğini devredin.\n\n"
            "> *Aşağıdaki [Web Paneli] butonu yalnızca aktif Secret Odaya sahip olan oda sahibine özeldir.*"
        ),
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_footer(text=f"{bot_name} • 7/24 Canlı Web Yönetim Arayüzü")
    return embed

async def send_interaction_msg(interaction: discord.Interaction, content: str, ephemeral: bool = True):
    """Etkileşim yanıtını defer durumuna göre güvenli bir şekilde gönderir."""
    try:
        if interaction.response.is_done():
            await interaction.followup.send(content, ephemeral=ephemeral)
        else:
            await interaction.response.send_message(content, ephemeral=ephemeral)
    except Exception:
        pass

async def get_controlled_room(interaction: discord.Interaction) -> discord.VoiceChannel | None:
    """Oda sahibinin veya odayı devralan kişinin paneli kullanmasını sağlar."""
    user = interaction.user
    if not isinstance(user, discord.Member):
        user = interaction.guild.get_member(user.id) or user

    guild = interaction.guild
    if not guild:
        return None

    # 1. Kullanıcı şu an bir ses kanalında mı?
    user_voice_ch = user.voice.channel if (user.voice and user.voice.channel) else None

    # Eğer kullanıcı bir secret odadaysa
    if user_voice_ch and is_secret_room(user_voice_ch):
        if is_room_controller(user_voice_ch, user):
            return user_voice_ch
        else:
            # Odadaki başka bir üye butona bastıysa engelle
            room_info = get_room_data(user_voice_ch.id)
            owner_id = room_info.get("owner_id") or room_info.get("transferred_to")
            owner_member = guild.get_member(int(owner_id)) if owner_id else None
            owner_name = owner_member.display_name if owner_member else "Oda Sahibi"
            await send_interaction_msg(
                interaction,
                f"❌ **Bu butonlar yalnızca oda sahibi ({owner_name}) veya odaya özel izinli üyelere aittir!**\n"
                f"Oda yetkilisi sen olmadığın için bu paneli açamazsın."
            )
            return None

    # 2. Eğer kullanıcı o an seste değilse veya genel ses odasındaysa,
    # sunucuda açtığı veya kendisine devredilen aktif bir secret oda var mı bakalım
    for ch in guild.voice_channels:
        if is_secret_room(ch) and is_room_controller(ch, user):
            return ch

    # 3. Hiçbir aktif oda bulunamadı
    await send_interaction_msg(
        interaction,
        "⚠️ **Sana ait veya sana devredilen aktif bir Secret Oda bulunamadı!**\n"
        "Paneldeki butonları kullanabilmek için önce **tıkla-aç** kanalına tıklayıp kendi odanı oluşturmalısın ya da devraldığın odaya katılmalısın."
    )
    return None

# ─────────────────────────────────────────────
# MODALLAR (İSİM & LİMİT DÜZENLEME)
# ─────────────────────────────────────────────
class RenameRoomModal(discord.ui.Modal, title="Oda İsmi Değiştir"):
    new_name = discord.ui.TextInput(
        label="Yeni Oda İsmi",
        placeholder="Örn: 🖤 6Closy Priv",
        max_length=40,
        required=True
    )

    async def on_submit(self, interaction: discord.Interaction):
        ch = await get_controlled_room(interaction)
        if not ch:
            return

        name_val = self.new_name.value.strip()
        if not name_val:
            await interaction.response.send_message("⚠️ Geçerli bir isim girmelisin.", ephemeral=True)
            return

        await ch.edit(name=name_val)
        await interaction.response.send_message(f"✅ Odanızın ismi **'{name_val}'** olarak güncellendi!", ephemeral=True)

class LimitRoomModal(discord.ui.Modal, title="Oda Kişi Limiti"):
    limit_input = discord.ui.TextInput(
        label="Kişi Limiti (0: Limitsiz, 1-99)",
        placeholder="0",
        max_length=2,
        required=True
    )

    async def on_submit(self, interaction: discord.Interaction):
        ch = await get_controlled_room(interaction)
        if not ch:
            return

        val = self.limit_input.value.strip()
        if not val.isdigit() or int(val) < 0 or int(val) > 99:
            await interaction.response.send_message("⚠️ Lütfen 0 ile 99 arasında bir sayı girin (0: Limitsiz).", ephemeral=True)
            return

        limit_num = int(val)
        await ch.edit(user_limit=limit_num)
        limit_text = "Limitsiz" if limit_num == 0 else f"{limit_num} kişi"
        await interaction.response.send_message(f"✅ Odanızın kişi limiti **{limit_text}** olarak ayarlandı!", ephemeral=True)

# ─────────────────────────────────────────────
# KULLANICI SEÇİM MENÜLERİ (İZİN / ENGEL / DEVRET)
# ─────────────────────────────────────────────
class RoomTrustSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.select(cls=discord.ui.UserSelect, placeholder="Odaya özel giriş izni vermek istediğin kişiyi seç...")
    async def select_user(self, interaction: discord.Interaction, select: discord.ui.UserSelect):
        ch = await get_controlled_room(interaction)
        if not ch or not select.values:
            return
        target_user = select.values[0]
        target_member = interaction.guild.get_member(target_user.id) or target_user
        await ch.set_permissions(target_member, connect=True, view_channel=True, manage_channels=True, move_members=True)
        await interaction.response.send_message(f"✅ {target_user.mention} için odaya özel izin verildi!", ephemeral=True)

class RoomUntrustSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.select(cls=discord.ui.UserSelect, placeholder="Özel giriş iznini kaldırmak istediğin kişiyi seç...")
    async def select_user(self, interaction: discord.Interaction, select: discord.ui.UserSelect):
        ch = await get_controlled_room(interaction)
        if not ch or not select.values:
            return
        target_user = select.values[0]
        target_member = interaction.guild.get_member(target_user.id) or target_user
        await ch.set_permissions(target_member, overwrite=None)
        await interaction.response.send_message(f"➖ {target_user.mention} kullanıcısının özel izni kaldırıldı.", ephemeral=True)

class RoomBlockSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.select(cls=discord.ui.UserSelect, placeholder="Odadan atıp engellemek istediğin kişiyi seç...")
    async def select_user(self, interaction: discord.Interaction, select: discord.ui.UserSelect):
        ch = await get_controlled_room(interaction)
        if not ch or not select.values:
            return
        target_user = select.values[0]
        target_member = interaction.guild.get_member(target_user.id) or target_user
        await ch.set_permissions(target_member, connect=False)
        if isinstance(target_member, discord.Member) and target_member.voice and target_member.voice.channel == ch:
            try:
                await target_member.move_to(None)
            except Exception:
                pass
        await interaction.response.send_message(f"⛔ {target_user.mention} engellendi ve odadan atıldı!", ephemeral=True)

class RoomUnblockSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.select(cls=discord.ui.UserSelect, placeholder="Engeli kaldırmak istediğin kişiyi seç...")
    async def select_user(self, interaction: discord.Interaction, select: discord.ui.UserSelect):
        ch = await get_controlled_room(interaction)
        if not ch or not select.values:
            return
        target_user = select.values[0]
        target_member = interaction.guild.get_member(target_user.id) or target_user
        await ch.set_permissions(target_member, overwrite=None)
        await interaction.response.send_message(f"🛡️ {target_user.mention} kullanıcısının engeli kaldırıldı!", ephemeral=True)

class RoomTransferSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.select(cls=discord.ui.UserSelect, placeholder="Oda sahipliğini devretmek istediğin kişiyi seç...")
    async def select_user(self, interaction: discord.Interaction, select: discord.ui.UserSelect):
        await interaction.response.defer(ephemeral=True)
        ch = await get_controlled_room(interaction)
        if not ch or not select.values:
            return
        new_owner = select.values[0]
        if new_owner.id == interaction.user.id:
            await interaction.followup.send("⚠️ Zaten bu odanın sahibisiniz!", ephemeral=True)
            return

        # Oda yetkilisini hem owner_id hem transferred_to olarak güncelle & yeni web_token üret
        new_token = secrets.token_urlsafe(16)
        set_room_data(ch.id, owner_id=new_owner.id, transferred_to=new_owner.id, web_token=new_token)

        target_member = interaction.guild.get_member(new_owner.id)
        if not target_member:
            try:
                target_member = await interaction.guild.fetch_member(new_owner.id)
            except Exception:
                target_member = new_owner

        try:
            await ch.set_permissions(interaction.user, overwrite=None)
        except Exception:
            pass
        try:
            await ch.set_permissions(target_member, connect=True, view_channel=True, manage_channels=True, move_members=True)
        except Exception:
            pass

        panel_ch_id = config.get("secret_panel_kanal_id")
        panel_mention = f"<#{panel_ch_id}>" if panel_ch_id else "#secret-panel"
        new_panel_url = get_room_web_url(ch.id)

        # 1. Oda sohbetine etiket atarak duyur
        try:
            embed_room = discord.Embed(
                title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ✦ Oda Sahipliği Devredildi 👑",
                description=(
                    f"Bu odanın yönetimi {interaction.user.mention} tarafından {new_owner.mention} kullanıcısına devredildi!\n\n"
                    f"› **Yeni Oda Sahibi:** {new_owner.mention}\n"
                    f"› **Web Kontrol Paneli:** Aşağıdaki butona tıklayarak odanızı web üzerinden yönetebilirsiniz."
                ),
                color=get_embed_color(),
                timestamp=datetime.now(timezone.utc)
            )
            logo = get_brand_logo_url(interaction.guild)
            if logo:
                embed_room.set_thumbnail(url=logo)
            embed_room.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Secret Oda Devir")
            
            web_view = discord.ui.View()
            web_view.add_item(discord.ui.Button(label="Web Paneli", url=new_panel_url, style=discord.ButtonStyle.link))
            await ch.send(content=f"👑 {new_owner.mention} **Oda artık senin!**", embed=embed_room, view=web_view)
        except Exception as e:
            print(f"[Oda Devir Sohbet Bildirimi Hatası]: {e}")

        # 2. Devralan kişiye DM'den bildirim gönder
        try:
            embed_dm = discord.Embed(
                title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ✦ Oda Sahipliği Sana Devredildi! 👑",
                description=(
                    f"Selam {new_owner.mention}!\n\n"
                    f"**{interaction.guild.name}** sunucusundaki **{ch.name}** Secret Ses Odasının sahipliği "
                    f"{interaction.user.mention} tarafından sana devredildi.\n\n"
                    f"› Artık odanın tüm kontrolü sende!\n"
                    f"› Odanın ismini, limitini, kilidini veya izinlerini panel butonlarından ya da web panelinden dilediğin gibi yönetebilirsin."
                ),
                color=get_embed_color(),
                timestamp=datetime.now(timezone.utc)
            )
            logo = get_brand_logo_url(interaction.guild)
            if logo:
                embed_dm.set_thumbnail(url=logo)
            embed_dm.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Secret Voice Notification")
            dm_view = discord.ui.View()
            dm_view.add_item(discord.ui.Button(label="Web Paneli", url=new_panel_url, style=discord.ButtonStyle.link))
            await target_member.send(embed=embed_dm, view=dm_view)
        except Exception:
            pass

        await interaction.followup.send(
            f"👑 **Oda sahipliği başarıyla {new_owner.mention} kullanıcısına devredildi!**\n"
            f"Oda sohbetine duyuru atıldı ve eski web erişim yetkileri sıfırlandı.",
            ephemeral=True
        )

# ─────────────────────────────────────────────
# KALICI PANEL BUTONLARI (VIEW)
# ─────────────────────────────────────────────
class SecretRoomControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Web Paneli", style=discord.ButtonStyle.primary, custom_id="imza:secret_web")
    async def btn_web(self, interaction: discord.Interaction, button: discord.ui.Button):
        ch = await get_controlled_room(interaction)
        if not ch:
            return
        await interaction.response.defer(ephemeral=True)
        web_url = get_room_web_url(ch.id)
        room_info = get_room_data(ch.id)
        owner_id = room_info.get("owner_id") or room_info.get("transferred_to") or interaction.user.id
        owner_member = interaction.guild.get_member(int(owner_id)) if owner_id else interaction.user
        owner_name = owner_member.display_name if owner_member else interaction.user.display_name

        preview_file = await get_web_dashboard_preview_file(ch.name, owner_name, ch.id, web_url)
        bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
        embed = discord.Embed(
            title=f"🌐 {bot_name} ✦ CANLI WEB KONTROL PANELİ",
            description=(
                f"> **{ch.name}** odanız için ultra-lüks web kontrol paneliniz hazır!\n\n"
                f"› 👑 **Oda Sahibi:** {owner_member.mention}\n"
                f"› ⚡ **Özellikler:** Canlı ses dalgası equalizer, anlık üye arama/izin/engelleme, isim & limit değişimi, davet linki.\n"
                f"› 🔗 **Panel Adresi:** [Web Dashboard'u Açmak İçin Tıkla]({web_url})\n\n"
                f"Tarayıcınızdan odanızı canlı yönetmek için aşağıdaki **[Web Kontrol Panelini Aç ↗]** butonuna tıklayın!"
            ),
            color=get_embed_color(),
            timestamp=datetime.now(timezone.utc)
        )
        logo = get_brand_logo_url(interaction.guild)
        if logo:
            embed.set_thumbnail(url=logo)
        embed.set_image(url="attachment://web_dashboard_preview.png")
        embed.set_footer(text=f"{bot_name} • 7/24 Canlı Web Yönetim Arayüzü", icon_url=logo if logo else None)

        view = discord.ui.View()
        view.add_item(discord.ui.Button(label="Web Kontrol Panelini Aç ↗", url=web_url, style=discord.ButtonStyle.link))
        await interaction.followup.send(embed=embed, file=preview_file, view=view, ephemeral=True)

# ─────────────────────────────────────────────
# VIP AYRICALIKLARI & KONTROL PANELİ
# ─────────────────────────────────────────────
def render_vip_panel_card() -> io.BytesIO:
    """VIP Bilgi & İsim değiştirme paneli için şık koyu kart çizer."""
    W, H = 960, 320
    img = Image.new('RGBA', (W, H), (10, 11, 15, 255))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle([(10, 10), (W - 10, H - 10)], radius=20, fill=(16, 18, 26, 255), outline=(241, 196, 15, 180), width=2)
    draw.line([(35, 12), (W - 35, 12)], fill=(241, 196, 15, 220), width=2)
    font_title = get_card_font(bold=True, size=26)
    font_sub = get_card_font(bold=False, size=14)
    font_badge = get_card_font(bold=True, size=12)
    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    draw.text((38, 30), f"{bot_name}  •  VIP MEMBERSHIP INTERFACE", fill=(241, 196, 15, 255), font=font_badge)
    draw.text((38, 55), "VIP AYRICALIKLARI & İSİM KONTROL MERKEZİ", fill=(255, 255, 255, 255), font=font_title)
    draw.text((38, 105), "VIP üyelerimiz bu panel üzerinden diledikleri zaman isimlerini değiştirebilir ve özel ayrıcalıklarını görüntüleyebilir.", fill=(180, 185, 205, 255), font=font_sub)
    draw.rounded_rectangle([(38, 155), (W - 38, 265)], radius=12, fill=(20, 24, 38, 255), outline=(40, 48, 72, 255), width=1)
    draw.text((55, 175), "👑 VIP Ayrıcalıkları: Sınırsız İsim Değiştirme | Özel VIP Rolü | Öncelikli Ses Erişimi", fill=(241, 196, 15, 255), font=font_badge)
    draw.text((55, 210), "Aşağıdaki butonları kullanarak hemen isminizi güncelleyebilirsiniz.", fill=(150, 160, 180, 255), font=font_sub)
    out = io.BytesIO()
    img.save(out, format='PNG')
    out.seek(0)
    return out

async def get_vip_panel_card_file(guild: discord.Guild = None) -> discord.File:
    img_buf = await asyncio.to_thread(render_vip_panel_card)
    return discord.File(fp=img_buf, filename="vip_panel.png")

def build_vip_privileges_embed(guild: discord.Guild = None) -> discord.Embed:
    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    vip_role_id = config.get("vip_rol_id", 0)
    embed = discord.Embed(
        title=f"{bot_name} ✦ VIP AYRICALIKLARI",
        description=(
            f"> Sunucumuzda <@&{vip_role_id}> rolüne sahip olan değerli üyelerimiz için özel tanımlanmış ayrıcalıklar:\n\n"
            "✨ **Otomatik İsim Değiştirme:** Aşağıdaki butona tıklayarak dilediğiniz zaman isminizi özelleştirebilirsiniz.\n"
            "👑 **Özel VIP Rolü:** Sohbet ve listede belirgin altın rengi rozet.\n"
            "🔊 **Öncelikli Ses Erişimi:** Dolu odalara ve özel priv alanlarına katılma önceliği.\n\n"
            "*VIP ayrıcalıklarınızı kullanmak için aşağıdaki butona basabilirsiniz.*"
        ),
        color=0xf1c40f,
        timestamp=datetime.now(timezone.utc)
    )
    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_footer(text=f"{bot_name} • VIP Management")
    return embed

class VipChangeNickModal(discord.ui.Modal, title="VIP İsim Değiştir"):
    new_nick = discord.ui.TextInput(
        label="Yeni Kullanıcı Adınız (Nickname)",
        placeholder="Örn: ✦ Nick",
        max_length=32,
        required=True
    )
    async def on_submit(self, interaction: discord.Interaction):
        vip_role_id = config.get("vip_rol_id", 0)
        guild = interaction.guild
        member = interaction.user
        role = guild.get_role(int(vip_role_id))
        if not role or role not in member.roles:
            await interaction.response.send_message("❌ **Bu özelliği yalnızca VIP üyeler kullanabilir!**", ephemeral=True)
            return
        nick_val = self.new_nick.value.strip()
        try:
            await member.edit(nick=nick_val)
            await interaction.response.send_message(f"✅ İsminiz başarıyla **'{nick_val}'** olarak güncellendi!", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("❌ Yetki hatası: Botun rolü isminizi değiştirmeye yetmiyor (Rol sırasında bot daha üstte olmalıdır).", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ İsim değiştirilemedi: {e}", ephemeral=True)

class VipPrivilegesView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="İsim Değiştir", emoji="✏️", style=discord.ButtonStyle.primary, custom_id="imza:vip_btn_nick")
    async def btn_nick(self, interaction: discord.Interaction, button: discord.ui.Button):
        vip_role_id = config.get("vip_rol_id", 0)
        role = interaction.guild.get_role(int(vip_role_id))
        if not role or role not in interaction.user.roles:
            await interaction.response.send_message("❌ **Bu panel yalnızca VIP rolüne sahip üyelere özeldir!**", ephemeral=True)
            return
        await interaction.response.send_modal(VipChangeNickModal())

    @discord.ui.button(label="Ayrıcalıklar", emoji="👑", style=discord.ButtonStyle.secondary, custom_id="imza:vip_btn_info")
    async def btn_info(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = build_vip_privileges_embed(interaction.guild)
        await interaction.response.send_message(embed=embed, ephemeral=True)


# ─────────────────────────────────────────────
# ARKA PLAN GÖREVLERİ (BACKGROUND TASKS)
# ─────────────────────────────────────────────
@tasks.loop(seconds=15)
async def live_panel_update():
    """Canlı ses panelini düzenli aralıklarla otomatik günceller."""
    panel_ch_id = config.get("panel_kanal_id")
    panel_msg_id = config.get("panel_mesaj_id")

    if not panel_ch_id or not panel_msg_id:
        return

    try:
        channel = bot.get_channel(int(panel_ch_id))
        if not channel:
            channel = await bot.fetch_channel(int(panel_ch_id))
        if not channel:
            return

        msg = await channel.fetch_message(int(panel_msg_id))
        if msg:
            embed = build_voice_embed(channel.guild)
            view = VoiceRefreshView()
            await msg.edit(embed=embed, view=view)
    except discord.NotFound:
        config["panel_mesaj_id"] = None
        save_config(config)
    except Exception as e:
        pass

@tasks.loop(seconds=10)
async def keep_voice_connection():
    """Botu belirtilen ses kanalında (kulaklık kapalı, mic açık) 7/24 bağlı tutar."""
    target_ch_id = config.get("sabit_ses_kanal_id")
    if not target_ch_id:
        return

    try:
        channel = bot.get_channel(int(target_ch_id))
        if not channel:
            try:
                channel = await bot.fetch_channel(int(target_ch_id))
            except Exception:
                return
        if not channel or not isinstance(channel, (discord.VoiceChannel, discord.StageChannel)):
            return

        guild = channel.guild
        vc = guild.voice_client

        if vc is not None:
            if vc.is_connected() and vc.channel and vc.channel.id == channel.id:
                me_vs = guild.me.voice if guild.me else None
                if me_vs and (not me_vs.self_deaf or me_vs.self_mute):
                    try:
                        await guild.change_voice_state(channel=channel, self_mute=False, self_deaf=True)
                    except Exception:
                        pass
                return
            elif vc.is_connected() and vc.channel and vc.channel.id != channel.id:
                try:
                    await vc.move_to(channel)
                    await guild.change_voice_state(channel=channel, self_mute=False, self_deaf=True)
                    print(f"[Sabit Ses] Bot sabit kanala ({channel.name}) taşındı.", flush=True)
                    return
                except Exception:
                    pass

            # Ses istemcisi takılı veya kopmuşsa güvenle kapat
            try:
                await vc.disconnect(force=True)
            except Exception:
                pass
            await asyncio.sleep(1)

        # Kanala bağlan ve kulaklık kapalı, mikrofon açık ayarla
        try:
            await channel.connect(self_deaf=True, self_mute=False, reconnect=True)
            await asyncio.sleep(0.5)
            await guild.change_voice_state(channel=channel, self_mute=False, self_deaf=True)
            print(f"[Sabit Ses] {channel.name} kanalına bağlanıldı (Kulaklık: Kapalı, Mic: Açık).", flush=True)
        except Exception as e:
            print(f"[Sabit Ses Bağlantı Hatası]: {e}", flush=True)
    except Exception as e:
        print(f"[Sabit Ses Genel Hata]: {e}", flush=True)

@tasks.loop(seconds=20)
async def presence_rotation():
    """Botun durumunu 'Yayında' (Streaming - Mor Rozet) olarak dönerek günceller."""
    await bot.wait_until_ready()
    if not bot.guilds:
        return

    guild = bot.guilds[0]
    voice_count = sum(len(c.members) for c in guild.voice_channels) + sum(len(c.members) for c in guild.stage_channels)
    member_count = guild.member_count or len(guild.members)
    bot_adi = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    stream_url = config.get("stream_url", "https://www.twitch.tv/imzapriw")

    # 1. durum: Sesteki kişi (Yayında - Mor Rozet)
    try:
        activity1 = discord.Streaming(
            name=f"🎧 {voice_count} kişi seste | {bot_adi}",
            url=stream_url
        )
        await bot.change_presence(activity=activity1)
    except Exception as e:
        print(f"[Presence Hata 1]: {e}", flush=True)

    await asyncio.sleep(10)

    # 2. durum: Toplam üye (Yayında - Mor Rozet)
    try:
        activity2 = discord.Streaming(
            name=f"👥 {member_count} üye | {bot_adi}",
            url=stream_url
        )
        await bot.change_presence(activity=activity2)
    except Exception as e:
        print(f"[Presence Hata 2]: {e}", flush=True)

# ─────────────────────────────────────────────
# SES DEĞİŞİKLİĞİNDE ANLIK PANEL & SECRET ODA YÖNETİMİ
# ─────────────────────────────────────────────
@bot.event
async def on_voice_state_update(member, before, after):
    """Ses durumlarını dinler: Sabit ses koruması, Secret oda oluşturma, boşalan odayı silme."""
    # 0. BOT SABİT SES KORUMASI (Botu kanaldan düşürme / taşıma koruması)
    target_ch_id = config.get("sabit_ses_kanal_id")
    if target_ch_id and member.id == bot.user.id:
        if after.channel is None or after.channel.id != int(target_ch_id):
            await asyncio.sleep(1)
            target_ch = member.guild.get_channel(int(target_ch_id))
            if target_ch:
                vc = member.guild.voice_client
                try:
                    if vc and vc.is_connected():
                        await vc.move_to(target_ch)
                    else:
                        await target_ch.connect(self_deaf=True, self_mute=False, reconnect=True)
                except Exception:
                    pass

    # 1. SECRET ODA AÇMA (➕ Secret Oda Aç kanalına tıklandığında)
    giris_kanal_id = config.get("secret_giris_kanal_id")
    if after.channel and giris_kanal_id and after.channel.id == int(giris_kanal_id):
        guild = member.guild
        category = after.channel.category

        # Kanal İzinleri
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(connect=True, view_channel=True),
            member: discord.PermissionOverwrite(connect=True, view_channel=True, manage_channels=True, move_members=True),
            guild.me: discord.PermissionOverwrite(connect=True, view_channel=True, manage_channels=True, move_members=True)
        }

        try:
            room_name = f"🔒 {member.display_name}"
            new_room = await guild.create_voice_channel(
                name=room_name,
                category=category,
                overwrites=overwrites,
                reason=f"Secret oda oluşturuldu: {member.display_name}"
            )

            # Üyeyi yeni odaya taşı
            await member.move_to(new_room)

            # Kaydet
            web_token = secrets.token_urlsafe(16)
            set_room_data(new_room.id, owner_id=member.id, locked=False, hidden=False, web_token=web_token)
            web_url = get_room_web_url(new_room.id)

            panel_ch_id = config.get("secret_panel_kanal_id")
            panel_mention = f"<#{panel_ch_id}>" if panel_ch_id else "panel"
            try:
                preview_file = await get_web_dashboard_preview_file(new_room.name, member.display_name, new_room.id, web_url)
                bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
                embed_room = discord.Embed(
                    title=f"🌐 {bot_name} ✦ SECRET ODAN HAZIR & CANLI WEB PANELİ",
                    description=(
                        f"👑 Tebrikler {member.mention}, **{new_room.name}** odan başarıyla oluşturuldu!\n\n"
                        f"› 🎮 **Discord'dan Yönet:** {panel_mention} kanalındaki butonları kullanabilirsin.\n"
                        f"› 🌐 **Web'den Canlı Yönet:** Tarayıcından görsel arayüzle odayı yönetmek için aşağıdaki butona tıkla!\n"
                        f"› 🔗 **Link:** [Web Kontrol Panelini Aç]({web_url})"
                    ),
                    color=get_embed_color(),
                    timestamp=datetime.now(timezone.utc)
                )
                logo = get_brand_logo_url(guild)
                if logo:
                    embed_room.set_thumbnail(url=logo)
                embed_room.set_image(url="attachment://web_dashboard_preview.png")
                embed_room.set_footer(text=f"{bot_name} • Secret Voice Web Interface", icon_url=logo if logo else None)

                view_web = discord.ui.View()
                view_web.add_item(discord.ui.Button(label="🌐 Web Kontrol Panelini Aç ↗", url=web_url, style=discord.ButtonStyle.link))
                await new_room.send(
                    content=member.mention,
                    embed=embed_room,
                    file=preview_file,
                    view=view_web,
                    delete_after=180
                )
            except Exception as e:
                print(f"[Secret Oda Web Mesaj Hatası]: {e}")
            print(f"[Secret Oda] Yeni oda oluşturuldu: {new_room.name} ({member.display_name}) | Web URL: {web_url}")
        except Exception as e:
            print(f"[Secret Oda Hata]: {e}")

    # 2. BOŞALAN SECRET ODALARI OTOMATİK SİLME (VIP Kalıcı Oda Korumalı)
    if before.channel and (before.channel.id in secret_rooms or str(before.channel.id) in secret_rooms):
        if len(before.channel.members) == 0:
            ch_to_del = before.channel
            r_info = get_room_data(ch_to_del.id)
            if r_info.get("vip_persistent"):
                print(f"[VIP Koruma] {ch_to_del.name} odası VIP 7/24 Kalıcı Oda Koruması aktif olduğu için silinmedi.")
            else:
                remove_room_data(ch_to_del.id)
                try:
                    await ch_to_del.delete(reason="Secret oda boşaldığı için otomatik silindi.")
                    print(f"[Secret Oda] Boşalan oda silindi: {ch_to_del.name}")
                except Exception as e:
                    print(f"[Secret Oda Silme Hatası]: {e}")

    # 3. CANLI PANEL YENİLEME
    if before.channel != after.channel:
        panel_ch_id = config.get("panel_kanal_id")
        panel_msg_id = config.get("panel_mesaj_id")

        if panel_ch_id and panel_msg_id:
            try:
                channel = bot.get_channel(int(panel_ch_id))
                if channel:
                    msg = await channel.fetch_message(int(panel_msg_id))
                    if msg:
                        embed = build_voice_embed(channel.guild)
                        await msg.edit(embed=embed, view=VoiceRefreshView())
            except Exception:
                pass

# ─────────────────────────────────────────────
# ODA SOHBET & KONUŞMA KAYITLARI (LOGGING)
# ─────────────────────────────────────────────
ODA_KAYITLARI_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "oda_kayitlari")
os.makedirs(ODA_KAYITLARI_DIR, exist_ok=True)

@bot.event
async def on_message(message: discord.Message):
    """Ses odalarının ve Secret odaların metin sohbetindeki tüm konuşmaları bot klasörüne kaydeder."""
    if not message.author.bot and message.guild:
        ch = message.channel
        # Eğer mesaj bir ses odası veya Secret odanın metin sohbetinde yazıldıysa
        if isinstance(ch, discord.VoiceChannel) or (hasattr(ch, "category_id") and is_secret_room(ch)):
            date_str = datetime.now().strftime("%Y-%m-%d")
            clean_ch_name = "".join(c for c in ch.name if c.isalnum() or c in (' ', '_', '-')).strip() or f"oda_{ch.id}"
            filename = os.path.join(ODA_KAYITLARI_DIR, f"{clean_ch_name}_{date_str}.log")

            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            author_info = f"{message.author.display_name} (@{message.author.name} - ID: {message.author.id})"
            content = message.content or ""
            if message.attachments:
                att_urls = " [Ekler: " + ", ".join(a.url for a in message.attachments) + "]"
                content += att_urls

            log_line = f"[{timestamp}] {author_info}: {content}\n"
            try:
                with open(filename, "a", encoding="utf-8") as f:
                    f.write(log_line)
            except Exception as e:
                print(f"[Oda Sohbet Kayıt Hatası]: {e}")

    await bot.process_commands(message)

# ─────────────────────────────────────────────
# OTOMATİK DURUM (STATUS) ROLÜ SİSTEMİ
# ─────────────────────────────────────────────
def has_status_keyword(member: discord.Member) -> bool:
    """Üyenin özel durumunda /imzapriw veya discord.gg/imzapriw olup olmadığını denetler."""
    if not member or member.bot:
        return False

    keywords = config.get("durum_kelimeleri", ["/imzapriw", "discord.gg/imzapriw", ".gg/imzapriw"])

    for activity in getattr(member, "activities", []):
        state_text = str(getattr(activity, "state", "") or "").lower()
        name_text = str(getattr(activity, "name", "") or "").lower()

        for kw in keywords:
            kw_low = kw.lower()
            if kw_low in state_text or kw_low in name_text:
                return True

    return False

async def check_and_update_status_role(member: discord.Member):
    """Üyenin durumunu kontrol eder ve rolü verir / alır."""
    if not member or member.bot or not member.guild:
        return

    role_id = config.get("durum_rol_id")
    if not role_id:
        return

    role = member.guild.get_role(int(role_id))
    if not role:
        return

    should_have = has_status_keyword(member)
    has_role = role in member.roles

    try:
        if should_have and not has_role:
            await member.add_roles(role, reason="Durumuna /imzapriw ekledi.")
            print(f"[Durum Rolü] + {member.display_name} durumuna destek ekledi -> '{role.name}' rolü verildi.")
        elif not should_have and has_role:
            await member.remove_roles(role, reason="Durumundan /imzapriw sildi.")
            print(f"[Durum Rolü] - {member.display_name} durumundan desteği sildi -> '{role.name}' rolü geri alındı.")
    except discord.Forbidden:
        print(f"[Durum Rolü UYARI] Botun rolü, '{role.name}' rolünün altında veya 'Rolleri Yönet' yetkisi eksik!")
    except Exception as e:
        print(f"[Durum Rolü Hata]: {e}")

@bot.event
async def on_presence_update(before, after):
    """Kullanıcı durumunu (özel durumunu) değiştirdiğinde otomatik rol kontrolü yapar."""
    await check_and_update_status_role(after)

@bot.event
async def on_member_join(member):
    """Yeni üye sunucuya katıldığında otorol verir ve durumunu kontrol eder."""
    # 1. Otorol (Member Rolü)
    otorol_id = config.get("otorol_id", 0)
    if otorol_id and member.guild:
        role = member.guild.get_role(int(otorol_id))
        if role:
            try:
                await member.add_roles(role, reason="IMZA Otomatik Üye Rolü")
                print(f"[Otorol] + {member.display_name} katıldı -> '{role.name}' rolü verildi.", flush=True)
            except Exception as e:
                print(f"[Otorol Hata]: {e}", flush=True)

    # 2. Durum Rolü Kontrolü
    await check_and_update_status_role(member)

async def initial_status_scan():
    """Bot açıldığında tüm üyeleri tarayarak durumu güncel olanlara rolü verir."""
    await bot.wait_until_ready()
    await asyncio.sleep(4)
    role_id = config.get("durum_rol_id")
    if not role_id:
        return

    for guild in bot.guilds:
        role = guild.get_role(int(role_id))
        if not role:
            continue
        print(f"[Durum Rolü] {guild.name} sunucusu taranıyor...")
        added, removed = 0, 0
        for member in guild.members:
            if not member.bot:
                should_have = has_status_keyword(member)
                has_it = role in member.roles
                try:
                    if should_have and not has_it:
                        await member.add_roles(role, reason="Bot başlangıç durum taraması.")
                        added += 1
                        await asyncio.sleep(0.3)
                    elif not should_have and has_it:
                        await member.remove_roles(role, reason="Bot başlangıç durum taraması.")
                        removed += 1
                        await asyncio.sleep(0.3)
                except Exception:
                    pass
        print(f"[Durum Rolü] {guild.name} taraması tamamlandı (+{added} verildi, -{removed} alındı).")

# ─────────────────────────────────────────────
# SECRET ODA WEB KONTROL PANELİ & API SUNUCUSU
# ─────────────────────────────────────────────
WEB_RUNNER = None

async def web_landing(request):
    """Ana sayfa karşılama ve oda ID / token ile panele yönlendirme ekranı."""
    html = f"""<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ✦ Secret Web Gateway</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {{ font-family: system-ui, -apple-system, sans-serif; background: #0a0c10; }}
        .glass-card {{ background: rgba(18, 21, 31, 0.85); backdrop-filter: blur(16px); border: 1px solid rgba(45, 52, 75, 0.5); }}
    </style>
</head>
<body class="text-slate-200 min-h-screen flex items-center justify-center p-4">
    <div class="glass-card max-w-md w-full p-8 rounded-2xl shadow-2xl text-center">
        <div class="w-16 h-16 rounded-2xl bg-indigo-600 flex items-center justify-center text-white text-3xl font-black mx-auto mb-4 shadow-lg shadow-indigo-600/30">
            ɨ
        </div>
        <h1 class="text-2xl font-black text-white tracking-wide mb-1">{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} SECRET CONTROL</h1>
        <p class="text-xs text-slate-400 mb-6">Özel Ses Odası Canlı Web Yönetim Paneli</p>

        <div class="bg-slate-900/90 p-4 rounded-xl text-left border border-slate-800 text-xs text-slate-300 mb-6 space-y-2">
            <div class="flex items-center gap-2 font-bold text-indigo-400">
                <i class="fa-solid fa-lightbulb"></i> Nasıl Giriş Yapılır?
            </div>
            <p>1. Discord sunucusunda <strong>➕・Secret Oda Aç</strong> kanalına tıklayın.</p>
            <p>2. Odanız açıldığında gelen mesajdaki <strong>[🌐 Web Paneli]</strong> butonuna tıklayın veya <strong>/secret-web</strong> komutunu yazın.</p>
            <p>3. Size özel üretilen şifreli panel bağlantısıyla odanızı doğrudan tarayıcıdan yönetin.</p>
        </div>

        <form onsubmit="event.preventDefault(); goRoom();" class="space-y-3">
            <input type="text" id="manual-room-id" placeholder="Oda ID (Örn: 1545924929613070416)" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500">
            <input type="text" id="manual-token" placeholder="Erişim Anahtarı (Token)" class="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500">
            <button type="submit" class="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition">
                Panele Git <i class="fa-solid fa-arrow-right ml-1"></i>
            </button>
        </form>
    </div>
    <script>
        function goRoom() {{
            const r = document.getElementById('manual-room-id').value.trim();
            const t = document.getElementById('manual-token').value.trim();
            if (!r) return alert('Lütfen Oda ID girin');
            window.location.href = '/secret/' + r + (t ? '?token=' + encodeURIComponent(t) : '');
        }}
    </script>
</body>
</html>"""
    return web.Response(text=html, content_type="text/html")

async def web_secret_dashboard(request):
    """Secret Oda Dashboard HTML dosyasını sunar."""
    room_id_str = request.match_info.get("room_id")
    try:
        room_id = int(room_id_str)
    except Exception:
        room_id = None

    admin_token = request.query.get("admin_token")
    uid_str = request.query.get("uid")
    uid = int(uid_str) if (uid_str and uid_str.isdigit()) else None

    # Eğer yönetici linkiyle gelindiyse yetkisini doğrula
    if admin_token:
        is_valid, msg = await validate_admin_access(admin_token, uid)
        if not is_valid:
            return web.Response(
                text=f"""<!DOCTYPE html>
<html lang="tr">
<head><meta charset="UTF-8"><title>Erişim Reddedildi ✦ ɨ̇ ʍ ʐ ǟ</title>
<style>
body {{ background: #07090e; color: #fff; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
.card {{ background: #121624; border: 1px solid rgba(244,63,94,0.3); border-radius: 20px; padding: 40px; text-align: center; max-width: 440px; box-shadow: 0 10px 40px rgba(244,63,94,0.15); }}
h1 {{ color: #f43f5e; margin-bottom: 12px; font-size: 22px; }}
p {{ color: #94a3b8; font-size: 14px; line-height: 1.6; }}
</style></head>
<body><div class="card"><h1>🚫 Yetkisiz Giriş</h1><p>{msg}</p></div></body></html>""",
                status=403,
                content_type="text/html"
            )
    elif uid and room_id:
        ch = bot.get_channel(room_id)
        if not ch:
            try:
                ch = await bot.fetch_channel(room_id)
            except Exception:
                ch = None
        if ch:
            member = ch.guild.get_member(uid)
            if not member:
                try:
                    member = await ch.guild.fetch_member(uid)
                except Exception:
                    member = None
            if not member or not is_room_controller(ch, member):
                return web.Response(
                    text=f"""<!DOCTYPE html>
<html lang="tr">
<head><meta charset="UTF-8"><title>Yetkisiz Erişim ✦ ɨ̇ ʍ ʐ ǟ</title>
<style>
body {{ background: #07090e; color: #fff; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
.card {{ background: #121624; border: 1px solid rgba(245,158,11,0.3); border-radius: 20px; padding: 40px; text-align: center; max-width: 440px; box-shadow: 0 10px 40px rgba(245,158,11,0.15); }}
h1 {{ color: #f59e0b; margin-bottom: 12px; font-size: 22px; }}
p {{ color: #94a3b8; font-size: 14px; line-height: 1.6; }}
</style></head>
<body><div class="card"><h1>🔒 Oda Yetkiniz Kaldırıldı</h1><p>Bu odanın yönetim yetkisi devredilmiş veya erişim izniniz kaldırılmıştır.</p></div></body></html>""",
                    status=403,
                    content_type="text/html"
                )

    html_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "secret_dashboard.html")
    if not os.path.exists(html_path):
        return web.Response(text="Dashboard HTML dosyası bulunamadı.", status=500, content_type="text/plain")
    with open(html_path, "r", encoding="utf-8") as f:
        content = f.read()

    target_guild = ch.guild if (room_id and 'ch' in locals() and ch) else (bot.guilds[0] if bot.guilds else None)
    brand_logo = get_brand_logo_url(target_guild) or "/static/logo.png"
    if brand_logo:
        content = content.replace('src="/static/logo.png"', f'src="{brand_logo}"')

    return web.Response(text=content, content_type="text/html")

USER_PROFILE_CACHE = {}

async def get_user_banner_info(user_id: int):
    now = time.time()
    cached = USER_PROFILE_CACHE.get(user_id)
    if cached and (now - cached.get("fetched_at", 0) < 300):
        return cached.get("banner"), cached.get("accent")

    banner_url = None
    accent_hex = None
    try:
        user_obj = await bot.fetch_user(user_id)
        if user_obj:
            if getattr(user_obj, 'banner', None):
                banner_url = user_obj.banner.url
            accent = getattr(user_obj, 'accent_color', None)
            if accent:
                accent_hex = f"#{accent.value:06x}"
    except Exception:
        pass

    USER_PROFILE_CACHE[user_id] = {
        "banner": banner_url,
        "accent": accent_hex,
        "fetched_at": now
    }
    return banner_url, accent_hex

async def api_get_secret_room(request):
    """Odanın anlık canlı bilgilerini JSON formatında döner."""
    room_id_str = request.match_info.get("room_id")
    try:
        room_id = int(room_id_str)
    except ValueError:
        return web.json_response({"error": "Geçersiz oda ID"}, status=400)

    token = request.query.get("token")
    admin_token = request.query.get("admin_token")
    expected_token = get_room_token(room_id)

    uid_str = request.query.get("uid")
    uid = int(uid_str) if (uid_str and uid_str.isdigit()) else None

    is_admin = False
    if admin_token:
        is_valid_admin, admin_msg = await validate_admin_access(admin_token, uid)
        if is_valid_admin:
            is_admin = True
        else:
            return web.json_response({"error": admin_msg, "revoked": True}, status=403)

    ch = bot.get_channel(room_id)
    if not ch:
        try:
            ch = await bot.fetch_channel(room_id)
        except Exception:
            return web.json_response({"error": "Oda bulunamadı veya kapatılmış."}, status=404)

    is_controller = False
    if uid and ch:
        try:
            member = ch.guild.get_member(uid)
            if not member:
                try:
                    member = await ch.guild.fetch_member(uid)
                except Exception:
                    member = None
            if member and is_room_controller(ch, member):
                is_controller = True
        except Exception:
            pass

    has_valid_token = bool(token and token == expected_token)

    if not is_admin and not is_controller and not has_valid_token:
        return web.json_response({"error": "Yetkisiz erişim. Geçersiz erişim anahtarı."}, status=403)

    guild = ch.guild
    room_info = get_room_data(room_id)
    owner_id = room_info.get("owner_id") or room_info.get("transferred_to")
    owner = guild.get_member(int(owner_id)) if owner_id else None

    members_data = []
    for m in ch.members:
        vs = m.voice
        banner_url, accent_hex = await get_user_banner_info(m.id)
        if hasattr(m, 'display_banner') and m.display_banner:
            banner_url = m.display_banner.url

        members_data.append({
            "id": str(m.id),
            "name": m.display_name,
            "username": m.name,
            "avatar": m.display_avatar.url if m.display_avatar else None,
            "banner": banner_url,
            "accent_color": accent_hex,
            "is_owner": (m.id == int(owner_id)) if owner_id else False,
            "self_mute": bool(vs.self_mute or vs.mute) if vs else False,
            "self_deaf": bool(vs.self_deaf or vs.deaf) if vs else False
        })

    trusted_members = []
    blocked_members = []
    for target, ow in ch.overwrites.items():
        if isinstance(target, (discord.Member, discord.User)):
            if ow.connect is True or ow.view_channel is True:
                trusted_members.append({"id": str(target.id), "name": target.display_name})
            elif ow.connect is False:
                blocked_members.append({"id": str(target.id), "name": target.display_name})

    default_ow = ch.overwrites_for(guild.default_role)
    is_locked = (default_ow.connect is False) or room_info.get("locked", False)
    is_hidden = (default_ow.view_channel is False) or room_info.get("hidden", False)

    bot_avatar = get_brand_logo_url(guild) or (bot.user.display_avatar.url if bot.user and bot.user.display_avatar else None)
    guild_icon = (guild.icon.url if guild.icon else None) or get_brand_logo_url(guild) or "/static/logo.png"
    owner_avatar = owner.display_avatar.url if owner and owner.display_avatar else None

    # VIP Yetki & Kategori Kontrolleri
    vip_role_id = config.get("vip_rol_id", 0)
    vip_cat_id = config.get("vip_kategori_id")

    is_vip = False
    viewer = guild.get_member(uid) if uid else owner
    if viewer and any(r.id == int(vip_role_id) for r in viewer.roles):
        is_vip = True
    elif owner and any(r.id == int(vip_role_id) for r in owner.roles):
        is_vip = True
    elif is_admin:
        is_vip = True

    is_in_vip_category = False
    if vip_cat_id and ch.category_id == int(vip_cat_id):
        is_in_vip_category = True
    elif ch.category and "vip" in ch.category.name.lower():
        is_in_vip_category = True

    has_crown = ch.name.startswith("👑・") or ch.name.startswith("👑 ")
    owner_ow = ch.overwrites_for(owner) if owner else None
    has_priority = bool(owner_ow and owner_ow.priority_speaker)

    non_owner_mems = [m for m in ch.members if not m.bot and (not owner or m.id != owner.id)]
    is_mass_muted = bool(non_owner_mems and all(m.voice and m.voice.mute for m in non_owner_mems))

    return web.json_response({
        "ok": True,
        "id": str(ch.id),
        "name": ch.name,
        "user_limit": ch.user_limit or 0,
        "is_locked": is_locked,
        "is_hidden": is_hidden,
        "owner_id": str(owner_id) if owner_id else None,
        "owner_name": owner.display_name if owner else "Oda Sahibi",
        "owner_avatar": owner_avatar,
        "bot_name": config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ"),
        "bot_avatar": bot_avatar,
        "guild_icon": guild_icon,
        "guild_name": guild.name,
        "members": members_data,
        "trusted_members": trusted_members,
        "blocked_members": blocked_members,
        "is_vip": is_vip,
        "is_in_vip_category": is_in_vip_category,
        "current_category_name": ch.category.name if ch.category else "Kategorisiz",
        "has_crown": has_crown,
        "has_priority": has_priority,
        "vip_persistent": bool(room_info.get("vip_persistent", False)),
        "is_mass_muted": is_mass_muted,
        "bitrate": ch.bitrate,
        "max_bitrate": guild.bitrate_limit,
        "web_token": expected_token
    })

async def api_secret_room_action(request):
    """Web panelinden gelen buton/ayar isteklerini Discord üzerinde uygular."""
    room_id_str = request.match_info.get("room_id")
    try:
        room_id = int(room_id_str)
    except ValueError:
        return web.json_response({"error": "Geçersiz oda ID"}, status=400)

    token = request.query.get("token")
    admin_token = request.query.get("admin_token")
    expected_token = get_room_token(room_id)

    uid_str = request.query.get("uid")
    uid = int(uid_str) if (uid_str and uid_str.isdigit()) else None

    is_admin = False
    if admin_token:
        is_valid_admin, admin_msg = await validate_admin_access(admin_token, uid)
        if is_valid_admin:
            is_admin = True
        else:
            return web.json_response({"error": admin_msg, "revoked": True}, status=403)

    ch = bot.get_channel(room_id)
    if not ch:
        try:
            ch = await bot.fetch_channel(room_id)
        except Exception:
            return web.json_response({"error": "Oda bulunamadı veya kapatılmış."}, status=404)

    is_controller = False
    if uid and ch:
        try:
            member = ch.guild.get_member(uid)
            if not member:
                try:
                    member = await ch.guild.fetch_member(uid)
                except Exception:
                    member = None
            if member and is_room_controller(ch, member):
                is_controller = True
        except Exception:
            pass

    has_valid_token = bool(token and token == expected_token)

    if not is_admin and not is_controller and not has_valid_token:
        return web.json_response({"error": "Yetkisiz erişim. Yetkiniz veya erişim anahtarınız geçersiz.", "revoked": True}, status=403)

    guild = ch.guild
    room_info = get_room_data(ch.id)
    owner_id = room_info.get("owner_id") or room_info.get("transferred_to") or room_info.get("creator_id")
    owner = guild.get_member(int(owner_id)) if owner_id else None
    if not owner and owner_id:
        try:
            owner = await guild.fetch_member(int(owner_id))
        except Exception:
            owner = None

    checker = guild.get_member(uid) if uid else owner
    if not checker and uid:
        try:
            checker = await guild.fetch_member(uid)
        except Exception:
            checker = owner
    try:
        data = await request.json()
    except Exception:
        data = {}
    action = data.get("action")

    try:
        if action == "rename":
            new_name = str(data.get("name", "")).strip()
            if not new_name:
                return web.json_response({"error": "Geçerli bir isim girmelisiniz."}, status=400)

            # Emojileri ve boşlukları temizleyerek karşılaştır
            clean_curr = re.sub(r"^[\s🔒🔓🔐👑・]+", "", ch.name).strip()
            clean_new = re.sub(r"^[\s🔒🔓🔐👑・]+", "", new_name).strip()
            if clean_curr == clean_new:
                return web.json_response({"ok": True, "name": ch.name, "message": "Oda ismi zaten bu şekilde ayarlı."})

            # Eğer odanın VIP tacı varsa koru
            if (ch.name.startswith("👑・") or room_info.get("has_crown")) and not clean_new.startswith("👑・"):
                target_name = f"👑・{clean_new}"
            else:
                target_name = clean_new

            if len(target_name) > 32:
                target_name = target_name[:32]

            # Discord Rate Limit Kontrolü (10 dakikada en fazla 2 düzenleme)
            now = time.time()
            history = [t for t in ROOM_RENAME_HISTORY.get(ch.id, []) if now - t < 600]
            if len(history) >= 2:
                oldest = min(history)
                wait_sec = int(600 - (now - oldest)) + 1
                wait_min = wait_sec // 60
                wait_rem = wait_sec % 60
                time_str = f"{wait_min} dakika {wait_rem} saniye" if wait_min > 0 else f"{wait_sec} saniye"
                return web.json_response({
                    "error": f"Discord kuralı: Kanal ismi 10 dakikada en fazla 2 kez değiştirilebilir. Lütfen {time_str} sonra tekrar deneyin."
                }, status=429)

            try:
                await ch.edit(name=target_name)
                history.append(now)
                ROOM_RENAME_HISTORY[ch.id] = history
                set_room_data(ch.id, name=target_name, custom_name=target_name)
                return web.json_response({"ok": True, "name": target_name, "message": f"Oda ismi '{target_name}' olarak güncellendi! ✅"})
            except discord.HTTPException as he:
                if he.status == 429:
                    retry_after = int(getattr(he, 'retry_after', 60))
                    return web.json_response({
                        "error": f"Discord kanal adı düzenleme sınırına ulaşıldı (Rate Limited). Lütfen {retry_after} saniye bekleyin."
                    }, status=429)
                return web.json_response({"error": f"Discord hatası: {he}"}, status=500)

        elif action == "limit":
            limit_val = int(data.get("limit", 0))
            limit_val = max(0, min(99, limit_val))
            await ch.edit(user_limit=limit_val)
            lim_text = "Limitsiz" if limit_val == 0 else f"{limit_val} kişi"
            return web.json_response({"ok": True, "message": f"Oda limiti {lim_text} olarak ayarlandı."})

        elif action == "lock":
            locked = bool(data.get("locked", True))
            ow = ch.overwrites_for(guild.default_role)
            ow.connect = False if locked else None
            await ch.set_permissions(guild.default_role, overwrite=ow)
            set_room_data(ch.id, locked=locked)
            return web.json_response({"ok": True, "message": "Oda kilitlendi." if locked else "Oda kilidi açıldı."})

        elif action == "hide":
            hidden = bool(data.get("hidden", True))
            ow = ch.overwrites_for(guild.default_role)
            ow.view_channel = False if hidden else None
            await ch.set_permissions(guild.default_role, overwrite=ow)
            set_room_data(ch.id, hidden=hidden)
            return web.json_response({"ok": True, "message": "Oda gizlendi." if hidden else "Oda görünür yapıldı."})

        elif action == "trust":
            uid = int(data.get("user_id"))
            member = guild.get_member(uid)
            if not member:
                try:
                    member = await bot.fetch_user(uid)
                except Exception:
                    member = discord.Object(id=uid)
            await ch.set_permissions(member, connect=True, view_channel=True, manage_channels=True, move_members=True)
            return web.json_response({"ok": True, "message": f"{getattr(member, 'display_name', uid)} kullanıcısına özel izin verildi."})

        elif action == "untrust":
            uid = int(data.get("user_id"))
            member = guild.get_member(uid) or discord.Object(id=uid)
            await ch.set_permissions(member, overwrite=None)
            return web.json_response({"ok": True, "message": "Özel izin kaldırıldı."})

        elif action == "block":
            uid = int(data.get("user_id"))
            member = guild.get_member(uid)
            if member and member.voice and member.voice.channel == ch:
                try:
                    await member.move_to(None)
                except Exception:
                    pass
            target = member or discord.Object(id=uid)
            await ch.set_permissions(target, connect=False)
            return web.json_response({"ok": True, "message": f"{getattr(member, 'display_name', uid)} engellendi ve odadan atıldı."})

        elif action == "unblock":
            uid = int(data.get("user_id"))
            member = guild.get_member(uid) or discord.Object(id=uid)
            await ch.set_permissions(member, overwrite=None)
            return web.json_response({"ok": True, "message": "Kullanıcının engeli kaldırıldı."})

        elif action == "kick":
            uid = int(data.get("user_id"))
            member = guild.get_member(uid)
            if member and member.voice and member.voice.channel == ch:
                try:
                    await member.move_to(None)
                    return web.json_response({"ok": True, "message": f"{member.display_name} odadan atıldı."})
                except Exception as e:
                    return web.json_response({"error": f"Odadan atılamadı: {e}"}, status=500)
            return web.json_response({"ok": True, "message": "Kullanıcı zaten seste değil."})

        elif action in ["mute", "mute_member"]:
            raw_uid = data.get("user_id") or data.get("target_id")
            if not raw_uid:
                return web.json_response({"error": "user_id belirtilmedi."}, status=400)
            uid = int(raw_uid)
            should_mute = bool(data.get("mute", True))
            member = guild.get_member(uid)
            if member:
                ow = ch.overwrites_for(member)
                ow.speak = not should_mute
                await ch.set_permissions(member, overwrite=ow)
                try:
                    if member.voice and member.voice.channel == ch:
                        await member.edit(mute=should_mute)
                except Exception:
                    pass
                state_str = "susturuldu" if should_mute else "susturması kaldırıldı"
                return web.json_response({"ok": True, "message": f"{member.display_name} {state_str}."})
            return web.json_response({"error": "Kullanıcı bulunamadı."}, status=404)

        elif action == "invite":
            inv = await ch.create_invite(max_age=3600, max_uses=10, reason="Web Kontrol Panel Daveti")
            return web.json_response({"ok": True, "invite_url": inv.url})

        elif action == "transfer":
            uid = int(data.get("user_id"))
            new_owner = guild.get_member(uid)
            if not new_owner:
                return web.json_response({"error": "Kullanıcı sunucuda bulunamadı."}, status=404)

            old_owner_id = room_info.get("owner_id") or room_info.get("transferred_to") or room_info.get("creator_id")

            # 1. Yeni gizli token üret ve sahipliği kaydet (eski sahibin token'ı anında geçersiz olur)
            new_token = secrets.token_urlsafe(16)
            set_room_data(ch.id, owner_id=uid, transferred_to=uid, web_token=new_token)

            # 2. Eski sahibin oda üzerindeki yönetim/taşıma izinlerini kaldır
            if old_owner_id and int(old_owner_id) != uid:
                old_owner = guild.get_member(int(old_owner_id))
                if old_owner:
                    try:
                        await ch.set_permissions(old_owner, overwrite=None)
                    except Exception:
                        pass

            # 3. Yeni sahibe tam yönetim izinlerini ver
            try:
                await ch.set_permissions(new_owner, connect=True, view_channel=True, manage_channels=True, move_members=True)
            except Exception:
                pass

            # 4. Yeni sahibe ses odası sohbetinde yeni web paneli link butonunu gönder
            try:
                new_panel_url = get_room_web_url(ch.id)
                web_view = discord.ui.View()
                web_view.add_item(discord.ui.Button(label="Web Paneli", url=new_panel_url, style=discord.ButtonStyle.link))
                await ch.send(content=f"👑 **Oda sahipliği devredildi!**\nYeni Oda Sahibi: {new_owner.mention}\nWeb yönetim paneli erişim anahtarı yenilenmiştir:", view=web_view)
            except Exception:
                pass

            return web.json_response({
                "ok": True,
                "transferred": True,
                "message": f"Oda sahipliği {new_owner.display_name} kullanıcısına devredildi. Yetkileriniz sonlandırıldı."
            })

        elif action == "vip_set_category":
            vip_role_id = config.get("vip_rol_id", 0)
            has_vip = is_admin or (checker and any(r.id == int(vip_role_id) for r in checker.roles)) or (owner and any(r.id == int(vip_role_id) for r in owner.roles))
            if not has_vip:
                return web.json_response({"error": "Bu özellik yalnızca VIP rolüne sahip üyelere özeldir!"}, status=403)

            now_ts = time.time()
            last_sw = VIP_CAT_COOLDOWN.get(ch.id, 0)
            if now_ts - last_sw < 60:
                rem = int(60 - (now_ts - last_sw))
                return web.json_response({"error": f"Discord kanal taşıma sınırı nedeniyle lütfen {rem} saniye bekleyin."}, status=429)

            target = data.get("category", "vip")
            try:
                if target == "vip":
                    vip_cat_id = config.get("vip_kategori_id")
                    vip_cat = guild.get_channel(int(vip_cat_id)) if vip_cat_id else None
                    if not vip_cat:
                        for c in guild.categories:
                            if "vip" in c.name.lower():
                                vip_cat = c
                                break
                    if not vip_cat:
                        vip_cat = await guild.create_category(
                            name=f"━━━ {config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} VIP SECRET ━━━",
                            reason="VIP Secret Odalar Kategorisi"
                        )
                        config["vip_kategori_id"] = vip_cat.id
                        save_config(config)

                    await ch.edit(category=vip_cat)
                    VIP_CAT_COOLDOWN[ch.id] = now_ts
                    return web.json_response({"ok": True, "category": "vip", "message": f"Odanız başarıyla '{vip_cat.name}' VIP kategorisine taşındı! 👑"})

                elif target == "normal":
                    normal_cat_id = config.get("secret_kategori_id")
                    normal_cat = guild.get_channel(int(normal_cat_id)) if normal_cat_id else None
                    if not normal_cat:
                        return web.json_response({"error": "Normal secret kategorisi bulunamadı."}, status=404)
                    await ch.edit(category=normal_cat)
                    VIP_CAT_COOLDOWN[ch.id] = now_ts
                    return web.json_response({"ok": True, "category": "normal", "message": f"Odanız normal '{normal_cat.name}' kategorisine taşındı."})
                else:
                    return web.json_response({"error": "Geçersiz kategori hedefi."}, status=400)
            except discord.HTTPException as he:
                if he.status == 429:
                    return web.json_response({"error": "Discord kanal taşıma limitine ulaşıldı (Rate Limited). Lütfen birkaç dakika sonra tekrar deneyin."}, status=429)
                return web.json_response({"error": f"Discord hatası: {he}"}, status=500)

        elif action == "vip_toggle_persistent":
            vip_role_id = config.get("vip_rol_id", 0)
            has_vip = is_admin or (checker and any(r.id == int(vip_role_id) for r in checker.roles)) or (owner and any(r.id == int(vip_role_id) for r in owner.roles))
            if not has_vip:
                return web.json_response({"error": "Bu özellik yalnızca VIP rolüne sahip üyelere özeldir!"}, status=403)

            curr_state = bool(room_info.get("vip_persistent", False))
            new_state = not curr_state
            set_room_data(ch.id, vip_persistent=new_state)
            msg = "👑 7/24 Kalıcı VIP Oda Koruması AKTİF! Odadan herkes çıksa bile odanız silinmeyecektir." if new_state else "Kalıcı oda koruması kapatıldı. Oda boşalınca standart şekilde silinecektir."
            return web.json_response({"ok": True, "vip_persistent": new_state, "message": msg})

        elif action == "vip_mass_mute":
            vip_role_id = config.get("vip_rol_id", 0)
            has_vip = is_admin or (checker and any(r.id == int(vip_role_id) for r in checker.roles)) or (owner and any(r.id == int(vip_role_id) for r in owner.roles))
            if not has_vip:
                return web.json_response({"error": "Bu özellik yalnızca VIP rolüne sahip üyelere özeldir!"}, status=403)

            mute_target = data.get("mute")
            non_owner_mems = [m for m in ch.members if not m.bot and (not owner or m.id != owner.id) and (not checker or m.id != checker.id)]
            if not non_owner_mems:
                return web.json_response({"error": "Odada susturulabilecek başka üye bulunmuyor."}, status=400)

            if mute_target is None:
                any_unmuted = any(not (m.voice and m.voice.mute) for m in non_owner_mems)
                mute_target = any_unmuted

            cnt = 0
            for m in non_owner_mems:
                try:
                    await m.edit(mute=mute_target)
                    cnt += 1
                except Exception:
                    pass

            msg = f"🔇 Odadaki {cnt} üye tek tıkla susturuldu! (Yalnızca siz konuşabilirsiniz)" if mute_target else f"🔊 Odadaki {cnt} üyenin mikrofonu açıldı!"
            return web.json_response({"ok": True, "is_mass_muted": mute_target, "count": cnt, "message": msg})

        elif action == "vip_russian_roulette":
            vip_role_id = config.get("vip_rol_id", 0)
            has_vip = is_admin or (checker and any(r.id == int(vip_role_id) for r in checker.roles)) or (owner and any(r.id == int(vip_role_id) for r in owner.roles))
            if not has_vip:
                return web.json_response({"error": "Bu özellik yalnızca VIP rolüne sahip üyelere özeldir!"}, status=403)

            candidates = [m for m in ch.members if not m.bot]
            if len(candidates) < 2:
                return web.json_response({"error": "Rus Ruleti için odada en az 2 üye olmalıdır! Arkadaşlarınızı odaya çağırın."}, status=400)

            victim = random.choice(candidates)
            penalty_type = random.choice(["mute", "deaf"])
            penalty_desc = "30 Saniye Mikrofon Susturma" if penalty_type == "mute" else "30 Saniye Kulaklık Susturma"

            try:
                if penalty_type == "mute":
                    await victim.edit(mute=True)
                else:
                    await victim.edit(deafen=True)

                async def revert_penalty(target_member, p_type):
                    await asyncio.sleep(30)
                    try:
                        if p_type == "mute":
                            await target_member.edit(mute=False)
                        else:
                            await target_member.edit(deafen=False)
                    except Exception:
                        pass
                asyncio.create_task(revert_penalty(victim, penalty_type))
            except Exception:
                pass

            bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
            embed = discord.Embed(
                title="🎯 VIP RUS RULETİ TETİĞİ ÇEKİLDİ!",
                description=(
                    f"💥 **KLİK! NAMLU ATEŞ ALDI!**\n\n"
                    f"› 🎯 **Kurban:** {victim.mention} (`{victim.display_name}`)\n"
                    f"› ⚖️ **Cezası:** **{penalty_desc}**!\n"
                    f"› ⏱️ *Süre bitiminde (30 sn) otomatik açılacaktır.*"
                ),
                color=0xf43f5e,
                timestamp=datetime.now(timezone.utc)
            )
            if victim.display_avatar:
                embed.set_thumbnail(url=victim.display_avatar.url)
            embed.set_footer(text=f"{bot_name} • VIP Party Games")
            try:
                await ch.send(embed=embed)
            except Exception:
                pass

            return web.json_response({
                "ok": True,
                "victim_id": str(victim.id),
                "victim_name": victim.display_name,
                "penalty": penalty_desc,
                "message": f"💥 Rulet tetiklendi! Kurban: {victim.display_name} ({penalty_desc})"
            })

        elif action == "vip_toggle_crown":
            vip_role_id = config.get("vip_rol_id", 0)
            has_vip = is_admin or (checker and any(r.id == int(vip_role_id) for r in checker.roles)) or (owner and any(r.id == int(vip_role_id) for r in owner.roles))
            if not has_vip:
                return web.json_response({"error": "Bu özellik yalnızca VIP rolüne sahip üyelere özeldir!"}, status=403)

            curr_name = ch.name
            if curr_name.startswith("👑・"):
                new_name = curr_name[len("👑・"):].strip()
                msg = "VIP Tacı odadan kaldırıldı."
            elif curr_name.startswith("👑 "):
                new_name = curr_name[len("👑 "):].strip()
                msg = "VIP Tacı odadan kaldırıldı."
            else:
                new_name = f"👑・{curr_name}".strip()
                msg = "Oda ismine VIP Kraliyet Tacı (👑) eklendi!"

            if len(new_name) > 32:
                new_name = new_name[:32]
            await ch.edit(name=new_name)
            return web.json_response({"ok": True, "name": new_name, "message": msg})

        elif action == "vip_boost_bitrate":
            vip_role_id = config.get("vip_rol_id", 0)
            has_vip = is_admin or (checker and any(r.id == int(vip_role_id) for r in checker.roles)) or (owner and any(r.id == int(vip_role_id) for r in owner.roles))
            if not has_vip:
                return web.json_response({"error": "Bu özellik yalnızca VIP rolüne sahip üyelere özeldir!"}, status=403)

            max_br = guild.bitrate_limit
            await ch.edit(bitrate=max_br)
            return web.json_response({"ok": True, "bitrate": max_br, "message": f"Ses kalitesi VIP Ultra HD ({int(max_br / 1000)} kbps) seviyesine yükseltildi! ⚡"})

        elif action == "vip_priority_speaker":
            vip_role_id = config.get("vip_rol_id", 0)
            has_vip = is_admin or (checker and any(r.id == int(vip_role_id) for r in checker.roles)) or (owner and any(r.id == int(vip_role_id) for r in owner.roles))
            if not has_vip:
                return web.json_response({"error": "Bu özellik yalnızca VIP rolüne sahip üyelere özeldir!"}, status=403)

            target_m = owner or checker
            ow = ch.overwrites_for(target_m)
            new_state = not (ow.priority_speaker is True)
            ow.priority_speaker = new_state if new_state else None
            await ch.set_permissions(target_m, overwrite=ow)
            msg = "VIP Öncelikli Konuşmacı modu aktif edildi! 🎙️" if new_state else "VIP Öncelikli Konuşmacı modu kapatıldı."
            return web.json_response({"ok": True, "priority": new_state, "message": msg})

        elif action == "vip_lounge_announcement":
            vip_role_id = config.get("vip_rol_id", 0)
            has_vip = is_admin or (checker and any(r.id == int(vip_role_id) for r in checker.roles)) or (owner and any(r.id == int(vip_role_id) for r in owner.roles))
            if not has_vip:
                return web.json_response({"error": "Bu özellik yalnızca VIP rolüne sahip üyelere özeldir!"}, status=403)

            bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
            embed = discord.Embed(
                title="👑 VIP LOUNGE ✦ Özel Oda Bildirimi",
                description=f"✨ **{getattr(owner, 'display_name', 'Oda Sahibi')}**, bu odayı **VIP Statüsünde** yönetiyor!\n> *Keyifli sohbetler ve iyi eğlenceler dileriz.*",
                color=0xf1c40f
            )
            if owner and owner.display_avatar:
                embed.set_thumbnail(url=owner.display_avatar.url)
            embed.set_footer(text=f"{bot_name} • VIP Elite Suite")
            try:
                await ch.send(embed=embed)
                return web.json_response({"ok": True, "message": "Oda metin kanalına VIP Locası duyurusu gönderildi! 👑"})
            except Exception as e:
                return web.json_response({"error": f"Duyuru gönderilemedi: {e}"}, status=500)

        elif action == "close":
            remove_room_data(ch.id)
            try:
                await ch.delete(reason="Web Kontrol Panelinden kapatıldı.")
            except Exception:
                pass
            return web.json_response({"ok": True, "message": "Oda başarıyla kapatıldı."})

        else:
            return web.json_response({"error": "Bilinmeyen aksiyon"}, status=400)

    except Exception as e:
        return web.json_response({"error": str(e)}, status=500)

async def api_get_guild_members(request):
    """Sunucu üyelerinin arama listesini döner."""
    if not bot.guilds:
        return web.json_response([])
    guild = bot.guilds[0]
    members = []
    for m in guild.members:
        if not m.bot:
            members.append({
                "id": str(m.id),
                "name": m.display_name,
                "avatar": m.display_avatar.url if m.display_avatar else None
            })
    return web.json_response(members[:100])

async def web_secret_admin_dashboard(request):
    """Tüm secret kanalları gösteren Master Yönetici Hub HTML dosyasını sunar."""
    token = request.query.get("token")
    uid_str = request.query.get("uid")
    uid = int(uid_str) if (uid_str and uid_str.isdigit()) else None

    is_valid, msg = await validate_admin_access(token, uid)
    if not is_valid:
        return web.Response(
            text=f"""<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Erişim Reddedildi ✦ ɨ̇ ʍ ʐ ǟ</title>
<style>
body {{ background: #07090e; color: #fff; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
.card {{ background: #121624; border: 1px solid rgba(244,63,94,0.3); border-radius: 20px; padding: 40px; text-align: center; max-width: 440px; box-shadow: 0 10px 40px rgba(244,63,94,0.15); }}
h1 {{ color: #f43f5e; margin-bottom: 12px; font-size: 22px; }}
p {{ color: #94a3b8; font-size: 14px; line-height: 1.6; }}
</style>
</head>
<body>
<div class="card">
  <h1>🚫 Yetkisiz Giriş</h1>
  <p>{msg}</p>
</div>
</body>
</html>""",
            status=403,
            content_type="text/html"
        )

    html_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "secret_admin.html")
    if not os.path.exists(html_path):
        return web.Response(text="secret_admin.html dosyası bulunamadı.", status=500, content_type="text/plain")
    with open(html_path, "r", encoding="utf-8") as f:
        content = f.read()

    target_guild = bot.guilds[0] if bot.guilds else None
    brand_logo = get_brand_logo_url(target_guild) or "/static/logo.png"
    if brand_logo:
        content = content.replace('src="/static/logo.png"', f'src="{brand_logo}"')

    return web.Response(text=content, content_type="text/html")

async def api_get_secret_admin_rooms(request):
    """Sunucudaki tüm aktif secret odaların listesini ve anlık durumlarını döner."""
    token = request.query.get("token")
    uid_str = request.query.get("uid")
    uid = int(uid_str) if (uid_str and uid_str.isdigit()) else None

    is_valid, msg = await validate_admin_access(token, uid)
    if not is_valid:
        return web.json_response({"error": msg, "revoked": True}, status=403)

    guild = bot.guilds[0] if bot.guilds else None
    if not guild:
        return web.json_response({"ok": True, "rooms": [], "stats": {}})

    data_map = load_secret_rooms()
    cat_id = config.get("secret_kategori_id")
    giris_id = config.get("secret_giris_kanal_id")

    channel_ids = set()
    for k in data_map.keys():
        try:
            channel_ids.add(int(k))
        except Exception:
            pass

    if cat_id:
        try:
            cat = guild.get_channel(int(cat_id))
            if cat and isinstance(cat, discord.CategoryChannel):
                for vc in cat.voice_channels:
                    if not giris_id or vc.id != int(giris_id):
                        channel_ids.add(vc.id)
        except Exception:
            pass

    rooms_list = []
    total_members_count = 0
    locked_count = 0
    hidden_count = 0

    for cid in channel_ids:
        ch = guild.get_channel(cid)
        if not ch or not isinstance(ch, (discord.VoiceChannel, discord.StageChannel)):
            continue

        rdata = get_room_data(cid)
        room_token = get_room_token(cid)

        default_ow = ch.overwrites_for(guild.default_role)
        is_locked = (default_ow.connect is False) or rdata.get("locked", False)
        is_hidden = (default_ow.view_channel is False) or rdata.get("hidden", False)

        if is_locked:
            locked_count += 1
        if is_hidden:
            hidden_count += 1

        owner_id = rdata.get("transferred_to") or rdata.get("owner_id") or rdata.get("creator_id")
        owner = guild.get_member(int(owner_id)) if owner_id else None

        members = []
        for m in ch.members:
            total_members_count += 1
            vs = m.voice
            members.append({
                "id": str(m.id),
                "name": m.display_name,
                "avatar": m.display_avatar.url if m.display_avatar else None,
                "self_mute": bool(vs.self_mute or vs.mute) if vs else False,
                "self_deaf": bool(vs.self_deaf or vs.deaf) if vs else False
            })

        rooms_list.append({
            "id": str(ch.id),
            "name": ch.name,
            "user_limit": ch.user_limit or 0,
            "is_locked": is_locked,
            "is_hidden": is_hidden,
            "token": room_token,
            "owner_id": str(owner_id) if owner_id else None,
            "owner_name": owner.display_name if owner else "Bilinmeyen Sahip",
            "owner_avatar": owner.display_avatar.url if owner and owner.display_avatar else None,
            "members": members
        })

    rooms_list.sort(key=lambda x: x["name"])

    stats = {
        "total_rooms": len(rooms_list),
        "total_members": total_members_count,
        "locked_rooms": locked_count,
        "hidden_rooms": hidden_count
    }

    return web.json_response({
        "ok": True,
        "bot_name": config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ"),
        "guild_name": guild.name,
        "guild_icon": (guild.icon.url if guild and guild.icon else None) or get_brand_logo_url(guild) or "/static/logo.png",
        "stats": stats,
        "rooms": rooms_list
    })

async def api_secret_admin_action(request):
    """Admin hub üzerinden doğrudan bir odayı kapatma, kilitleme vs. uygular."""
    token = request.query.get("token")
    uid_str = request.query.get("uid")
    uid = int(uid_str) if (uid_str and uid_str.isdigit()) else None

    is_valid, msg = await validate_admin_access(token, uid)
    if not is_valid:
        return web.json_response({"error": msg, "revoked": True}, status=403)

    try:
        data = await request.json()
    except Exception:
        data = {}

    action = data.get("action")
    guild = bot.guilds[0] if bot.guilds else None
    if not guild:
        return web.json_response({"error": "Sunucu bulunamadı."}, status=400)

    try:
        if action == "lock_all":
            locked = bool(data.get("locked", True))
            data_map = load_secret_rooms()
            cat_id = config.get("secret_kategori_id")
            giris_id = config.get("secret_giris_kanal_id")
            channel_ids = set()
            for k in data_map.keys():
                try:
                    channel_ids.add(int(k))
                except Exception:
                    pass
            if cat_id:
                try:
                    cat = guild.get_channel(int(cat_id))
                    if cat and isinstance(cat, discord.CategoryChannel):
                        for vc in cat.voice_channels:
                            if not giris_id or vc.id != int(giris_id):
                                channel_ids.add(vc.id)
                except Exception:
                    pass

            count = 0
            for cid in channel_ids:
                ch = guild.get_channel(cid)
                if ch and isinstance(ch, (discord.VoiceChannel, discord.StageChannel)):
                    try:
                        ow = ch.overwrites_for(guild.default_role)
                        ow.connect = False if locked else None
                        await ch.set_permissions(guild.default_role, overwrite=ow)
                        set_room_data(ch.id, locked=locked)
                        count += 1
                    except Exception:
                        pass
            msg = f"Tüm odalar ({count} adet) kilitlendi." if locked else f"Tüm odaların ({count} adet) kilidi açıldı."
            return web.json_response({"ok": True, "message": msg})

        room_id_str = data.get("room_id")
        if not room_id_str:
            return web.json_response({"error": "room_id eksik."}, status=400)

        try:
            room_id = int(room_id_str)
        except ValueError:
            return web.json_response({"error": "Geçersiz room_id."}, status=400)

        ch = bot.get_channel(room_id)
        if not ch:
            try:
                ch = await bot.fetch_channel(room_id)
            except Exception:
                return web.json_response({"error": "Oda bulunamadı."}, status=404)

        if action == "clean_empty":
            data_map = load_secret_rooms()
            cat_id = config.get("secret_kategori_id")
            giris_id = config.get("secret_giris_kanal_id")
            channel_ids = set()
            for k in data_map.keys():
                try:
                    channel_ids.add(int(k))
                except Exception:
                    pass
            if cat_id:
                try:
                    cat = guild.get_channel(int(cat_id))
                    if cat and isinstance(cat, discord.CategoryChannel):
                        for vc in cat.voice_channels:
                            if not giris_id or vc.id != int(giris_id):
                                channel_ids.add(vc.id)
                except Exception:
                    pass

            deleted_count = 0
            for cid in channel_ids:
                ch_vc = guild.get_channel(cid)
                if ch_vc and isinstance(ch_vc, (discord.VoiceChannel, discord.StageChannel)):
                    if len(ch_vc.members) == 0:
                        try:
                            remove_room_data(ch_vc.id)
                            await ch_vc.delete(reason="Master Admin: Boş secret odalar temizlendi.")
                            deleted_count += 1
                        except Exception:
                            pass
            return web.json_response({"ok": True, "message": f"{deleted_count} adet boş secret oda temizlendi."})

        elif action == "close":
            remove_room_data(ch.id)
            await ch.delete(reason="Secret Yönetici Hub'ı üzerinden kapatıldı.")
            return web.json_response({"ok": True, "message": "Oda başarıyla kapatıldı ve silindi."})

        elif action == "rename":
            new_name = str(data.get("name", "")).strip()
            if not new_name:
                return web.json_response({"error": "Yeni oda adı boş olamaz."}, status=400)
            await ch.edit(name=new_name, reason="Master Admin tarafından oda ismi değiştirildi.")
            set_room_data(ch.id, name=new_name)
            return web.json_response({"ok": True, "message": f"Oda ismi '{new_name}' olarak güncellendi."})

        elif action == "limit":
            limit = int(data.get("limit", 0))
            limit = max(0, min(99, limit))
            await ch.edit(user_limit=limit, reason="Master Admin tarafından kişi limiti güncellendi.")
            set_room_data(ch.id, user_limit=limit)
            return web.json_response({"ok": True, "message": f"Kişi limiti {limit if limit > 0 else 'Limitsiz'} olarak ayarlandı."})

        elif action == "invite":
            try:
                invite = await ch.create_invite(max_age=3600, max_uses=10, reason="Master Hub anlık davet linki")
                return web.json_response({"ok": True, "invite_url": invite.url})
            except Exception as e:
                return web.json_response({"error": f"Davet oluşturulamadı: {e}"}, status=500)

        elif action == "lock":
            locked = bool(data.get("locked", True))
            ow = ch.overwrites_for(guild.default_role)
            ow.connect = False if locked else None
            await ch.set_permissions(guild.default_role, overwrite=ow)
            set_room_data(ch.id, locked=locked)
            return web.json_response({"ok": True, "message": "Oda kilitlendi." if locked else "Oda kilidi açıldı."})

        elif action == "hide":
            hidden = bool(data.get("hidden", True))
            ow = ch.overwrites_for(guild.default_role)
            ow.view_channel = False if hidden else None
            await ch.set_permissions(guild.default_role, overwrite=ow)
            set_room_data(ch.id, hidden=hidden)
            return web.json_response({"ok": True, "message": "Oda gizlendi." if hidden else "Oda görünür yapıldı."})

        elif action == "kick_member":
            member_id_str = data.get("member_id")
            if not member_id_str:
                return web.json_response({"error": "member_id eksik."}, status=400)
            target_member = guild.get_member(int(member_id_str))
            if target_member and target_member.voice and target_member.voice.channel and target_member.voice.channel.id == ch.id:
                await target_member.move_to(None, reason="Secret Yönetici Hub'ından sesten atıldı.")
                return web.json_response({"ok": True, "message": f"{target_member.display_name} sesten çıkarıldı."})
            return web.json_response({"error": "Kullanıcı bu seste bulunamadı."}, status=400)

        else:
            return web.json_response({"error": "Bilinmeyen admin aksiyonu."}, status=400)

    except Exception as e:
        return web.json_response({"error": f"İşlem hatası: {e}"}, status=500)

async def web_brand_logo(request):
    """Sunucu / bot imza logosunu statik dosya olarak sunar."""
    logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "imza_logo.png")
    if os.path.exists(logo_path):
        return web.FileResponse(logo_path)
    return web.Response(status=404)

def setup_secret_web_routes(app):
    app.router.add_get("/", web_landing)
    app.router.add_get("/static/logo.png", web_brand_logo)
    app.router.add_get("/secret/{room_id}", web_secret_dashboard)
    app.router.add_get("/api/secret/{room_id}", api_get_secret_room)
    app.router.add_post("/api/secret/{room_id}/action", api_secret_room_action)
    app.router.add_get("/api/guild/members", api_get_guild_members)
    app.router.add_get("/secret-admin", web_secret_admin_dashboard)
    app.router.add_get("/api/secret-admin/rooms", api_get_secret_admin_rooms)
    app.router.add_post("/api/secret-admin/action", api_secret_admin_action)

CLOUDFLARED_SECRET_PROC = None

async def start_secret_cloudflare_tunnel(port: int = 8082) -> str | None:
    """cloudflared-secret.exe kullanarak odaya özel anlık küresel HTTPS adresi oluşturur."""
    global CLOUDFLARED_SECRET_PROC, ACTIVE_WEB_URL
    base_dir = os.path.dirname(os.path.abspath(__file__))
    cf_path = os.path.join(base_dir, "cloudflared-secret.exe")
    if not os.path.exists(cf_path):
        cf_path = os.path.join(base_dir, "cloudflared.exe")

    # Eğer klasörde yoksa diğer bot klasörlerinden (örn: imza-ticket-bot) otomatik çek
    if not os.path.exists(cf_path):
        candidate_paths = [
            os.path.join(base_dir, "..", "imza-ticket-bot", "cloudflared.exe"),
            os.path.join(base_dir, "..", "ticket-bot", "cloudflared.exe"),
            os.path.join(base_dir, "..", "cloudflared.exe"),
            os.path.join(os.environ.get("USERPROFILE", "C:/Users/Administrator"), "Desktop", "imza-ticket-bot", "cloudflared.exe"),
            shutil.which("cloudflared")
        ]
        for cp in candidate_paths:
            if cp and os.path.exists(cp):
                try:
                    dest = os.path.join(base_dir, "cloudflared-secret.exe")
                    shutil.copyfile(cp, dest)
                    cf_path = dest
                    print(f"[Secret Web] ✅ cloudflared {cp} konumundan otomatik kopyalandı.", flush=True)
                    break
                except Exception:
                    cf_path = cp
                    break

    # Hâlâ bulunamadıysa Cloudflare GitHub'ından otomatik indir
    if not os.path.exists(cf_path):
        print("[Secret Web] cloudflared.exe bulunamadı, Cloudflare'dan otomatik indiriliyor...", flush=True)
        try:
            cf_url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
            dest = os.path.join(base_dir, "cloudflared-secret.exe")
            urllib.request.urlretrieve(cf_url, dest)
            cf_path = dest
            print("[Secret Web] ✅ cloudflared-secret.exe başarıyla indirildi!", flush=True)
        except Exception as e:
            print(f"[Secret Web] cloudflared indirme hatası: {e}", flush=True)

    if not os.path.exists(cf_path):
        pub_url = get_server_public_ip_url()
        print(f"[Secret Web] cloudflared bulunamadı. Genel IP bağlantısı kullanılacak: {pub_url}", flush=True)
        ACTIVE_WEB_URL = pub_url
        return pub_url

    try:
        proc_name = os.path.basename(cf_path)
        try:
            subprocess.run(["taskkill", "/f", "/im", proc_name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

        CLOUDFLARED_SECRET_PROC = subprocess.Popen(
            [cf_path, "tunnel", "--protocol", "http2", "--url", f"http://127.0.0.1:{port}"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace"
        )
        print("[Secret Web] Cloudflare Canlı HTTPS Tüneli kuruluyor (HTTP/2 modu)...", flush=True)

        start_t = time.time()
        while time.time() - start_t < 20:
            line = await asyncio.to_thread(CLOUDFLARED_SECRET_PROC.stdout.readline)
            if not line:
                await asyncio.sleep(0.2)
                continue
            m = re.search(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com", line)
            if m:
                ACTIVE_WEB_URL = m.group(0).rstrip("/")
                print(f"[Secret Web] ✅ Canlı Global HTTPS Web Paneli Hazır: {ACTIVE_WEB_URL}", flush=True)
                config["secret_web_base_url"] = ACTIVE_WEB_URL
                save_config(config)

                async def drain_cf():
                    global ACTIVE_WEB_URL, CLOUDFLARED_SECRET_PROC
                    try:
                        while CLOUDFLARED_SECRET_PROC and CLOUDFLARED_SECRET_PROC.poll() is None:
                            l = await asyncio.to_thread(CLOUDFLARED_SECRET_PROC.stdout.readline)
                            if l:
                                m2 = re.search(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com", l)
                                if m2 and m2.group(0).rstrip("/") != ACTIVE_WEB_URL:
                                    ACTIVE_WEB_URL = m2.group(0).rstrip("/")
                                    config["secret_web_base_url"] = ACTIVE_WEB_URL
                                    save_config(config)
                                    print(f"[Secret Web] Web Tüneli Güncellendi: {ACTIVE_WEB_URL}", flush=True)
                            else:
                                await asyncio.sleep(0.5)
                    except Exception:
                        pass
                    print("[Secret Web] ⚠️ Cloudflare Tünel bağlantısı koptu. Yeniden bağlanılıyor...", flush=True)
                    ACTIVE_WEB_URL = None
                    await asyncio.sleep(3)
                    asyncio.create_task(start_secret_cloudflare_tunnel(port))

                asyncio.create_task(drain_cf())
                return ACTIVE_WEB_URL

    except Exception as e:
        print(f"[Secret Web Tünel Başlatma Hatası]: {e}", flush=True)

    pub_url = get_server_public_ip_url()
    ACTIVE_WEB_URL = pub_url
    return pub_url

async def start_secret_web_server():
    global WEB_RUNNER
    if WEB_RUNNER is not None:
        return
    port = int(config.get("secret_web_port", 8082))
    app = web.Application()
    setup_secret_web_routes(app)
    WEB_RUNNER = web.AppRunner(app)
    await WEB_RUNNER.setup()
    site = web.TCPSite(WEB_RUNNER, "0.0.0.0", port)
    await site.start()
    print(f"[Secret Web Server] Port {port} üzerinde yerel web sunucusu dinlemede.", flush=True)
    await start_secret_cloudflare_tunnel(port)

# ─────────────────────────────────────────────
# BOT AÇILIŞ (ON_READY) & SLASH SENKRONİZASYON
# ─────────────────────────────────────────────
@bot.event
async def on_ready():
    banner = f"""
    ╔══════════════════════════════════════════════════════════╗
    ║                     {config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}                          ║
    ║        Priv Discord List & Ses İstatistik Botu           ║
    ╠══════════════════════════════════════════════════════════╣
    ║  Bot İsmi: {str(bot.user):<45} ║
    ║  Mod:      Yalnızca Slash (/) Komutları                  ║
    ║  Sunucu:   {len(bot.guilds):<45} ║
    ╚══════════════════════════════════════════════════════════╝
    """
    print(banner)

    # Kalıcı View'leri kaydet (bot yeniden başlayınca butonlar çalışmaya devam eder)
    bot.add_view(VoiceRefreshView())
    bot.add_view(SecretRoomControlView())
    bot.add_view(VipPrivilegesView())

    # Slash komutlarını senkronize et
    try:
        synced = await bot.tree.sync()
        print(f"[Slash] {len(synced)} slash komutu başarıyla Discord'a kaydedildi.")
        for cmd in synced:
            print(f" └ /{cmd.name} -> {cmd.description}")
    except Exception as e:
        print(f"[Slash Hata]: {e}")

    # Arka plan görevlerini başlat
    if not live_panel_update.is_running():
        live_panel_update.start()
    if not presence_rotation.is_running():
        presence_rotation.start()
    if not keep_voice_connection.is_running():
        keep_voice_connection.start()

    # İlk durum aktivitesi (Yayında - Mor Rozet)
    bot_adi = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    stream_url = config.get("stream_url", "https://www.twitch.tv/imzapriw")
    try:
        await bot.change_presence(activity=discord.Streaming(name=f"👑 discord.gg/imzapriw | {bot_adi}", url=stream_url))
    except Exception as e:
        print(f"[Presence Açılış Hatası]: {e}", flush=True)

    # Arka plan durum taramasını başlat
    asyncio.create_task(initial_status_scan())

    # Secret Web Kontrol Paneli Sunucusunu Başlat
    try:
        await start_secret_web_server()
    except Exception as e:
        print(f"[Secret Web Sunucu Başlatma Hatası]: {e}", flush=True)

# ─────────────────────────────────────────────
# SLASH KOMUTLARI (TAMAMI `/` İLE ÇALIŞIR)
# ─────────────────────────────────────────────

# 1. /ses
@bot.tree.command(name="ses", description="Seste kaç kişi olduğunu ve odalardaki üyeleri listeler.")
async def slash_ses(interaction: discord.Interaction):
    embed = build_voice_embed(interaction.guild)
    await interaction.response.send_message(embed=embed, view=VoiceRefreshView())

# 2. /say
@bot.tree.command(name="say", description="Seste kaç kişi olduğunu, mikrofon/kulaklık/yayın durumlarını resimli afişle gösterir.")
async def slash_say(interaction: discord.Interaction):
    await interaction.response.defer()
    file, embed = await get_voice_say_file_and_embed(interaction.guild)
    await interaction.followup.send(file=file, embed=embed)

# 3. /liste
@bot.tree.command(name="liste", description="Sunucu üyeleri, aktiflik, boost ve detaylı genel sayım dökümünü resimli gösterir.")
async def slash_liste(interaction: discord.Interaction):
    await interaction.response.defer()
    file, embed = await get_say_file_and_embed(interaction.guild)
    await interaction.followup.send(file=file, embed=embed)

# 4. /nerede
@bot.tree.command(name="nerede", description="Bir kullanıcının hangi ses odasında olduğunu bulur.")
@app_commands.describe(kullanici="Hangi ses kanalında olduğuna bakılacak kullanıcı")
async def slash_nerede(interaction: discord.Interaction, kullanici: discord.Member = None):
    target = kullanici or interaction.user
    embed = get_user_voice_embed(target)
    await interaction.response.send_message(embed=embed)

# 5. /panel (Yönetici)
@bot.tree.command(name="panel", description="Bulunduğun kanala canlı oto-güncellenen ses takip paneli kurar.")
@app_commands.default_permissions(administrator=True)
async def slash_panel(interaction: discord.Interaction):
    embed = build_voice_embed(interaction.guild)
    await interaction.response.send_message("✅ Canlı Ses Paneli oluşturuluyor...", ephemeral=True)
    msg = await interaction.channel.send(embed=embed, view=VoiceRefreshView())

    config["panel_kanal_id"] = interaction.channel_id
    config["panel_mesaj_id"] = msg.id
    save_config(config)
    await interaction.followup.send("✅ **Canlı Ses Paneli Başarıyla Kuruldu!** Her 15 saniyede veya ses odalarında hareket olduğunda otomatik yenilenecektir.", ephemeral=True)

# 6. /sil (Yönetici)
@bot.tree.command(name="sil", description="Belirtilen sayıda mesajı sohbetten temizler.")
@app_commands.describe(miktar="Silinecek mesaj sayısı (1-100)")
@app_commands.default_permissions(manage_messages=True)
async def slash_sil(interaction: discord.Interaction, miktar: int = 10):
    if miktar < 1 or miktar > 100:
        await interaction.response.send_message("⚠️ Miktar 1 ile 100 arasında olmalıdır.", ephemeral=True)
        return

    await interaction.response.defer(ephemeral=True)
    deleted = await interaction.channel.purge(limit=miktar)
    await interaction.followup.send(f"🧹 `{len(deleted)}` adet mesaj temizlendi.", ephemeral=True)

# 7. /yardim
@bot.tree.command(name="yardim", description="ɨ̇ ʍ ʐ ǟ botunun tüm slash komutlarını gösterir.")
async def slash_yardim(interaction: discord.Interaction):
    embed = build_help_embed()
    await interaction.response.send_message(embed=embed)

# 8. /durum-tara (Yönetici)
@bot.tree.command(name="durum-tara", description="Sunucudaki üyeleri tarar ve durumunda /imzapriw olanlara rol verir.")
@app_commands.default_permissions(administrator=True)
async def slash_durum_tara(interaction: discord.Interaction):
    role_id = config.get("durum_rol_id")
    if not role_id:
        await interaction.response.send_message("❌ `config.json` dosyasında `durum_rol_id` ayarlanmamış.", ephemeral=True)
        return

    role = interaction.guild.get_role(int(role_id))
    if not role:
        await interaction.response.send_message(f"❌ `{role_id}` ID'li rol bu sunucuda bulunamadı.", ephemeral=True)
        return

    await interaction.response.defer(ephemeral=True)

    already_supporters = []
    added_list = []
    removed_list = []
    total = 0

    for member in interaction.guild.members:
        if not member.bot:
            total += 1
            should_have = has_status_keyword(member)
            has_it = role in member.roles
            try:
                if should_have and has_it:
                    already_supporters.append(member.mention)
                elif should_have and not has_it:
                    await member.add_roles(role, reason="Manuel durum taraması.")
                    added_list.append(member.mention)
                    await asyncio.sleep(0.2)
                elif not should_have and has_it:
                    await member.remove_roles(role, reason="Manuel durum taraması.")
                    removed_list.append(member.mention)
                    await asyncio.sleep(0.2)
            except discord.Forbidden:
                await interaction.followup.send(
                    f"⚠️ **Yetki Hatası:** Botun rolü, {role.mention} rolünün **altında**!\n"
                    f"Lütfen Sunucu Ayarları > Roller kısmından botun rolünü {role.mention} rolünün üstüne sürükleyin.",
                    ephemeral=True
                )
                return
            except Exception:
                pass

    already_text = ", ".join(already_supporters) if already_supporters else "Yok"
    added_text = ", ".join(added_list) if added_list else "0 üye"
    removed_text = ", ".join(removed_list) if removed_list else "0 üye"

    desc = (
        f"🎯 **Hedef Rol:** {role.mention}\n"
        f"🔍 **Taranan Kullanıcı:** `{total}`\n\n"
        f"⭐ **Zaten Rolü Olan Aktif Destekçiler ({len(already_supporters)}):**\n"
        f"└ {already_text}\n\n"
        f"✅ **Yeni Rol Verilen ({len(added_list)}):**\n"
        f"└ {added_text}\n\n"
        f"❌ **Rolü Geri Alınan ({len(removed_list)}):**\n"
        f"└ {removed_text}\n\n"
        f"*Özel durumuna `/imzapriw` veya `discord.gg/imzapriw` yazanların rolleri otomatik olarak güncellenir.*"
    )

    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ┊ Durum Taraması Tamamlandı",
        description=desc,
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    logo = get_brand_logo_url(interaction.guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Otomatik Rol Sistemi")
    await interaction.followup.send(embed=embed, ephemeral=True)

# 9. /secret-oda-kur (Yönetici)
@bot.tree.command(name="secret-oda-kur", description="Otomatik Secret Oda (Özel Ses Kanalı) sistemini sunucuya kurar.")
@app_commands.default_permissions(administrator=True)
async def slash_secret_oda_kur(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild

    try:
        # 1. Kategori oluştur
        cat_name = f"━━━ {config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} SECRET ━━━"
        category = await guild.create_category(name=cat_name, reason="Secret Oda kategorisi")

        # 2. Kalıcı Panel Metin Kanalını oluştur (üyeler yazamaz, sadece butonlara basar)
        text_overwrites = {
            guild.default_role: discord.PermissionOverwrite(
                view_channel=True,
                read_message_history=True,
                send_messages=False,
                add_reactions=False
            ),
            guild.me: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                embed_links=True,
                manage_messages=True
            )
        }
        panel_channel = await guild.create_text_channel(
            name="💬・secret-panel",
            category=category,
            overwrites=text_overwrites,
            reason="Secret Oda kontrol panel kanalı"
        )

        # 3. Kontrol Paneli Görsel Kartını ve Butonlarını kanala at
        panel_file = await get_secret_panel_card_file(guild)
        panel_msg = await panel_channel.send(file=panel_file, view=SecretRoomControlView())

        # 4. Giriş tetikleyici ses kanalını oluştur
        ch_name = "➕・Secret Oda Aç"
        gen_channel = await guild.create_voice_channel(
            name=ch_name,
            category=category,
            user_limit=1,
            reason="Secret Oda tetikleyici ses kanalı"
        )

        # 5. Config'e kaydet
        config["secret_kategori_id"] = category.id
        config["secret_panel_kanal_id"] = panel_channel.id
        config["secret_panel_mesaj_id"] = panel_msg.id
        config["secret_giris_kanal_id"] = gen_channel.id
        save_config(config)

        embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ┊ Secret Oda Sistemi Kuruldu",
            description=(
                "**Secret (Özel) Oda Sistemi Başarıyla Kuruldu!**\n\n"
                f"• Kategori: `{category.name}`\n"
                f"• Panel Kanalı: {panel_channel.mention}\n"
                f"• Giriş Kanalı: {gen_channel.mention}\n\n"
                "**Nasıl Kullanılır?**\n"
                f"1. Üyeler {gen_channel.mention} kanalına tıklar ve otomatik özel odaya taşınır.\n"
                f"2. Üyeler odalarını yönetmek için {panel_channel.mention} kanalındaki butonlara basar.\n"
                "3. Odada kimse kalmadığında bot odayı sunucudan otomatik olarak siler."
            ),
            color=get_embed_color(),
            timestamp=datetime.now(timezone.utc)
        )
        logo = get_brand_logo_url(guild)
        if logo:
            embed.set_thumbnail(url=logo)
        embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Secret Voice System")

        await interaction.followup.send(embed=embed, ephemeral=True)
        print(f"[Secret Oda] Kurulum tamamlandı: Kategori={category.name}, Panel={panel_channel.name}, Giriş={gen_channel.name}")
    except Exception as e:
        await interaction.followup.send(f"Kurulum sırasında bir hata oluştu: {e}", ephemeral=True)

# 10. /secret-panel-gonder (Yönetici)
@bot.tree.command(name="secret-panel-gonder", description="Bulunduğun metin kanalına Secret Oda Görsel Yönetim Panelini gönderir.")
@app_commands.default_permissions(administrator=True)
async def slash_secret_panel_gonder(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    panel_file = await get_secret_panel_card_file(interaction.guild)
    msg = await interaction.channel.send(file=panel_file, view=SecretRoomControlView())
    config["secret_panel_kanal_id"] = interaction.channel_id
    config["secret_panel_mesaj_id"] = msg.id
    save_config(config)
    await interaction.followup.send("Secret Oda Görsel Yönetim Paneli başarıyla kanala gönderildi.", ephemeral=True)

# 10.1. /secret-panel-guncelle (Yönetici)
@bot.tree.command(name="secret-panel-guncelle", description="Kayıtlı Secret Panel kanalındaki mesajı görsel yeni tasarımla günceller.")
@app_commands.default_permissions(administrator=True)
async def slash_secret_panel_guncelle(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    ch_id = config.get("secret_panel_kanal_id")
    msg_id = config.get("secret_panel_mesaj_id")
    if not ch_id:
        await interaction.followup.send("Kayıtlı bir Secret Panel kanalı bulunamadı! Lütfen `/secret-panel-gonder` komutunu kullanın.", ephemeral=True)
        return

    channel = interaction.guild.get_channel(int(ch_id))
    if not channel:
        await interaction.followup.send("Kayıtlı Secret Panel kanalı sunucuda bulunamadı!", ephemeral=True)
        return

    panel_file = await get_secret_panel_card_file(interaction.guild)
    if msg_id:
        try:
            old_msg = await channel.fetch_message(int(msg_id))
            if old_msg:
                try:
                    await old_msg.delete()
                except Exception:
                    pass
        except Exception:
            pass

    new_msg = await channel.send(file=panel_file, view=SecretRoomControlView())
    config["secret_panel_kanal_id"] = channel.id
    config["secret_panel_mesaj_id"] = new_msg.id
    save_config(config)
    await interaction.followup.send(f"Secret Panel {channel.mention} kanalında görsel yeni tasarımıyla başarıyla güncellendi.", ephemeral=True)

# 10.2. /secret-web (Secret Oda Sahibi Web Kontrol Paneli)
@bot.tree.command(name="secret-web", description="Secret odanızı web üzerinden yönetmeniz için kişisel web panel linki ve önizlemesi üretir.")
async def slash_secret_web(interaction: discord.Interaction):
    ch = await get_controlled_room(interaction)
    if not ch:
        return
    await interaction.response.defer(ephemeral=True)
    web_url = get_room_web_url(ch.id, user_id=interaction.user.id)
    room_info = get_room_data(ch.id)
    owner_id = room_info.get("owner_id") or room_info.get("transferred_to") or interaction.user.id
    owner_member = interaction.guild.get_member(int(owner_id)) if owner_id else interaction.user
    owner_name = owner_member.display_name if owner_member else interaction.user.display_name

    preview_file = await get_web_dashboard_preview_file(ch.name, owner_name, ch.id, web_url)
    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    embed = discord.Embed(
        title=f"🌐 {bot_name} ✦ CANLI WEB KONTROL PANELİ",
        description=(
            f"> **{ch.name}** odanız için ultra-lüks web kontrol paneliniz hazır!\n\n"
            f"› 👑 **Oda Sahibi:** {owner_member.mention}\n"
            f"› ⚡ **Özellikler:** Canlı ses dalgası equalizer, anlık üye arama/izin/engelleme, isim & limit değişimi, davet linki.\n"
            f"› 🔗 **Panel Adresi:** [Web Dashboard'u Açmak İçin Tıkla]({web_url})\n\n"
            f"Tarayıcınızdan odanızı canlı yönetmek için aşağıdaki **[🌐 Web Kontrol Panelini Aç ↗]** butonuna tıklayın!"
        ),
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    logo = get_brand_logo_url(interaction.guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_image(url="attachment://web_dashboard_preview.png")
    embed.set_footer(text=f"{bot_name} • 7/24 Canlı Web Yönetim Arayüzü", icon_url=logo if logo else None)

    view = discord.ui.View()
    view.add_item(discord.ui.Button(label="🌐 Web Kontrol Panelini Aç ↗", url=web_url, style=discord.ButtonStyle.link))
    await interaction.followup.send(embed=embed, file=preview_file, view=view, ephemeral=True)

# 11. /otorol-ayarla (Yönetici)
@bot.tree.command(name="otorol-ayarla", description="Sunucuya yeni girenlere otomatik verilecek rolü ayarlar.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(rol="Otomatik verilecek üye rolü")
async def slash_otorol_ayarla(interaction: discord.Interaction, rol: discord.Role):
    if interaction.guild.me.top_role <= rol:
        await interaction.response.send_message(
            f"⚠️ **Dikkat:** Botun rolü (`{interaction.guild.me.top_role.name}`), `{rol.name}` rolünün altında!\n"
            "Botun bu rolü verebilmesi için lütfen Sunucu Ayarları > Roller kısmından botun rolünü yukarı taşı.",
            ephemeral=True
        )
        return

    config["otorol_id"] = rol.id
    save_config(config)
    await interaction.response.send_message(
        f"✅ **Otorol başarıyla güncellendi:** {rol.mention} (`{rol.id}`)\n"
        f"Artık sunucuya yeni giren herkese bu rol otomatik verilecektir.",
        ephemeral=True
    )

# 12. /otorol-tara (Yönetici)
@bot.tree.command(name="otorol-tara", description="Sunucuda otorolü (Member) bulunmayan mevcut tüm üyelere topluca rolü verir.")
@app_commands.default_permissions(administrator=True)
async def slash_otorol_tara(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild

    role_id = config.get("otorol_id", 0)
    role = guild.get_role(int(role_id))
    if not role:
        await interaction.followup.send("❌ Otorol bulunamadı! Lütfen önce `/otorol-ayarla` ile rol seçin.", ephemeral=True)
        return

    if guild.me.top_role <= role:
        await interaction.followup.send(
            f"❌ **Yetki Hatası:** Botun rolü (`{guild.me.top_role.name}`), `{role.name}` rolünün altında!\n"
            "Lütfen Sunucu Ayarları > Roller bölümünden botun rolünü yukarı taşıyın.",
            ephemeral=True
        )
        return

    given_count = 0
    already_have = 0

    for m in guild.members:
        if not m.bot:
            if role not in m.roles:
                try:
                    await m.add_roles(role, reason="Toplu otorol taraması")
                    given_count += 1
                    await asyncio.sleep(0.3)
                except Exception:
                    pass
            else:
                already_have += 1

    await interaction.followup.send(
        f"✅ **Otorol Taraması Tamamlandı!**\n\n"
        f"› 🎯 **Rol:** {role.mention}\n"
        f"› ➕ **Yeni Verilen:** `{given_count}` üye\n"
        f"› 🛡️ **Zaten Sahip Olan:** `{already_have}` üye",
        ephemeral=True
    )

# 13. /vip (Yönetici & Rol Yönetme Yetkisi)
@bot.tree.command(name="vip", description="Belirtilen üyeye VIP rolünü verir.")
@app_commands.default_permissions(manage_roles=True)
@app_commands.describe(
    kullanıcı="VIP rolü verilecek üye",
    sebep="İşlem açıklaması / sebebi (İsteğe bağlı)"
)
async def slash_vip(interaction: discord.Interaction, kullanıcı: discord.Member, sebep: str = "Belirtilmedi"):
    guild = interaction.guild
    vip_role_id = config.get("vip_rol_id", 0)
    role = guild.get_role(int(vip_role_id))

    if not role:
        await interaction.response.send_message(f"❌ **VIP rolü sunucuda bulunamadı!** (ID: `{vip_role_id}`)", ephemeral=True)
        return

    if guild.me.top_role <= role:
        await interaction.response.send_message(
            f"❌ **Yetki Hatası:** Botun en yüksek rolü (`{guild.me.top_role.name}`), VIP rolü (`{role.name}`) altında veya eşit!\n"
            "Lütfen Sunucu Ayarları > Roller bölümünden botun rolünü VIP rolünün üstüne sürükleyin.",
            ephemeral=True
        )
        return

    if kullanıcı.bot:
        await interaction.response.send_message("❌ Botlara VIP rolü verilemez.", ephemeral=True)
        return

    # Durumu kontrol et (Var mı, yok mu?)
    has_vip = role in kullanıcı.roles

    if has_vip:
        await interaction.response.send_message(
            f"⚠️ {kullanıcı.mention} zaten **{role.name}** rolüne sahip!\n"
            f"Rolü geri almak için **`/vip-al`** komutunu kullanabilirsin.",
            ephemeral=True
        )
        return

    # VIP'yi ver
    try:
        await kullanıcı.add_roles(role, reason=f"VIP Verildi: {interaction.user.display_name} | Sebep: {sebep}")
        embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ✦ VIP ROLÜ TANIMLANDI 👑",
            description=(
                f"> {kullanıcı.mention} kullanıcısına VIP ayrıcalıkları başarıyla tanımlandı!\n\n"
                f"› 👤 **Kullanıcı:** {kullanıcı.mention} (`{kullanıcı.id}`)\n"
                f"› 🛡️ **İşlemi Yapan:** {interaction.user.mention}\n"
                f"› 👑 **Verilen Rol:** {role.mention}\n"
                f"› 📝 **Sebep:** `{sebep}`"
            ),
            color=0xf1c40f,
            timestamp=datetime.now(timezone.utc)
        )
        if kullanıcı.display_avatar:
            embed.set_thumbnail(url=kullanıcı.display_avatar.url)
        logo = get_brand_logo_url(guild)
        if logo:
            embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • VIP Yönetimi", icon_url=logo)
        await interaction.response.send_message(embed=embed)
        print(f"[VIP] + {interaction.user.display_name} tarafından {kullanıcı.display_name} üyesine VIP rolü verildi.", flush=True)

        # Kullanıcıya DM tebrik bildirimi (İsteğe bağlı)
        try:
            dm_embed = discord.Embed(
                title=f"👑 VIP Rolün Tanımlandı! ✦ {guild.name}",
                description=(
                    f"Tebrikler {kullanıcı.mention}!\n\n"
                    f"**{guild.name}** sunucumuzda sana özel **{role.name}** rolü tanımlandı.\n"
                    f"Ayrıcalıkların ve VIP odalara erişimin keyfini çıkar!\n\n"
                    f"› **Veren Yetkili:** {interaction.user.display_name}\n"
                    f"› **Sebep:** `{sebep}`"
                ),
                color=0xf1c40f,
                timestamp=datetime.now(timezone.utc)
            )
            if logo:
                dm_embed.set_thumbnail(url=logo)
            await kullanıcı.send(embed=dm_embed)
        except Exception:
            pass
    except Exception as e:
        await interaction.response.send_message(f"❌ VIP rolü verilirken bir hata oluştu: {e}", ephemeral=True)

# 14. /vip-al (Yönetici & Rol Yönetme Yetkisi)
@bot.tree.command(name="vip-al", description="Belirtilen üyeden VIP rolünü geri alır.")
@app_commands.default_permissions(manage_roles=True)
@app_commands.describe(
    kullanıcı="VIP rolü alınacak üye",
    sebep="Rol alma sebebi (İsteğe bağlı)"
)
async def slash_vip_al(interaction: discord.Interaction, kullanıcı: discord.Member, sebep: str = "Belirtilmedi"):
    guild = interaction.guild
    vip_role_id = config.get("vip_rol_id", 0)
    role = guild.get_role(int(vip_role_id))

    if not role:
        await interaction.response.send_message(f"❌ **VIP rolü sunucuda bulunamadı!** (ID: `{vip_role_id}`)", ephemeral=True)
        return

    if guild.me.top_role <= role:
        await interaction.response.send_message(
            f"❌ **Yetki Hatası:** Botun en yüksek rolü (`{guild.me.top_role.name}`), VIP rolü (`{role.name}`) altında veya eşit!\n"
            "Lütfen Sunucu Ayarları > Roller bölümünden botun rolünü VIP rolünün üstüne sürükleyin.",
            ephemeral=True
        )
        return

    if role not in kullanıcı.roles:
        await interaction.response.send_message(f"⚠️ {kullanıcı.mention} kullanıcısında zaten **{role.name}** rolü bulunmuyor!", ephemeral=True)
        return

    try:
        await kullanıcı.remove_roles(role, reason=f"VIP Alındı: {interaction.user.display_name} | Sebep: {sebep}")
        embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ✦ VIP ROLÜ ALINDI ❌",
            description=(
                f"> {kullanıcı.mention} kullanıcısından VIP ayrıcalıkları başarıyla geri alındı.\n\n"
                f"› 👤 **Kullanıcı:** {kullanıcı.mention} (`{kullanıcı.id}`)\n"
                f"› 🛡️ **Yetkili:** {interaction.user.mention}\n"
                f"› 👑 **Geri Alınan Rol:** {role.mention}\n"
                f"› 📝 **Sebep:** `{sebep}`"
            ),
            color=0xed4245,
            timestamp=datetime.now(timezone.utc)
        )
        if kullanıcı.display_avatar:
            embed.set_thumbnail(url=kullanıcı.display_avatar.url)
        logo = get_brand_logo_url(guild)
        if logo:
            embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • VIP Yönetimi", icon_url=logo)
        await interaction.response.send_message(embed=embed)
        print(f"[VIP AL] - {interaction.user.display_name} tarafından {kullanıcı.display_name} üyesinden VIP rolü alındı.", flush=True)

        # Kullanıcıya DM bilgilendirme (İsteğe bağlı)
        try:
            dm_embed = discord.Embed(
                title=f"👑 VIP Rolün Geri Alındı ✦ {guild.name}",
                description=(
                    f"Merhaba {kullanıcı.mention},\n\n"
                    f"**{guild.name}** sunucusundaki **{role.name}** rolün yetkili tarafından geri alındı.\n\n"
                    f"› **İşlemi Yapan:** {interaction.user.display_name}\n"
                    f"› **Sebep:** `{sebep}`"
                ),
                color=0xed4245,
                timestamp=datetime.now(timezone.utc)
            )
            if logo:
                dm_embed.set_thumbnail(url=logo)
            await kullanıcı.send(embed=dm_embed)
        except Exception:
            pass
    except Exception as e:
        await interaction.response.send_message(f"❌ VIP rolü alınırken bir hata oluştu: {e}", ephemeral=True)

# 15. /vip-kanal-kur (Yönetici)
@bot.tree.command(name="vip-kanal-kur", description="VIP ayrıcalıkları ve butonla otomatik nickname değiştirme panelini kurar.")
@app_commands.describe(kanal="Panelin gönderileceği metin kanalı (seçilmezse otomatik '👑・vip-bilgi' kanalı açılır)")
async def slash_vip_kanal_kur(interaction: discord.Interaction, kanal: discord.TextChannel = None):
    # Yetki kontrolü (Yönetici)
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ Bu komutu yalnızca **Yönetici** yetkisine sahip kişiler kullanabilir.", ephemeral=True)
        return

    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild

    target_channel = kanal
    created_new = False

    if not target_channel:
        cat_id = config.get("secret_kategori_id")
        category = guild.get_channel(int(cat_id)) if cat_id else None

        vip_role_id = config.get("vip_rol_id", 0)
        vip_role = guild.get_role(int(vip_role_id))

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=True, send_messages=False, add_reactions=False),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, embed_links=True, attach_files=True)
        }
        if vip_role:
            overwrites[vip_role] = discord.PermissionOverwrite(view_channel=True, send_messages=False)

        try:
            target_channel = await guild.create_text_channel(
                name="👑・vip-bilgi",
                category=category,
                overwrites=overwrites,
                topic="VIP üyelerimizin sahip olduğu tüm ayrıcalıklar ve canlı nickname değiştirme kontrol merkezi.",
                reason="VIP Ayrıcalıkları ve Kontrol Paneli için otomatik kanal oluşturuldu."
            )
            created_new = True
        except Exception as e:
            await interaction.followup.send(f"❌ Otomatik kanal oluşturulamadı: {e}. Lütfen komutta bir metin kanalı belirtin.", ephemeral=True)
            return

    # Görsel ve embed hazırla
    try:
        file = await get_vip_panel_card_file(guild)
        embed = build_vip_privileges_embed(guild)
        view = VipPrivilegesView()

        msg = await target_channel.send(file=file, embed=embed, view=view)

        # Config kaydet
        config["vip_kanal_id"] = target_channel.id
        config["vip_mesaj_id"] = msg.id
        save_config(config)

        res_text = (
            f"✅ **VIP Ayrıcalıkları ve Etkileşim Paneli Başarıyla Kuruldu!**\n\n"
            f"› 📢 **Kanal:** {target_channel.mention}\n"
            f"› 👑 **VIP Rolü:** <@&{config.get('vip_rol_id', 0)}>\n"
            f"› ✨ **Aktif Özellikler:** VIP üyeler artık bu panelden isim değiştirme, kraliyet tagı süsleme (👑, ✦, ⚡, 💎), özel VIP kimlik kartı üretme, VIP şans çarkı çevirme ve locadan havalı selam gönderme ayrıcalıklarını sınırsız kullanabilir!"
        )
        if created_new:
            res_text += f"\n*(Kanal `@everyone` için sadece okumaya açık, mesaj yazmaya kapalı olarak yapılandırıldı)*"

        await interaction.followup.send(res_text, ephemeral=True)
    except Exception as e:
        await interaction.followup.send(f"❌ Panel kurulurken bir hata oluştu: {e}", ephemeral=True)

# 16. /secret-yönetim & /secret-yonetim (Yetkili Yöneticilere Özel Master Hub)
async def handle_secret_admin_command(interaction: discord.Interaction):
    # Yetki kontrolü (Rol 0 veya Yönetici)
    if not is_secret_admin(interaction.user):
        admin_role_id = config.get("secret_admin_rol_id", 0)
        await interaction.response.send_message(
            f"❌ **Erişim Reddedildi!**\nBu komutu yalnızca yetkili yöneticiler (<@&{admin_role_id}>) kullanabilir.",
            ephemeral=True
        )
        return

    guild = interaction.guild
    admin_url = get_secret_admin_web_url(user_id=interaction.user.id)
    direct_url = get_secret_admin_direct_ip_url(user_id=interaction.user.id)
    admin_role_id = config.get("secret_admin_rol_id", 0)

    # Anlık istatistik hesaplama
    cat_id = config.get("secret_kategori_id")
    giris_id = config.get("secret_giris_kanal_id")
    data_map = load_secret_rooms()

    channel_ids = set()
    for k in data_map.keys():
        try:
            channel_ids.add(int(k))
        except Exception:
            pass
    if cat_id and guild:
        try:
            cat = guild.get_channel(int(cat_id))
            if cat and isinstance(cat, discord.CategoryChannel):
                for vc in cat.voice_channels:
                    if not giris_id or vc.id != int(giris_id):
                        channel_ids.add(vc.id)
        except Exception:
            pass

    active_rooms = 0
    total_voice_members = 0
    locked_rooms = 0
    hidden_rooms = 0

    if guild:
        for cid in channel_ids:
            ch = guild.get_channel(cid)
            if ch and isinstance(ch, (discord.VoiceChannel, discord.StageChannel)):
                active_rooms += 1
                total_voice_members += len(ch.members)
                default_ow = ch.overwrites_for(guild.default_role)
                if default_ow.connect is False:
                    locked_rooms += 1
                if default_ow.view_channel is False:
                    hidden_rooms += 1

    bot_adi = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    logo = guild.icon.url if guild and guild.icon else (bot.user.display_avatar.url if bot.user and bot.user.display_avatar else None)

    embed = discord.Embed(
        title=f"👑 Secret Oda Yönetim Merkezi ✦ Tüm Odalar Hub'ı",
        description=(
            f"Merhaba **{interaction.user.display_name}**,\n"
            f"Sunucudaki tüm aktif Secret odalarını canlı olarak izleyebileceğiniz, tek tıkla odaları "
            f"kapatabileceğiniz, kilitleyebileceğiniz ve doğrudan odaların web paneline bağlanabileceğiniz "
            f"**Secret Yönetici Web Hub'ı** hazır!\n\n"
            f"📊 **Anlık Durum Özeti:**\n"
            f"› 🎙️ **Aktif Secret Oda:** `{active_rooms}` adet\n"
            f"› 👥 **Sesteki Toplam Üye:** `{total_voice_members}` kişi\n"
            f"› 🔒 **Kilitli / Gizli:** `{locked_rooms}` kilitli | `{hidden_rooms}` gizli\n"
            f"› 🛡️ **Erişim Yetkisi:** <@&{admin_role_id}>\n\n"
            f"› 🌐 **Global HTTPS:** [Panele Git]({admin_url})\n"
            f"› ⚡ **Doğrudan IP (Yedek):** [IP ile Bağlan]({direct_url})"
        ),
        color=0x6366f1,
        timestamp=datetime.now(timezone.utc)
    )
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_footer(text=f"{bot_adi} ✦ Master Admin Konsolu", icon_url=logo or bot.user.display_avatar.url)

    view = discord.ui.View()
    view.add_item(discord.ui.Button(
        label="Secret Yönetim Paneli ↗",
        url=admin_url,
        style=discord.ButtonStyle.link,
        emoji="👑"
    ))
    if direct_url and direct_url != admin_url:
        view.add_item(discord.ui.Button(
            label="Doğrudan IP Girişi ↗",
            url=direct_url,
            style=discord.ButtonStyle.link,
            emoji="🌐"
        ))

    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

@bot.tree.command(name="secret-yönetim", description="Tüm Secret odalarını canlı gösteren yönetici kontrol hub linkini verir.")
async def slash_secret_yonetim_tr(interaction: discord.Interaction):
    await handle_secret_admin_command(interaction)

@bot.tree.command(name="secret-yonetim", description="Tüm Secret odalarını canlı gösteren yönetici kontrol hub linkini verir.")
async def slash_secret_yonetim_en(interaction: discord.Interaction):
    await handle_secret_admin_command(interaction)

# ─────────────────────────────────────────────
# SPOTIFY KART & KOMUTLARI (/spotify & /spo)
# ─────────────────────────────────────────────

def get_spotify_font(size: int, bold: bool = False):
    paths = [
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
    ]
    for p in paths:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()

def create_spotify_card(
    song_title: str,
    artist_name: str,
    album_name: str,
    current_sec: float,
    total_sec: float,
    user_name: str,
    album_img: Image.Image = None,
    avatar_img: Image.Image = None
) -> Image.Image:
    width = 880
    height = 280
    radius = 26

    # 1. Taban Resim & Arka Plan Bulanıklığı
    bg_img = Image.new("RGBA", (width, height), (15, 17, 23, 255))
    if album_img:
        try:
            blurred_bg = album_img.resize((width, int(width * album_img.height / album_img.width))).filter(ImageFilter.GaussianBlur(38))
            crop_y = (blurred_bg.height - height) // 2
            blurred_bg = blurred_bg.crop((0, max(0, crop_y), width, max(0, crop_y) + height))
            dark_overlay = Image.new("RGBA", (width, height), (10, 12, 16, 215))
            blurred_bg = Image.alpha_composite(blurred_bg.convert("RGBA"), dark_overlay)
            bg_img = blurred_bg
        except Exception:
            pass

    # Yuvarlatılmış kart maskesi
    mask = Image.new("L", (width, height), 0)
    mask_draw = ImageDraw.Draw(mask)
    mask_draw.rounded_rectangle([(0, 0), (width, height)], radius=radius, fill=255)
    
    card = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    card.paste(bg_img, (0, 0), mask)
    draw = ImageDraw.Draw(card)

    # İnce kart kenarlığı
    draw.rounded_rectangle([(0, 0), (width - 1, height - 1)], radius=radius, outline=(255, 255, 255, 28), width=1)

    # 2. Sol Bölüm: Albüm Kapağı & Spotify Yeşili Glow Efekti
    cov_x = 35
    cov_y = 35
    cov_size = 210
    cov_radius = 20

    if album_img:
        cover_resized = album_img.convert("RGBA").resize((cov_size, cov_size), Image.Resampling.LANCZOS)
        
        # Kapak arkası yeşil neon ışıma (ambient glow)
        glow_pad = 28
        glow_size = cov_size + glow_pad * 2
        glow_img = Image.new("RGBA", (glow_size, glow_size), (0, 0, 0, 0))
        glow_draw = ImageDraw.Draw(glow_img)
        glow_draw.rounded_rectangle(
            [(glow_pad - 4, glow_pad - 4), (glow_size - glow_pad + 4, glow_size - glow_pad + 4)],
            radius=cov_radius + 4,
            fill=(29, 185, 84, 100)
        )
        glow_img = glow_img.filter(ImageFilter.GaussianBlur(18))
        card.alpha_composite(glow_img, (cov_x - glow_pad, cov_y - glow_pad))

        # Yuvarlatılmış kapak
        cov_mask = Image.new("L", (cov_size, cov_size), 0)
        cov_mask_draw = ImageDraw.Draw(cov_mask)
        cov_mask_draw.rounded_rectangle([(0, 0), (cov_size, cov_size)], radius=cov_radius, fill=255)
        
        card.paste(cover_resized, (cov_x, cov_y), cov_mask)
        draw.rounded_rectangle([(cov_x, cov_y), (cov_x + cov_size, cov_y + cov_size)], radius=cov_radius, outline=(255, 255, 255, 40), width=1)
    else:
        draw.rounded_rectangle([(cov_x, cov_y), (cov_x + cov_size, cov_y + cov_size)], radius=cov_radius, fill=(24, 28, 40, 255), outline=(255, 255, 255, 40), width=1)

    # 3. Sağ Bölüm: Şarkı, Sanatçı ve Çalma Bilgileri
    text_x = cov_x + cov_size + 30
    
    # 3a. Başlık Rozeti: "• SPOTIFY'DA DİNLİYOR"
    top_y = 42
    draw.ellipse([(text_x, top_y + 4), (text_x + 8, top_y + 12)], fill=(29, 185, 84, 255))
    font_sub = get_spotify_font(13, bold=True)
    draw.text((text_x + 16, top_y), "SPOTIFY'DA DİNLİYOR", font=font_sub, fill=(29, 185, 84, 255))

    # 3b. Şarkı Adı (Büyük ve Kalın)
    title_y = top_y + 24
    font_title = get_spotify_font(28, bold=True)
    display_title = song_title
    max_title_w = width - text_x - 45
    while font_title.getbbox(display_title)[2] > max_title_w and len(display_title) > 3:
        display_title = display_title[:-4] + "..."
    draw.text((text_x, title_y), display_title, font=font_title, fill=(255, 255, 255, 255))

    # 3c. Sanatçı Adı
    artist_y = title_y + 36
    font_artist = get_spotify_font(18, bold=False)
    display_artist = artist_name
    while font_artist.getbbox(display_artist)[2] > max_title_w and len(display_artist) > 3:
        display_artist = display_artist[:-4] + "..."
    draw.text((text_x, artist_y), display_artist, font=font_artist, fill=(209, 213, 219, 255))

    # 3d. Albüm Adı ve Disk İkonu
    album_y = artist_y + 26
    font_album = get_spotify_font(14, bold=False)
    display_album = album_name or ""
    while font_album.getbbox(display_album)[2] > (max_title_w - 24) and len(display_album) > 3:
        display_album = display_album[:-4] + "..."
    if display_album:
        disc_size = 13
        disc_y = album_y + 3
        draw.ellipse([(text_x, disc_y), (text_x + disc_size, disc_y + disc_size)], outline=(148, 163, 184, 200), width=1)
        draw.ellipse([(text_x + 4, disc_y + 4), (text_x + disc_size - 4, disc_y + disc_size - 4)], fill=(148, 163, 184, 200))
        draw.text((text_x + disc_size + 8, album_y), display_album, font=font_album, fill=(148, 163, 184, 230))

    # 3e. İlerleme Çubuğu (Progress Bar)
    bar_x = text_x
    bar_y = album_y + 36
    bar_w = 400
    bar_h = 6
    bar_radius = 3

    progress = max(0.0, min(1.0, current_sec / total_sec if total_sec > 0 else 0.0))
    played_w = int(bar_w * progress)

    # Arka plan çizgi
    draw.rounded_rectangle([(bar_x, bar_y), (bar_x + bar_w, bar_y + bar_h)], radius=bar_radius, fill=(55, 65, 81, 200))

    # Oynatılan kısım (Spotify Yeşili)
    if played_w > 0:
        draw.rounded_rectangle([(bar_x, bar_y), (bar_x + played_w, bar_y + bar_h)], radius=bar_radius, fill=(29, 185, 84, 255))

    # İlerleme imleci (Beyaz Nokta)
    thumb_radius = 6
    thumb_x = bar_x + played_w
    thumb_y = bar_y + bar_h // 2
    draw.ellipse([(thumb_x - thumb_radius, thumb_y - thumb_radius), (thumb_x + thumb_radius, thumb_y + thumb_radius)], fill=(255, 255, 255, 255))

    # 3f. Süre Metni: "2:36 / 4:59"
    time_y = bar_y + 12
    cur_m = int(current_sec) // 60
    cur_s = int(current_sec) % 60
    tot_m = int(total_sec) // 60
    tot_s = int(total_sec) % 60
    time_str = f"{cur_m}:{cur_s:02d} / {tot_m}:{tot_s:02d}"
    font_time = get_spotify_font(13, bold=False)
    draw.text((bar_x, time_y), time_str, font=font_time, fill=(148, 163, 184, 255))

    # 3g. Dinleyen Kullanıcı Bilgisi (Sağ Alt)
    if user_name:
        font_user = get_spotify_font(14, bold=True)
        u_bbox = font_user.getbbox(user_name)
        u_w = u_bbox[2] - u_bbox[0]

        ava_size = 40
        ava_x = width - 40 - ava_size
        ava_y = height - 32 - ava_size
        user_x = ava_x - u_w - 12
        user_y = ava_y + (ava_size - (u_bbox[3] - u_bbox[1])) // 2

        draw.text((user_x, user_y), user_name, font=font_user, fill=(241, 245, 249, 255))

        if avatar_img:
            ava_resized = avatar_img.convert("RGBA").resize((ava_size, ava_size), Image.Resampling.LANCZOS)
            ava_mask = Image.new("L", (ava_size, ava_size), 0)
            ava_draw = ImageDraw.Draw(ava_mask)
            ava_draw.ellipse([(0, 0), (ava_size, ava_size)], fill=255)

            card.paste(ava_resized, (ava_x, ava_y), ava_mask)
            draw.ellipse([(ava_x - 2, ava_y - 2), (ava_x + ava_size + 1, ava_y + ava_size + 1)], outline=(29, 185, 84, 255), width=2)
        else:
            draw.ellipse([(ava_x, ava_y), (ava_x + ava_size, ava_y + ava_size)], fill=(30, 41, 59, 255), outline=(29, 185, 84, 255), width=2)

    return card

async def handle_spotify_command(interaction: discord.Interaction, target_member: discord.Member = None):
    # 1. 3 saniyelik zaman aşımı hatasını (The application did not respond) önlemek için hemen defer ediyoruz
    await interaction.response.defer()

    # 2. Üyeyi mutlaka sunucunun önbelleğinden alıyoruz (Discord Gateway aktiviteleri/presence buradadır)
    user_id = target_member.id if target_member else interaction.user.id
    target = None
    if interaction.guild:
        target = interaction.guild.get_member(user_id)

    if not target:
        target = target_member or interaction.user

    # 3. Spotify aktivitesini ara
    spotify_act = None
    if hasattr(target, "activities") and target.activities:
        for act in target.activities:
            if isinstance(act, discord.Spotify):
                spotify_act = act
                break
            elif getattr(act, "name", "").lower() == "spotify":
                spotify_act = act
                break

    if not spotify_act:
        name = target.display_name if hasattr(target, "display_name") else target.name
        await interaction.followup.send(
            f"⚠️ **{name}** şu anda Spotify dinlemiyor veya Discord durumunda Spotify etkin değil.\n*(Discord Ayarları > Activity Privacy > 'Display current activity as a status message' açık olmalıdır)*",
            ephemeral=True
        )
        return

    song_title = getattr(spotify_act, "title", "Bilinmeyen Şarkı") or "Bilinmeyen Şarkı"
    if hasattr(spotify_act, "artists") and spotify_act.artists:
        artist_name = ", ".join(spotify_act.artists)
    else:
        artist_name = getattr(spotify_act, "artist", "Bilinmeyen Sanatçı") or "Bilinmeyen Sanatçı"
    album_name = getattr(spotify_act, "album", "") or ""
    album_url = getattr(spotify_act, "album_cover_url", None)
    track_url = getattr(spotify_act, "track_url", None)

    duration = 0.0
    if hasattr(spotify_act, "duration") and spotify_act.duration:
        duration = spotify_act.duration.total_seconds()

    start = getattr(spotify_act, "start", None)
    if start:
        now = datetime.now(timezone.utc)
        current_sec = (now - start).total_seconds()
        current_sec = max(0.0, min(current_sec, duration))
    else:
        current_sec = 0.0

    user_name = target.display_name if hasattr(target, "display_name") else target.name
    avatar_url = target.display_avatar.url if hasattr(target, "display_avatar") and target.display_avatar else None

    album_img = None
    avatar_img = None

    async with aiohttp.ClientSession() as session:
        if album_url:
            try:
                async with session.get(album_url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    if resp.status == 200:
                        cov_bytes = await resp.read()
                        album_img = Image.open(io.BytesIO(cov_bytes))
            except Exception:
                pass
        if avatar_url:
            try:
                async with session.get(avatar_url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    if resp.status == 200:
                        ava_bytes = await resp.read()
                        avatar_img = Image.open(io.BytesIO(ava_bytes))
            except Exception:
                pass

    def generate_card():
        card = create_spotify_card(
            song_title=song_title,
            artist_name=artist_name,
            album_name=album_name,
            current_sec=current_sec,
            total_sec=duration,
            user_name=user_name,
            album_img=album_img,
            avatar_img=avatar_img
        )
        buf = io.BytesIO()
        card.save(buf, format="PNG")
        buf.seek(0)
        return buf

    buf = await asyncio.to_thread(generate_card)
    file = discord.File(fp=buf, filename="spotify_card.png")

    view = None
    if track_url:
        view = discord.ui.View()
        view.add_item(discord.ui.Button(label="Spotify'da Aç", url=track_url, style=discord.ButtonStyle.link, emoji="🎵"))

    await interaction.followup.send(file=file, view=view)

@bot.tree.command(name="spotify", description="Spotify'da dinlediğin (veya belirtilen üyenin) şarkısını özel kart olarak gösterir.")
@app_commands.describe(kullanici="Şarkısına bakmak istediğin kullanıcı (boş bırakırsan kendin)")
async def slash_spotify(interaction: discord.Interaction, kullanici: discord.Member = None):
    await handle_spotify_command(interaction, kullanici)

@bot.tree.command(name="spo", description="Spotify'da dinlediğin (veya belirtilen üyenin) şarkısını özel kart olarak gösterir.")
@app_commands.describe(kullanici="Şarkısına bakmak istediğin kullanıcı (boş bırakırsan kendin)")
async def slash_spo(interaction: discord.Interaction, kullanici: discord.Member = None):
    await handle_spotify_command(interaction, kullanici)

# ─────────────────────────────────────────────
# BAŞLATMA FONKSİYONU
# ─────────────────────────────────────────────
def main():
    token = config.get("bot_token", "").strip()
    if not token or token == "BOT_TOKENINIZI_BURAYA_YAZIN":
        print("\n" + "═"*60)
        print(f" [!] DİKKAT: {config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} için henüz Bot Token girilmedi!")
        print(" Lütfen config.json dosyasını açıp 'bot_token' alanına")
        print(" Discord Developer Portal'dan aldığın bot tokenını yapıştır.")
        print("═"*60 + "\n")
        input("Devam etmek için Enter tuşuna bas...")
        sys.exit(1)

    # ----------------------------------------------------
    # 🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ (Açılış Kilidi)
    # ----------------------------------------------------
    from closy_license_client import verify_license_sync, setup_license_guard
    _lic_key = config.get("lisans_anahtari", "").strip()
    _lic_api = config.get("lisans_api_url", "http://localhost:5050").strip()

    print("\n" + "=" * 60)
    print("  🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ")
    print(f"  🔑 Lisans Anahtarı : {_lic_key or 'GİRİLMEDİ'}")
    print(f"  🌐 Lisans Sunucusu : {_lic_api}")
    print("=" * 60)

    _lic_res = verify_license_sync(_lic_key, api_url=_lic_api)
    if not _lic_res.get("valid"):
        print("\n" + "!" * 65)
        print("  [LİSANS HATASI] ⛔ BOT BAŞLATILAMADI!")
        print(f"  Sebep: {_lic_res.get('reason', 'Geçersiz Lisans')}")
        print("  Lütfen config.json dosyasındaki 'lisans_anahtari' alanına")
        print("  satın aldığınız geçerli lisansı giriniz.")
        print("  Lisans Satın Almak veya Yenilemek İçin: https://discord.gg/imzapriw")
        print("!" * 65 + "\n")
        try:
            input("Kapatmak için Enter tuşuna basınız...")
        except Exception:
            pass
        sys.exit(1)

    print(f"  [LİSANS ONAYLANDI] 🟢 {_lic_res.get('message', 'Lisans aktif.')}")
    print(f"  [BİLGİ] Lisans Sahibi: {_lic_res.get('owner_discord', 'Müşteri')} | Kalan: {_lic_res.get('days_left')} Gün")
    print("=" * 60 + "\n")
    setup_license_guard(bot, license_key=_lic_key, api_url=_lic_api)

    try:
        bot.run(token)
    except discord.LoginFailure:
        print("\n[HATA] Girdiğin Bot Token geçersiz! Lütfen config.json dosyasını kontrol et.\n")
        input("Çıkmak için Enter tuşuna bas...")
    except Exception as e:
        print(f"\n[HATA] Bot başlatılırken bir sorun oluştu: {e}\n")
        input("Çıkmak için Enter tuşuna bas...")

if __name__ == "__main__":
    main()
