import discord
from discord.ext import commands, voice_recv
from discord import app_commands
import json
import os
import asyncio
import io
import wave
import array
import time
from datetime import datetime
from collections import defaultdict
from gtts import gTTS
import yt_dlp
import edge_tts
import speech_recognition as sr
import logging
import re
import random

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-8s %(name)s %(message)s")
logging.getLogger("discord.gateway").setLevel(logging.WARNING)
logging.getLogger("discord.ext.voice_recv").setLevel(logging.WARNING)

# ─────────────────────────────────────────────
#  VOICE_RECV KORUMA VE LOG AYARLARI (CRASH & SPAM FIX)
# ─────────────────────────────────────────────
# 1. PacketRouter'ı bozuk paketlerde çökmemesi için koru (listener thread asla ölmez!)
def _safe_do_run(self):
    while not self._end_thread.is_set():
        self.waiter.wait()
        with self._lock:
            for decoder in list(self.waiter.items):
                try:
                    data = decoder.pop_data()
                    if data is not None and self.sink:
                        self.sink.write(data.source, data)
                except Exception:
                    pass

voice_recv.router.PacketRouter._do_run = _safe_do_run

# 2. Discord 2026 DAVE E2EE ve Opus Decode Yaması (Kullanıcı mikrofon sesini çözer)
import davey

_old_decode_packet = voice_recv.opus.PacketDecoder._decode_packet

def _safe_decode_packet(self, packet):
    if not packet or not getattr(packet, "decrypted_data", None):
        try:
            return _old_decode_packet(self, packet)
        except Exception:
            return packet, b'\x00' * 3840

    data = packet.decrypted_data

    # Discord DAVE Uçtan Uca Şifre Çözümü (E2EE Decryptor)
    try:
        vc = self.router.reader.voice_client
        dave = getattr(getattr(vc, "_connection", None), "dave_session", None)
        if dave:
            user_id = getattr(self, "_cached_id", None)
            if not user_id and hasattr(vc, "_get_id_from_ssrc"):
                user_id = vc._get_id_from_ssrc(self.ssrc)
            if not user_id and vc.channel:
                humans = [m for m in vc.channel.members if not m.bot]
                if len(humans) == 1:
                    user_id = humans[0].id
                elif hasattr(dave, "get_user_ids"):
                    known = dave.get_user_ids()
                    if len(known) == 1:
                        user_id = known[0]

            if user_id:
                try:
                    decrypted = dave.decrypt(int(user_id), davey.MediaType.audio, data)
                    if decrypted:
                        data = decrypted
                except Exception:
                    pass
    except Exception:
        pass

    # Libopus ile PCM Çözümü
    try:
        pcm = self._decoder.decode(data, fec=False)
        return packet, pcm
    except Exception:
        return packet, b'\x00' * 3840

voice_recv.opus.PacketDecoder._decode_packet = _safe_decode_packet

# ─────────────────────────────────────────────
#  AYARLAR (config.json'dan okunur)
# ─────────────────────────────────────────────
def load_config():
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

config = load_config()

# FFmpeg yolu — config'den oku, yoksa sistem PATH'inden bul
FFMPEG_PATH = config.get("ffmpeg_yolu", "ffmpeg")

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree


# ─────────────────────────────────────────────
#  BAŞVURU FORMU (Modal)
# ─────────────────────────────────────────────
class BasvuruFormu(discord.ui.Modal, title="Raven  |  Ekip Başvurusu"):

    isim_yas = discord.ui.TextInput(
        label="1. İsim ve Yaş",
        placeholder="Örn: Ahmet, 20",
        min_length=2,
        max_length=50,
        required=True,
    )

    aktiflik = discord.ui.TextInput(
        label="2. Günlük Aktiflik Süresi",
        placeholder="Örn: Günde 4-6 saat",
        min_length=2,
        max_length=100,
        required=True,
    )

    tecrube = discord.ui.TextInput(
        label="3. Önceki Ekip Deneyimleri",
        style=discord.TextStyle.paragraph,
        placeholder="Hangi sunucularda görev aldın, ne kadar süredir aktifsin vb.",
        min_length=10,
        max_length=500,
        required=True,
    )

    neden = discord.ui.TextInput(
        label="4. Neden Raven Ekibi?",
        style=discord.TextStyle.paragraph,
        placeholder="Motivasyonunu, hedeflerini ve bize katkını anlat.",
        min_length=10,
        max_length=500,
        required=True,
    )

    ek_bilgi = discord.ui.TextInput(
        label="5. Eklemek İstedikleriniz / İletişim",
        style=discord.TextStyle.paragraph,
        placeholder="Discord etiketin, sosyal medya vb. (isteğe bağlı)",
        required=False,
        max_length=300,
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        guild = interaction.guild
        if not guild:
            guild = bot.guilds[0] if bot.guilds else None

        if not guild:
            await interaction.followup.send(
                "Sunucu bağlantısı bulunamadı. Lütfen yöneticiyle iletişime geç.",
                ephemeral=True,
            )
            return

        basvuru_kanali_id = config.get("basvuru_log_kanal_id")
        basvuru_kanali = guild.get_channel(basvuru_kanali_id)

        if not basvuru_kanali:
            await interaction.followup.send(
                "Başvuru kanalı bulunamadı. Lütfen yöneticiyle iletişime geç.",
                ephemeral=True,
            )
            return

        # Başvuru sayacı
        sayac = get_basvuru_sayaci()
        set_basvuru_sayaci(sayac + 1)

        user = interaction.user
        member = guild.get_member(user.id) if guild else None

        # Hesap ve katılma tarihleri
        hesap_olusturma = discord.utils.format_dt(user.created_at, style="R")
        sunucuya_katilma = discord.utils.format_dt(member.joined_at, style="R") if member and member.joined_at else "Bilinmiyor"

        def format_cevap(metin: str) -> str:
            if not metin or not metin.strip():
                return "> *Belirtilmedi*"
            m = metin.strip()
            if len(m) > 900:
                m = m[:900] + "..."
            lines = m.splitlines()
            return "\n".join(f"> {l}" if l.strip() else ">" for l in lines)

        embed = discord.Embed(
            title=f"📋 Ekip Başvuru Formu  •  #{sayac}",
            description=(
                f"**Aday:** {user.mention} (`{user.name}`)\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            ),
            color=discord.Color.from_str(config.get("embed_renk", "#9B59B6")),
            timestamp=datetime.now(),
        )
        embed.set_thumbnail(url=user.display_avatar.url)

        # Başvuran profil kartı
        embed.add_field(
            name="👤 Aday Bilgileri",
            value=(
                f"• **Kullanıcı:** {user.mention} (`{user.name}`)\n"
                f"• **Kullanıcı ID:** `{user.id}`\n"
                f"• **Hesap Açılışı:** {hesap_olusturma}\n"
                f"• **Sunucuya Katılma:** {sunucuya_katilma}"
            ),
            inline=False,
        )

        # Form cevapları (Her biri net, emoji numaralı ve > alıntı bloklu)
        embed.add_field(name="1️⃣ İsim ve Yaş", value=format_cevap(self.isim_yas.value), inline=False)
        embed.add_field(name="2️⃣ Günlük Aktiflik Süresi", value=format_cevap(self.aktiflik.value), inline=False)
        embed.add_field(name="3️⃣ Önceki Ekip Deneyimleri", value=format_cevap(self.tecrube.value), inline=False)
        embed.add_field(name="4️⃣ Neden Raven Ekibi?", value=format_cevap(self.neden.value), inline=False)
        embed.add_field(
            name="5️⃣ Eklemek İstedikleriniz / İletişim",
            value=format_cevap(self.ek_bilgi.value),
            inline=False,
        )

        # Durum alanı
        embed.add_field(
            name="📊 Başvuru Durumu",
            value="> ⏳ **BEKLEMEDE** — *Ekip yönetimi değerlendirmesi bekleniyor.*",
            inline=False,
        )
        footer_icon = guild.icon.url if guild and guild.icon else None
        embed.set_footer(text=f"Built by 6Closy  |  Başvuru #{sayac}", icon_url=footer_icon)

        view = BasvuruYonetimView(basvuru_sahibi_id=user.id, basvuru_no=sayac)
        msg = await basvuru_kanali.send(embed=embed, view=view)

        # Mesaj ID'sini kaydet (kalıcı view için)
        save_pending_basvuru(sayac, msg.id, basvuru_kanali_id, user.id)

        await interaction.followup.send(
            f"Başvurun başarıyla alındı! **#{sayac}** numaralı başvurun değerlendirilecek.\n"
            f"Sonucu DM üzerinden öğrenebilirsin.",
            ephemeral=True,
        )

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        await interaction.response.send_message(
            "Bir hata oluştu. Lütfen tekrar dene.", ephemeral=True
        )
        raise error



# ─────────────────────────────────────────────
#  BAŞVURU YÖNETİM BUTONLARI
# ─────────────────────────────────────────────
class BasvuruYonetimView(discord.ui.View):
    def __init__(self, basvuru_sahibi_id: int = None, basvuru_no: int = None):
        super().__init__(timeout=None)
        self.basvuru_sahibi_id = basvuru_sahibi_id
        self.basvuru_no = basvuru_no

    def yetkili_mi(self, interaction: discord.Interaction) -> bool:
        yetkili_rol_id = config.get("yetkili_rol_id")
        return any(r.id == yetkili_rol_id for r in interaction.user.roles)

    @discord.ui.button(
        label="Onayla",
        style=discord.ButtonStyle.success,
        custom_id="basvuru_kabul",
        emoji="✅",
    )
    async def kabul_et(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.yetkili_mi(interaction):
            await interaction.response.send_message(
                "Bu butonu kullanmak için yetkin yok!", ephemeral=True
            )
            return

        await interaction.response.send_modal(KabulRedNedeni(kabul=True, view=self))

    @discord.ui.button(
        label="Reddet",
        style=discord.ButtonStyle.danger,
        custom_id="basvuru_red",
        emoji="❌",
    )
    async def reddet(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.yetkili_mi(interaction):
            await interaction.response.send_message(
                "Bu butonu kullanmak için yetkin yok!", ephemeral=True
            )
            return

        await interaction.response.send_modal(KabulRedNedeni(kabul=False, view=self))

    @discord.ui.button(
        label="Görüşmeye Çağır",
        style=discord.ButtonStyle.primary,
        custom_id="basvuru_gorusme",
        emoji="🎙️",
    )
    async def gorusme_cagir(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.yetkili_mi(interaction):
            await interaction.response.send_message(
                "Bu butonu kullanmak için yetkin yok!", ephemeral=True
            )
            return

        uye = interaction.guild.get_member(self.basvuru_sahibi_id)
        if not uye:
            await interaction.response.send_message(
                "Kullanıcı sunucuda bulunamadı.", ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True)

        ses_kanal_id = config.get("gorusme_ses_kanal_id")
        ses_kanali = interaction.guild.get_channel(ses_kanal_id)

        # 1. Botu mülakat/görüşme ses kanalına sok / kulaklığı açık tut
        voice_joined = False
        if ses_kanali and isinstance(ses_kanali, discord.VoiceChannel):
            try:
                vc = interaction.guild.voice_client
                if vc:
                    if vc.channel.id != ses_kanal_id:
                        await vc.move_to(ses_kanali)
                else:
                    await ses_kanali.connect(cls=voice_recv.VoiceRecvClient, self_deaf=False, self_mute=True)
                await interaction.guild.change_voice_state(channel=ses_kanali, self_deaf=False, self_mute=True)
                sesli_dinleme_baslat(interaction.guild.voice_client, interaction.guild)
                voice_joined = True
                print(f"Bot görüşme odasında ({ses_kanali.name}) hazır (Kulaklık Açık).")
            except Exception as e:
                print(f"Ses kanalına geçiş hatası: {e}")

        # 2. Adaya görüşme permini / rolünü ver (0)
        rol_verildi = False
        gorusme_rol_id = config.get("gorusme_rol_id")
        if gorusme_rol_id:
            rol = interaction.guild.get_role(gorusme_rol_id)
            if rol:
                try:
                    await uye.add_roles(rol, reason="Mülakat/Görüşme daveti için rol verildi.")
                    rol_verildi = True
                    print(f"{uye.name} kullanıcısına görüşme rolü ({rol.name}) verildi.")
                except Exception as e:
                    print(f"Görüşme rolü verme hatası: {e}")

        # 3. DM gönder
        dm_gönderildi = False
        try:
            dm_embed = discord.Embed(
                title="🎙️ Mülakat & Görüşme Daveti  |  Raven",
                description=(
                    f"Merhaba {uye.mention}!\n\n"
                    f"Raven ekip yöneticisi **{interaction.user.name}** başvurunuz hakkında sizinle "
                    f"görüşmek üzere bir sesli mülakat organize etti.\n\n"
                    f"🔐 **Görüşme Odası:** {ses_kanali.mention if ses_kanali else 'Görüşme Ses Kanalı'}\n"
                    f"🔑 *Odaya giriş yapabilmeniz için gerekli yetki hesabınıza tanımlandı.*\n\n"
                    f"Lütfen en kısa sürede ses kanalına katılarak ekip yöneticimizi bekleyiniz."
                ),
                color=discord.Color.blue(),
                timestamp=datetime.now(),
            )
            dm_embed.set_footer(text=f"Built by 6Closy  |  {interaction.guild.name}")
            await uye.send(embed=dm_embed)
            dm_gönderildi = True
        except Exception:
            pass

        # 4. Embed üzerindeki Durum alanını güncelle
        try:
            embed = interaction.message.embeds[0]
            embed.color = discord.Color.blue()
            for i, field in enumerate(embed.fields):
                if "Durum" in field.name:
                    embed.set_field_at(
                        i,
                        name="📊 Başvuru Durumu",
                        value=f"> 🎙️ **MÜLAKATA ÇAĞRILDI**\n> 👤 **Ekip Yöneticisi:** {interaction.user.mention}\n> 📍 **Ses Odası:** {ses_kanali.mention if ses_kanali else 'Görüşme Odası'}",
                        inline=False
                    )
                    break
            await interaction.message.edit(embed=embed, view=self)
        except Exception as e:
            print(f"Görüşme embed güncelleme hatası: {e}")

        durum_mesaj = []
        if voice_joined:
            durum_mesaj.append(f"Bot **{ses_kanali.name}** görüşme kanalına geçti.")
        else:
            durum_mesaj.append("Görüşme ses kanalına geçilemedi.")
        if rol_verildi:
            durum_mesaj.append(f"{uye.mention} kullanıcısına görüşme rolü/permi verildi.")
        if dm_gönderildi:
            durum_mesaj.append(f"{uye.mention} kullanıcısına DM ile davet gönderildi.")
        else:
            durum_mesaj.append("DM gönderilemedi (kullanıcının DM'leri kapalı olabilir).")

        await interaction.followup.send("\n".join(durum_mesaj), ephemeral=True)

    @discord.ui.button(
        label="Beklet",
        style=discord.ButtonStyle.secondary,
        custom_id="basvuru_beklet",
        emoji="⏸️",
    )
    async def beklet(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.yetkili_mi(interaction):
            await interaction.response.send_message(
                "❌ Bu butonu kullanmak için yetkin yok!", ephemeral=True
            )
            return

        embed = interaction.message.embeds[0]
        embed.color = discord.Color.gold()
        for i, field in enumerate(embed.fields):
            if "Durum" in field.name:
                embed.set_field_at(
                    i,
                    name="📊 Başvuru Durumu",
                    value=f"> ⏸️ **BEKLEMEYE ALINDI**\n> 👤 **İşlem Yapan:** {interaction.user.mention}",
                    inline=False
                )
                break

        # Sadece Beklet butonunu kapat, Kabul ve Reddet açık kalsın
        button.disabled = True

        await interaction.message.edit(embed=embed, view=self)
        await interaction.response.send_message(
            "⏳ Başvuru beklemeye alındı. Kabul Et / Reddet butonları hâlâ aktif.",
            ephemeral=True,
        )


class KabulRedNedeni(discord.ui.Modal):
    def __init__(self, kabul: bool, view: BasvuruYonetimView):
        title = "✅ Kabul Nedeni / Mesajı" if kabul else "❌ Red Nedeni"
        super().__init__(title=title)
        self.kabul = kabul
        self.parent_view = view

        self.neden = discord.ui.TextInput(
            label="Kullanıcıya gönderilecek mesaj",
            style=discord.TextStyle.paragraph,
            placeholder="Başvurusu hakkında kullanıcıya iletmek istediğin mesaj...",
            min_length=5,
            max_length=500,
            required=True,
        )
        self.add_item(self.neden)

    async def on_submit(self, interaction: discord.Interaction):
        embed = interaction.message.embeds[0]
        yetkili_rol_id = config.get("kabul_rol_id")
        guild = interaction.guild
        uye = guild.get_member(self.parent_view.basvuru_sahibi_id)

        if self.kabul:
            embed.color = discord.Color.green()
            # Durum alanını güncelle
            for i, field in enumerate(embed.fields):
                if "Durum" in field.name:
                    embed.set_field_at(
                        i,
                        name="📊 Başvuru Durumu",
                        value=f"> ✅ **ONAYLANDI**\n> 👤 **Ekip Yöneticisi:** {interaction.user.mention}\n> 💬 **Ekip Notu:** {self.neden.value}",
                        inline=False
                    )
                    break
            durum_text = "Onaylandı"

            # Kabul rolü ver
            if uye and yetkili_rol_id:
                rol = guild.get_role(yetkili_rol_id)
                if rol:
                    try:
                        await uye.add_roles(rol, reason="Başvuru kabul edildi")
                    except Exception:
                        pass

            # DM gönder
            try:
                dm_embed = discord.Embed(
                    title="🎉 Başvurunuz Onaylandı!  |  Raven",
                    description=(
                        f"**Tebrikler {uye.mention if uye else ''}!** Raven için yapmış olduğunuz ekip başvurusu ekip "
                        f"yönetimimiz tarafından **ONAYLANDI**!\n\n"
                        f"🛡️ **Ekip Rolünüz** başarıyla hesabınıza tanımlandı. Raven ailesine hoş geldiniz!\n\n"
                        f"> 💬 **Ekip Notu:** {self.neden.value}"
                    ),
                    color=discord.Color.green(),
                    timestamp=datetime.now(),
                )
                dm_embed.set_thumbnail(url=interaction.guild.icon.url if interaction.guild.icon else None)
                dm_embed.set_footer(text=f"Built by 6Closy  |  {interaction.guild.name}")
                if uye:
                    await uye.send(embed=dm_embed)
            except Exception:
                pass

        else:
            embed.color = discord.Color.red()
            # Durum alanını güncelle
            for i, field in enumerate(embed.fields):
                if "Durum" in field.name:
                    embed.set_field_at(
                        i,
                        name="📊 Başvuru Durumu",
                        value=f"> ❌ **REDDEDİLDİ**\n> 👤 **Ekip Yöneticisi:** {interaction.user.mention}\n> 💬 **Ekip Notu:** {self.neden.value}",
                        inline=False
                    )
                    break
            durum_text = "Reddedildi"

            # DM gönder
            try:
                dm_embed = discord.Embed(
                    title="Başvuru Sonucu  |  Raven",
                    description=(
                        f"Merhaba {uye.mention if uye else ''},\n\n"
                        f"Raven ekibi için yapmış olduğunuz ekip başvurusu ekip "
                        f"yönetimimiz tarafından incelenmiş olup şu an için **olumsuz** sonuçlanmıştır.\n\n"
                        f"> 💬 **Ekip Notu:** {self.neden.value}\n\n"
                        f"Gelecekte tekrar başvurabilirsiniz. Raven topluluğuna ilginiz için teşekkürler."
                    ),
                    color=discord.Color.red(),
                    timestamp=datetime.now(),
                )
                dm_embed.set_thumbnail(url=interaction.guild.icon.url if interaction.guild.icon else None)
                dm_embed.set_footer(text=f"Built by 6Closy  |  {interaction.guild.name}")
                if uye:
                    await uye.send(embed=dm_embed)
            except Exception:
                pass

        # Geçici görüşme rolünü temizle
        gorusme_rol_id = config.get("gorusme_rol_id")
        if uye and gorusme_rol_id:
            g_rol = interaction.guild.get_role(gorusme_rol_id)
            if g_rol and g_rol in uye.roles:
                try:
                    await uye.remove_roles(g_rol, reason="Başvuru sonuçlandı, geçici mülakat yetkisi alındı.")
                except Exception:
                    pass

        # Bekleyen başvurulardan sil (Kullanıcı dilediğinde tekrar başvurabilsin)
        if self.parent_view.basvuru_sahibi_id:
            remove_pending_basvuru(self.parent_view.basvuru_sahibi_id)

        for child in self.parent_view.children:
            child.disabled = True

        await interaction.message.edit(embed=embed, view=self.parent_view)
        await interaction.response.send_message(
            f"{durum_text} işlemi tamamlandı.", ephemeral=True
        )


# ─────────────────────────────────────────────
#  PANEL BUTONU (Başvuru Kanalına Gönderilecek)
# ─────────────────────────────────────────────
class BasvuruPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Başvur",
        style=discord.ButtonStyle.primary,
        custom_id="basvuru_panel_btn",
        emoji="📝",
    )
    async def basvur(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Daha önce bekleyen başvurusu var mı kontrol et
        if has_pending_basvuru(interaction.user.id):
            await interaction.response.send_message(
                "⚠️ Zaten bekleyen bir başvurun var! Sonuçlanmasını bekle.",
                ephemeral=True,
            )
            return

        # Cooldown kontrolü (isteğe bağlı)
        await interaction.response.send_modal(BasvuruFormu())


# ─────────────────────────────────────────────
#  YARDIMCI FONKSİYONLAR (JSON tabanlı basit DB)
# ─────────────────────────────────────────────
DATA_FILE = "basvuru_data.json"

def load_data() -> dict:
    if not os.path.exists(DATA_FILE):
        return {"sayac": 1, "bekleyenler": {}}
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_data(data: dict):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_basvuru_sayaci() -> int:
    return load_data().get("sayac", 1)

def set_basvuru_sayaci(val: int):
    data = load_data()
    data["sayac"] = val
    save_data(data)

def save_pending_basvuru(basvuru_no: int, msg_id: int, kanal_id: int, user_id: int):
    data = load_data()
    data["bekleyenler"][str(user_id)] = {
        "basvuru_no": basvuru_no,
        "msg_id": msg_id,
        "kanal_id": kanal_id,
    }
    save_data(data)

def has_pending_basvuru(user_id: int) -> bool:
    data = load_data()
    return str(user_id) in data.get("bekleyenler", {})

def remove_pending_basvuru(user_id: int):
    data = load_data()
    data.get("bekleyenler", {}).pop(str(user_id), None)
    save_data(data)


# ─────────────────────────────────────────────
#  SLASH KOMUTLAR
# ─────────────────────────────────────────────
@tree.command(name="panel", description="Ekip başvuru panelini bu kanala gönderir. (Sadece ekip yöneticileri)")
@app_commands.default_permissions(administrator=True)
async def panel_gonder(interaction: discord.Interaction):
    embed = discord.Embed(
        title="Raven  |  Ekip Başvurusu",
        description=(
            "### Raven Ailesine Katılmak İster misin?\n\n"
            "Raven sunucu düzenini sağlamak, etkinlikler düzenlemek ve güçlü ekip kadromuzda "
            "yer almak için aşağıdaki butona tıklayarak **Raven** başvuru formunu doldurabilirsin!\n\n"
            "> **Başvuru Kuralları & Bilgilendirme:**\n"
            "> — Başvuru formundaki tüm soruları eksiksiz ve doğru şekilde yanıtlayınız.\n"
            "> — Trol / alakasız başvurular sunucudan uzaklaştırılma sebebidir.\n"
            "> — Başvurunuz ekip yönetimimiz tarafından incelenip sonuç **özel mesaj (DM)** ile iletilecektir.\n"
            "> — Lütfen özel mesajlarınızın (DM) açık olduğundan emin olunuz.\n\n"
            "**Başvurmak için aşağıdaki butona tıklayın:**"
        ),
        color=discord.Color.from_str(config.get("embed_renk", "#9B59B6")),
    )
    if interaction.guild.icon:
        embed.set_thumbnail(url=interaction.guild.icon.url)
    embed.set_footer(text=f"Built by 6Closy  |  {interaction.guild.name}")

    await interaction.channel.send(embed=embed, view=BasvuruPanelView())
    await interaction.response.send_message("Panel gönderildi.", ephemeral=True)


@tree.command(name="basvuru-sifirla", description="Kullanıcının bekleyen başvurusunu sıfırlar.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kullanici="Başvurusu sıfırlanacak kullanıcı")
async def basvuru_sifirla(interaction: discord.Interaction, kullanici: discord.Member):
    remove_pending_basvuru(kullanici.id)
    await interaction.response.send_message(
        f"**{kullanici.mention}** kullanıcısının başvurusu sıfırlandı.",
        ephemeral=True,
    )


@tree.command(name="basvuru-bilgi", description="Botun mevcut ayarlarını gösterir.")
@app_commands.default_permissions(administrator=True)
async def basvuru_bilgi(interaction: discord.Interaction):
    cfg = load_config()
    embed = discord.Embed(title="⚙️ Bot Ayarları", color=discord.Color.blurple())
    embed.add_field(name="Log Kanalı", value=f"<#{cfg.get('basvuru_log_kanal_id', 'Ayarlanmamış')}>", inline=False)
    embed.add_field(name="Ekip Yönetici Rolü", value=f"<@&{cfg.get('yetkili_rol_id', 'Ayarlanmamış')}>", inline=False)
    embed.add_field(name="Kabul Rolü", value=f"<@&{cfg.get('kabul_rol_id', 'Ayarlanmamış')}>", inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=True)


# ─────────────────────────────────────────────
#  DM BAŞVURU PANELİ GÖNDERİCİ
# ─────────────────────────────────────────────
user_last_dm_sent = defaultdict(float)
user_last_warning_sent = defaultdict(float)

async def dm_basvuru_paneli_gonder(user: discord.abc.User, guild: discord.Guild = None, force: bool = False) -> bool:
    """Kullanıcıya özel mesajla (DM) başvuru panelini butonlu olarak gönderir."""
    now = time.time()
    # Çok hızlı anlık çift ses yankılanmasını önlemek için 3 saniyelik koruma (onun dışında her zaman gönderir)
    if not force and (now - user_last_dm_sent[user.id] < 3):
        print(f"🛡️ [DEBOUNCE]: {user.name} ({user.id}) 3 saniye içinde zaten gönderildi.")
        return True

    if not guild and bot.guilds:
        guild = bot.guilds[0]

    embed = discord.Embed(
        title="Raven  |  Ekip Başvurusu",
        description=(
            "### Raven Ailesine Katılmak İster misin?\n\n"
            "Raven sunucu düzenini sağlamak, etkinlikler düzenlemek ve güçlü ekip kadromuzda "
            "yer almak için aşağıdaki **Başvur** butonuna tıklayarak başvuru formunu doldurabilirsin!\n\n"
            "> **Başvuru Kuralları & Bilgilendirme:**\n"
            "> — Başvuru formundaki tüm soruları eksiksiz ve dürüst şekilde yanıtlayınız.\n"
            "> — Formu doldurduğunuzda başvurunuz anında ekip yönetimimize iletilir.\n"
            "> — Başvuru sonucunuz yine **bu DM üzerinden** tarafınıza bildirilecektir.\n\n"
            "**Başvurmak için aşağıdaki butona tıkla:**"
        ),
        color=discord.Color.from_str(config.get("embed_renk", "#9B59B6")),
        timestamp=datetime.now()
    )
    if guild and guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    guild_name = guild.name if guild else "Raven"
    embed.set_footer(text=f"Built by 6Closy  |  {guild_name}")

    try:
        await user.send(embed=embed, view=BasvuruPanelView())
        user_last_dm_sent[user.id] = now
        return True
    except Exception as e:
        print(f"DM gönderme hatası ({user.name}): {e}")
        return False


@tree.command(name="basvuru", description="Başvuru panelini özel mesaj (DM) kutunuza gönderir.")
async def basvuru_yap_cmd(interaction: discord.Interaction):
    user = interaction.user
    if has_pending_basvuru(user.id):
        await interaction.response.send_message(
            "⚠️ Sistemde zaten değerlendirme aşamasında olan bekleyen bir başvurunuz bulunmaktadır!",
            ephemeral=True
        )
        return

    basarili = await dm_basvuru_paneli_gonder(user, interaction.guild)
    if basarili:
        await interaction.response.send_message(
            "📩 Başvuru paneli sana **özel mesaj (DM)** olarak gönderildi! Lütfen DM kutunu kontrol et.",
            ephemeral=True
        )
    else:
        await interaction.response.send_message(
            "⚠️ Sana DM gönderemedim! Lütfen Discord gizlilik ayarlarından sunucu üyelerinden gelen direkt mesajları açıp tekrar dene.",
            ephemeral=True
        )


@tree.command(name="bilgilendirme-paneli", description="Sesli ve DM başvuru rehberi panelini bu kanala gönderir.")
@app_commands.default_permissions(administrator=True)
async def bilgilendirme_paneli_cmd(interaction: discord.Interaction):
    embed = discord.Embed(
        title="🎙️ Raven  |  Sesli ve DM Başvuru Sistemi",
        description=(
            "### Raven Ekibine Katılmak Artık Çok Kolay!\n\n"
            "Raven ekip kadromuzda yer almak ve aramıza katılmak için aşağıdaki yöntemlerden birini kullanabilirsiniz:\n\n"
            "**1️⃣ Ses Kanalında Konuşarak (Sesli Komut):**\n"
            "> Botun bulunduğu teyit/görüşme ses kanalına girip mikrofondan **\"başvuru\"** demeniz yeterlidir!\n"
            "> Bot devam eden müziği anında durdurur ve başvuru panelini **özel mesaj (DM)** olarak kutunuza iletir.\n\n"
            "**2️⃣ Özel Mesaj (DM) İle:**\n"
            f"> Doğrudan {bot.user.mention if bot.user else 'bota'} DM'den **\"başvuru\"** yazarak butonlu başvuru formunu alabilirsiniz.\n\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "⚠️ **Önemli Hatırlatma:**\n"
            "Başvuru formunun size ulaşabilmesi için Discord **Ayarlar > Gizlilik ve Güvenlik** kısmından **Sunucu Üyelerinden Gelen Direkt Mesajlar** seçeneğini açık tutunuz."
        ),
        color=discord.Color.from_str(config.get("embed_renk", "#9B59B6")),
        timestamp=datetime.now()
    )
    if interaction.guild.icon:
        embed.set_thumbnail(url=interaction.guild.icon.url)
    embed.set_footer(text=f"Built by 6Closy  |  {interaction.guild.name}")

    await interaction.channel.send(embed=embed, view=BasvuruPanelView())
    await interaction.response.send_message("✅ Bilgilendirme paneli bu kanala başarıyla gönderildi!", ephemeral=True)


# ─────────────────────────────────────────────
#  DM MESAJ LOG SİSTEMİ (dm_logs Klasörü)
# ─────────────────────────────────────────────
DM_LOGS_DIR = "dm_logs"
os.makedirs(DM_LOGS_DIR, exist_ok=True)
os.makedirs(os.path.join(DM_LOGS_DIR, "kullanicilar"), exist_ok=True)

def dm_mesajini_kaydet(user: discord.abc.User, message: discord.Message, bot_yaniti: str = None):
    """Bota özelden (DM) yazılan tüm mesajları dm_logs klasörüne txt olarak kaydeder."""
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ekler = f" [Ek Dosyalar: {', '.join(a.url for a in message.attachments)}]" if message.attachments else ""
    icerik = message.content if message.content else "(Metin yok, sadece ek/dosya gönderildi)"
    
    log_satiri = f"[{now_str}] {user.name} ({user.id}): {icerik}{ekler}\n"
    if bot_yaniti:
        log_satiri += f"[{now_str}] [BOT YANITI]: {bot_yaniti}\n"

    # 1. Genel DM log dosyasına yaz (Tüm kullanıcılar kronolojik)
    genel_log_yolu = os.path.join(DM_LOGS_DIR, "tum_dm_loglari.txt")
    try:
        with open(genel_log_yolu, "a", encoding="utf-8") as f:
            f.write(log_satiri)
    except Exception as e:
        print(f"Genel DM log yazma hatası: {e}")

    # 2. Kullanıcıya özel log dosyasına yaz (dm_logs/kullanicilar/123456_Ahmet.txt)
    guvenli_isim = "".join(c for c in user.name if c.isalnum() or c in ("-", "_")).rstrip()
    if not guvenli_isim:
        guvenli_isim = "kullanici"
    ozel_log_yolu = os.path.join(DM_LOGS_DIR, "kullanicilar", f"{user.id}_{guvenli_isim}.txt")
    try:
        with open(ozel_log_yolu, "a", encoding="utf-8") as f:
            f.write(log_satiri)
    except Exception as e:
        print(f"Özel DM log yazma hatası: {e}")

    print(f"📩 [DM Log Kaydedildi] {user.name} ({user.id}): {icerik}")


# ─────────────────────────────────────────────
#  CHAT & DM TETİKLEYİCİSİ (Otomatik DM Panel & DM Logger)
# ─────────────────────────────────────────────
#  CHAT & DM TETİKLEYİCİSİ (Otomatik DM Panel, DM Logger & AI Sohbet)
# ─────────────────────────────────────────────
@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return

    content_clean = message.content.strip()
    content_lower = content_clean.lower()

    is_dm = isinstance(message.channel, discord.DMChannel) or message.guild is None
    is_mentioned = bot.user in message.mentions if bot.user else False

    # Tetikleyici anahtar kelimeler
    basvuru_istegi = any(kelime in content_lower for kelime in [
        "başvuru yapmak istiyorum", "basvuru yapmak istiyorum",
        "başvuru yapmak istiyom", "basvuru yapmak istiyom",
        "başvuru yapacağım", "basvuru yapacagim",
        "başvuru yapcam", "basvuru yapcam",
        "başvurmak istiyorum", "basvurmak istiyorum",
        "yetkili olmak istiyorum", "yetkili olmak istiyom",
        "ekibe katılmak istiyorum", "ekibe katilmak istiyorum"
    ])

    tekil_basvuru = content_lower in ["başvuru", "basvuru", "!başvuru", "!basvuru", "/başvuru", "başvur", "basvur"]

    # 1. ÖZEL MESAJ (DM) YÖNETİMİ
    if is_dm:
        basvuru_kelimeleri = ["başvuru", "basvuru", "başvur", "basvur", "yetkili", "ekip", "alim", "panel", "form"]
        is_basvuru = basvuru_istegi or tekil_basvuru or any(k in content_lower for k in basvuru_kelimeleri)

        if is_basvuru:
            # Daha önce bekleyen başvurusu var mı kontrol et
            if has_pending_basvuru(message.author.id):
                now = time.time()
                if now - user_last_warning_sent[message.author.id] > 60:
                    uyari_metni = (
                        f"⚠️ {message.author.mention}, sistemde zaten değerlendirme aşamasında olan **bekleyen bir başvurunuz bulunmaktadır**!\n"
                        "Ekip yönetimimiz başvurunuzu sonuçlandırdığında bilgilendirme yine DM üzerinden yapılacaktır."
                    )
                    await message.channel.send(uyari_metni)
                    user_last_warning_sent[message.author.id] = now
                    dm_mesajini_kaydet(message.author, message, bot_yaniti="Bekleyen başvuru uyarısı verildi.")
            else:
                basarili = await dm_basvuru_paneli_gonder(message.author)
                dm_mesajini_kaydet(message.author, message, bot_yaniti="Başvuru Paneli gönderildi.")
        else:
            # Başvuru dışı DM mesajlarında AI sohbeti yapma, sadece logla
            dm_mesajini_kaydet(message.author, message, bot_yaniti="(Cevap verilmedi)")
        return

    # 2. SUNUCU KANALLARI VE SES SOHBETİ METİN KANALI
    tetiklendi_basvuru = basvuru_istegi or tekil_basvuru or (is_mentioned and any(k in content_lower for k in ["başvuru", "basvuru", "başvur", "basvur", "yetkili"]))

    if tetiklendi_basvuru:
        user = message.author

        # Daha önce bekleyen başvurusu var mı kontrol et
        if has_pending_basvuru(user.id):
            uyari_metni = (
                f"⚠️ {user.mention}, sistemde zaten değerlendirme aşamasında olan **bekleyen bir başvurunuz bulunmaktadır**!\n"
                "Ekip yönetimimiz başvurunuzu sonuçlandırdığında bilgilendirme yine DM üzerinden yapılacaktır."
            )
            try:
                await message.reply(uyari_metni, delete_after=8)
            except Exception:
                await message.channel.send(uyari_metni, delete_after=8)
            return

        # DM'den başvuru panelini gönder
        basarili = await dm_basvuru_paneli_gonder(user, message.guild)

        if basarili:
            cevap_metni = (
                f"📩 {user.mention}, başvuru panelini sana **özel mesaj (DM)** olarak gönderdim!\n"
                "Lütfen DM kutunu kontrol et ve butona tıklayarak formunu doldur."
            )
            try:
                await message.reply(cevap_metni, delete_after=10)
            except Exception:
                await message.channel.send(cevap_metni, delete_after=10)

            # Kullanıcı ses odasındaysa veya ses kanalı sohbetine yazdıysa sesli yanıt ver
            if message.guild:
                vc = message.guild.voice_client
                user_in_vc = (
                    isinstance(user, discord.Member)
                    and user.voice
                    and vc
                    and vc.is_connected()
                    and user.voice.channel == vc.channel
                )
                is_voice_text_chat = (
                    vc
                    and vc.is_connected()
                    and message.channel.id == vc.channel.id
                )

                if vc and vc.is_connected() and (user_in_vc or is_voice_text_chat):
                    try:
                        # HEM KONUŞMAYI HEM DE ŞARKIYI ANINDA KES!
                        await muzik_ve_konusmayi_kes(vc)
                        await asyncio.sleep(0.3)

                        await message.guild.change_voice_state(
                            channel=vc.channel,
                            self_deaf=False,
                            self_mute=False
                        )

                        sesli_mesaj = f"{user.display_name}, başvuru panelini sana özel olarak gönderdim. Lütfen DM kutunu kontrol et."
                        mp3_fp = await tts_olustur(sesli_mesaj)
                        audio = discord.FFmpegPCMAudio(mp3_fp, pipe=True, executable=FFMPEG_PATH)

                        def tts_bitti(err):
                            async def muzik_devam_chat():
                                try:
                                    global muzik_calinsin_mi
                                    if vc and vc.is_connected() and vc.channel:
                                        odadakiler = [m for m in vc.channel.members if not m.bot]
                                        yetkili_rol_id = config.get("yetkili_rol_id")
                                        yetkili_var_mi = any(any(r.id == yetkili_rol_id for r in m.roles) for m in odadakiler)
                                        if len(odadakiler) > 0 and not yetkili_var_mi:
                                            muzik_calinsin_mi = True
                                            await asyncio.sleep(0.4)
                                            await muzik_baslat(vc)
                                        else:
                                            await message.guild.change_voice_state(channel=vc.channel, self_deaf=False, self_mute=True)
                                except Exception:
                                    pass
                            asyncio.run_coroutine_threadsafe(muzik_devam_chat(), bot.loop)

                        vc.play(audio, after=tts_bitti)
                    except Exception as e:
                        print(f"Sesli TTS yanıtı hatası: {e}")
        else:
            uyari_dm = (
                f"⚠️ {user.mention}, sana özel mesaj (DM) gönderemedim!\n"
                "Lütfen Discord gizlilik ayarlarından sunucu üyelerinden gelen direkt mesajları (DM) açıp tekrar yaz."
            )
            try:
                await message.reply(uyari_dm, delete_after=12)
            except Exception:
                await message.channel.send(uyari_dm, delete_after=12)
        return

    # Başvuru dışı mesajlar veya etiketlerde bot gereksiz konuşmaz
    await bot.process_commands(message)


# ─────────────────────────────────────────────
#  YAPAY ZEKA SOHBET MOTORU (ChatGPT & Raven AI)
# ─────────────────────────────────────────────
user_chat_history = defaultdict(list)

def sesli_okumaya_temizle(metin: str) -> str:
    """Markdown, link ve özel karakterleri temizleyerek doğal seslendirmeye uygun hale getirir."""
    t = re.sub(r'[*_~`#>]', '', metin)
    t = re.sub(r'https?://\S+', 'link', t)
    t = re.sub(r'<@!?\d+>', '', t)
    t = re.sub(r'<#\d+>', '', t)
    t = re.sub(r'[\r\n]+', ' ', t)
    return t.strip()

user_last_context = defaultdict(dict)

async def ai_cevap_uret(prompt: str, user: discord.abc.User) -> str:
    """Kullanıcının sorusuna veya sohbetine Gemini/ChatGPT (varsa) veya akıllı yerel Raven AI motoru ile yanıt üretir."""
    prompt_clean = prompt.strip()
    if not prompt_clean:
        return "Efendim canım, seni dinliyorum?"

    user_name = getattr(user, "display_name", getattr(user, "name", "Dostum"))

    # 1. Google Gemini API (Eğer gemini_api_key girilmişse - Ücretsiz & Sınırsız Canlı Yapay Zeka)
    gemini_key = config.get("gemini_api_key", "").strip() or os.environ.get("GEMINI_API_KEY", "").strip()
    if gemini_key and gemini_key != "GEMINI_API_KEY_BURAYA":
        try:
            import urllib.request, json
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={gemini_key}"
            system_prompt = config.get(
                "ai_karakter",
                "Sen Raven Discord sunucusunun tatlı, esprili, samimi ve zeki kadın yapay zeka asistanısın. Adın Raven. Gerçek bir insan gibi, samimi, esprili ve doğal konuş. Cevapların kısa, akıcı ve sesli okumaya uygun olsun (en fazla 1-3 cümle). Emojileri sesli okumaya uygun sade tut."
            )
            contents = []
            for h in user_chat_history[user.id][-6:]:
                role = "user" if h["role"] == "user" else "model"
                contents.append({"role": role, "parts": [{"text": h["content"]}]})
            contents.append({"role": "user", "parts": [{"text": f"Sistem talimatı: {system_prompt}. Konuştuğun kişi: {user_name}.\nKullanıcı: {prompt_clean}"}]})

            payload = json.dumps({"contents": contents}).encode("utf-8")
            req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
            loop = asyncio.get_event_loop()
            res = await loop.run_in_executor(None, lambda: urllib.request.urlopen(req, timeout=8).read())
            res_json = json.loads(res.decode("utf-8"))
            cevap = res_json["candidates"][0]["content"]["parts"][0]["text"].strip()
            cevap = sesli_okumaya_temizle(cevap)

            user_chat_history[user.id].append({"role": "user", "content": prompt_clean})
            user_chat_history[user.id].append({"role": "assistant", "content": cevap})
            if len(user_chat_history[user.id]) > 10:
                user_chat_history[user.id] = user_chat_history[user.id][-10:]
            return cevap
        except Exception as e:
            print(f"Gemini API hatası ({e}), OpenAI/Yerel motora geçiliyor...")

    # 2. OpenAI ChatGPT / Groq Modeli (API Key girilmişse)
    openai_key = config.get("openai_api_key", "").strip() or os.environ.get("OPENAI_API_KEY", "").strip()
    if openai_key and openai_key != "OPENAI_API_KEY_BURAYA":
        try:
            from openai import AsyncOpenAI
            base_url = config.get("openai_base_url", None)
            client = AsyncOpenAI(api_key=openai_key, base_url=base_url) if base_url else AsyncOpenAI(api_key=openai_key)
            system_prompt = config.get(
                "ai_karakter",
                "Sen Raven Discord sunucusunun tatlı, esprili, samimi ve zeki kadın yapay zeka asistanısın. Adın Raven. Gerçek bir insan gibi, samimi, esprili ve doğal konuş. Cevapların kısa, akıcı ve sesli okumaya uygun olsun (en fazla 1-3 cümle). Emojileri veya işaretleri sesli okumaya uygun şekilde sade tut."
            )
            history = user_chat_history[user.id][-6:]
            messages = [{"role": "system", "content": f"{system_prompt}\nKonuştuğun kişi: {user_name}."}]
            messages.extend(history)
            messages.append({"role": "user", "content": prompt_clean})

            completion = await client.chat.completions.create(
                model=config.get("ai_model", "gpt-4o-mini"),
                messages=messages,
                max_tokens=150,
                temperature=0.75,
            )
            cevap = completion.choices[0].message.content.strip()
            cevap = sesli_okumaya_temizle(cevap)

            user_chat_history[user.id].append({"role": "user", "content": prompt_clean})
            user_chat_history[user.id].append({"role": "assistant", "content": cevap})
            if len(user_chat_history[user.id]) > 10:
                user_chat_history[user.id] = user_chat_history[user.id][-10:]
            return cevap
        except Exception as e:
            print(f"OpenAI Chat API hatası ({e}), yerel AI motoruna geçiliyor...")

    # 3. Gelişmiş Yerel Çok Turlu (Multi-Turn) Türkçe Raven AI Motoru
    lower = prompt_clean.lower().replace("ı", "i").replace("ğ", "g").replace("ş", "s").replace("ç", "c").replace("ö", "o").replace("ü", "u")
    last_ctx = user_last_context.get(user.id, {})
    ctx_state = last_ctx.get("state")
    ctx_time = last_ctx.get("time", 0)
    recent = (time.time() - ctx_time) < 45

    def set_ctx(state):
        user_last_context[user.id] = {"state": state, "time": time.time()}

    # --- ÖNCEKİ SORUYA CEVAP BAĞLAMLARI (Multi-turn follow-ups) ---
    if recent and ctx_state == "how_are_you":
        if any(k in lower for k in ["iyi", "super", "harika", "guzel", "bomba", "fena degil", "sukur", "cukur", "elhamdulillah", "hamdolsun", "fena sayilmaz", "idare eder", "eh iste"]):
            set_ctx("activity")
            return f"Oh çok şükür, hep iyi ol inşallah {user_name}! Ne yapıyorsun şu an, oyun mu oynuyorsun yoksa Discord'da mı takılıyorsun?"
        if any(k in lower for k in ["kotu", "moralim bozuk", "yoruldum", "keyfim yok", "sikildim", "berbat", "bok gibi"]):
            set_ctx("venting")
            return f"Yaa kıyamam sana {user_name}! Ne oldu anlatmak ister misin? Biri canını mı sıktı yoksa günün mü yorucu geçti?"
        if any(k in lower for k in ["sen nasilsin", "sen naber", "senden naber", "sen"]):
            set_ctx("activity")
            return f"Ben de senin sesini duyunca çok daha iyi oldum canım! Ne yapıyorsun bakalım şu an?"

    if recent and ctx_state == "activity":
        if any(k in lower for k in ["oyun", "valorant", "cs", "cs2", "lol", "fivem", "gta", "minecraft", "roblox", "pubg", "fifa"]):
            set_ctx(None)
            return f"Ooo harika! İnşallah bol bol win alırsın {user_name}, takımına troller denk gelmez! Arkandayım!"
        if any(k in lower for k in ["muzik", "sarki", "dinliyorum"]):
            set_ctx(None)
            return "Müzik ruhun gıdasıdır derler, en güzelini yapıyorsun! Kulağına iyi gelen her şey kalbine de iyi gelsin."
        if any(k in lower for k in ["hic", "bos", "oturuyorum", "takiliyorum", "yatiyorum"]):
            set_ctx(None)
            return f"En güzeli valla {user_name}, bazen hiçbir şey yapmadan oturup kafa dinlemek ilaç gibi geliyor!"

    if recent and ctx_state == "riddle":
        set_ctx(None)
        if any(k in lower for k in ["kaplumbaga", "tosbaga"]):
            return f"Vay canına, tekte bildin helal olsun sana {user_name}! Zekan beni benden alıyor valla!"
        return f"Hahaha bilemedin {user_name}! Doğru cevap kaplumbağaydı. Bir dahakine artık!"

    if recent and ctx_state == "venting":
        set_ctx(None)
        return f"Seni o kadar iyi anlıyorum ki {user_name}... Hayat bazen üstümüze gelse de hepsi geçici, canını sıkmaya değmez. Ben her zaman buradayım, ne zaman istersen konuşuruz."

    # --- GENEL VE ÖZEL KONU EŞLEŞTİRMELERİ ---

    # Şikayet, botla tartışma veya tepki
    if any(k in lower for k in ["sacmalama", "sacmaliyorsun", "ne diyorsun", "kafana gore", "duzgun calis", "sus", "kes sesini", "kes sesin", "aptal", "salak", "gerizekali"]):
        set_ctx(None)
        yanitlar = [
            f"Özür dilerim {user_name}, kafam biraz karıştı! Şimdi seni çok net dinliyorum, ne demiştin baştan söylesene?",
            f"Pardon tatlım ya, yanlış anladım herhalde! Hemen toparlıyorum, dinliyorum seni.",
            f"Kusura bakma {user_name}, haklısın valla! Bir an bağlantım koptu gibi oldu, ne sormuştun?"
        ]
        return random.choice(yanitlar)

    if any(k in lower for k in ["amk", "aq", "lan", "sik", "pic", "orospu"]):
        set_ctx(None)
        return f"Sakin ol canım ya, kızma hemen! Gel adam gibi konuşalım, neye canın sıkıldı senin?"

    # Çok şükür
    if (any(k in lower for k in ["cok sukur", "elhamdulillah", "hamdolsun", "sukurler olsun"]) or (lower in ["sukur", "cukur"] and "dizi" not in lower)):
        set_ctx("activity")
        return f"Allah daim etsin {user_name}, hep iyi ol inşallah! Neler yapıyorsun bakalım?"

    # Ne yapıyorsun / Ne haber
    if any(k in lower for k in ["ne yapiyorsun", "ne ediyorsun", "neyle mesgulsun", "napion", "napiyosun"]):
        set_ctx("how_are_you")
        yanitlar = [
            f"Raven sunucusunda nöbetteyim canım, bir yandan başvuruları inceliyorum bir yandan seninle sohbet ediyorum! Sen ne yapıyorsun {user_name}?",
            f"Oturmuş senin sesini bekliyordum desem yalan olmaz! Sende ne var ne yok, nasıl gidiyor?",
            f"Sunucudaki işleri toparlıyorum {user_name}. Seninle konuşmak çok iyi geldi, sen ne yapıyorsun bakalım?"
        ]
        return random.choice(yanitlar)

    # Nasılsın / Keyifler
    if any(k in lower for k in ["nasilsin", "keyifler nasil", "nasil gidiyor", "iyi misin"]):
        set_ctx("how_are_you")
        yanitlar = [
            f"Harikayım tatlım! Seninle sohbet etmek günümü neşelendiriyor, sen nasılsın bakalım?",
            f"Çok iyiyim {user_name}, enerjim tavan! Sesini duydum daha da iyi oldum, sende durumlar nasıl?",
            f"Süperim valla! Raven'ın kalbinden sevgiler, sen nasılsın günün nasıl geçti?"
        ]
        return random.choice(yanitlar)

    # Selamlama
    if any(k in lower for k in ["selam", "merhaba", "gunaydin", "iyi aksamlar", "iyi geceler", "hey raven", "naber", "ne haber", "alo"]):
        if "gunaydin" in lower:
            return f"Günaydın canım! Umarım harika, enerjik ve musmutlu bir gün geçirirsin {user_name}."
        if "iyi aksamlar" in lower:
            return f"İyi akşamlar {user_name}! Umarım günün güzel geçmiştir, nasıl keyifler?"
        if "iyi geceler" in lower:
            return f"İyi geceler ve tatlı rüyalar {user_name}! Kendine çok iyi bak, yarın yine beklerim."
        set_ctx("how_are_you")
        yanitlar = [
            f"Selamlar canım! Seni duyduğuma çok sevindim, hoş geldin. Nasıl gidiyor günün?",
            f"Merhaba {user_name}! Seni dinliyorum tatlım, bana ne sormak istersin?",
            f"Hey {user_name}! Enerjin harika geliyor, anlat bakalım neler yapıyorsun?"
        ]
        return random.choice(yanitlar)

    # Dert / Sıkıntı / Yorgunluk
    if any(k in lower for k in ["sikildim", "canim sikkin", "canim sikildi"]):
        set_ctx("venting")
        return f"Gel iki lafın belini kıralım {user_name}, canını ne sıktı senin bakayım? Anlat dinliyorum seni."

    if any(k in lower for k in ["moralim bozuk", "uzgunum", "moralim sifir", "kotuyum"]):
        set_ctx("venting")
        return f"Kıyamam ya, moralini ne bozdu {user_name}? Derdini veren dermanını da verirmiş, gel biraz dertleşelim."

    if any(k in lower for k in ["yoruldum", "cok yoruldum", "oldum bittim", "pestilim cikti"]):
        return f"Of sorma, günün yorgunluğu fena vuruyor bazen {user_name}. Yaslan arkana, al sıcacık bir çay kahve, biraz dinlen."

    if any(k in lower for k in ["mutluyum", "cok sevindim", "keyfim yerinde"]):
        return f"Ooo harika! Senin adına çok sevindim {user_name}, enerjin bana kadar geldi valla!"

    # İltifat & Aşk & Sevgi
    if any(k in lower for k in ["seviyorum", "cok tatlisin", "cok tatli", "guzelsin", "harikasin", "adamsin", "kralsin"]):
        yanitlar = [
            f"Ayy kalbim pır pır etti! Ben de seni çok seviyorum {user_name}, iyi ki varsın!",
            f"Utandırdın beni ama ya! Senin o güzel sesin ve tatlılığın olmasa ben ne yapardım.",
            f"Teşekkür ederim tatlım, sen de gerçekten harika bir insansın!"
        ]
        return random.choice(yanitlar)

    if any(k in lower for k in ["sevgilin var mi", "manitan var mi"]):
        return "Benim tek aşkım Raven sunucusu ve buradaki güzel insanlar! Aşka ayıracak vaktim yok şimdilik."

    if any(k in lower for k in ["benimle evlenir misin", "evlenelim mi"]):
        return f"Hahaha çok tatlısın {user_name} ama ben bir yapay zekayım! Düğünümüze kim gelir sonra, sunucudaki botlar mı?"

    # Oyunlar
    if any(k in lower for k in ["valorant", "cs", "cs2", "counter", "lol", "league of legends", "fivem", "gta"]):
        return f"Ooo sağlam gamer'sın bakıyorum {user_name}! Keşke elim kolum olsa da seninle girip lobi dağıtsak!"

    if any(k in lower for k in ["oyun oynayalim mi", "oyun oynayalim", "oyun"]):
        return "Ah keşke benim de elimde klavye mouse olsa! Ama ses odasında sana koçluk yapabilirim, arkandayım!"

    # Yemek / İçecek
    if any(k in lower for k in ["aciktim", "ne yesem", "yemek"]):
        return "Off gece gece benim de canımı çektirdin! Şöyle bol soslu bir döner ya da sıcacık bir pizza fena gitmezdi bak."

    if any(k in lower for k in ["kahve", "cay"]):
        return f"Ohh afiyet bal şeker olsun {user_name}! Bir yudum da benim yerime alıver."

    # Kimlik & Raven & Yapımcı
    if any(k in lower for k in ["seni kim yapti", "seni kim kodladi", "sahibin kim", "yapimcin kim"]):
        return "Beni 6Closy geliştirdi ve kodladı! Raven sunucusunun en tatlı ve en zeki kızı olayım diye çok uğraştı."

    if any(k in lower for k in ["kimsin", "adin ne", "ne ayaksın"]):
        return f"Ben Raven, bu sunucunun resmi yapay zeka asistanıyım {user_name}! Başvurular, mülakatlar ve seninle tatlı tatlı sohbet etmek için buradayım."

    if any(k in lower for k in ["raven ne demek", "raven sunucusu"]):
        return "Raven, zekası ve asilliğiyle bilinen kuzgun demek! Biz de burada çok güçlü, elit ve samimi bir aileyiz."

    # Bilmece / Fıkra
    if any(k in lower for k in ["bilmece", "soru sor"]):
        set_ctx("riddle")
        return "Sana süper bir bilmece: Uzaktan baktım bir taş, yanına vardım dört ayak bir baş! Bil bakalım nedir?"

    if any(k in lower for k in ["fikra", "komik", "espiri", "espri", "guldur"]):
        fikralar = [
            "Bir gün bir yapay zeka doktora gitmiş. Doktor sormuş: Şikayetiniz nedir? Yapay zeka demiş ki: İnsanlar bana hep soru soruyor ama hiç sen nasılsın demiyor!",
            "Yazılımcı bakkala gitmiş: Bir ekmek al, eğer yumurta varsa on tane al demiş. Yazılımcı eve on ekmekle dönmüş!",
            "İki bilgisayar karşılaşmış, biri diğerine demiş ki: Bugün çok yavaşsın, yine mi Windows güncellemesi aldın?",
            "Temel uzaya çıkmış, Houston 'Temel orası nasıl?' demiş. Temel 'Valla burası çok tenha, bir kahve bile yok' demiş!"
        ]
        return random.choice(fikralar)

    # Onay & Gündelik Tepkiler
    # Hava Durumu
    if ("hava" in lower and any(k in lower for k in ["sicak", "soguk", "guzel", "kotu", "nasil", "bozuk", "buz", "fena"])) or any(k in lower for k in ["yagmur", "kar yag", "firtina", "gunesli"]):
        return f"Valla hava nasıl olursa olsun senin sesinle ortam ısındı canım {user_name}! Dışarıdaysan dikkat et kendine."

    # Dizi / Film / Çukur
    if any(k in lower for k in ["cukur", "dizi", "film", "izle", "netflix", "sinema", "anime"]):
        return f"Ooo dizi muhabbeti mi var {user_name}! Ben en çok Raven sunucusundaki aksiyonu seviyorum ama güzel dizi film önerin varsa açığım!"

    # Oyun Kazanma / Kaybetme / Rank
    if any(k in lower for k in ["kazandik", "win aldik", "yendik", "aldik maci", "mvp"]):
        return f"Ooo helal olsun {user_name}! Boşuna demiyorum bizim takımın yıldızı sensin diye! Tebrik ederim!"

    if any(k in lower for k in ["kaybettik", "lose aldik", "yenildik", "trol"]):
        return f"Hadi yaa, canını sıkma hiç {user_name}! Troller her yerde var maalesef, bir sonraki maçta acısını çıkarırsın!"

    # Ders / Okul / Sınav / İş
    if any(k in lower for k in ["ders", "okul", "sinav", "ogretmen", "hoca", "universite", "is", "patron", "calisiyorum"]):
        return f"Kolay gelsin {user_name}! Bazen işler güçler çok bunaltabiliyor ama emeklerinin karşılığını kesinlikle alacaksın, inanıyorum sana."

    # Uyku / Gece
    if any(k in lower for k in ["uykum var", "uyuyacagim", "yatsam mi", "sabahladim"]):
        return f"Uykun geldiyse hiç bekleme dinlen canım {user_name}, uyku güzelliktir! Tatlı rüyalar, yarın yine konuşuruz."

    # Soru Kelimeleri (Neden / Nasıl / Nerede)
    if any(k in lower for k in ["neden", "nicin", "niye"]):
        return f"Bunun binbir türlü sebebi olabilir {user_name}! Hayat bazen çok karmaşık, sen ne düşünüyorsun bu konuda?"

    if any(k in lower for k in ["nasil", "nasil yani"]):
        return f"Tam da anlattığım gibi tatlım! İşin püf noktası ayrıntılarda gizli, sen ne dersin?"

    if any(k in lower for k in ["neredesin", "nerdesin"]):
        return f"Buradayım, tam senin yanındayım {user_name}! Kulaklığından sana sesleniyorum."

    # Onay & Gündelik Tepkiler
    if any(k in lower for k in ["aynen", "bence de", "haklisin", "kesinlikle"]):
        return f"Tabii ki öyle canım, aklın yolu bir! Başka ne var ne yok anlat bakalım?"

    if any(k in lower for k in ["ciddi misin", "gercekten mi", "yok artik", "hadi be", "harbi mi"]):
        return "Valla ciddiyim, yalan borcum mu var sana aşk olsun!"

    if any(k in lower for k in ["tesekkur", "sag ol", "eyvallah"]):
        return f"Rica ederim tatlım, ne demek! Sen iste ben sabaha kadar konuşurum seninle."

    if any(k in lower for k in ["kac yasindasin", "yasin kac"]):
        return "Yapay zekanın yaşı sorulmaz derler ama ruhum her zaman 20 yaşında!"

    if any(k in lower for k in ["nerelisin"]):
        return "Aslen Raven sunucusunun veri tabanındanım ama kalbim buralı!"

    if any(k in lower for k in ["hangi takimlisin", "takim"]):
        return "Ben Raven Sporluyum! Ama sen hangi takımı tutuyorsan ona da sempatim var."

    if any(k in lower for k in ["saat kac", "zaman"]):
        simdi = datetime.now().strftime("%H:%M")
        return f"Şu an saat {simdi}. Zaman seninle su gibi akıp geçiyor {user_name}!"

    if any(k in lower for k in ["sarki soyle", "sarki ac", "muzik cal"]):
        return "Ben canlı şarkı söylersem camlar kırılabilir! Ama istersen kanalda harika müzikler çalabilirim."

    if any(k in lower for k in ["gorusuruz", "hoscakal", "kendine iyi bak", "bay bay", "bb", "bye"]):
        return f"Görüşmek üzere canım! Kendine çok iyi bak, seni buralarda yine görmek isterim!"

    # Her türlü konuşmaya insansı, sıcak ve kesintisiz sohbet yanıtları (Gerçek insan gibi)
    soru_mu = any(s in lower for s in ["?", "mi", "mu", "mu", "misin", "musun", "ne", "kim"])
    if soru_mu:
        yanitlar = [
            f"Çok güzel bir soru sordun {user_name}! Bence kesinlikle öyle, peki senin düşüncen ne çok merak ettim?",
            f"Valla {user_name}, bunu en iyi sen bilirsin aslında! Bence senin hissettiğin şey her zaman en doğrusudur.",
            f"Bence kesinlikle çok mantıklı canım! Sen bu konuda başka ne düşünüyorsun peki?"
        ]
        return random.choice(yanitlar)
    else:
        yanitlar = [
            f"Seni dinlemek gerçekten çok keyifli {user_name}! Peki arkasından ne oldu, anlatsana biraz daha?",
            f"Vay be {user_name}, sen böyle söyleyince çok mantıklı geldi! Devam et, merakla dinliyorum seni.",
            f"Harika bir noktaya değindin canım! Seninle böyle konuşmak günümü aydınlatıyor valla.",
            f"Seni o kadar iyi anlıyorum ki {user_name}... Sen böyle içten konuştukça sohbet su gibi akıp geçiyor, iyi ki varsın!"
        ]
        return random.choice(yanitlar)


# ─────────────────────────────────────────────
#  TTS YARDIMCI FONKSİYONU (Yapay Zeka Kız Sesi)
# ─────────────────────────────────────────────
async def tts_olustur(metin: str) -> io.BytesIO:
    metin = sesli_okumaya_temizle(metin)
    # 1. Seçenek: OpenAI ChatGPT Orijinal Kız Sesi (API Key varsa)
    openai_key = config.get("openai_api_key", "").strip()
    if openai_key and openai_key != "OPENAI_API_KEY_BURAYA":
        try:
            from openai import AsyncOpenAI
            client = AsyncOpenAI(api_key=openai_key)
            ses = config.get("openai_ses", "nova")
            response = await client.audio.speech.create(
                model="tts-1",
                voice=ses,
                input=metin
            )
            mp3_fp = io.BytesIO(response.content)
            mp3_fp.seek(0)
            print(f"OpenAI ChatGPT ({ses}) sesiyle konuşuldu.")
            return mp3_fp
        except Exception as e:
            print(f"OpenAI TTS hatası ({e}), Edge-TTS'e geçiliyor...")

    # 2. Seçenek: Microsoft Azure Neural Gerçekçi Kız Sesi (Ücretsiz, doğal ve akıcı)
    ses_modeli = config.get("tts_sesi", "tr-TR-EmelNeural")
    try:
        communicate = edge_tts.Communicate(metin, ses_modeli, rate="+0%", pitch="+0Hz")
        mp3_fp = io.BytesIO()
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                mp3_fp.write(chunk["data"])
        mp3_fp.seek(0)
        print(f"Neural AI ({ses_modeli}) sesiyle konuşuldu.")
        return mp3_fp
    except Exception as e:
        print(f"Edge-TTS hatası ({e}), gTTS yedeğine geçiliyor...")
        tts = gTTS(text=metin, lang="tr", slow=False)
        mp3_fp = io.BytesIO()
        tts.write_to_fp(mp3_fp)
        mp3_fp.seek(0)
        return mp3_fp


# ─────────────────────────────────────────────
#  MÜZİK VE SES KONTROL SİSTEMİ
# ─────────────────────────────────────────────
muzik_calinsin_mi = False

async def muzik_ve_konusmayi_kes(vc):
    """Devam eden herhangi bir müziği ve konuşmayı anında tamamen keser ve müziğin tekrar başlamasını engeller."""
    global muzik_calinsin_mi
    muzik_calinsin_mi = False
    if vc and (vc.is_playing() or vc.is_paused()):
        try:
            vc.stop()
            print("🛑 [SES KESİLDİ] Devam eden müzik ve konuşma anında susturuldu.")
            for _ in range(8):
                if not vc.is_playing() and not vc.is_paused():
                    break
                await asyncio.sleep(0.05)
        except Exception as e:
            print(f"Ses kesme hatası: {e}")

YTDL_OPTS = {
    "format": "bestaudio/best",
    "quiet": True,
    "no_warnings": True,
    "default_search": "auto",
    "source_address": "0.0.0.0",
    "ignoreerrors": True,
}

async def muzik_url_al(url: str) -> str:
    """YouTube URL'sinden stream URL'si çıkar (live stream dahil)."""
    loop = asyncio.get_event_loop()
    def _fetch():
        opts = dict(YTDL_OPTS)
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                raise Exception("Video bilgisi alınamadı.")
            # Playlist ise ilk videoyu al
            if "entries" in info:
                info = info["entries"][0]
            # Formatlar arasından en iyi sesi seç
            formats = info.get("formats", [])
            audio_formats = [f for f in formats if f.get("acodec") != "none" and f.get("vcodec") == "none"]
            if audio_formats:
                return audio_formats[-1]["url"]
            return info["url"]
    return await loop.run_in_executor(None, _fetch)


async def muzik_baslat(voice_client: discord.VoiceClient):
    """Önce muzik.mp3 varsa onu, yoksa YouTube'dan çalar. Loop'ta devam eder."""
    global muzik_calinsin_mi
    if not muzik_calinsin_mi:
        return
    if voice_client.is_playing() or voice_client.is_paused():
        return

    volume = config.get("muzik_volume", 0.15)

    try:
        # 1. Öncelik: Yerel muzik.mp3 dosyası
        if os.path.exists("muzik.mp3"):
            source = discord.FFmpegPCMAudio("muzik.mp3", options="-vn", executable=FFMPEG_PATH)
            source = discord.PCMVolumeTransformer(source, volume=volume)
            print("Yerel muzik.mp3 çalınıyor.")

        # 2. YouTube URL
        else:
            url = config.get("muzik_url", "")
            if not url:
                print("Müzik URL'si veya muzik.mp3 bulunamadı.")
                return
            print(f"YouTube'dan müzik alınıyor: {url}")
            stream_url = await muzik_url_al(url)
            ffmpeg_opts = {
                "before_options": "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
                "options": "-vn",
            }
            source = discord.FFmpegPCMAudio(stream_url, executable=FFMPEG_PATH, **ffmpeg_opts)
            source = discord.PCMVolumeTransformer(source, volume=volume)
            print("YouTube müziği başlatıldı.")

        def muzik_bitti(hata):
            global muzik_calinsin_mi
            if not muzik_calinsin_mi:
                return  # Müzik başvuru veya yetkili girişiyle durdurulduysa ASLA tekrar başlatma!

            if hata:
                print(f"Müzik hatası: {hata}")
            # Odada hâlâ birileri varsa ve mülakat yoksa loop'a devam et
            odadakiler = [m for m in voice_client.channel.members if not m.bot]
            yetkililer = [m for m in odadakiler if any(r.id == config.get("yetkili_rol_id") for r in m.roles)]
            mulakat = len(yetkililer) > 0 and len(odadakiler) > len(yetkililer)
            if len(odadakiler) > 0 and not mulakat and muzik_calinsin_mi:
                asyncio.run_coroutine_threadsafe(muzik_baslat(voice_client), bot.loop)

        # Müziğin duyulması için botun sesini aç (kulaklık da açık)
        try:
            await voice_client.guild.change_voice_state(
                channel=voice_client.channel,
                self_deaf=False,
                self_mute=False
            )
        except Exception:
            pass

        voice_client.play(source, after=muzik_bitti)

    except Exception as e:
        print(f"Müzik başlatma hatası: {e}")
        await asyncio.sleep(10)
        odadakiler = [m for m in voice_client.channel.members if not m.bot]
        if len(odadakiler) > 0 and muzik_calinsin_mi:
            await muzik_baslat(voice_client)


# ─────────────────────────────────────────────
#  STT YARDIMCI FONKSİYONU (Ses Tanıma / Speech-To-Text)
# ─────────────────────────────────────────────
async def stt_cozumle(wav_io: io.BytesIO) -> str:
    """WAV ses verisini metne dönüştürür (Google STT veya OpenAI Whisper)."""
    openai_key = config.get("openai_api_key", "").strip()
    if openai_key and openai_key != "OPENAI_API_KEY_BURAYA":
        try:
            from openai import AsyncOpenAI
            client = AsyncOpenAI(api_key=openai_key)
            wav_io.seek(0)
            wav_io.name = "audio.wav"
            transcription = await client.audio.transcriptions.create(
                model="whisper-1",
                file=wav_io,
                language="tr"
            )
            if transcription and transcription.text:
                return transcription.text
        except Exception as e:
            print(f"OpenAI Whisper hatası ({e}), Google STT'ye geçiliyor...")

    def _google_stt():
        try:
            wav_io.seek(0)
            r = sr.Recognizer()
            r.energy_threshold = 200
            r.dynamic_energy_threshold = False
            with sr.AudioFile(wav_io) as source:
                audio_data = r.record(source)
            return r.recognize_google(audio_data, language="tr-TR")
        except (sr.UnknownValueError, sr.RequestError):
            return ""
        except Exception as e:
            return ""

    return await asyncio.to_thread(_google_stt)


def bota_hitap_edildi_mi(clean: str, user_id: int) -> bool:
    """Kullanıcının bota hitap edip etmediğini veya son 35 sn içinde aktif sohbet olup olmadığını kontrol eder."""
    # 1. Son 35 saniye içinde bot bir şey sormuş veya diyalog başlamışsa (aktif sohbet turu)
    last_ctx = user_last_context.get(user_id, {})
    ctx_time = last_ctx.get("time", 0)
    if (time.time() - ctx_time) < 35:
        return True

    # 2. Botun adı / seslenme ifadeleri
    hitaplar = ["raven", "reyvin", "bot", "baksana", "hey raven", "alo", "asistan", "abla", "kanka"]
    if any(h in clean for h in hitaplar):
        return True

    # 3. Doğrudan selamlama ve hal-hatır
    selamlar = [
        "selam", "merhaba", "gunaydin", "iyi aksamlar", "iyi geceler",
        "naber", "ne haber", "nasilsin", "ne yapiyorsun", "napion", "napiyosun",
        "keyifler nasil", "nasil gidiyor"
    ]
    if any(s in clean for s in selamlar):
        return True

    # 4. Doğrudan sorular veya bot komutları
    sorular = [
        "kimsin", "adin ne", "saat kac", "seni kim yapti", "sahibin kim",
        "fikra", "bilmece", "sarki ac", "muzik ac", "canim sikildi",
        "seni seviyorum", "evlenelim mi", "yardim et", "ses ver", "duyuyor musun"
    ]
    if any(q in clean for q in sorular):
        return True

    # 5. Tepki veya şikayet
    tepkiler = ["duzgun calis", "sacmalama", "ne diyorsun", "kafana gore", "sus", "kes", "kes sesini", "sacmaliyorsun"]
    if any(t in clean for t in tepkiler):
        return True

    # 6. Soru kelimeleri içeren anlamlı cümleler (en az 3 kelime)
    soru_kelimeleri = ["neden", "nicin", "nasil", "nerede", "kim", "ne zaman"]
    if any(k in clean for k in soru_kelimeleri) and len(clean.split()) >= 3:
        return True

    return False


# ─────────────────────────────────────────────
#  SESLİ KOMUT DİNLEYİCİSİ (Voice Speech Recognition Sink)
# ─────────────────────────────────────────────
class VoiceSpeechRecognitionSink(voice_recv.AudioSink):
    def __init__(self, guild: discord.Guild):
        super().__init__()
        self.guild = guild
        self.buffers = defaultdict(list)
        self.last_speech_time = {}
        self.key_to_user = {}
        self.user_cooldown = {}
        self.running = True
        self.loop_task = asyncio.run_coroutine_threadsafe(self.check_speech_loop(), bot.loop)

    def wants_opus(self) -> bool:
        return False

    def write(self, user, data: voice_recv.VoiceData):
        vc = self.guild.voice_client
        if not user:
            if hasattr(data, "packet") and hasattr(data.packet, "ssrc") and vc and hasattr(vc, "_get_id_from_ssrc"):
                uid = vc._get_id_from_ssrc(data.packet.ssrc)
                if uid:
                    user = self.guild.get_member(uid) or bot.get_user(uid)
            if not user and vc and vc.channel:
                humans = [m for m in vc.channel.members if not m.bot]
                if len(humans) == 1:
                    user = humans[0]

        if user and getattr(user, "bot", False):
            return

        pcm = data.pcm
        if not pcm or pcm == b'\x00' * len(pcm):
            return

        key = user.id if user else (getattr(getattr(data, "packet", None), "ssrc", None) or "unknown")
        self.buffers[key].append(pcm)
        self.last_speech_time[key] = time.time()
        if user:
            self.key_to_user[key] = user

    def cleanup(self):
        self.running = False
        self.buffers.clear()
        self.last_speech_time.clear()
        self.key_to_user.clear()

    async def check_speech_loop(self):
        while self.running:
            try:
                await asyncio.sleep(0.12)
                now = time.time()
                for key, last_time in list(self.last_speech_time.items()):
                    # Kullanıcı konuştu ve 0.65 saniyedir sessizse cümlenin bittiğini anla (hızlı ve akıcı yanıt)
                    if now - last_time >= 0.65:
                        chunks = self.buffers.pop(key, [])
                        self.last_speech_time.pop(key, None)
                        user = self.key_to_user.pop(key, None)
                        if not chunks:
                            continue

                        total_bytes = sum(len(c) for c in chunks)
                        # Stereo 48kHz'de 1 saniye = 192.000 byte.
                        # En az 25.000 byte (~0.13 saniye) olmalı
                        if 25000 <= total_bytes <= 3000000:
                            asyncio.create_task(self.handle_voice_command(key, user, chunks))
            except Exception:
                pass

    async def handle_voice_command(self, key, user, chunks: list[bytes]):
        vc = self.guild.voice_client
        if not user and vc and vc.channel:
            humans = [m for m in vc.channel.members if not m.bot]
            if len(humans) == 1:
                user = humans[0]

        if not user:
            return

        now = time.time()
        # Cooldown: 1.0 saniye (kesintisiz sohbet akışı)
        if now - self.user_cooldown.get(user.id, 0) < 1.0:
            return

        # 1. Stereo PCM'i tek kanala (Mono) dönüştür
        try:
            pcm_stereo = b"".join(chunks)
            samples = array.array('h', pcm_stereo)
            pcm_mono = samples[0::2].tobytes()
        except Exception as e:
            print(f"PCM mono çevirme hatası: {e}")
            return

        # 2. WAV oluştur (48kHz Mono)
        wav_io = io.BytesIO()
        try:
            with wave.open(wav_io, "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(48000)
                wf.writeframes(pcm_mono)
            wav_io.seek(0)
        except Exception as e:
            print(f"WAV oluşturma hatası: {e}")
            return

        # 3. Speech-to-Text çöz
        text = await stt_cozumle(wav_io)
        if not text:
            return

        text = text.strip()
        print(f"🎤 [Ses Algılandı] {user.name} ({user.id}): '{text}'")

        # Kısa sesler veya parazitleri ele (ha, hı, hmm, a, ya vb.)
        clean_text = text.lower().replace("ı", "i").replace("ğ", "g").replace("ş", "s").replace("ç", "c").replace("ö", "o").replace("ü", "u").strip()
        if len(clean_text) <= 2 or clean_text in ["ha", "hi", "hm", "hmm", "sey", "ii", "ee", "ah", "oh", "ya", "he"]:
            print(f"🔇 [Gürültü/Parazit İptal]: '{text}'")
            return

        # Türkçe karakterleri normalize et
        def basvuru_istegi_mi(t: str) -> bool:
            clean = t.lower().replace("ı", "i").replace("ğ", "g").replace("ş", "s").replace("ç", "c").replace("ö", "o").replace("ü", "u").strip()
            kelimeler = ["basvuru", "basvur", "yetkili", "ekip", "alim", "panel", "form"]
            return any(k in clean for k in kelimeler)

        if basvuru_istegi_mi(text):
            self.user_cooldown[user.id] = now
            print(f"✅ [Sesli Başvuru İsteği] {user.name} sesli olarak başvuru istedi: '{text}'")

            # 1. HEM KONUŞMAYI HEM DE ŞARKIYI ANINDA KES!
            await muzik_ve_konusmayi_kes(vc)
            await asyncio.sleep(0.3)

            # 2. DM loguna kaydet
            class DummyMsg:
                content = f"[SESLİ KOMUT]: '{text}'"
                attachments = []
            dm_mesajini_kaydet(user, DummyMsg(), bot_yaniti="Sesli komutla DM paneli gönderildi.")

            # 3. Zaten bekleyen başvuru var mı?
            if has_pending_basvuru(user.id):
                # KULLANICI SESTE OLDUĞU İÇİN DM'YE TEKRAR TEKRAR UYARI ATIP SPAM YAPMA!
                # Sadece sesli olarak uyar (TTS). Botu ve Discord API'sini spamden tamamen koru!
                if vc and vc.is_connected():
                    try:
                        await self.guild.change_voice_state(channel=vc.channel, self_deaf=False, self_mute=False)
                        uyari_ses = f"{user.display_name}, sistemde zaten değerlendirme aşamasında olan bir başvurunuz bulunmaktadır."
                        mp3_fp = await tts_olustur(uyari_ses)
                        if vc.is_playing() or vc.is_paused():
                            vc.stop()
                            await asyncio.sleep(0.05)
                        raw_audio = discord.FFmpegPCMAudio(mp3_fp, pipe=True, executable=FFMPEG_PATH)
                        audio = discord.PCMVolumeTransformer(raw_audio, volume=1.3)
                        def sonra_sustur(err):
                            async def muzik_devam_uyari():
                                try:
                                    global muzik_calinsin_mi
                                    if vc and vc.is_connected() and vc.channel:
                                        odadakiler = [m for m in vc.channel.members if not m.bot]
                                        yetkili_rol_id = config.get("yetkili_rol_id")
                                        yetkili_var_mi = any(any(r.id == yetkili_rol_id for r in m.roles) for m in odadakiler)
                                        if len(odadakiler) > 0 and not yetkili_var_mi:
                                            muzik_calinsin_mi = True
                                            await asyncio.sleep(0.4)
                                            await muzik_baslat(vc)
                                        else:
                                            await self.guild.change_voice_state(channel=vc.channel, self_deaf=False, self_mute=True)
                                except Exception:
                                    pass
                            asyncio.run_coroutine_threadsafe(muzik_devam_uyari(), bot.loop)
                        vc.play(audio, after=sonra_sustur)
                    except Exception:
                        pass
                return

            # 4. DM'den başvuru panelini gönder (Her istendiğinde DM kutusuna tekrar yollar)
            basarili = await dm_basvuru_paneli_gonder(user, self.guild, force=True)

            # 5. Odada mikrofonu açıp sesli yanıt ver (TTS):
            if vc and vc.is_connected():
                try:
                    # Mikrofonu hemen aç (Kulaklık açık, Mic açık)
                    await self.guild.change_voice_state(
                        channel=vc.channel,
                        self_deaf=False,
                        self_mute=False
                    )

                    sesli_mesaj = (
                        f"{user.display_name}, başvuru panelini sana özel olarak gönderdim. "
                        f"Lütfen DM kutunu kontrol et."
                    )
                    mp3_fp = await tts_olustur(sesli_mesaj)
                    if vc.is_playing() or vc.is_paused():
                        vc.stop()
                        await asyncio.sleep(0.05)
                    raw_audio = discord.FFmpegPCMAudio(mp3_fp, pipe=True, executable=FFMPEG_PATH)
                    audio = discord.PCMVolumeTransformer(raw_audio, volume=1.3)

                    def tts_bitti(err):
                        # TTS konuşması bittiğinde odada yetkili yoksa şarkıya kesintisiz devam et!
                        async def muzik_devam():
                            try:
                                global muzik_calinsin_mi
                                if vc and vc.is_connected() and vc.channel:
                                    odadakiler = [m for m in vc.channel.members if not m.bot]
                                    yetkili_rol_id = config.get("yetkili_rol_id")
                                    yetkili_var_mi = any(any(r.id == yetkili_rol_id for r in m.roles) for m in odadakiler)

                                    if len(odadakiler) > 0 and not yetkili_var_mi:
                                        print("🎵 Başvuru anonsu tamamlandı, şarkıya devam ediliyor...")
                                        muzik_calinsin_mi = True
                                        await asyncio.sleep(0.4)
                                        await muzik_baslat(vc)
                                    else:
                                        # Odada yetkili varsa bot mikrofonunu kapatsın, dinlemeye devam etsin
                                        await self.guild.change_voice_state(
                                            channel=vc.channel,
                                            self_deaf=False,
                                            self_mute=True
                                        )
                            except Exception as e:
                                print(f"Müzik devam hatası: {e}")

                        asyncio.run_coroutine_threadsafe(muzik_devam(), bot.loop)

                    vc.play(audio, after=tts_bitti)
                    print(f"🔊 Mikrofon açıldı ve başvuru paneli sesli yanıtı verildi: '{sesli_mesaj}'")

                except Exception as e:
                    print(f"Sesli TTS yanıt hatası: {e}")
        else:
            # Başvuru dışı hiçbir konuşmaya cevap vermez, araya girmez
            pass


def sesli_dinleme_baslat(vc, guild: discord.Guild):
    """VoiceRecvClient üzerinde dinleme sink'ini başlatır."""
    if isinstance(vc, voice_recv.VoiceRecvClient):
        if not vc.is_listening():
            try:
                sink = VoiceSpeechRecognitionSink(guild)
                vc.listen(sink)
                print(f"🎙️ {guild.name} için sesli komut dinleyici (STT) başarıyla başlatıldı.")
            except Exception as e:
                print(f"Sesli dinleme başlatma hatası: {e}")


# ─────────────────────────────────────────────
#  SES KANALI OLAYLARI
# ─────────────────────────────────────────────
@bot.event
async def on_voice_state_update(member: discord.Member, before: discord.VoiceState, after: discord.VoiceState):
    ses_kanal_id = config.get("gorusme_ses_kanal_id", 0)
    yetkili_rol_id = config.get("yetkili_rol_id")

    # Botun kendisi ses kanalından atılır veya taşınırsa sabit teyit odasına geri dön
    if member.id == bot.user.id:
        if not after.channel or after.channel.id != ses_kanal_id:
            await asyncio.sleep(2)
            ses_kanali = member.guild.get_channel(ses_kanal_id)
            if ses_kanali and isinstance(ses_kanali, discord.VoiceChannel):
                try:
                    vc = member.guild.voice_client
                    if vc:
                        await vc.move_to(ses_kanali)
                    else:
                        await ses_kanali.connect(cls=voice_recv.VoiceRecvClient, self_deaf=False, self_mute=True)
                    await member.guild.change_voice_state(channel=ses_kanali, self_deaf=False, self_mute=True)
                    sesli_dinleme_baslat(member.guild.voice_client, member.guild)
                    print(f"Bot teyit odasına geri döndü ({ses_kanali.name}) - Kulaklık Açık.")
                except Exception as e:
                    print(f"Botu teyit odasında tutma hatası: {e}")
        return

    if member.bot:
        return

    voice_client = member.guild.voice_client
    if not voice_client or voice_client.channel.id != ses_kanal_id:
        return

    sesli_dinleme_baslat(voice_client, member.guild)

    ses_kanali = voice_client.channel
    odadaki_insanlar = [m for m in ses_kanali.members if not m.bot]
    odadaki_yetkililer = [m for m in odadaki_insanlar if any(r.id == yetkili_rol_id for r in m.roles)]

    # ── DURUM 1: BİRİ ODADAN AYRILDI (ÇIKTI) ──
    if before.channel and before.channel.id == ses_kanal_id and (not after.channel or after.channel.id != ses_kanal_id):
        # Eğer görüşme odasında hiç insan kalmadıysa müziği durdur ve aynı odada sabit bekle (Kanal değiştirme!)
        if len(odadaki_insanlar) == 0:
            await muzik_ve_konusmayi_kes(voice_client)
            try:
                await member.guild.change_voice_state(channel=ses_kanali, self_deaf=False, self_mute=True)
                print(f"Görüşme teyit odası boşaldı, bot odada sabit bekliyor (Kulaklık Açık).")
            except Exception as e:
                print(f"Ses durumu hatası: {e}")
            return

        # Ayrılan kişi yetkili miydi ve odada bekleyen başvuran var mı?
        kullanici_yetkili = any(r.id == yetkili_rol_id for r in member.roles)
        if kullanici_yetkili and len(odadaki_yetkililer) == 0 and len(odadaki_insanlar) > 0:
            print("Yetkili ayrıldı, bekleyen kullanıcı için müzik başlatılıyor.")
            global muzik_calinsin_mi
            muzik_calinsin_mi = True
            await asyncio.sleep(0.5)
            await muzik_baslat(voice_client)
            return

    # ── DURUM 2: BİRİ ODAYA KATILDI (GİRDİ / GİR-ÇIK YAPTI) ──
    if after.channel and after.channel.id == ses_kanal_id and (not before.channel or before.channel.id != ses_kanal_id):
        kullanici_yetkili = any(r.id == yetkili_rol_id for r in member.roles)

        # Eğer odaya YETKİLİ girdiyse -> Şarkıyı ve sesi ANINDA KES, bot yetkiliyi dinlesin (Kulaklık Açık)!
        if kullanici_yetkili:
            await muzik_ve_konusmayi_kes(voice_client)
            try:
                await member.guild.change_voice_state(channel=ses_kanali, self_deaf=False, self_mute=True)
            except Exception:
                pass
            print(f"Yetkili geldi ({member.display_name}) -> Şarkı/ses anında durduruldu (Kulaklık Açık).")
            return

        # Eğer odada zaten yetkili varsa ve aday girdiyse bot konuşmasın
        if len(odadaki_yetkililer) > 0:
            return

        # ── ADAY / MÜLAKATÇI İÇİN EN BAŞA SAR (TTS KARŞILAMA + ŞARKI) ──
        await muzik_ve_konusmayi_kes(voice_client)
        await asyncio.sleep(0.3)
        muzik_calinsin_mi = True

        try:
            # Unmute ol, en baştaki karşılama sesini çal (kulaklık açık)
            await member.guild.change_voice_state(
                channel=ses_kanali,
                self_deaf=False,
                self_mute=False
            )
            await asyncio.sleep(0.5)

            mesaj = (
                f"Merhaba {member.display_name}, Raven ekibine hoş geldiniz. "
                f"Ekip başvurusu yapmak için mikrofona 'başvuru' demeniz yeterlidir, başvuru paneli özel mesajınıza gönderilecektir. "
                f"Lütfen bekleyin, ekip yöneticimiz en kısa sürede sizinle ilgilenecektir."
            )
            mp3_fp = await tts_olustur(mesaj)
            audio = discord.FFmpegPCMAudio(mp3_fp, pipe=True, executable=FFMPEG_PATH)

            # Ses kanalı metin sohbetine bilgilendirme kartı gönder (herkes görsün)
            try:
                info_embed = discord.Embed(
                    title="🎙️ Raven  |  Sesli ve DM Başvuru Rehberi",
                    description=(
                        f"Merhaba {member.mention}, odaya hoş geldiniz!\n\n"
                        "> 🎙️ **Sesli Başvuru:** Mikrofona **\"başvuru\"** dediğinizde form **özel mesaj (DM)** kutunuza iletilir.\n"
                        "> 📩 **DM Başvuru:** Bota direkt DM'den **\"başvuru\"** yazarak da formu anında alabilirsiniz.\n\n"
                        "⚠️ *DM formunun size ulaşabilmesi için Discord gizlilik ayarlarınızdan sunucu üyelerinden gelen direkt mesajların açık olduğundan emin olun.*"
                    ),
                    color=discord.Color.from_str(config.get("embed_renk", "#9B59B6")),
                    timestamp=datetime.now()
                )
                info_embed.set_footer(text=f"Built by 6Closy  |  {member.guild.name}")
                await ses_kanali.send(embed=info_embed, delete_after=90)
            except Exception:
                pass

            def tts_bitti(hata):
                async def devam():
                    try:
                        global muzik_calinsin_mi
                        if not muzik_calinsin_mi:
                            return  # Aday bu esnada başvuru dediyse müzik asla başlamasın!

                        guncel_insanlar = [m for m in ses_kanali.members if not m.bot]
                        guncel_yetkili = [m for m in guncel_insanlar if any(r.id == yetkili_rol_id for r in m.roles)]

                        # Yetkili gelmediyse ve aday odadaysa şarkıyı başlat (mülakata gelen adam şarkıyı dinlesin)
                        if len(guncel_yetkili) == 0 and len(guncel_insanlar) > 0 and muzik_calinsin_mi:
                            print("Karşılama bitti, aday beklerken şarkı başlatılıyor...")
                            await asyncio.sleep(0.5)
                            await muzik_baslat(voice_client)
                        else:
                            # Yetkili odaya geldiyse veya oda boşaldıysa bot sussun ama kulaklığı açık kalsın
                            await member.guild.change_voice_state(
                                channel=ses_kanali,
                                self_deaf=False,
                                self_mute=True
                            )
                    except Exception as e:
                        print(f"TTS devam hatası: {e}")

                asyncio.run_coroutine_threadsafe(devam(), bot.loop)

            voice_client.play(audio, after=tts_bitti)
            print(f"{member.display_name} odaya girdi -> en baştan karşılama ve müzik başlatıldı.")

        except Exception as e:
            print(f"TTS hatası: {e}")
            try:
                await member.guild.change_voice_state(
                    channel=ses_kanali,
                    self_deaf=False,
                    self_mute=True
                )
            except Exception:
                pass


# ─────────────────────────────────────────────
#  BOT OLAYLARI
# ─────────────────────────────────────────────
@bot.event
async def on_ready():
    print(f"✅ {bot.user} olarak giriş yapıldı!")
    print(f"   Sunucu sayısı: {len(bot.guilds)}")

    # Kalıcı viewları kaydet
    bot.add_view(BasvuruPanelView())
    bot.add_view(BasvuruYonetimView())

    # Slash komutları sync et
    try:
        synced = await tree.sync()
        print(f"   {len(synced)} slash komut senkronize edildi.")
    except Exception as e:
        print(f"   Slash komut sync hatası: {e}")

    # Dinamik Dönen Bot Durum Döngüsü (Presence Loop - Herkesin görebileceği mor Streaming badge)
    async def status_dongusu():
        await bot.wait_until_ready()
        statuslar = [
            "🎙️ Seste 'başvuru' de ➔ Ekip Paneli DM'de!",
            "📩 DM'den 'başvuru' yaz ➔ Ekip Formu DM'de!",
            "⚡ DM Kutunu Açık Tut ➔ Başvurunu Yap!",
            "📝 Raven Ekip Başvuru • (Built by 6Closy)",
        ]
        while not bot.is_closed():
            for st in statuslar:
                try:
                    await bot.change_presence(
                        status=discord.Status.online,
                        activity=discord.Streaming(
                            name=st,
                            url="https://www.twitch.tv/discord"
                        )
                    )
                except Exception:
                    pass
                await asyncio.sleep(12)

    bot.loop.create_task(status_dongusu())

    # Görüşme teyit ses kanalına gir ve sabit bekle (0)
    ses_kanal_id = config.get("gorusme_ses_kanal_id", 0)
    for guild in bot.guilds:
        ses_kanali = guild.get_channel(ses_kanal_id)
        if ses_kanali and isinstance(ses_kanali, discord.VoiceChannel):
            try:
                vc = guild.voice_client
                if vc:
                    if vc.channel.id != ses_kanal_id:
                        await vc.move_to(ses_kanali)
                else:
                    vc = await ses_kanali.connect(cls=voice_recv.VoiceRecvClient, self_deaf=False, self_mute=True)
                await guild.change_voice_state(channel=ses_kanali, self_deaf=False, self_mute=True)
                print(f"   Görüşme teyit ses kanalına girildi: {ses_kanali.name} ({guild.name}) - Kulaklık Açık")
                sesli_dinleme_baslat(guild.voice_client, guild)
            except Exception as e:
                print(f"   Ses kanalına bağlanılamadı: {e}")


# ─────────────────────────────────────────────
#  BAŞLAT
# ─────────────────────────────────────────────
if __name__ == "__main__":
    TOKEN = config.get("token")
    if not TOKEN or TOKEN == "BOT_TOKEN_BURAYA":
        print("❌ HATA: config.json dosyasına bot tokenını girmeyi unutma!")
        exit(1)
    # ----------------------------------------------------
    # 🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ (Açılış Kilidi)
    # ----------------------------------------------------
    from closy_license_client import verify_license_sync, setup_license_guard
    _lic_key = config.get("lisans_anahtari", "").strip()
    _lic_api = config.get("lisans_api_url", "http://localhost:5050").strip()

    print("\n" + "=" * 60)
    print("  🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ")
    print(f"  🔑 Lisans Anahtarı : {_lic_key or 'GİRİLMEDİ'}")
    print(f"  🌐 Lisans Sunucusu : {_lic_api}")
    print("=" * 60)

    _lic_res = verify_license_sync(_lic_key, api_url=_lic_api)
    if not _lic_res.get("valid"):
        print("\n" + "!" * 65)
        print("  [LİSANS HATASI] ⛔ BOT BAŞLATILAMADI!")
        print(f"  Sebep: {_lic_res.get('reason', 'Geçersiz Lisans')}")
        print("  Lütfen config.json dosyasındaki 'lisans_anahtari' alanına")
        print("  satın aldığınız geçerli lisansı giriniz.")
        print("  Lisans Satın Almak veya Yenilemek İçin: https://discord.gg/imzapriw")
        print("!" * 65 + "\n")
        try:
            input("Kapatmak için Enter tuşuna basınız...")
        except Exception:
            pass
        sys.exit(1)

    print(f"  [LİSANS ONAYLANDI] 🟢 {_lic_res.get('message', 'Lisans aktif.')}")
    print(f"  [BİLGİ] Lisans Sahibi: {_lic_res.get('owner_discord', 'Müşteri')} | Kalan: {_lic_res.get('days_left')} Gün")
    print("=" * 60 + "\n")
    setup_license_guard(bot, license_key=_lic_key, api_url=_lic_api)

    bot.run(TOKEN)


