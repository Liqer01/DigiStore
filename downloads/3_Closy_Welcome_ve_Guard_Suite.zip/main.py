import os
import sys
import json
import random
import math
import asyncio
import re
import io
from datetime import datetime, timezone, timedelta
from typing import Union, Optional
from PIL import Image, ImageDraw, ImageFont
import aiohttp

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import discord
from discord import app_commands
from discord.ext import commands, tasks

# ─────────────────────────────────────────────
# DİZİNLER & AYARLAR (CONFIG)
# ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
GIVEAWAYS_PATH = os.path.join(BASE_DIR, "giveaways.json")
STATS_PATH = os.path.join(BASE_DIR, "stats.json")

DEFAULT_CONFIG = {
    "bot_token": "BOT_TOKENINI_BURAYA_YAZIN",
    "bot_adi": "ɨ̇ ʍ ʐ ǟ",
    "embed_renk": "0x111216",
    "logo_url": None,
    "otorol_id": 0,
    "hosgeldin_kanal_id": None,
    "ayrilan_kanal_id": None,
    "dm_hosgeldin": False,
    "sabit_ses_kanal_id": 0,
    "stream_url": "https://www.twitch.tv/imzapriw",
    "giveaway_vip_carpan": 2,
    "vip_rol_id": 0,
    "booster_rol_id": 0,
    "kufur_engel": True,
    "spam_engel": True,
    "mod_log_kanal_id": None,
    "ozel_kufurler": [],
    "spam_timeout_dakika": 2,
    "guard_kanal_koruma": True,
    "guard_whitelist_kullanicilar": [],
    "guard_whitelist_roller": [],
    "guard_uyari_limiti": 3,
    "guard_uyarilar": {},
    "guard_guvenli_botlar": [0, 0],
    "rol_log_kanal_id": None,
    "reklam_engel": True,
    "reklam_timeout_dakika": 5,
    "staff_dm_log_role_id": 0
}

def load_config() -> dict:
    if not os.path.exists(CONFIG_PATH):
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8-sig") as f:
            return {**DEFAULT_CONFIG, **json.load(f)}
    except Exception as e:
        print(f"[Config Okuma Hatası]: {e}", flush=True)
        return DEFAULT_CONFIG.copy()

def save_config(cfg: dict):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=4)

config = load_config()

# ─────────────────────────────────────────────
# ÇEKİLİŞ (GIVEAWAY) VE AKTİFLİK / STATS DEPOLAMA
# ─────────────────────────────────────────────
def load_giveaways() -> dict:
    if not os.path.exists(GIVEAWAYS_PATH):
        save_giveaways({})
        return {}
    try:
        with open(GIVEAWAYS_PATH, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        return {}

def save_giveaways(data: dict):
    with open(GIVEAWAYS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def load_stats() -> dict:
    if not os.path.exists(STATS_PATH):
        save_stats({})
        return {}
    try:
        with open(STATS_PATH, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        return {}

def save_stats(data: dict):
    with open(STATS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def get_level_from_xp(xp: int) -> int:
    if xp <= 0:
        return 1
    return max(1, int(1 + (xp / 100) ** 0.5))

def get_xp_for_level(level: int) -> int:
    return int(100 * ((level - 1) ** 2))

def make_progress_bar(current_level_xp: int, needed_level_xp: int, length: int = 10) -> str:
    if needed_level_xp <= 0:
        return "`" + "▰" * length + "` **%100**"
    fraction = min(1.0, max(0.0, current_level_xp / needed_level_xp))
    filled = int(round(length * fraction))
    bar = "▰" * filled + "▱" * (length - filled)
    percent = int(fraction * 100)
    return f"`{bar}` **%{percent}**"

def format_seconds(secs: int) -> str:
    days = secs // 86400
    hours = (secs % 86400) // 3600
    minutes = (secs % 3600) // 60
    parts = []
    if days > 0:
        parts.append(f"{days}g")
    if hours > 0:
        parts.append(f"{hours}s")
    if minutes > 0 or not parts:
        parts.append(f"{minutes}dk")
    return " ".join(parts)

def parse_duration(time_str: str) -> int:
    time_str = time_str.strip().lower()
    units = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400, 'w': 604800}
    if time_str.isdigit():
        return int(time_str) * 60
    unit = time_str[-1]
    val = time_str[:-1]
    if unit in units and val.isdigit():
        return int(val) * units[unit]
    raise ValueError("Geçersiz süre biçimi. Örnek: '10m', '2h', '1d', '30s'")

def get_embed_color() -> int:
    renk_str = str(config.get("embed_renk", "0x111216")).strip()
    try:
        return int(renk_str, 16) if renk_str.startswith("0x") else int(renk_str)
    except ValueError:
        return 0x111216

def get_brand_logo_url(guild: discord.Guild = None) -> str:
    cfg_logo = config.get("logo_url")
    if cfg_logo and str(cfg_logo).startswith("http"):
        return cfg_logo
    if guild and guild.icon:
        return guild.icon.url
    return "https://cdn.discordapp.com/attachments/1066708687319760926/115000000000000000/imza.png"

# ─────────────────────────────────────────────
# BOT TANIMI & INTENTLER
# ─────────────────────────────────────────────
intents = discord.Intents.default()
intents.members = True          # Otorol ve üye giriş-çıkış için zorunlu
intents.message_content = True  # Mesaj içeriği
intents.voice_states = True     # Sabit ses kanalı için
intents.guilds = True

bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

# ─────────────────────────────────────────────
# HOŞ GELDİN & GİDEN EMBED / GÖRSEL KART MOTORU
# ─────────────────────────────────────────────
def get_card_font(bold: bool = False, size: int = 16):
    font_paths = [
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
    ]
    for p in font_paths:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()

def render_welcome_card(display_name: str, username: str, user_id: int,
                        member_count: int, sec_status: str, account_age_str: str,
                        role_name: str, created_date_str: str, created_relative_str: str,
                        avatar_bytes: bytes = None) -> io.BytesIO:
    W, H = 950, 370
    img = Image.new('RGBA', (W, H), (10, 11, 15, 255))
    draw = ImageDraw.Draw(img)

    # Dış kart çerçevesi ve arka plan
    draw.rounded_rectangle([(10, 10), (W - 10, H - 10)], radius=20, fill=(16, 17, 23, 255), outline=(32, 35, 48, 255), width=2)
    # Üst aydınlatma çizgisi
    draw.line([(35, 12), (W - 35, 12)], fill=(48, 52, 70, 180), width=1)

    # Fontlar
    font_tag = get_card_font(bold=True, size=13)
    font_title = get_card_font(bold=True, size=28)
    font_sub = get_card_font(bold=False, size=15)
    font_pill = get_card_font(bold=True, size=13)
    font_box_lbl = get_card_font(bold=True, size=12)
    font_box_val = get_card_font(bold=True, size=18)
    font_box_sub = get_card_font(bold=False, size=12)
    font_note = get_card_font(bold=False, size=13)
    font_watermark = get_card_font(bold=True, size=12)

    # Avatar
    av_size = 104
    av_x, av_y = 35, 30
    mask = Image.new('L', (av_size, av_size), 0)
    md = ImageDraw.Draw(mask)
    md.ellipse((0, 0, av_size, av_size), fill=255)

    ring_color = (46, 204, 113, 255)
    if "Yeni" in sec_status:
        ring_color = (237, 66, 69, 255)
    elif "Orta" in sec_status:
        ring_color = (241, 196, 15, 255)

    if avatar_bytes:
        try:
            av_raw = Image.open(io.BytesIO(avatar_bytes)).convert('RGBA')
            av_raw = av_raw.resize((av_size, av_size), Image.Resampling.LANCZOS)
            av_raw.putalpha(mask)
            img.paste(av_raw, (av_x, av_y), av_raw)
        except Exception:
            avatar_bytes = None

    if not avatar_bytes:
        fallback = Image.new('RGBA', (av_size, av_size), (35, 40, 55, 255))
        fb_draw = ImageDraw.Draw(fallback)
        initials = display_name[:2].upper() if len(display_name) >= 2 else display_name[:1].upper()
        fb_draw.text((32, 30), initials, fill=(255, 255, 255, 255), font=font_title)
        fallback.putalpha(mask)
        img.paste(fallback, (av_x, av_y), fallback)

    # Avatar halkası
    draw.ellipse([(av_x - 3, av_y - 3), (av_x + av_size + 3, av_y + av_size + 3)], outline=ring_color, width=3)

    # Başlık & Bilgiler
    name_x = av_x + av_size + 24
    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    draw.text((name_x, 30), f'{bot_name}  •  ARAMIZA HOŞ GELDİN', fill=(130, 137, 155, 255), font=font_tag)
    draw.text((name_x, 48), display_name, fill=(255, 255, 255, 255), font=font_title)
    draw.text((name_x, 88), f'@{username}  •  ID: {user_id}', fill=(150, 156, 175, 255), font=font_sub)

    # Sağ Üst Üye Sayısı Rozeti
    pill_text = f'{member_count}. ÜYE'
    pill_w = int(draw.textlength(pill_text, font=font_pill)) + 30
    pill_x = W - 35 - pill_w
    pill_y = 38
    draw.rounded_rectangle([(pill_x, pill_y), (pill_x + pill_w, pill_y + 32)], radius=16, fill=(24, 28, 42, 255), outline=(88, 101, 242, 200), width=1)
    draw.text((pill_x + 15, pill_y + 7), pill_text, fill=(200, 210, 255, 255), font=font_pill)

    # 4 Bilgi Kutucuğu
    box_y = 150
    box_h = 90
    box_w = 207
    spacing = 15
    start_x = 35

    boxes = [
        ('GÜVENLİK', sec_status, account_age_str, ring_color),
        ('TANIMLANAN ROL', f'@{role_name}', 'Otomatik Tanımlandı', (88, 101, 242, 255)),
        ('HESAP AÇILIŞI', created_date_str, created_relative_str, (241, 196, 15, 255)),
        ('SUNUCU TOPLAMI', f'{member_count} Kişi', 'Giderek Büyüyoruz', (235, 69, 158, 255))
    ]

    for i, (label, val, sub, accent) in enumerate(boxes):
        bx = start_x + i * (box_w + spacing)
        draw.rounded_rectangle([(bx, box_y), (bx + box_w, box_y + box_h)], radius=12, fill=(22, 24, 33, 255), outline=(38, 41, 56, 255), width=1)
        # Accent bar
        draw.rounded_rectangle([(bx + 14, box_y + 14), (bx + 18, box_y + 26)], radius=2, fill=accent)
        draw.text((bx + 26, box_y + 13), label, fill=(130, 137, 155, 255), font=font_box_lbl)
        draw.text((bx + 14, box_y + 38), val, fill=(255, 255, 255, 255), font=font_box_val)
        draw.text((bx + 14, box_y + 66), sub, fill=(110, 116, 135, 255), font=font_box_sub)

    # Alt Bilgilendirme Kutusu
    note_y = 280
    draw.rounded_rectangle([(35, note_y), (W - 35, note_y + 55)], radius=10, fill=(20, 22, 30, 255), outline=(35, 38, 50, 255), width=1)
    draw.rounded_rectangle([(35, note_y), (39, note_y + 55)], radius=2, fill=(88, 101, 242, 255))

    draw.text((55, note_y + 11), 'Kurallara uymayı ve sunucumuzda keyifli vakit geçirmeyi unutma!', fill=(180, 186, 205, 255), font=font_note)
    draw.text((55, note_y + 31), 'Özel ses odaları ve sohbet için sunucumuzu keşfedebilirsin.', fill=(120, 126, 145, 255), font=font_box_sub)

    draw.text((W - 225, note_y + 20), f'{bot_name}  •  PRİV WELCOME', fill=(75, 80, 100, 255), font=font_watermark)

    out = io.BytesIO()
    img.save(out, format='PNG')
    out.seek(0)
    return out

async def get_welcome_card_file(member: discord.Member, assigned_role_name: str = None) -> discord.File:
    guild = member.guild
    now = datetime.now(timezone.utc)
    created_at = member.created_at
    account_age_days = (now - created_at).days

    if account_age_days < 7:
        sec_status = "Yeni Hesap"
        age_str = f"Yaş: {account_age_days} gün (Riskli)"
    elif account_age_days < 30:
        sec_status = "Orta Düzey"
        age_str = f"Yaş: {account_age_days} gün"
    else:
        sec_status = "Güvenilir Hesap"
        age_str = f"Hesap Yaşı: {account_age_days} gün"
    if assigned_role_name:
        role_name = assigned_role_name
    else:
        otorol_id = config.get("otorol_id", 0)
        found_role = guild.get_role(int(otorol_id)) if otorol_id else None
        role_name = found_role.name if found_role else "Member"

    aylar = {1: "Ocak", 2: "Şubat", 3: "Mart", 4: "Nisan", 5: "Mayıs", 6: "Haziran",
             7: "Temmuz", 8: "Ağustos", 9: "Eylül", 10: "Ekim", 11: "Kasım", 12: "Aralık"}
    date_str = f"{created_at.day} {aylar.get(created_at.month, '')} {created_at.year}"

    if account_age_days < 30:
        rel_str = f"{account_age_days} gün önce açılmış"
    elif account_age_days < 365:
        rel_str = f"{account_age_days // 30} ay önce açılmış"
    else:
        rel_str = f"{account_age_days // 365} yıl önce açılmış"

    member_count = guild.member_count or len(guild.members)

    avatar_bytes = None
    try:
        if member.display_avatar:
            avatar_bytes = await member.display_avatar.with_format("png").with_size(128).read()
    except Exception as e:
        print(f"[Hoş Geldin Avatar Hatası]: {e}", flush=True)

    img_buf = await asyncio.to_thread(
        render_welcome_card,
        member.display_name,
        member.name,
        member.id,
        member_count,
        sec_status,
        age_str,
        role_name,
        date_str,
        rel_str,
        avatar_bytes
    )
    return discord.File(fp=img_buf, filename=f"hosgeldin_{member.id}.png")

def build_welcome_embed(member: discord.Member) -> discord.Embed:
    guild = member.guild
    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    color = get_embed_color()

    # Hesap Yaşı Kontrolü
    now = datetime.now(timezone.utc)
    created_at = member.created_at
    account_age_days = (now - created_at).days
    created_ts = int(created_at.timestamp())

    if account_age_days < 7:
        sec_status = "**Yeni Hesap** *(Son 7 gün içinde açılmış)*"
    elif account_age_days < 30:
        sec_status = "**Orta Düzey** *(Son 1 ay içinde açılmış)*"
    else:
        sec_status = "**Güvenilir Hesap** *(Eski tarihli)*"

    otorol_id = config.get("otorol_id", 0)
    role = guild.get_role(int(otorol_id)) if otorol_id else None
    role_str = role.mention if role else "`Otomatik Üye Rolü`"

    member_count = guild.member_count or len(guild.members)

    embed = discord.Embed(
        title=f"{bot_name} ✦ ARAMIZA HOŞ GELDİN",
        description=(
            f"> Selam {member.mention}, **{guild.name}** sunucumuza hoş geldin!\n"
            f"> Seninle birlikte sunucumuz **{member_count}** kişi oldu.\n\n"
            f"### ÜYE BİLGİLERİ\n"
            f"› **Kullanıcı:** {member.mention} (`{member.name}`)\n"
            f"› **Kullanıcı ID:** `{member.id}`\n"
            f"› **Hesap Açılışı:** <t:{created_ts}:D> (<t:{created_ts}:R>)\n"
            f"› **Güvenlik:** {sec_status}\n"
            f"› **Tanımlanan Rol:** {role_str}\n\n"
            f"### BİLGİLENDİRME\n"
            f"› Kurallara uymayı ve keyifli vakit geçirmeyi unutma!\n"
            f"› Özel ses odaları ve sohbet için sunucumuzu keşfedebilirsin."
        ),
        color=color,
        timestamp=now
    )

    if member.display_avatar:
        embed.set_thumbnail(url=member.display_avatar.url)

    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_author(name=guild.name, icon_url=logo)

    embed.set_footer(text=f"{bot_name} • Priv Hoş Geldin & Otorol Sistemi", icon_url=logo if logo else None)
    return embed

def render_leave_card(display_name: str, username: str, user_id: int,
                      member_count: int, stay_duration_str: str, stay_sub_str: str,
                      joined_date_str: str, joined_sub_str: str,
                      roles_str: str, roles_sub_str: str,
                      leave_time_str: str,
                      avatar_bytes: bytes = None) -> io.BytesIO:
    W, H = 950, 370
    img = Image.new('RGBA', (W, H), (10, 11, 15, 255))
    draw = ImageDraw.Draw(img)

    # Dış kart çerçevesi ve koyu priv arka plan
    draw.rounded_rectangle([(10, 10), (W - 10, H - 10)], radius=20, fill=(16, 17, 23, 255), outline=(48, 30, 35, 255), width=2)
    # Üst aydınlatma çizgisi (Kızıl priv ışıltı)
    draw.line([(35, 12), (W - 35, 12)], fill=(85, 38, 45, 180), width=1)

    # Fontlar
    font_tag = get_card_font(bold=True, size=13)
    font_title = get_card_font(bold=True, size=28)
    font_sub = get_card_font(bold=False, size=15)
    font_pill = get_card_font(bold=True, size=13)
    font_box_lbl = get_card_font(bold=True, size=12)
    font_box_val = get_card_font(bold=True, size=18)
    font_box_sub = get_card_font(bold=False, size=12)
    font_note = get_card_font(bold=False, size=13)
    font_watermark = get_card_font(bold=True, size=12)

    # Avatar
    av_size = 104
    av_x, av_y = 35, 30
    mask = Image.new('L', (av_size, av_size), 0)
    md = ImageDraw.Draw(mask)
    md.ellipse((0, 0, av_size, av_size), fill=255)

    ring_color = (237, 66, 69, 255)  # Crimson Red

    if avatar_bytes:
        try:
            av_raw = Image.open(io.BytesIO(avatar_bytes)).convert('RGBA')
            av_raw = av_raw.resize((av_size, av_size), Image.Resampling.LANCZOS)
            av_raw.putalpha(mask)
            img.paste(av_raw, (av_x, av_y), av_raw)
        except Exception:
            avatar_bytes = None

    if not avatar_bytes:
        fallback = Image.new('RGBA', (av_size, av_size), (45, 25, 30, 255))
        fb_draw = ImageDraw.Draw(fallback)
        initials = display_name[:2].upper() if len(display_name) >= 2 else display_name[:1].upper()
        fb_draw.text((32, 30), initials, fill=(255, 200, 200, 255), font=font_title)
        fallback.putalpha(mask)
        img.paste(fallback, (av_x, av_y), fallback)

    # Avatar halkası (Koyu kızıl vurgu)
    draw.ellipse([(av_x - 3, av_y - 3), (av_x + av_size + 3, av_y + av_size + 3)], outline=ring_color, width=3)

    # Başlık & Bilgiler
    name_x = av_x + av_size + 24
    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    draw.text((name_x, 30), f'{bot_name}  •  ARAMIZDAN AYRILDI', fill=(185, 95, 105, 255), font=font_tag)
    draw.text((name_x, 48), display_name, fill=(255, 255, 255, 255), font=font_title)
    draw.text((name_x, 88), f'@{username}  •  ID: {user_id}', fill=(150, 156, 175, 255), font=font_sub)

    # Sağ Üst Kalan Üye Sayısı Rozeti
    pill_text = f'{member_count} ÜYE KALDI'
    pill_w = int(draw.textlength(pill_text, font=font_pill)) + 30
    pill_x = W - 35 - pill_w
    pill_y = 38
    draw.rounded_rectangle([(pill_x, pill_y), (pill_x + pill_w, pill_y + 32)], radius=16, fill=(35, 18, 22, 255), outline=(237, 66, 69, 180), width=1)
    draw.text((pill_x + 15, pill_y + 7), pill_text, fill=(255, 180, 180, 255), font=font_pill)

    # 4 Bilgi Kutucuğu
    box_y = 150
    box_h = 90
    box_w = 207
    spacing = 15
    start_x = 35

    boxes = [
        ('SUNUCUDA KALMA', stay_duration_str, stay_sub_str, (237, 66, 69, 255)),
        ('KATILDIĞI TARİH', joined_date_str, joined_sub_str, (241, 196, 15, 255)),
        ('SON ROLLERİ', roles_str, roles_sub_str, (88, 101, 242, 255)),
        ('GÜNCEL DURUM', f'{member_count} Kişi', 'Kalan Toplam Üye', (235, 69, 158, 255))
    ]

    for i, (label, val, sub, accent) in enumerate(boxes):
        bx = start_x + i * (box_w + spacing)
        draw.rounded_rectangle([(bx, box_y), (bx + box_w, box_y + box_h)], radius=12, fill=(22, 24, 33, 255), outline=(38, 41, 56, 255), width=1)
        # Sol renkli accent bar
        draw.rounded_rectangle([(bx + 14, box_y + 14), (bx + 18, box_y + 26)], radius=2, fill=accent)
        draw.text((bx + 26, box_y + 13), label, fill=(130, 137, 155, 255), font=font_box_lbl)
        draw.text((bx + 14, box_y + 38), val, fill=(255, 255, 255, 255), font=font_box_val)
        draw.text((bx + 14, box_y + 66), sub, fill=(110, 116, 135, 255), font=font_box_sub)

    # Alt Bilgilendirme Kutusu
    note_y = 280
    draw.rounded_rectangle([(35, note_y), (W - 35, note_y + 55)], radius=10, fill=(20, 22, 30, 255), outline=(35, 38, 50, 255), width=1)
    draw.rounded_rectangle([(35, note_y), (39, note_y + 55)], radius=2, fill=(237, 66, 69, 255))

    draw.text((55, note_y + 11), 'Sunucumuzdan ayrıldı. Yolu açık olsun, dilediği zaman kapımız açık!', fill=(190, 180, 185, 255), font=font_note)
    draw.text((55, note_y + 31), f'Ayrılış Saati: {leave_time_str} • Otomatik Güvenlik Logu', fill=(130, 120, 125, 255), font=font_box_sub)

    draw.text((W - 225, note_y + 20), f'{bot_name}  •  PRİV FAREWELL', fill=(105, 60, 65, 255), font=font_watermark)

    out = io.BytesIO()
    img.save(out, format='PNG')
    out.seek(0)
    return out

async def get_leave_card_file(member: discord.Member) -> discord.File:
    guild = member.guild
    now = datetime.now(timezone.utc)
    member_count = guild.member_count or len(guild.members)

    aylar = {1: "Ocak", 2: "Şubat", 3: "Mart", 4: "Nisan", 5: "Mayıs", 6: "Haziran",
             7: "Temmuz", 8: "Ağustos", 9: "Eylül", 10: "Ekim", 11: "Kasım", 12: "Aralık"}

    joined_at = getattr(member, "joined_at", None)
    if joined_at:
        stay_seconds = int((now - joined_at).total_seconds())
        stay_days = stay_seconds // 86400
        stay_hours = (stay_seconds % 86400) // 3600
        if stay_days > 0:
            stay_duration_str = f"{stay_days} gün, {stay_hours} sa"
            stay_sub_str = f"{stay_days} gün sunucudaydı"
        elif stay_hours > 0:
            stay_duration_str = f"{stay_hours} saat"
            stay_sub_str = "Kısa süreli üyelik"
        else:
            stay_duration_str = f"{max(1, stay_seconds // 60)} dakika"
            stay_sub_str = "Hızlı ayrılış"

        joined_date_str = f"{joined_at.day} {aylar.get(joined_at.month, '')} {joined_at.year}"
        if stay_days < 30:
            joined_sub_str = f"{stay_days} gün önce katıldı"
        elif stay_days < 365:
            joined_sub_str = f"{stay_days // 30} ay önce katıldı"
        else:
            joined_sub_str = f"{stay_days // 365} yıl önce katıldı"
    else:
        stay_duration_str = "Bilinmiyor"
        stay_sub_str = "Kayıt bulunamadı"
        joined_date_str = "Belirtilmemiş"
        joined_sub_str = "Tarih okunamadı"

    roles = [r.name for r in getattr(member, "roles", []) if r.name != "@everyone"]
    if roles:
        if len(roles) == 1:
            roles_str = f"@{roles[0][:15]}"
            roles_sub_str = "Ayrılırken Sahipti"
        elif len(roles) <= 2:
            roles_str = f"@{roles[0][:10]} +1"
            roles_sub_str = f"Toplam {len(roles)} Rol"
        else:
            roles_str = f"@{roles[0][:10]} (+{len(roles)-1})"
            roles_sub_str = f"Toplam {len(roles)} Rol"
    else:
        roles_str = "Rolsüz"
        roles_sub_str = "Rol bulunmuyor"

    now_local = datetime.now()
    leave_time_str = now_local.strftime("%d.%m.%Y %H:%M")

    avatar_bytes = None
    try:
        if member.display_avatar:
            avatar_bytes = await member.display_avatar.with_format("png").with_size(128).read()
    except Exception as e:
        print(f"[Ayrılan Avatar Hatası]: {e}", flush=True)

    img_buf = await asyncio.to_thread(
        render_leave_card,
        member.display_name,
        member.name,
        member.id,
        member_count,
        stay_duration_str,
        stay_sub_str,
        joined_date_str,
        joined_sub_str,
        roles_str,
        roles_sub_str,
        leave_time_str,
        avatar_bytes
    )
    return discord.File(fp=img_buf, filename=f"ayrilan_{member.id}.png")

def build_leave_embed(member: discord.Member) -> discord.Embed:
    guild = member.guild
    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    member_count = guild.member_count or len(guild.members)
    now = datetime.now(timezone.utc)
    now_ts = int(now.timestamp())

    # Sunucuda kalma süresi hesaplama
    stay_info = ""
    if hasattr(member, "joined_at") and member.joined_at:
        joined_at = member.joined_at
        joined_ts = int(joined_at.timestamp())
        stay_seconds = int((now - joined_at).total_seconds())
        stay_days = stay_seconds // 86400
        stay_hours = (stay_seconds % 86400) // 3600

        if stay_days > 0:
            stay_str = f"{stay_days} gün, {stay_hours} saat"
        elif stay_hours > 0:
            stay_str = f"{stay_hours} saat"
        else:
            stay_str = f"{max(1, stay_seconds // 60)} dakika"

        stay_info = (
            f"› **Sunucuya Katılmıştı:** <t:{joined_ts}:D> (<t:{joined_ts}:R>)\n"
            f"› **Sunucuda Kaldığı Süre:** `{stay_str}`\n"
        )

    # Ayrılırken sahip olduğu roller (varsa)
    roles = [r.mention for r in getattr(member, "roles", []) if r.name != "@everyone"]
    if roles:
        if len(roles) > 4:
            roles_text = " • ".join(roles[:4]) + f" *(+{len(roles) - 4} daha)*"
        else:
            roles_text = " • ".join(roles)
        roles_line = f"› **Ayrılırken Rolleri:** {roles_text}\n"
    else:
        roles_line = ""

    embed = discord.Embed(
        title=f"{bot_name} ✦ ARAMIZDAN AYRILDI",
        description=(
            f"> **{member.display_name}** (`@{member.name}`) sunucumuza veda etti.\n\n"
            f"### AYRILAN ÜYE BİLGİLERİ\n"
            f"› **Kullanıcı:** {member.mention} (`{member.name}`)\n"
            f"› **Kullanıcı ID:** `{member.id}`\n"
            f"{stay_info}"
            f"{roles_line}\n"
            f"### GÜNCEL SUNUCU DURUMU\n"
            f"› **Kalan Üye Sayısı:** **`{member_count}`** kişi\n"
            f"› **Ayrılış Saati:** <t:{now_ts}:t> (<t:{now_ts}:R>)"
        ),
        color=0x992d22,  # Koyu Priv Kırmızı
        timestamp=now
    )
    if member.display_avatar:
        embed.set_thumbnail(url=member.display_avatar.url)

    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_author(name=guild.name, icon_url=logo)
        embed.set_footer(text=f"{bot_name} • Priv Ayrılış Logu", icon_url=logo)
    else:
        embed.set_footer(text=f"{bot_name} • Priv Ayrılış Logu")

    return embed

# ─────────────────────────────────────────────
# OTOROL & HOŞ GELDİN EVENTLERİ
# ─────────────────────────────────────────────
@bot.event
async def on_member_join(member: discord.Member):
    """Yeni üye katıldığında otomatik rol verir ve hoşgeldin mesajı gönderir."""
    guild = member.guild

    # 1. OTOROL
    otorol_id = config.get("otorol_id", 0)
    assigned_role_name = None
    if otorol_id:
        role = guild.get_role(int(otorol_id))
        if role:
            try:
                await member.add_roles(role, reason="IMZA Otomatik Üye Rolü")
                assigned_role_name = role.name
                print(f"[Otorol] + {member.display_name} katıldı -> '{role.name}' rolü verildi.", flush=True)
            except Exception as e:
                print(f"[Otorol Hata]: {e}", flush=True)

    # 2. HOŞ GELDİN KANAL MESAJI
    target_channel = None
    ch_id = config.get("hosgeldin_kanal_id")
    if ch_id:
        target_channel = guild.get_channel(int(ch_id))

    # Eğer özel kanal seçilmediyse uygun bir kanal ara
    if not target_channel:
        for ch in guild.text_channels:
            low_name = ch.name.lower()
            if any(w in low_name for w in ["hoş-geldin", "hos-geldin", "hosgeldin", "hoşgeldin", "gelen-giden", "giris-cikis"]):
                target_channel = ch
                break
        if not target_channel and guild.system_channel:
            target_channel = guild.system_channel

    if target_channel and target_channel.permissions_for(guild.me).send_messages:
        try:
            card_file = await get_welcome_card_file(member, assigned_role_name=assigned_role_name)
            # Yalnızca doğrudan etiket atılır, metin eklenmez
            await target_channel.send(content=member.mention, file=card_file)
            print(f"[Hoş Geldin] {member.display_name} için {target_channel.name} kanalına görsel karşılama kartı gönderildi.", flush=True)
        except Exception as e:
            print(f"[Hoş Geldin Mesaj Hatası]: {e}", flush=True)

    # 3. DM HOŞ GELDİN MESAJI (Açıksa)
    if config.get("dm_hosgeldin", False):
        try:
            card_file = await get_welcome_card_file(member, assigned_role_name=assigned_role_name)
            await member.send(file=card_file)
        except Exception:
            pass

@bot.event
async def on_member_remove(member: discord.Member):
    """Üye ayrıldığında ayrılan kanalına veya log kanalına bildirim atar."""
    guild = member.guild
    ch_id = config.get("ayrilan_kanal_id") or config.get("hosgeldin_kanal_id")
    if not ch_id:
        return

    channel = guild.get_channel(int(ch_id))
    if channel and channel.permissions_for(guild.me).send_messages:
        try:
            card_file = await get_leave_card_file(member)
            await channel.send(file=card_file)
            print(f"[Ayrılan] {member.display_name} için {channel.name} kanalına görsel veda kartı gönderildi.", flush=True)
        except Exception as e:
            print(f"[Ayrılan Mesaj Hatası]: {e}", flush=True)

@bot.event
async def on_member_update(before: discord.Member, after: discord.Member):
    """
    Kullanıcının rolleri sağ tıkla veya yönetimsel olarak değiştirildiğinde
    audit log üzerinden işlemi yapan yetkiliyi tespit eder ve log kanalına detaylı Priv rapor iletir.
    """
    # Rol farkını tespit et
    added_roles = [r for r in after.roles if r not in before.roles and r.name != "@everyone"]
    removed_roles = [r for r in before.roles if r not in after.roles and r.name != "@everyone"]

    if not added_roles and not removed_roles:
        return

    guild = after.guild

    # Log kanalını belirle (rol_log_kanal_id veya mod_log_kanal_id)
    log_ch_id = config.get("rol_log_kanal_id") or config.get("mod_log_kanal_id")
    log_channel = None
    if log_ch_id:
        log_channel = guild.get_channel(int(log_ch_id))

    # Discord Audit Log'un yazılması için kısa bir bekleme
    await asyncio.sleep(0.7)

    executor = None
    audit_reason = None
    try:
        async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.member_role_update):
            if entry.target and entry.target.id == after.id:
                diff = (discord.utils.utcnow() - entry.created_at).total_seconds()
                if diff < 15:
                    executor = entry.user
                    audit_reason = entry.reason
                    break
    except Exception as e:
        print(f"[Rol Log Audit Hatası]: {e}", flush=True)

    # İşlemi yapan yetkili metinleri
    if executor:
        executor_text = executor.mention
        executor_name = f"{executor.display_name} (`{executor.name}`)"
        executor_id = str(executor.id)
    else:
        executor_text = "`Bilinmeyen Yetkili / Sistem`"
        executor_name = "Bilinmiyor"
        executor_id = "-"

    # Embed Rengi & Başlığı
    if added_roles and not removed_roles:
        color = 0x2ecc71
        action_title = "Rol Tanımlandı"
    elif removed_roles and not added_roles:
        color = 0xe74c3c
        action_title = "Rol Geri Alındı"
    else:
        color = 0x9b59b6
        action_title = "Rol Güncellemesi"

    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  {action_title}",
        color=color,
        timestamp=datetime.now(timezone.utc)
    )

    embed.add_field(
        name="Hedef Kullanıcı",
        value=f"{after.mention}\n`{after.name}` • ID: `{after.id}`",
        inline=True
    )
    embed.add_field(
        name="İşlemi Yapan Yetkili",
        value=f"{executor_text}\n`{executor_name}` • ID: `{executor_id}`",
        inline=True
    )

    if added_roles:
        roles_str = " • ".join(r.mention for r in added_roles)
        embed.add_field(name="Eklenen Roller", value=roles_str, inline=False)

    if removed_roles:
        roles_str = " • ".join(r.mention for r in removed_roles)
        embed.add_field(name="Geri Alınan Roller", value=roles_str, inline=False)

    if audit_reason:
        embed.add_field(name="İşlem Sebebi", value=f"`{audit_reason}`", inline=False)

    if after.display_avatar:
        embed.set_thumbnail(url=after.display_avatar.url)

    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Rol Denetim Logu", icon_url=logo)
    else:
        embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Rol Denetim Logu")

    if log_channel and log_channel.permissions_for(guild.me).send_messages:
        try:
            await log_channel.send(embed=embed)
            print(f"[Rol Log] {executor_name} -> {after.display_name} kullanıcısının rollerini güncelledi.", flush=True)
        except Exception as e:
            print(f"[Rol Log Gönderme Hatası]: {e}", flush=True)



# ─────────────────────────────────────────────
# 7/24 SABİT SES & YAYINDA DURUMU
# ─────────────────────────────────────────────
@tasks.loop(seconds=10)
async def keep_voice_connection():
    """Botu belirtilen ses kanalında (kulaklık kapalı, mic açık) 7/24 bağlı tutar."""
    target_ch_id = config.get("sabit_ses_kanal_id", 0)
    if not target_ch_id:
        return

    try:
        channel = bot.get_channel(int(target_ch_id))
        if not channel:
            try:
                channel = await bot.fetch_channel(int(target_ch_id))
            except Exception:
                return
        if not channel or not isinstance(channel, (discord.VoiceChannel, discord.StageChannel)):
            return

        guild = channel.guild
        vc = guild.voice_client

        if vc is not None:
            if vc.is_connected() and vc.channel and vc.channel.id == channel.id:
                me_vs = guild.me.voice if guild.me else None
                if me_vs and (not me_vs.self_deaf or me_vs.self_mute):
                    try:
                        await guild.change_voice_state(channel=channel, self_mute=False, self_deaf=True)
                    except Exception:
                        pass
                return
            elif vc.is_connected() and vc.channel and vc.channel.id != channel.id:
                try:
                    await vc.move_to(channel)
                    await guild.change_voice_state(channel=channel, self_mute=False, self_deaf=True)
                    print(f"[Sabit Ses] Bot sabit kanala ({channel.name}) taşındı.", flush=True)
                    return
                except Exception:
                    pass

            # Ses istemcisi takılı veya kopmuşsa temizce kapat
            try:
                await vc.disconnect(force=True)
            except Exception:
                pass
            await asyncio.sleep(1)

        # Kanala bağlan ve kulaklık kapalı, mikrofon açık ayarla
        try:
            await channel.connect(self_deaf=True, self_mute=False, reconnect=True)
            await asyncio.sleep(0.5)
            await guild.change_voice_state(channel=channel, self_mute=False, self_deaf=True)
            print(f"[Sabit Ses] {channel.name} kanalına bağlanıldı (Kulaklık: Kapalı, Mic: Açık).", flush=True)
        except Exception as e:
            print(f"[Sabit Ses Bağlantı Hatası]: {e}", flush=True)
    except Exception as e:
        print(f"[Sabit Ses Genel Hata]: {e}", flush=True)

@tasks.loop(seconds=20)
async def presence_rotation():
    """Botun durumunu 'Yayında' (Streaming - Mor Rozet) olarak dönerek günceller."""
    await bot.wait_until_ready()
    bot_adi = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    stream_url = config.get("stream_url", "https://www.twitch.tv/imzapriw")

    guild_count = len(bot.guilds)
    total_members = sum(g.member_count or len(g.members) for g in bot.guilds)

    try:
        activity1 = discord.Streaming(
            name=f"Hoş Geldin & Otorol | {bot_adi}",
            url=stream_url
        )
        await bot.change_presence(activity=activity1)
    except Exception:
        pass

    await asyncio.sleep(10)

    try:
        activity2 = discord.Streaming(
            name=f"{total_members} Üye | discord.gg/imzapriw",
            url=stream_url
        )
        await bot.change_presence(activity=activity2)
    except Exception:
        pass

@bot.event
async def on_voice_state_update(member, before, after):
    """Bot kanaldan düşürülürse veya taşınırsa otomatik olarak sabit kanala geri sokar."""
    target_ch_id = config.get("sabit_ses_kanal_id", 0)
    if target_ch_id and member.id == bot.user.id:
        if after.channel is None or after.channel.id != int(target_ch_id):
            await asyncio.sleep(1)
            target_ch = member.guild.get_channel(int(target_ch_id))
            if target_ch:
                vc = member.guild.voice_client
                try:
                    if vc and vc.is_connected():
                        await vc.move_to(target_ch)
                    else:
                        await target_ch.connect(self_deaf=True, self_mute=False, reconnect=True)
                    await member.guild.change_voice_state(channel=target_ch, self_mute=False, self_deaf=True)
                except Exception:
                    pass

# ─────────────────────────────────────────────
# GÜVENLİK & MODERASYON MOTORU (KÜFÜR & SPAM)
# ─────────────────────────────────────────────
def is_moderation_immune(member: discord.Member) -> bool:
    """Yöneticiler, yetkililer veya botlar koruma filtrelerine takılmaz."""
    if not isinstance(member, discord.Member):
        return False
    if member.guild_permissions.administrator or member.guild_permissions.manage_messages:
        return True
    staff_role_id = config.get("ticket_yetkili_rol_id")
    if staff_role_id and any(r.id == int(staff_role_id) for r in member.roles):
        return True
    return False

DEFAULT_SWEAR_WORDS = [
    "amk", "aq", "oç", "oc", "orospu", "orospuçocuğu", "orospu cocugu", "piç", "pic",
    "sik", "siktir", "sikiş", "sikis", "sikik", "sikem", "sikim", "sikeyim", "sikerim",
    "sokayım", "sokayim", "yarrak", "yarak", "yarrag", "taşak", "tasak", "amına",
    "amınakoyim", "amkoyim", "amina", "aminakoyayim", "amcık", "amcik", "göt", "got",
    "götveren", "gotveren", "kahpe", "kahbe", "pezevenk", "ibne", "puşt", "pust",
    "döl", "dol", "dalyarak", "sperm", "orospu evladı", "orospu evladi", "ananı", "anani",
    "bacını", "bacini", "sülaleni", "sulaleni"
]

LEETSPEAK_MAP = str.maketrans({
    '1': 'i', '!': 'i', '|': 'i',
    '0': 'o', 'ö': 'o', 'Ö': 'o',
    '3': 'e', '€': 'e',
    '4': 'a', '@': 'a', 'â': 'a',
    '5': 's', '$': 's', 'ş': 's', 'Ş': 's',
    '7': 't', '+': 't',
    '8': 'b',
    'ü': 'u', 'Ü': 'u',
    'ğ': 'g', 'Ğ': 'g',
    'ç': 'c', 'Ç': 'c',
    'İ': 'i', 'I': 'ı'
})

SHORT_SWEAR_WORDS = {"amk", "aq", "oc", "oç", "pic", "piç", "sik", "got", "göt", "dol", "döl"}

def clean_invisible_chars(text: str) -> str:
    """Görünmez boşlukları ve sıfır genişlikli karakterleri temizler."""
    invisible = ['\u200b', '\u200c', '\u200d', '\ufeff', '\u2060', '\u00ad', '\u200e', '\u200f']
    for ch in invisible:
        text = text.replace(ch, '')
    return text

def normalize_text(text: str) -> str:
    """Metni leetspeak ve aksanlardan arındırıp küçük harfe çevirir."""
    cleaned = clean_invisible_chars(text).lower()
    return cleaned.translate(LEETSPEAK_MAP)

def collapse_repeated_chars(text: str) -> str:
    """Tekrarlanan karakterleri teke düşürür (örn: amkkkkk -> amk, siiiik -> sik)."""
    return re.sub(r'(.)\1+', r'\1', text)

def check_profanity(text: str) -> tuple[bool, str]:
    """
    Metinde küfür veya argo bulunup bulunmadığını akıllı normalizasyonla denetler.
    Return: (is_profane, detected_word)
    """
    if not text:
        return False, ""

    norm = normalize_text(text)
    custom_words = config.get("ozel_kufurler", [])
    all_swears = DEFAULT_SWEAR_WORDS + [w.lower() for w in custom_words if w]

    # 1. Kelime/Token Bazlı Kontrol
    tokens = re.findall(r'\b[a-zçğıöşü0-9]+\b', norm)
    tokens += [collapse_repeated_chars(t) for t in tokens]
    for t in tokens:
        if t in all_swears:
            return True, t
        if t.startswith(('siktir', 'siker', 'sikey', 'siktim', 'sikti', 'sikis', 'sikiş', 'sikik', 'orospu', 'yarrak', 'yarak', 'pezevenk', 'amcik', 'amcık')):
            return True, t

    # 2. Boşluksuz / Noktalı Birleşik Kontrol
    no_spaces = re.sub(r'[^a-zçğıöşü0-9]+', '', norm)
    no_spaces_collapsed = collapse_repeated_chars(no_spaces)
    for bad in all_swears:
        clean_bad = normalize_text(bad)
        if clean_bad in SHORT_SWEAR_WORDS:
            if no_spaces == clean_bad or no_spaces_collapsed == clean_bad:
                return True, bad
        else:
            if clean_bad in no_spaces or clean_bad in no_spaces_collapsed:
                return True, bad

    return False, ""

# user_id: { "messages": [(timestamp, content_hash)], "warn_ts": float }
user_spam_data = {}

def check_spam(message: discord.Message) -> tuple[bool, str]:
    """
    Kullanıcının mesajında flood, tekrar, toplu etiket veya spam bulunup bulunmadığını denetler.
    Return: (is_spam, reason)
    """
    now = datetime.now(timezone.utc).timestamp()
    u_id = message.author.id
    content = message.content or ""

    # 1. Toplu Etiket (Mass Mention) Spami
    total_mentions = len(message.mentions) + len(message.role_mentions)
    if total_mentions >= 5:
        return True, "Toplu etiket spami"

    # 2. Emoji Spami (10+ emoji)
    custom_emojis = re.findall(r'<a?:[a-zA-Z0-9_]+:[0-9]+>', content)
    unicode_emojis = re.findall(r'[\U00010000-\U0010ffff]', content)
    if len(custom_emojis) + len(unicode_emojis) >= 10:
        return True, "Aşırı emoji spami"

    # 3. Tek Karakter Tekrarı (örn: aaaaaaaaaaaaaaaaaaaaaaaaa)
    if len(content) > 30 and re.search(r'(.)\1{24,}', content):
        return True, "Harf uzatma / flood spami"

    # 4. Zaman Penceresi Takibi (Flood & Tekrarlayan Mesaj)
    if u_id not in user_spam_data:
        user_spam_data[u_id] = {"messages": [], "warn_ts": 0.0}

    u_data = user_spam_data[u_id]
    u_data["messages"] = [(t, h) for (t, h) in u_data["messages"] if now - t <= 10.0]

    content_hash = hash(content.strip().lower())
    u_data["messages"].append((now, content_hash))

    # A) Hızlı Mesaj Flood'u: Son 3.5 saniyede 5+ mesaj VEYA son 6 saniyede 7+ mesaj
    recent_3_5s = [t for (t, h) in u_data["messages"] if now - t <= 3.5]
    if len(recent_3_5s) >= 5:
        return True, "Hızlı mesaj flood'u"

    recent_6s = [t for (t, h) in u_data["messages"] if now - t <= 6.0]
    if len(recent_6s) >= 7:
        return True, "Hızlı mesaj flood'u"

    # B) Tekrarlayan Aynı Mesaj: Son 8 saniyede aynı mesajdan 3+ adet
    if len(content.strip()) >= 3:
        recent_same = [h for (t, h) in u_data["messages"] if now - t <= 8.0 and h == content_hash]
        if len(recent_same) >= 3:
            return True, "Tekrarlayan aynı mesaj spami"

    return False, ""

async def handle_profanity_violation(message: discord.Message, detected_word: str):
    """Küfür tespit edildiğinde mesajı siler, uyarı verir ve loglar."""
    member = message.author
    channel = message.channel
    guild = message.guild

    try:
        await message.delete()
    except Exception:
        pass

    try:
        await channel.send(
            f"{member.mention} bu sunucuda küfür ve argo kullanımı yasaktır.",
            delete_after=4
        )
    except Exception:
        pass

    log_ch_id = config.get("mod_log_kanal_id")
    if log_ch_id and guild:
        log_ch = guild.get_channel(int(log_ch_id))
        if log_ch:
            embed = discord.Embed(
                title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Küfür Engellendi",
                description=(
                    f"• **Kullanıcı:** {member.mention} (`{member.name}` - `{member.id}`)\n"
                    f"• **Kanal:** {channel.mention}\n"
                    f"• **Tespit Edilen:** `{detected_word}`\n"
                    f"• **İçerik:** ```{message.content[:500]}```"
                ),
                color=0xed4245,
                timestamp=datetime.now(timezone.utc)
            )
            logo = get_brand_logo_url(guild)
            if logo:
                embed.set_thumbnail(url=logo)
            embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Güvenlik Sistemi")
            await log_ch.send(embed=embed)

async def handle_spam_violation(message: discord.Message, reason: str):
    """Spam tespit edildiğinde mesajı siler, ilk uyarıyı yapar veya timeout uygular."""
    member = message.author
    channel = message.channel
    guild = message.guild
    now = datetime.now(timezone.utc).timestamp()

    try:
        await message.delete()
    except Exception:
        pass

    u_data = user_spam_data.get(member.id, {"warn_ts": 0.0})
    last_warn = u_data.get("warn_ts", 0.0)

    # Son 45 saniye içinde uyarılmışsa -> Timeout
    if now - last_warn <= 45.0:
        timeout_mins = int(config.get("spam_timeout_dakika", 2))
        try:
            await member.timeout(timedelta(minutes=timeout_mins), reason=f"Spam/Flood: {reason}")
            await channel.send(
                f"{member.mention} tekrarlanan spam nedeniyle **{timeout_mins} dakika** susturuldu.",
                delete_after=6
            )
        except Exception as e:
            print(f"[Timeout Hatası]: {e}", flush=True)

        log_ch_id = config.get("mod_log_kanal_id")
        if log_ch_id and guild:
            log_ch = guild.get_channel(int(log_ch_id))
            if log_ch:
                embed = discord.Embed(
                    title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Spam Cezası (Timeout)",
                    description=(
                        f"• **Kullanıcı:** {member.mention} (`{member.name}` - `{member.id}`)\n"
                        f"• **Kanal:** {channel.mention}\n"
                        f"• **Sebep:** `{reason}`\n"
                        f"• **Süre:** `{timeout_mins} Dakika`\n"
                        f"• **Son Mesaj:** ```{message.content[:500]}```"
                    ),
                    color=0xed4245,
                    timestamp=datetime.now(timezone.utc)
                )
                logo = get_brand_logo_url(guild)
                if logo:
                    embed.set_thumbnail(url=logo)
                embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Güvenlik Sistemi")
                await log_ch.send(embed=embed)
    else:
        u_data["warn_ts"] = now
        try:
            await channel.send(
                f"{member.mention} lütfen sohbette spam / flood yapmayınız.",
                delete_after=4
            )
        except Exception:
            pass

# ─────────────────────────────────────────────
# YETKİLİ DM LOG SİSTEMİ (0)
# ─────────────────────────────────────────────
async def send_staff_dm_log(
    guild: discord.Guild,
    title: str,
    description: str,
    color: int = 0xed4245,
    fields: Optional[list[tuple[str, str, bool]]] = None,
    image_file: Optional[discord.File] = None
):
    """0 rolüne sahip yetkililere özel DM üzerinden mod log bildirimi iletir."""
    if not guild:
        return
    staff_role_id = int(config.get("staff_dm_log_role_id", 0))
    staff_role = guild.get_role(staff_role_id)
    if not staff_role:
        return

    staff_members = [m for m in staff_role.members if not m.bot]
    if not staff_members:
        return

    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.now(timezone.utc)
    )
    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Yetkili DM Denetim Sistemi")

    if fields:
        for fname, fval, finline in fields:
            embed.add_field(name=fname, value=fval, inline=finline)

    if image_file:
        embed.set_image(url=f"attachment://{image_file.filename}")

    img_bytes = None
    img_filename = None
    if image_file:
        img_bytes = image_file.fp.read()
        img_filename = image_file.filename

    for member in staff_members:
        try:
            if img_bytes and img_filename:
                file_to_send = discord.File(io.BytesIO(img_bytes), filename=img_filename)
                await member.send(embed=embed, file=file_to_send)
            else:
                await member.send(embed=embed)
        except Exception:
            pass

# ─────────────────────────────────────────────
# REKLAM & LİNK KORUMA MOTORU (GIF İSTİSNALI)
# ─────────────────────────────────────────────
URL_REGEX = re.compile(
    r'(?:https?://|ftp://|www\.)[^\s/$.?#].[^\s]*|discord(?:\.gg|(?:app)?\.com/invite)/[a-zA-Z0-9-]+',
    re.IGNORECASE
)

def is_allowed_gif_link(url: str) -> bool:
    """Discord Tenor / Giphy yerleşik GIF aramaları ve doğrudan .gif linklerini istisna tutar."""
    u = url.lower()
    if "tenor.com" in u or "giphy.com" in u:
        return True
    path_part = u.split('?')[0]
    if path_part.endswith(".gif"):
        return True
    return False

def check_advertising(text: str) -> tuple[bool, Optional[str]]:
    """Metinde yetkisiz reklam / link bulunup bulunmadığını denetler (GIF serbest)."""
    matches = URL_REGEX.findall(text)
    for match in matches:
        if not is_allowed_gif_link(match):
            return True, match
    return False, None

def generate_ad_proof_image(author_name: str, author_id: str, channel_name: str, content: str) -> io.BytesIO:
    """Reklam mesajı için şık Discord temalı bir kanıt kartı üretir."""
    w, h = 680, 240
    img = Image.new('RGB', (w, h), color=(15, 18, 28))
    draw = ImageDraw.Draw(img)

    # Dış çerçeve ve üst bar
    draw.rectangle([(0, 0), (w-1, h-1)], outline=(239, 68, 68), width=2)
    draw.rectangle([(2, 2), (w-3, 38)], fill=(38, 20, 26))
    draw.text((16, 11), 'REKLAM & LINK IHLALI KANITI (GÖRSEL LOG)', fill=(248, 113, 113))

    # Üye & Kanal Detayı
    draw.text((22, 50), f'Kullanici: @{author_name} (ID: {author_id})', fill=(226, 232, 240))
    draw.text((22, 72), f'Kanal: #{channel_name}', fill=(148, 163, 184))

    # Mesaj Kutusu
    draw.rectangle([(20, 102), (w-20, h-22)], fill=(22, 27, 42), outline=(51, 65, 85))
    draw.text((32, 112), 'Engellenen Mesaj Metni:', fill=(148, 163, 184))

    clean_msg = content.replace('\n', ' ')
    if len(clean_msg) > 75:
        clean_msg = clean_msg[:72] + '...'
    draw.text((32, 138), clean_msg, fill=(239, 68, 68))

    # Alt Bilgi Notu
    draw.text((32, 175), 'Sistem: Otomatik Link Engelleme (Discord GIF Haric)', fill=(100, 116, 139))

    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    return buf

async def handle_ad_violation(message: discord.Message, matched_url: str):
    """Reklam tespit edildiğinde mesajı siler, yetkililere resimli DM atar ve uyarı verir."""
    member = message.author
    channel = message.channel
    guild = message.guild

    try:
        await message.delete()
    except Exception:
        pass

    # Kullanıcıya kanalda anlık uyarı
    try:
        await channel.send(
            f"{member.mention} bu sunucuda reklam ve bağlantı (link) paylaşımı yasaktır!",
            delete_after=5
        )
    except Exception:
        pass

    # Kanıt görselini üret
    ch_name = getattr(channel, "name", "bilinmeyen-kanal")
    proof_buf = generate_ad_proof_image(member.name, str(member.id), ch_name, message.content)

    # Mod Log kanalına gönder
    log_ch_id = config.get("mod_log_kanal_id")
    if log_ch_id:
        log_ch = guild.get_channel(int(log_ch_id))
        if log_ch and log_ch.permissions_for(guild.me).send_messages:
            embed = discord.Embed(
                title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Reklam / Link Engellendi",
                description=(
                    f"• **Kullanıcı:** {member.mention} (`{member.name}` - `{member.id}`)\n"
                    f"• **Kanal:** {channel.mention}\n"
                    f"• **Tespit Edilen Link:** `{matched_url}`\n"
                    f"• **Durum:** Mesaj anında silindi, yetkili DM loguna iletildi."
                ),
                color=0xed4245,
                timestamp=datetime.now(timezone.utc)
            )
            logo = get_brand_logo_url(guild)
            if logo:
                embed.set_thumbnail(url=logo)
            embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Reklam Koruması")
            proof_buf.seek(0)
            log_file = discord.File(io.BytesIO(proof_buf.read()), filename="reklam_kaniti.png")
            embed.set_image(url="attachment://reklam_kaniti.png")
            try:
                await log_ch.send(embed=embed, file=log_file)
            except Exception:
                pass

    # 0 rolündeki yetkililere DM log gönder (Direkt RESİM olarak)
    proof_buf.seek(0)
    dm_file = discord.File(io.BytesIO(proof_buf.read()), filename="reklam_kaniti.png")
    fields = [
        ("Kullanıcı", f"{member.mention} (`{member.id}`)", True),
        ("Kanal", f"#{ch_name}", True),
        ("Yasaklı Link", f"`{matched_url}`", False),
        ("İşlem", "Mesaj otomatik silindi & kanıt resmi oluşturuldu", False)
    ]
    await send_staff_dm_log(
        guild=guild,
        title="🚨 [DENETİM] Reklam / Link İhlali Tespit Edildi",
        description=f"{member.mention} adlı üye #{ch_name} kanalında yetkisiz link paylaştı ve mesaj silindi.",
        color=0xed4245,
        fields=fields,
        image_file=dm_file
    )

# ─────────────────────────────────────────────
# GUARD KORUMA MOTORU (KANAL KORUMA & WHITELIST)
# ─────────────────────────────────────────────
def is_guard_whitelisted(user: Union[discord.Member, discord.User], guild: discord.Guild) -> bool:
    """Sunucu sahibi, botun kendisi, güvenli botlar veya whitelistteki kullanıcı/roller muaf tutulur."""
    if not guild or not user:
        return False
    # Sunucu sahibi daima tam muaf
    if user.id == guild.owner_id:
        return True
    # Botun kendisi muaf
    if bot.user and user.id == bot.user.id:
        return True
    # Güvenli botlar muaf (Destek botu vb.)
    guvenli_botlar = config.get("guard_guvenli_botlar", [0, 0])
    if user.id in guvenli_botlar:
        return True
    # Özel whitelist kullanıcıları
    whitelist_users = config.get("guard_whitelist_kullanicilar", [])
    if user.id in whitelist_users:
        return True
    # Özel whitelist rolleri
    whitelist_roles = config.get("guard_whitelist_roller", [])
    if whitelist_roles:
        member = user if hasattr(user, "roles") else guild.get_member(user.id)
        if member and hasattr(member, "roles"):
            if any(getattr(r, "id", None) in whitelist_roles for r in member.roles):
                return True
    return False

async def handle_guard_violation(guild: discord.Guild, executor: Union[discord.Member, discord.User], action_type: str, channel_name: str):
    """Yetkisiz kanal açma/silme girişiminde 3 aşamalı uyarı ve 3. aşamada yetkileri çekme mekanizması."""
    u_id_str = str(executor.id)
    uyarilar = config.setdefault("guard_uyarilar", {})
    count = uyarilar.get(u_id_str, 0) + 1
    uyarilar[u_id_str] = count
    save_config(config)

    limit = config.get("guard_uyari_limiti", 3)
    bot_adi = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")

    member = guild.get_member(executor.id)
    if not member:
        try:
            member = await guild.fetch_member(executor.id)
        except Exception:
            member = None

    if count < limit:
        # Aşama 1 & 2: Uyarı (DM + Mod Log)
        try:
            dm_embed = discord.Embed(
                title=f"{bot_adi}  |  Kanal Koruma Uyarısı",
                description=(
                    f"**Yetkisiz kanal işlemi engellendi!**\n\n"
                    f"• **İşlem:** Yetkisiz {action_type}\n"
                    f"• **Hedef Kanal:** `#{channel_name}`\n"
                    f"• **Uyarı Durumu:** `{count} / {limit}`\n\n"
                    f"Bu sunucuda kanal açma ve silme işlemleri yalnızca Guard güvenli listesindeki yetkililer tarafından yapılabilir.\n"
                    f"**{limit}. uyarıya ulaştığınızda tüm yetkili rolleriniz otomatik olarak geri alınacaktır.**"
                ),
                color=0xed4245,
                timestamp=datetime.now(timezone.utc)
            )
            logo = get_brand_logo_url(guild)
            if logo:
                dm_embed.set_thumbnail(url=logo)
            dm_embed.set_footer(text=f"{bot_adi} • Güvenlik Sistemi")
            await executor.send(embed=dm_embed)
        except Exception:
            pass

        log_ch_id = config.get("mod_log_kanal_id")
        if log_ch_id:
            log_ch = guild.get_channel(int(log_ch_id))
            if log_ch:
                log_embed = discord.Embed(
                    title=f"{bot_adi}  |  Yetkisiz {action_type} Engellendi",
                    description=(
                        f"• **Yetkili:** {executor.mention} (`{executor.name}` - `{executor.id}`)\n"
                        f"• **Eylem:** Yetkisiz {action_type}\n"
                        f"• **Kanal:** `#{channel_name}`\n"
                        f"• **Müdahale:** Kanal koruma tarafından engellendi / telafi edildi\n"
                        f"• **Ceza Durumu:** Uyarı `{count} / {limit}`"
                    ),
                    color=0xed4245,
                    timestamp=datetime.now(timezone.utc)
                )
                logo = get_brand_logo_url(guild)
                if logo:
                    log_embed.set_thumbnail(url=logo)
                log_embed.set_footer(text=f"{bot_adi} • Güvenlik Sistemi")
                await log_ch.send(embed=log_embed)
    else:
        # Aşama 3: Limit Aşıldı -> YETKİLERİ ÇEK + TIMEOUT
        removed_roles = []
        if member and guild.me:
            bot_top_role = guild.me.top_role
            roles_to_remove = []
            for r in member.roles:
                if r == guild.default_role or r.managed:
                    continue
                if hasattr(r, "position") and hasattr(bot_top_role, "position"):
                    if r.position >= bot_top_role.position:
                        continue
                elif r >= bot_top_role:
                    continue
                perms = r.permissions
                if (perms.administrator or perms.manage_channels or perms.manage_guild or
                    perms.manage_roles or perms.manage_messages or perms.ban_members or
                    perms.kick_members or perms.mention_everyone):
                    roles_to_remove.append(r)

            if roles_to_remove:
                try:
                    await member.remove_roles(*roles_to_remove, reason="Guard: 3 kez yetkisiz kanal işlemi (Yetkileri çekildi)")
                    removed_roles = [r.name for r in roles_to_remove]
                except Exception as e:
                    print(f"[Guard Yetki Çekme Hatası]: {e}", flush=True)

            try:
                await member.timeout(timedelta(hours=1), reason="Guard: 3 kez yetkisiz kanal işlemi (Yetkileri çekildi + 1 Saat Susturma)")
            except Exception as e:
                print(f"[Guard Timeout Hatası]: {e}", flush=True)

        removed_str = ", ".join(f"`{r}`" for r in removed_roles) if removed_roles else "*(Roller hiyerarşi sebebiyle çekilemedi veya yetkili rolü bulunamadı)*"

        try:
            dm_embed = discord.Embed(
                title=f"{bot_adi}  |  TÜM YETKİLERİNİZ GERİ ALINDI",
                description=(
                    f"**Güvenlik Protokolü Devreye Girdi!**\n\n"
                    f"Sunucuda izinsiz olarak `{count}` kez kanal işlemi (`{action_type}`) gerçekleştirdiğiniz için tüm yetkili rolleriniz geri alınmış ve hesabınıza güvenlik tedbiri uygulanmıştır.\n\n"
                    f"• **Son İşlem:** `#{channel_name}`\n"
                    f"• **Geri Alınan Roller:** {removed_str}\n"
                    f"• **Uygulanan Tedbir:** Yetkiler Sıfırlandı + 1 Saat Susturma (Timeout)"
                ),
                color=0x992d22,
                timestamp=datetime.now(timezone.utc)
            )
            logo = get_brand_logo_url(guild)
            if logo:
                dm_embed.set_thumbnail(url=logo)
            dm_embed.set_footer(text=f"{bot_adi} • Güvenlik Sistemi")
            await executor.send(embed=dm_embed)
        except Exception:
            pass

        log_ch_id = config.get("mod_log_kanal_id")
        if log_ch_id:
            log_ch = guild.get_channel(int(log_ch_id))
            if log_ch:
                log_embed = discord.Embed(
                    title=f"{bot_adi}  |  YETKİLER GERİ ALINDI (GUARD CEZASI)",
                    description=(
                        f"• **Yetkili:** {executor.mention} (`{executor.name}` - `{executor.id}`)\n"
                        f"• **İhlal Nedeni:** `{count}.` kez yetkisiz {action_type} işlemi\n"
                        f"• **Hedef Kanal:** `#{channel_name}`\n"
                        f"• **Geri Alınan Roller:** {removed_str}\n"
                        f"• **Uygulanan Tedbir:** Tüm Yetkili Rolleri Alındı + 1 Saat Timeout\n"
                        f"• **Durum:** Güvenlik protokolü başarıyla uygulandı."
                    ),
                    color=0x992d22,
                    timestamp=datetime.now(timezone.utc)
                )
                logo = get_brand_logo_url(guild)
                if logo:
                    log_embed.set_thumbnail(url=logo)
                log_embed.set_footer(text=f"{bot_adi} • Güvenlik Sistemi")
                await log_ch.send(embed=log_embed)

@bot.event
async def on_guild_channel_create(channel: discord.abc.GuildChannel):
    """Kanal açma olayını denetler, yetkililere DM iletir ve guard protokolünü çalıştırır."""
    await asyncio.sleep(0.8)

    guild = channel.guild
    executor = None

    try:
        async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.channel_create):
            if entry.target and entry.target.id == channel.id:
                diff = (discord.utils.utcnow() - entry.created_at).total_seconds()
                if diff < 15:
                    executor = entry.user
                    break
    except Exception as e:
        print(f"[Audit Log Hatası - Kanal Açma]: {e}", flush=True)

    # 0 rolündeki yetkililere DM ilet (Bot işlemleri hariç)
    if executor and not executor.bot:
        await send_staff_dm_log(
            guild=guild,
            title="📁 [DENETİM] Yeni Kanal Eklendi / Oluşturuldu",
            description=f"{executor.mention} sunucuda **#{channel.name}** kanalını oluşturdu.",
            color=0x3498db,
            fields=[
                ("Kanal Adı", f"#{channel.name}", True),
                ("Kanal ID", f"`{channel.id}`", True),
                ("İşlemi Yapan Yetkili", f"{executor.mention} (`{executor.name}` - `{executor.id}`)", False)
            ]
        )

    if not config.get("guard_kanal_koruma", True) or not executor:
        return

    # Whitelist kontrolü
    if is_guard_whitelisted(executor, guild):
        return

    # Yetkisiz işlem: Kanalı hemen sil
    ch_name = channel.name
    try:
        await channel.delete(reason=f"Guard: Yetkisiz kanal açma engellendi ({executor.name} - {executor.id})")
    except Exception as e:
        print(f"[Guard Kanal Silme Hatası]: {e}", flush=True)

    await handle_guard_violation(guild, executor, "Kanal Açma", ch_name)

@bot.event
async def on_guild_channel_delete(channel: discord.abc.GuildChannel):
    """Kanal silme olayını denetler, yetkililere DM iletir ve guard protokolünü çalıştırır."""
    await asyncio.sleep(0.8)

    guild = channel.guild
    executor = None

    try:
        async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.channel_delete):
            if entry.target and entry.target.id == channel.id:
                diff = (discord.utils.utcnow() - entry.created_at).total_seconds()
                if diff < 15:
                    executor = entry.user
                    break
    except Exception as e:
        print(f"[Audit Log Hatası - Kanal Silme]: {e}", flush=True)

    ch_name = channel.name

    # 0 rolündeki yetkililere DM ilet (Bot işlemleri hariç)
    if executor and not executor.bot:
        await send_staff_dm_log(
            guild=guild,
            title="🗑️ [DENETİM] Kanal Silindi",
            description=f"{executor.mention} sunucudan **#{ch_name}** kanalını sildi.",
            color=0xe67e22,
            fields=[
                ("Silinen Kanal", f"#{ch_name}", True),
                ("Kanal ID", f"`{channel.id}`", True),
                ("İşlemi Yapan Yetkili", f"{executor.mention} (`{executor.name}` - `{executor.id}`)", False)
            ]
        )

    if not config.get("guard_kanal_koruma", True) or not executor:
        return

    # Whitelist kontrolü
    if is_guard_whitelisted(executor, guild):
        return

    # Yetkisiz işlem: Kanalı kurtar (Geri oluştur)
    category = getattr(channel, "category", None)
    position = getattr(channel, "position", 0)
    overwrites = getattr(channel, "overwrites", {})

    try:
        if isinstance(channel, discord.TextChannel):
            topic = getattr(channel, "topic", None)
            await guild.create_text_channel(
                name=ch_name,
                category=category,
                position=position,
                topic=topic,
                overwrites=overwrites,
                reason=f"Guard: Yetkisiz silinen kanal geri yüklendi ({executor.name})"
            )
        elif isinstance(channel, discord.VoiceChannel):
            bitrate = getattr(channel, "bitrate", 64000)
            user_limit = getattr(channel, "user_limit", 0)
            await guild.create_voice_channel(
                name=ch_name,
                category=category,
                position=position,
                bitrate=bitrate,
                user_limit=user_limit,
                overwrites=overwrites,
                reason=f"Guard: Yetkisiz silinen ses kanalı geri yüklendi ({executor.name})"
            )
        elif isinstance(channel, discord.CategoryChannel):
            await guild.create_category(
                name=ch_name,
                position=position,
                overwrites=overwrites,
                reason=f"Guard: Yetkisiz silinen kategori geri yüklendi ({executor.name})"
            )
    except Exception as e:
        print(f"[Guard Kanal Kurtarma Hatası]: {e}", flush=True)

    await handle_guard_violation(guild, executor, "Kanal Silme", ch_name)

@bot.event
async def on_guild_role_create(role: discord.Role):
    """Sunucuda yeni bir rol oluşturulduğunda audit log üzerinden tespit edip yetkililere DM iletir."""
    guild = role.guild
    await asyncio.sleep(0.8)
    executor = None
    try:
        async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.role_create):
            if entry.target and entry.target.id == role.id:
                diff = (discord.utils.utcnow() - entry.created_at).total_seconds()
                if diff < 15:
                    executor = entry.user
                    break
    except Exception as e:
        print(f"[Role Create Audit Hatası]: {e}", flush=True)

    if not executor or executor.bot:
        return

    exec_text = executor.mention
    exec_id = str(executor.id)

    fields = [
        ("Oluşturulan Rol", f"{role.mention} (`{role.name}`)", True),
        ("İşlemi Yapan Yetkili", f"{exec_text} (`{exec_id}`)", True),
        ("Rol ID", f"`{role.id}`", False)
    ]
    await send_staff_dm_log(
        guild=guild,
        title="🛡️ [DENETİM] Yeni Rol Eklendi / Oluşturuldu",
        description=f"{exec_text} sunucuda **{role.name}** adında yeni bir rol oluşturdu.",
        color=0x2ecc71,
        fields=fields
    )

@bot.event
async def on_guild_role_delete(role: discord.Role):
    """Sunucuda bir rol silindiğinde audit log üzerinden tespit edip yetkililere DM iletir."""
    guild = role.guild
    await asyncio.sleep(0.8)
    executor = None
    try:
        async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.role_delete):
            if entry.target and entry.target.id == role.id:
                diff = (discord.utils.utcnow() - entry.created_at).total_seconds()
                if diff < 15:
                    executor = entry.user
                    break
    except Exception as e:
        print(f"[Role Delete Audit Hatası]: {e}", flush=True)

    if not executor or executor.bot:
        return

    exec_text = executor.mention
    exec_id = str(executor.id)

    fields = [
        ("Silinen Rol", f"**{role.name}**", True),
        ("İşlemi Yapan Yetkili", f"{exec_text} (`{exec_id}`)", True),
        ("Rol ID", f"`{role.id}`", False)
    ]
    await send_staff_dm_log(
        guild=guild,
        title="⚠️ [DENETİM] Sunucuda Rol Silindi",
        description=f"{exec_text} sunucudan **{role.name}** rolünü sildi.",
        color=0xed4245,
        fields=fields
    )

@bot.event
async def on_member_ban(guild: discord.Guild, user: Union[discord.User, discord.Member]):
    """Sunucudan bir üye banlandığında audit log üzerinden banlayan yetkiliyi tespit edip yetkililere DM iletir."""
    await asyncio.sleep(0.8)
    executor = None
    reason = "Gerekçe belirtilmedi"
    try:
        async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.ban):
            if entry.target and entry.target.id == user.id:
                diff = (discord.utils.utcnow() - entry.created_at).total_seconds()
                if diff < 15:
                    executor = entry.user
                    reason = entry.reason or "Gerekçe belirtilmedi"
                    break
    except Exception as e:
        print(f"[Ban Audit Log Hatası]: {e}", flush=True)

    if not executor or executor.bot:
        return

    exec_text = executor.mention
    exec_id = str(executor.id)

    fields = [
        ("Banlanan Kullanıcı", f"{user.mention} (`{user.name}` - `{user.id}`)", True),
        ("Banlayan Yetkili", f"{exec_text} (`{exec_id}`)", True),
        ("Gerekçe", f"`{reason}`", False)
    ]
    await send_staff_dm_log(
        guild=guild,
        title="🔨 [DENETİM] Üye Sunucudan Yasaklandı (Ban)",
        description=f"{exec_text} adlı yetkili {user.mention} kullanıcısını sunucudan yasakladı.",
        color=0xed4245,
        fields=fields
    )

@bot.event
async def on_member_unban(guild: discord.Guild, user: discord.User):
    """Sunucuda bir üyenin banı kaldırıldığında audit log üzerinden unban atan yetkiliyi tespit edip yetkililere DM iletir."""
    await asyncio.sleep(0.8)
    executor = None
    reason = "Gerekçe belirtilmedi"
    try:
        async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.unban):
            if entry.target and entry.target.id == user.id:
                diff = (discord.utils.utcnow() - entry.created_at).total_seconds()
                if diff < 15:
                    executor = entry.user
                    reason = entry.reason or "Gerekçe belirtilmedi"
                    break
    except Exception as e:
        print(f"[Unban Audit Log Hatası]: {e}", flush=True)

    if not executor or executor.bot:
        return

    exec_text = executor.mention
    exec_id = str(executor.id)

    fields = [
        ("Yasağı Kaldırılan", f"{user.mention} (`{user.name}` - `{user.id}`)", True),
        ("İşlemi Yapan Yetkili", f"{exec_text} (`{exec_id}`)", True),
        ("Gerekçe", f"`{reason}`", False)
    ]
    await send_staff_dm_log(
        guild=guild,
        title="🔓 [DENETİM] Üye Yasağı Kaldırıldı (Unban)",
        description=f"{exec_text} adlı yetkili {user.mention} kullanıcısının yasağını kaldırdı.",
        color=0x2ecc71,
        fields=fields
    )

# ─────────────────────────────────────────────
# MESAJ & CHAT AKTİFLİK MOTORU (ON_MESSAGE)
# ─────────────────────────────────────────────
@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or not message.guild:
        return

    # 1. Moderasyon & Koruma Denetimi (Küfür & Spam)
    if not is_moderation_immune(message.author):
        # Bilet kanallarında kullanıcıların ihlal bildirimlerini engellememek için bilet kanallarını hariç tut
        is_ticket_ch = message.channel.name.startswith(("talep-", "kilit-", "ticket-", "destek-"))

        # Küfür Kontrolü
        if config.get("kufur_engel", True) and not is_ticket_ch:
            is_profane, bad_word = check_profanity(message.content)
            if is_profane:
                await handle_profanity_violation(message, bad_word)
                return

        # Spam Kontrolü
        if config.get("spam_engel", True):
            is_spamming, spam_reason = check_spam(message)
            if is_spamming:
                await handle_spam_violation(message, spam_reason)
                return

        # Reklam / Link Kontrolü (GIF Haric)
        if config.get("reklam_engel", True) and not is_ticket_ch:
            is_ad, matched_url = check_advertising(message.content)
            if is_ad:
                await handle_ad_violation(message, matched_url)
                return

    # 2. Mesaj ve XP takibi
    stats = load_stats()
    u_id = str(message.author.id)
    if u_id not in stats:
        stats[u_id] = {
            "voice_seconds": 0,
            "messages": 0,
            "xp": 0,
            "level": 1,
            "last_xp_time": 0
        }

    stats[u_id]["messages"] = stats[u_id].get("messages", 0) + 1

    now_ts = int(datetime.now(timezone.utc).timestamp())
    last_xp = stats[u_id].get("last_xp_time", 0)

    # 30 saniye cooldown ile 15-25 XP kazandır
    if now_ts - last_xp >= 30:
        gain = random.randint(15, 25)
        old_xp = stats[u_id].get("xp", 0)
        new_xp = old_xp + gain
        stats[u_id]["xp"] = new_xp
        stats[u_id]["last_xp_time"] = now_ts

        old_lvl = stats[u_id].get("level", 1)
        new_lvl = get_level_from_xp(new_xp)
        if new_lvl > old_lvl:
            stats[u_id]["level"] = new_lvl
            try:
                bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
                embed = discord.Embed(
                    title=f"{bot_name}  |  Seviye Atladın",
                    description=f"Tebrikler {message.author.mention}! Sohbette aktif olarak **Seviye {new_lvl}** oldun!",
                    color=0xf1c40f
                )
                await message.channel.send(content=message.author.mention, embed=embed, delete_after=8)
            except Exception:
                pass

    save_stats(stats)
    await bot.process_commands(message)

# ─────────────────────────────────────────────
# SNIPE MOTORU (SİLİNEN MESAJLARI YAKALAMA)
# ─────────────────────────────────────────────
# Kanal bazlı son silinen mesajları saklar: {channel_id: [ {author, content, attachments, created_at, deleted_at} ]}
snipe_cache: dict[int, list[dict]] = {}

@bot.event
async def on_message_delete(message: discord.Message):
    """Kanalda silinen mesajları yakalayarak /snipe komutu için bellekte saklar."""
    if not message.guild or message.author.bot:
        return

    # İçerik ve ekler boşsa saklama
    if not message.content and not message.attachments:
        return

    ch_id = message.channel.id
    if ch_id not in snipe_cache:
        snipe_cache[ch_id] = []

    attachments_urls = [a.url for a in message.attachments]

    entry = {
        "author": message.author,
        "author_id": message.author.id,
        "author_name": message.author.name,
        "author_display": message.author.display_name,
        "author_avatar": message.author.display_avatar.url if message.author.display_avatar else None,
        "content": message.content or "(Metin içeriği yok)",
        "attachments": attachments_urls,
        "created_at": message.created_at,
        "deleted_at": datetime.now(timezone.utc)
    }

    # Kanal başına son 20 silinen mesajı sakla
    snipe_cache[ch_id].insert(0, entry)
    if len(snipe_cache[ch_id]) > 20:
        snipe_cache[ch_id].pop()

# ─────────────────────────────────────────────
# ÇEKİLİŞ (GIVEAWAY) BUTONU VE VIEW'İ (KALICI)
# ─────────────────────────────────────────────
class GiveawayJoinButton(discord.ui.Button):
    def __init__(self, count: int = 0):
        super().__init__(
            style=discord.ButtonStyle.secondary,
            label=f"🎉 Katıl ({count})",
            custom_id="giveaway_join_btn"
        )

    async def callback(self, interaction: discord.Interaction):
        giveaways = load_giveaways()
        msg_id_str = str(interaction.message.id)
        gw = giveaways.get(msg_id_str)
        if not gw:
            await interaction.response.send_message("Bu çekiliş kaydı bulunamadı.", ephemeral=True)
            return

        if gw.get("ended", False):
            await interaction.response.send_message("Bu çekiliş sona ermiştir.", ephemeral=True)
            return

        user_id = interaction.user.id
        participants = gw.get("participants", [])
        vip_role_id = config.get("vip_rol_id", 0)
        has_vip = False
        if isinstance(interaction.user, discord.Member) and vip_role_id:
            has_vip = any(r.id == int(vip_role_id) for r in interaction.user.roles)

        if user_id in participants:
            participants.remove(user_id)
            gw["participants"] = participants
            save_giveaways(giveaways)
            self.label = f"🎉 Katıl ({len(participants)})"
            await interaction.response.edit_message(view=self.view)
            await interaction.followup.send("Çekiliş katılımın iptal edildi.", ephemeral=True)
        else:
            participants.append(user_id)
            gw["participants"] = participants
            save_giveaways(giveaways)
            self.label = f"🎉 Katıl ({len(participants)})"
            await interaction.response.edit_message(view=self.view)
            if has_vip and gw.get("vip_multiplier", True):
                await interaction.followup.send(
                    "VIP rolüne sahip olduğun için çekilişte **2 Kat (+2x)** kazanma şansın tanımlandı!",
                    ephemeral=True
                )
            else:
                await interaction.followup.send("Çekilişe başarıyla katıldın! Bol şans dileriz 🎉", ephemeral=True)

class GiveawayView(discord.ui.View):
    def __init__(self, count: int = 0):
        super().__init__(timeout=None)
        self.add_item(GiveawayJoinButton(count=count))

async def grant_vip_to_winners(guild: discord.Guild, winners: list[int], prize: str) -> list[int]:
    """Kazanan üyelere VIP rolünü (0) otomatik olarak tanımlar."""
    vip_role_id = config.get("vip_rol_id", 0)
    if not vip_role_id or not guild:
        return []
    role = guild.get_role(int(vip_role_id))
    if not role:
        return []

    granted = []
    for w_id in winners:
        member = guild.get_member(w_id)
        if not member:
            try:
                member = await guild.fetch_member(w_id)
            except Exception:
                member = None
        if member and not member.bot:
            try:
                if role not in member.roles:
                    await member.add_roles(role, reason=f"VIP Çekilişi Kazanıldı: {prize}")
                    print(f"[Çekiliş Otomatik VIP] {member.display_name} üyesine kazandığı VIP rolü verildi.", flush=True)
                granted.append(w_id)
            except Exception as e:
                print(f"[Çekiliş VIP Verme Hatası]: {e}", flush=True)
    return granted

async def finish_giveaway(message_id: int):
    giveaways = load_giveaways()
    msg_id_str = str(message_id)
    gw = giveaways.get(msg_id_str)
    if not gw or gw.get("ended", False):
        return

    gw["ended"] = True
    save_giveaways(giveaways)

    channel_id = gw.get("channel_id")
    channel = bot.get_channel(channel_id)
    if not channel:
        try:
            channel = await bot.fetch_channel(channel_id)
        except Exception:
            return

    try:
        message = await channel.fetch_message(message_id)
    except Exception:
        return

    participants = gw.get("participants", [])
    winners_count = gw.get("winners_count", 1)
    prize = gw.get("prize", "Ödül")
    vip_multiplier = gw.get("vip_multiplier", True)
    vip_role_id = config.get("vip_rol_id", 0)
    guild = channel.guild

    unique_participants = list(set(participants))
    winners = []

    if unique_participants:
        pool = []
        for uid in unique_participants:
            weight = 1
            if vip_multiplier and vip_role_id:
                m = guild.get_member(uid)
                if m and any(r.id == int(vip_role_id) for r in m.roles):
                    weight = config.get("giveaway_vip_carpan", 2)
            pool.extend([uid] * weight)

        needed_winners = min(winners_count, len(unique_participants))
        chosen_set = set()
        while len(chosen_set) < needed_winners and pool:
            pick = random.choice(pool)
            chosen_set.add(pick)
            pool = [x for x in pool if x != pick]
        winners = list(chosen_set)

    # Otomatik VIP Kontrolü & Verme
    is_vip_reward = gw.get("auto_give_vip", False) or ("vip" in prize.lower())
    vip_granted_list = []
    if is_vip_reward and winners:
        vip_granted_list = await grant_vip_to_winners(guild, winners, prize)

    gw["winners"] = winners
    gw["vip_granted"] = vip_granted_list
    save_giveaways(giveaways)

    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    winner_mentions = ", ".join(f"<@{w}>" for w in winners) if winners else "Katılımcı bulunamadı."
    vip_line = "\n› **Otomatik Teslim:** Kazanan üyeye **VIP rolü** otomatik tanımlandı." if (is_vip_reward and winners) else ""

    embed = discord.Embed(
        title=f"{bot_name} ✦ ÇEKİLİŞ SONA ERDİ 🎉",
        description=(
            f"> **{prize}** çekilişi başarıyla sonuçlandı!\n\n"
            f"**Ödül:** **{prize}**\n"
            f"**Kazanan(lar):** {winner_mentions}\n"
            f"**Toplam Katılımcı:** `{len(unique_participants)}` üye\n"
            f"**VIP 2x Şans:** {'Aktif' if vip_multiplier else 'Kapalı'}"
            f"{vip_line}\n"
            f"**Bitiş:** <t:{int(datetime.now(timezone.utc).timestamp())}:F>"
        ),
        color=0x2ecc71 if winners else 0x95a5a6,
        timestamp=datetime.now(timezone.utc)
    )
    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_thumbnail(url=logo)
        embed.set_footer(text=f"{bot_name} • Çekiliş Sistemi", icon_url=logo)

    ended_view = discord.ui.View(timeout=None)
    btn = discord.ui.Button(
        style=discord.ButtonStyle.secondary,
        label=f"🎉 Çekiliş Bitti ({len(unique_participants)})",
        disabled=True,
        custom_id="giveaway_ended_btn"
    )
    ended_view.add_item(btn)

    try:
        await message.edit(embed=embed, view=ended_view)
    except Exception:
        pass

    if winners:
        extra_channel_msg = "\nVIP rolünüz hesabınıza otomatik olarak tanımlandı." if is_vip_reward else ""
        await channel.send(f"🎉 **Tebrikler {winner_mentions}!** **{prize}** çekilişini kazandınız! 🎉{extra_channel_msg}")
        for w_id in winners:
            m = guild.get_member(w_id)
            if m:
                try:
                    dm_desc = (
                        f"Selam {m.mention}!\n\n"
                        f"**{guild.name}** sunucumuzda düzenlenen **{prize}** çekilişini kazandın!\n\n"
                        f"› **Ödül:** **{prize}**\n"
                    )
                    if is_vip_reward:
                        dm_desc += f"› **Rol:** **VIP** rolün hesabına **otomatik olarak tanımlandı!** VIP odalara ve ayrıcalıklara hemen erişebilirsin.\n\n"
                    else:
                        dm_desc += f"› Ödülünü almak için lütfen sunucu yetkilileriyle iletişime geç.\n\n"
                    dm_desc += f"› **Çekiliş Mesajı:** [Tıkla ve Git]({message.jump_url})"

                    dm_embed = discord.Embed(
                        title=f"🎉 Çekiliş Kazandın! ✦ {guild.name}",
                        description=dm_desc,
                        color=0xf1c40f,
                        timestamp=datetime.now(timezone.utc)
                    )
                    if logo:
                        dm_embed.set_thumbnail(url=logo)
                    await m.send(embed=dm_embed)
                except Exception:
                    pass
    else:
        await channel.send(f"**{prize}** çekilişine yeterli katılım olmadığı için kazanan belirlenemedi.")

# ─────────────────────────────────────────────
# ARKA PLAN GÖREVLERİ: ÇEKİLİŞ SAYAÇ & SES XP
# ─────────────────────────────────────────────
@tasks.loop(seconds=10)
async def giveaway_checker():
    """Süresi dolan çekilişleri otomatik kontrol eder ve bitirir."""
    await bot.wait_until_ready()
    giveaways = load_giveaways()
    now_ts = int(datetime.now(timezone.utc).timestamp())
    for msg_id_str, gw in list(giveaways.items()):
        if not gw.get("ended", False):
            end_ts = gw.get("end_timestamp", 0)
            if now_ts >= end_ts:
                try:
                    await finish_giveaway(int(msg_id_str))
                except Exception as e:
                    print(f"[Çekiliş Bitirme Hatası {msg_id_str}]: {e}", flush=True)

@tasks.loop(seconds=60)
async def voice_xp_updater():
    """Her 60 saniyede seste olan üyelere ses süresi ve XP ekler."""
    await bot.wait_until_ready()
    stats = load_stats()
    changed = False

    for guild in bot.guilds:
        for vc in guild.voice_channels:
            if guild.afk_channel and vc.id == guild.afk_channel.id:
                continue

            members = [m for m in vc.members if not m.bot]
            if not members:
                continue

            for m in members:
                # Kulaklığı kapalı ve odada tek başınaysa süre sayma
                if m.voice and m.voice.self_deaf and len(members) == 1:
                    continue

                u_id = str(m.id)
                if u_id not in stats:
                    stats[u_id] = {
                        "voice_seconds": 0,
                        "messages": 0,
                        "xp": 0,
                        "level": 1,
                        "last_xp_time": 0
                    }

                stats[u_id]["voice_seconds"] = stats[u_id].get("voice_seconds", 0) + 60
                old_xp = stats[u_id].get("xp", 0)
                new_xp = old_xp + 5
                stats[u_id]["xp"] = new_xp

                old_lvl = stats[u_id].get("level", 1)
                new_lvl = get_level_from_xp(new_xp)
                if new_lvl > old_lvl:
                    stats[u_id]["level"] = new_lvl
                    try:
                        bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
                        lvl_embed = discord.Embed(
                            title=f"{bot_name} ✦ SEVİYE ATLADIN",
                            description=f"Tebrikler {m.mention}! Seste vakit geçirerek **Seviye {new_lvl}** oldun!",
                            color=0xf1c40f
                        )
                        await m.send(embed=lvl_embed)
                    except Exception:
                        pass

                changed = True

    if changed:
        save_stats(stats)

# ─────────────────────────────────────────────
# ON_READY & SENKRONİZASYON
# ─────────────────────────────────────────────
@bot.event
async def on_ready():
    bot_name = str(bot.user) if bot.user else "IMZA Hosgeldin Botu"
    banner = f"""
    ╔══════════════════════════════════════════════════════════╗
    ║                     {config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}                          ║
    ║           Priv Hoş Geldin & Otorol Botu                  ║
    ╠══════════════════════════════════════════════════════════╣
    ║  Bot İsmi: {bot_name:<45} ║
    ║  Sunucu:   {len(bot.guilds):<45} ║
    ║  Otorol:   {str(config.get('otorol_id')):<45} ║
    ╚══════════════════════════════════════════════════════════╝
    """
    print(banner, flush=True)

    # Kalıcı çekiliş buton view'ini kaydet
    bot.add_view(GiveawayView())

    # Slash komutlarını senkronize et
    try:
        synced = await bot.tree.sync()
        print(f"[Slash] {len(synced)} slash komutu başarıyla senkronize edildi.", flush=True)
        for cmd in synced:
            print(f" └ /{cmd.name} -> {cmd.description}", flush=True)
    except Exception as e:
        print(f"[Slash Hata]: {e}", flush=True)

    # Arka plan görevlerini başlat
    if not keep_voice_connection.is_running():
        keep_voice_connection.start()
    if not presence_rotation.is_running():
        presence_rotation.start()
    if not giveaway_checker.is_running():
        giveaway_checker.start()
    if not voice_xp_updater.is_running():
        voice_xp_updater.start()

    # İlk yayın durumu
    bot_adi = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    stream_url = config.get("stream_url", "https://www.twitch.tv/imzapriw")
    try:
        await bot.change_presence(activity=discord.Streaming(name=f"Hoş Geldin & Otorol | {bot_adi}", url=stream_url))
    except Exception as e:
        print(f"[Presence Hata]: {e}", flush=True)

    # Otorol hiyerarşi uyarısı kontrolü
    otorol_id = config.get("otorol_id")
    for guild in bot.guilds:
        if otorol_id:
            role = guild.get_role(int(otorol_id))
            if role and guild.me.top_role <= role:
                print(f"\n[DİKKAT!] Botun en yüksek rolü ('{guild.me.top_role.name}'), Otorol olan ('{role.name}') rolünden AŞAĞIDA!", flush=True)
                print("Lütfen Discord Sunucu Ayarları > Roller kısmından botun rolünü 'Member' rolünün ÜSTÜNE sürükleyin!\n", flush=True)

# ─────────────────────────────────────────────
# SLASH KOMUTLARI
# ─────────────────────────────────────────────

# 1. /hg-kur (Yönetici)
@bot.tree.command(name="hg-kur", description="Sunucuya otomatik hoş geldin kanalını açar ve ayarlar.")
@app_commands.default_permissions(administrator=True)
async def slash_hg_kur(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild

    try:
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=True, send_messages=False, read_message_history=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, embed_links=True, attach_files=True)
        }

        channel = await guild.create_text_channel(
            name="hoş-geldin",
            overwrites=overwrites,
            reason="IMZA Hoşgeldin kanalı oluşturuldu."
        )

        config["hosgeldin_kanal_id"] = channel.id
        save_config(config)

        # Bilgilendirme embedi at
        info_embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ✦ HOŞ GELDİN KANALI",
            description=(
                "> **Bu kanal sunucumuza yeni katılan üyelerin karşılanması için ayarlanmıştır.**\n\n"
                "› Yeni katılan tüm üyelere otomatik olarak **Member** rolü tanımlanır.\n"
                "› Sunucu kurallarına uyarak aramıza katılabilirsiniz!\n\n"
                "**Priv Ailesi:** `discord.gg/imzapriw`"
            ),
            color=get_embed_color(),
            timestamp=datetime.now(timezone.utc)
        )
        logo = get_brand_logo_url(guild)
        if logo:
            info_embed.set_thumbnail(url=logo)
        info_embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Welcome Interface")

        await channel.send(embed=info_embed)

        await interaction.followup.send(
            f"**Hoş geldin kanalı başarıyla oluşturuldu ve sabitlendi:** {channel.mention}\n"
            f"Gelen üyelere otomatik olarak `{config.get('otorol_id')}` ID'li rol verilecek.",
            ephemeral=True
        )
    except Exception as e:
        await interaction.followup.send(f"Kanal oluşturulurken hata: {e}", ephemeral=True)

# 2. /hg-kanal-ayarla (Yönetici)
@bot.tree.command(name="hg-kanal-ayarla", description="Hoş geldin mesajlarının gönderileceği kanalı belirler.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kanal="Hoş geldin mesajlarının atılacağı metin kanalı")
async def slash_hg_kanal_ayarla(interaction: discord.Interaction, kanal: discord.TextChannel):
    config["hosgeldin_kanal_id"] = kanal.id
    save_config(config)
    await interaction.response.send_message(
        f"**Hoş geldin kanalı başarıyla ayarlandı:** {kanal.mention}",
        ephemeral=True
    )

# 3. /otorol-ayarla (Yönetici)
@bot.tree.command(name="otorol-ayarla", description="Sunucuya yeni girenlere otomatik verilecek rolü ayarlar.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(rol="Otomatik verilecek üye rolü")
async def slash_otorol_ayarla(interaction: discord.Interaction, rol: discord.Role):
    if interaction.guild.me.top_role <= rol:
        await interaction.response.send_message(
            f"**Dikkat:** Botun rolü (`{interaction.guild.me.top_role.name}`), vermek istediğin `{rol.name}` rolünün altında veya eşit!\n"
            "Botun bu rolü üyelere verebilmesi için lütfen Sunucu Ayarları > Roller kısmından botun rolünü bu rolün üstüne taşı.",
            ephemeral=True
        )
        return

    config["otorol_id"] = rol.id
    save_config(config)
    await interaction.response.send_message(
        f"**Otorol başarıyla güncellendi:** {rol.mention} (`{rol.id}`)\n"
        f"Artık sunucuya yeni giren herkese bu rol otomatik verilecektir.",
        ephemeral=True
    )

# 4. /otorol-tara (Yönetici)
@bot.tree.command(name="otorol-tara", description="Sunucuda otorolü bulunmayan mevcut tüm üyelere topluca rolü verir.")
@app_commands.default_permissions(administrator=True)
async def slash_otorol_tara(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild

    role_id = config.get("otorol_id", 0)
    role = guild.get_role(int(role_id))
    if not role:
        await interaction.followup.send("Otorol bulunamadı! Lütfen önce `/otorol-ayarla` ile rol seçin.", ephemeral=True)
        return

    if guild.me.top_role <= role:
        await interaction.followup.send(
            f"**Yetki Hatası:** Botun rolü (`{guild.me.top_role.name}`), `{role.name}` rolünün altında!\n"
            "Lütfen Sunucu Ayarları > Roller bölümünden botun rolünü yukarı taşıyın.",
            ephemeral=True
        )
        return

    given_count = 0
    already_have = 0

    for m in guild.members:
        if not m.bot:
            if role not in m.roles:
                try:
                    await m.add_roles(role, reason="Toplu otorol taraması")
                    given_count += 1
                    await asyncio.sleep(0.3)
                except Exception:
                    pass
            else:
                already_have += 1

    await interaction.followup.send(
        f"**Otorol Taraması Tamamlandı!**\n\n"
        f"› **Rol:** {role.mention}\n"
        f"› **Yeni Verilen:** `{given_count}` üye\n"
        f"› **Zaten Sahip Olan:** `{already_have}` üye",
        ephemeral=True
    )

# 5. /hg-test (Yönetici)
@bot.tree.command(name="hg-test", description="Hoş geldin karşılama görsel kartını kendi üzerinde test eder.")
@app_commands.default_permissions(administrator=True)
async def slash_hg_test(interaction: discord.Interaction):
    await interaction.response.defer()
    try:
        card_file = await get_welcome_card_file(interaction.user)
        await interaction.followup.send(
            content=interaction.user.mention,
            file=card_file
        )
    except Exception as e:
        await interaction.followup.send(f"Görsel kart oluşturulurken hata oluştu: {e}", ephemeral=True)

# 6. /ayrilan-test (Yönetici)
@bot.tree.command(name="ayrilan-test", description="Ayrılma (Görüşürüz) görsel kartını kendi üzerinde test eder.")
@app_commands.default_permissions(administrator=True)
async def slash_ayrilan_test(interaction: discord.Interaction):
    await interaction.response.defer()
    try:
        card_file = await get_leave_card_file(interaction.user)
        await interaction.followup.send(
            file=card_file
        )
    except Exception as e:
        await interaction.followup.send(f"Görsel kart oluşturulurken hata oluştu: {e}", ephemeral=True)

# 6. /yardim
@bot.tree.command(name="yardim", description="Botun tüm slash komutlarını ve özelliklerini gösterir.")
async def slash_yardim(interaction: discord.Interaction):
    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ┊ Komut & Sistem Kılavuzu",
        description="Hoş Geldin, Otorol, VIP, Çekiliş ve Profil/Aktiflik Sistemleri.\n",
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )

    embed.add_field(
        name="Hoş Geldin & Otorol",
        value=(
            "`/hg-kur` ➔ Otomatik hoş geldin kanalı oluşturur ve yapılandırır.\n"
            "`/hg-kanal-ayarla [kanal]` ➔ Karşılama mesajlarının kanalını seçer.\n"
            "`/otorol-ayarla [rol]` ➔ Yeni girenlere verilecek otorolü ayarlar.\n"
            "`/otorol-tara` ➔ Rolü olmayan tüm mevcut üyelere topluca rol verir.\n"
            "`/hg-test` ➔ Karşılama mesajını kendi üzerinde test eder.\n"
            "`/ayrilan-test` ➔ Ayrılma veda mesajını kendi üzerinde test eder.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="VIP & Booster Ayrıcalıkları",
        value=(
            "`/nick [isim]` ➔ VIP ve Booster üyelerin kendi isimlerini değiştirmesini sağlar.\n"
            "`/vip [kullanıcı] (sebep)` ➔ Belirtilen üyeye VIP rolü tanımlar.\n"
            "`/vip-al [kullanıcı] (sebep)` ➔ Belirtilen üyeden VIP rolünü geri çeker.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="Çekiliş & Drop Sistemi",
        value=(
            "`/cekilis-baslat [süre] [kazanan] [ödül] (kanal) (vip_avantaj)`\n"
            "└ Kalıcı butonlu ve dinamik sayaçlı lüks çekiliş başlatır.\n"
            "`/cekilis-bitir [mesaj_id]` ➔ Çekilişi anında sonlandırır.\n"
            "`/cekilis-yenile [mesaj_id]` ➔ Çekilişten yeni kazanan seçer (Reroll).\n"
            "`/cekilis-iptal [mesaj_id]` ➔ Çekilişi iptal eder.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="Profil, Seviye & Aktiflik (Rank)",
        value=(
            "`/profil [kullanıcı]` ➔ Seviye, XP çubuğu, ses süresi ve mesaj istatistik kartı.\n"
            "`/top-ses` ➔ Seste en çok vakit geçiren ilk 10 üyenin sıralaması.\n"
            "`/top-chat` ➔ En çok mesaj atan ilk 10 üyenin sıralaması.\n"
            "`/top-seviye` ➔ En yüksek seviye ve XP'ye sahip ilk 10 üye.\n"
            "`/xp-ver [kullanıcı] [miktar]` ➔ *(Yönetici)* Kullanıcıya XP ödülü verir.\n"
            "`/xp-al [kullanıcı] [miktar]` ➔ *(Yönetici)* Kullanıcıdan XP düşer.\n"
            "`/istatistik-sifirla [kullanıcı]` ➔ *(Yönetici)* Üyenin verilerini sıfırlar.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="Güvenlik & Moderasyon",
        value=(
            "`/kufur-engel [acik/kapali]` ➔ Küfür ve argo korumasını açar veya kapatır.\n"
            "`/spam-engel [acik/kapali]` ➔ Spam ve flood korumasını açar veya kapatır.\n"
            "`/reklam-engel [acik/kapali]` ➔ Link/reklam korumasını açar veya kapatır (GIF hariç).\n"
            "`/koruma-durum` ➔ Aktif koruma filtrelerini ve ceza ayarlarını gösterir.\n"
            "`/kufur-ekle [kelime]` ➔ Özel yasaklı kelime ekler.\n"
            "`/kufur-sil [kelime]` ➔ Özel yasaklı kelimeyi listeden siler.\n"
            "`/kufur-liste` ➔ Özel yasaklı kelimeleri listeler.\n"
            "`/mod-log-ayarla [kanal]` ➔ Güvenlik log kanalını belirler.\n"
            "`/rol-log-ayarla [kanal]` ➔ Sağ tık rol denetim log kanalını belirler.\n"
            "`/mute [kullanıcı] [dakika]` ➔ Üyeyi belirtilen süre susturur (Timeout).\n"
            "`/unmute [kullanıcı]` ➔ Üyenin susturmasını kaldırır.\n"
            "`/ban [kullanıcı] (sebep)` ➔ Üyeyi sunucudan yasaklar (Ban).\n"
            "`/unban [kullanıcı_id] (sebep)` ➔ Yasaklı üyenin banını kaldırır (Unban).\n"
            "`/snipe (kullanıcı)` ➔ Bu kanalda silinen en son mesajı gösterir.\n"
        ),
        inline=False
    )

    embed.add_field(
        name="Guard Koruma (Kanal & Yetki Çekme)",
        value=(
            "`/guard-kanal [durum]` ➔ Kanal açma/silme korumasını açar veya kapatır.\n"
            "`/guard-ekle [kullanıcı/rol]` ➔ Güvenli listeye (whitelist) kullanıcı/rol ekler.\n"
            "`/guard-cikar [kullanıcı/rol]` ➔ Güvenli listeden kullanıcı/rol çıkarır.\n"
            "`/guard-liste` ➔ Whitelistteki yetkilileri ve aktif uyarıları listeler.\n"
            "`/guard-uyari-sifirla [kullanıcı]` ➔ Bir yetkilinin ihlal uyarısını sıfırlar.\n"
            "`/guard-durum` ➔ Guard koruma durumunu ve panel ayarlarını gösterir.\n"
        ),
        inline=False
    )

    otorol_id = config.get("otorol_id", 0)
    role_mention = f"<@&{otorol_id}>" if otorol_id else "`Ayarlanmadı`"
    vip_id = config.get("vip_rol_id", 0)
    vip_mention = f"<@&{vip_id}>" if vip_id else "`Ayarlanmadı`"
    booster_id = config.get("booster_rol_id", 0)
    booster_mention = f"<@&{booster_id}>" if booster_id else "`Ayarlanmadı`"
    hg_ch_id = config.get("hosgeldin_kanal_id")
    ch_mention = f"<#{hg_ch_id}>" if hg_ch_id else "`Otomatik / Ayarlanmadı`"
    kufur_durum = "Aktif" if config.get("kufur_engel", True) else "Kapalı"
    spam_durum = "Aktif" if config.get("spam_engel", True) else "Kapalı"

    embed.add_field(
        name="Aktif Ayarlar",
        value=(
            f"› **Aktif Otorol:** {role_mention}\n"
            f"› **VIP Rolü:** {vip_mention} *(Çekilişlerde 2x Şans & /nick)*\n"
            f"› **Booster Rolü:** {booster_mention} *(/nick Yetkisi)*\n"
            f"› **Küfür Koruması:** `{kufur_durum}`\n"
            f"› **Spam Koruması:** `{spam_durum}`\n"
            f"› **Hoş Geldin Kanalı:** {ch_mention}\n"
            f"› **Sabit Ses:** <#{config.get('sabit_ses_kanal_id', 0)}>\n"
            f"› **Durum:** Mor Rozet (Yayında - Twitch)"
        ),
        inline=False
    )

    logo = get_brand_logo_url(interaction.guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Priv Multi-System")
    await interaction.response.send_message(embed=embed, ephemeral=True)

# 7. /vip (Yönetici & Rol Yönetme Yetkisi)
@bot.tree.command(name="vip", description="Belirtilen üyeye VIP rolünü verir veya varsa geri alır.")
@app_commands.default_permissions(manage_roles=True)
@app_commands.describe(
    kullanıcı="VIP rolü verilecek veya alınacak üye",
    sebep="İşlem açıklaması / sebebi (İsteğe bağlı)"
)
async def slash_vip(interaction: discord.Interaction, kullanıcı: discord.Member, sebep: str = "Belirtilmedi"):
    guild = interaction.guild
    vip_role_id = config.get("vip_rol_id", 0)
    role = guild.get_role(int(vip_role_id))

    if not role:
        await interaction.response.send_message(f"VIP rolü sunucuda bulunamadı! (ID: `{vip_role_id}`)", ephemeral=True)
        return

    if guild.me.top_role <= role:
        await interaction.response.send_message(
            f"Yetki Hatası: Botun en yüksek rolü (`{guild.me.top_role.name}`), VIP rolü (`{role.name}`) altında veya eşit!\n"
            "Lütfen Sunucu Ayarları > Roller bölümünden botun rolünü VIP rolünün üstüne sürükleyin.",
            ephemeral=True
        )
        return

    if kullanıcı.bot:
        await interaction.response.send_message("Botlara VIP rolü verilemez.", ephemeral=True)
        return

    # Durumu kontrol et (Var mı, yok mu?)
    has_vip = role in kullanıcı.roles

    if has_vip:
        await interaction.response.send_message(
            f"{kullanıcı.mention} zaten **{role.name}** rolüne sahip!\n"
            f"Rolü geri almak için **`/vip-al`** komutunu kullanabilirsin.",
            ephemeral=True
        )
        return

    # VIP'yi ver
    try:
        await kullanıcı.add_roles(role, reason=f"VIP Verildi: {interaction.user.display_name} | Sebep: {sebep}")
        embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ✦ VIP ROLÜ TANIMLANDI",
            description=(
                f"> {kullanıcı.mention} kullanıcısına VIP ayrıcalıkları başarıyla tanımlandı.\n\n"
                f"› **Kullanıcı:** {kullanıcı.mention} (`{kullanıcı.id}`)\n"
                f"› **İşlemi Yapan:** {interaction.user.mention}\n"
                f"› **Verilen Rol:** {role.mention}\n"
                f"› **Sebep:** `{sebep}`"
            ),
            color=0xf1c40f,
            timestamp=datetime.now(timezone.utc)
        )
        if kullanıcı.display_avatar:
            embed.set_thumbnail(url=kullanıcı.display_avatar.url)
        logo = get_brand_logo_url(guild)
        if logo:
            embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • VIP Yönetimi", icon_url=logo)
        await interaction.response.send_message(embed=embed)
        print(f"[VIP] + {interaction.user.display_name} tarafından {kullanıcı.display_name} üyesine VIP rolü verildi.", flush=True)

        # Kullanıcıya DM tebrik bildirimi (İsteğe bağlı)
        try:
            dm_embed = discord.Embed(
                title=f"VIP Rolün Tanımlandı ✦ {guild.name}",
                description=(
                    f"Tebrikler {kullanıcı.mention}!\n\n"
                    f"**{guild.name}** sunucumuzda sana özel **{role.name}** rolü tanımlandı.\n"
                    f"Ayrıcalıkların ve VIP odalara erişimin keyfini çıkar!\n\n"
                    f"› **Veren Yetkili:** {interaction.user.display_name}\n"
                    f"› **Sebep:** `{sebep}`"
                ),
                color=0xf1c40f,
                timestamp=datetime.now(timezone.utc)
            )
            if logo:
                dm_embed.set_thumbnail(url=logo)
            await kullanıcı.send(embed=dm_embed)
        except Exception:
            pass
    except Exception as e:
        await interaction.response.send_message(f"VIP rolü verilirken bir hata oluştu: {e}", ephemeral=True)

# 8. /vip-al (Yönetici & Rol Yönetme Yetkisi)
@bot.tree.command(name="vip-al", description="Belirtilen üyeden VIP rolünü geri alır.")
@app_commands.default_permissions(manage_roles=True)
@app_commands.describe(
    kullanıcı="VIP rolü alınacak üye",
    sebep="Rol alma sebebi (İsteğe bağlı)"
)
async def slash_vip_al(interaction: discord.Interaction, kullanıcı: discord.Member, sebep: str = "Belirtilmedi"):
    guild = interaction.guild
    vip_role_id = config.get("vip_rol_id", 0)
    role = guild.get_role(int(vip_role_id))

    if not role:
        await interaction.response.send_message(f"VIP rolü sunucuda bulunamadı! (ID: `{vip_role_id}`)", ephemeral=True)
        return

    if guild.me.top_role <= role:
        await interaction.response.send_message(
            f"Yetki Hatası: Botun en yüksek rolü (`{guild.me.top_role.name}`), VIP rolü (`{role.name}`) altında veya eşit!\n"
            "Lütfen Sunucu Ayarları > Roller bölümünden botun rolünü VIP rolünün üstüne sürükleyin.",
            ephemeral=True
        )
        return

    if role not in kullanıcı.roles:
        await interaction.response.send_message(f"{kullanıcı.mention} kullanıcısında zaten **{role.name}** rolü bulunmuyor!", ephemeral=True)
        return

    try:
        await kullanıcı.remove_roles(role, reason=f"VIP Alındı: {interaction.user.display_name} | Sebep: {sebep}")
        embed = discord.Embed(
            title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} ✦ VIP ROLÜ ALINDI",
            description=(
                f"> {kullanıcı.mention} kullanıcısından VIP ayrıcalıkları başarıyla geri alındı.\n\n"
                f"› **Kullanıcı:** {kullanıcı.mention} (`{kullanıcı.id}`)\n"
                f"› **Yetkili:** {interaction.user.mention}\n"
                f"› **Geri Alınan Rol:** {role.mention}\n"
                f"› **Sebep:** `{sebep}`"
            ),
            color=0xed4245,
            timestamp=datetime.now(timezone.utc)
        )
        if kullanıcı.display_avatar:
            embed.set_thumbnail(url=kullanıcı.display_avatar.url)
        logo = get_brand_logo_url(guild)
        if logo:
            embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • VIP Yönetimi", icon_url=logo)
        await interaction.response.send_message(embed=embed)
        print(f"[VIP AL] - {interaction.user.display_name} tarafından {kullanıcı.display_name} üyesinden VIP rolü alındı.", flush=True)

        # Kullanıcıya DM bilgilendirme (İsteğe bağlı)
        try:
            dm_embed = discord.Embed(
                title=f"VIP Rolün Geri Alındı ✦ {guild.name}",
                description=(
                    f"Merhaba {kullanıcı.mention},\n\n"
                    f"**{guild.name}** sunucusundaki **{role.name}** rolün yetkili tarafından geri alındı.\n\n"
                    f"› **İşlemi Yapan:** {interaction.user.display_name}\n"
                    f"› **Sebep:** `{sebep}`"
                ),
                color=0xed4245,
                timestamp=datetime.now(timezone.utc)
            )
            if logo:
                dm_embed.set_thumbnail(url=logo)
            await kullanıcı.send(embed=dm_embed)
        except Exception:
            pass
    except Exception as e:
        await interaction.response.send_message(f"VIP rolü alınırken bir hata oluştu: {e}", ephemeral=True)

# 9. /nick (VIP & Booster Özel İsim Değiştirme)
@bot.tree.command(name="nick", description="VIP ve Booster üyelerin kendi isimlerini değiştirmesini sağlar.")
@app_commands.describe(
    isim="Yeni takma adınız (Sıfırlamak için boş bırakabilir veya 'sıfırla' yazabilirsiniz)",
    kullanıcı="Takma adı değiştirilecek üye (Yalnızca yetkililer başka üyeyi belirtebilir)"
)
async def slash_nick(interaction: discord.Interaction, isim: str = None, kullanıcı: discord.Member = None):
    guild = interaction.guild
    target = kullanıcı or interaction.user

    # Başka bir kullanıcının ismini değiştiriyorsa yetki kontrolü
    if target != interaction.user:
        has_manage = interaction.user.guild_permissions.manage_nicknames or interaction.user.guild_permissions.administrator
        if not has_manage:
            await interaction.response.send_message(
                "Başka bir üyenin takma adını değiştirmek için 'Kullanıcı Adlarını Yönet' yetkisine sahip olmalısınız.",
                ephemeral=True
            )
            return
    else:
        # Kendi ismini değiştiriyorsa VIP veya Booster kontrolü
        vip_role_id = config.get("vip_rol_id", 0)
        booster_role_id = config.get("booster_rol_id", 0)

        is_vip = vip_role_id and any(r.id == int(vip_role_id) for r in interaction.user.roles)
        is_booster = (booster_role_id and any(r.id == int(booster_role_id) for r in interaction.user.roles)) or (interaction.user.premium_since is not None)
        is_admin = interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_nicknames

        if not (is_vip or is_booster or is_admin):
            await interaction.response.send_message(
                "Bu komutu yalnızca **VIP** veya **Server Booster (Takviyeci)** üyeler kullanabilir.\n"
                "Ayrıcalıklardan faydalanmak için sunucuya takviye basabilir veya VIP edinebilirsiniz.",
                ephemeral=True
            )
            return

    # İsim uzunluğu ve sıfırlama kontrolü
    if isim:
        isim = isim.strip()
        if isim.lower() in ("sıfırla", "reset", "none", "yok", "temizle"):
            isim = None
        elif len(isim) > 32:
            await interaction.response.send_message(
                "Takma ad Discord sınırları gereği en fazla 32 karakter olabilir.",
                ephemeral=True
            )
            return
    else:
        isim = None

    # Sunucu sahibi kontrolü
    if target == guild.owner:
        await interaction.response.send_message(
            "Sunucu sahibinin takma adı Discord güvenlik protokolleri nedeniyle botlar tarafından değiştirilemez.",
            ephemeral=True
        )
        return

    # Rol hiyerarşisi kontrolü
    if guild.me.top_role <= target.top_role and target != guild.me:
        await interaction.response.send_message(
            f"Yetki Hatası: Botun en yüksek rolü (`{guild.me.top_role.name}`), {target.mention} üyesinin rolünün (`{target.top_role.name}`) altında veya eşit olduğu için işlem yapılamıyor.\n"
            "Lütfen Sunucu Ayarları > Roller bölümünden botun rolünü yukarı taşıyın.",
            ephemeral=True
        )
        return

    # Botun yetki kontrolü
    if not guild.me.guild_permissions.manage_nicknames:
        await interaction.response.send_message(
            "Yetki Hatası: Botun sunucuda 'Kullanıcı Adlarını Yönet' (Manage Nicknames) yetkisi bulunmuyor!",
            ephemeral=True
        )
        return

    old_name = target.display_name
    try:
        await target.edit(nick=isim, reason=f"/nick komutu: {interaction.user.display_name} ({interaction.user.id})")
        new_name = target.display_name if isim else target.name

        bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
        embed = discord.Embed(
            title=f"{bot_name} ✦ TAKMA AD GÜNCELLENDİ",
            description=(
                f"> {target.mention} kullanıcısının sunucu takma adı başarıyla güncellendi.\n\n"
                f"› **Kullanıcı:** {target.mention} (`{target.id}`)\n"
                f"› **Eski İsim:** `{old_name}`\n"
                f"› **Yeni İsim:** `{new_name}`\n"
                f"› **İşlemi Yapan:** {interaction.user.mention}\n"
                f"› **Durum:** {'İsim Değiştirildi' if isim else 'İsim Orijinale Sıfırlandı'}"
            ),
            color=get_embed_color(),
            timestamp=datetime.now(timezone.utc)
        )
        if target.display_avatar:
            embed.set_thumbnail(url=target.display_avatar.url)
        logo = get_brand_logo_url(guild)
        if logo:
            embed.set_footer(text=f"{bot_name} • Priv Nickname Management", icon_url=logo)
        else:
            embed.set_footer(text=f"{bot_name} • Priv Nickname Management")

        await interaction.response.send_message(embed=embed)
        print(f"[NICK] {interaction.user.display_name} -> {target.display_name} takma adı '{old_name}' -> '{new_name}' olarak değiştirildi.", flush=True)

    except discord.Forbidden:
        await interaction.response.send_message(
            "Discord API Yetki Hatası (403): Bot bu üyenin ismini değiştiremedi. Botun rolünün kullanıcının en yüksek rolünden yukarıda olduğundan emin olun.",
            ephemeral=True
        )
    except Exception as e:
        await interaction.response.send_message(f"Takma ad değiştirilirken bir hata oluştu: {e}", ephemeral=True)

# 10. /cekilis-baslat (Yönetici)
@bot.tree.command(name="cekilis-baslat", description="Sunucuda lüks butonlu ve sayaçlı çekiliş başlatır.")
@app_commands.default_permissions(manage_guild=True)
@app_commands.describe(
    sure="Çekiliş süresi (Örn: 10m, 1h, 24h, 3d, 30s)",
    kazanan="Kazanacak üye sayısı (Varsayılan: 1)",
    odul="Verilecek ödül (Örn: VIP Rolü, Discord Nitro)",
    kanal="Çekilişin yapılacağı kanal (İsteğe bağlı)",
    vip_avantaj="VIP üyeler için +2x kazanma şansı aktif olsun mu? (Varsayılan: Evet)",
    otomatik_vip="Kazanan üyeye VIP rolü otomatik verilsin mi? (Ödül adında VIP geçiyorsa otomatik algılar)"
)
async def slash_cekilis_baslat(
    interaction: discord.Interaction,
    sure: str,
    kazanan: int = 1,
    odul: str = "VIP Rolü",
    kanal: discord.TextChannel = None,
    vip_avantaj: bool = True,
    otomatik_vip: bool = None
):
    guild = interaction.guild
    target_channel = kanal or interaction.channel

    try:
        duration_seconds = parse_duration(sure)
    except ValueError as e:
        await interaction.response.send_message(f"{e}", ephemeral=True)
        return

    if kazanan < 1 or kazanan > 50:
        await interaction.response.send_message("Kazanan sayısı 1 ile 50 arasında olmalıdır.", ephemeral=True)
        return

    now_ts = int(datetime.now(timezone.utc).timestamp())
    end_ts = now_ts + duration_seconds

    # Otomatik VIP tespiti
    if otomatik_vip is None:
        otomatik_vip = "vip" in odul.lower()

    auto_vip_line = "\n› **Otomatik Teslim:** Kazanan üyeye **VIP rolü otomatik** tanımlanacaktır." if otomatik_vip else ""

    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    embed = discord.Embed(
        title=f"{bot_name} ✦ ÖDÜLLÜ ÇEKİLİŞ 🎉",
        description=(
            f"> **{odul}** çekilişi başladı!\n"
            f"> Aşağıdaki **Katıl** butonuna basarak çekilişe dahil olabilirsiniz.\n\n"
            f"### ÇEKİLİŞ BİLGİLERİ\n"
            f"› **Ödül:** **{odul}**\n"
            f"› **Kazanan Sayısı:** `{kazanan}` kişi\n"
            f"› **VIP Ayrıcalığı:** {'VIP Üyelere +2x Şans' if vip_avantaj else 'Standart'}"
            f"{auto_vip_line}\n"
            f"› **Düzenleyen:** {interaction.user.mention}\n"
            f"› **Kalan Süre:** <t:{end_ts}:R> (<t:{end_ts}:F>)"
        ),
        color=0xf1c40f,
        timestamp=datetime.fromtimestamp(end_ts, timezone.utc)
    )
    logo = get_brand_logo_url(guild)
    if logo:
        embed.set_thumbnail(url=logo)
        embed.set_footer(text=f"{bot_name} • Çekiliş Sistemi", icon_url=logo)

    view = GiveawayView(count=0)
    try:
        msg = await target_channel.send(content="🎉 **YENİ ÇEKİLİŞ BAŞLADI!** 🎉", embed=embed, view=view)
        giveaways = load_giveaways()
        giveaways[str(msg.id)] = {
            "channel_id": target_channel.id,
            "guild_id": guild.id,
            "prize": odul,
            "winners_count": kazanan,
            "end_timestamp": end_ts,
            "host_id": interaction.user.id,
            "vip_multiplier": vip_avantaj,
            "auto_give_vip": otomatik_vip,
            "participants": [],
            "ended": False,
            "winners": []
        }
        save_giveaways(giveaways)

        notice_text = f"Çekiliş başarıyla başlatıldı: {msg.jump_url}"
        if otomatik_vip:
            notice_text += "\n*VIP çekilişi algılandı: Çekiliş bittiğinde kazanan kişiye VIP rolü otomatik tanımlanacak.*"

        await interaction.response.send_message(notice_text, ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Çekiliş başlatılırken bir hata oluştu: {e}", ephemeral=True)

# 10. /cekilis-bitir (Yönetici)
@bot.tree.command(name="cekilis-bitir", description="Devam eden bir çekilişi süresini beklemeden anında bitirir.")
@app_commands.default_permissions(manage_guild=True)
@app_commands.describe(mesaj_id="Bitirilecek çekiliş mesajının ID'si")
async def slash_cekilis_bitir(interaction: discord.Interaction, mesaj_id: str):
    await interaction.response.defer(ephemeral=True)
    giveaways = load_giveaways()
    if mesaj_id not in giveaways:
        await interaction.followup.send("Bu ID'ye ait aktif bir çekiliş bulunamadı!", ephemeral=True)
        return

    if giveaways[mesaj_id].get("ended", False):
        await interaction.followup.send("Bu çekiliş zaten daha önce sonuçlanmış.", ephemeral=True)
        return

    try:
        await finish_giveaway(int(mesaj_id))
        await interaction.followup.send(f"`{mesaj_id}` ID'li çekiliş başarıyla sonuçlandırıldı.", ephemeral=True)
    except Exception as e:
        await interaction.followup.send(f"Çekiliş bitirilirken hata: {e}", ephemeral=True)

# 11. /cekilis-yenile (Yönetici)
@bot.tree.command(name="cekilis-yenile", description="Bitmiş bir çekilişten yeni kazanan(lar) seçer (Reroll).")
@app_commands.default_permissions(manage_guild=True)
@app_commands.describe(
    mesaj_id="Yeniden kazanan seçilecek çekiliş mesaj ID'si",
    kazanan="Seçilecek yeni kazanan sayısı (Varsayılan: 1)"
)
async def slash_cekilis_yenile(interaction: discord.Interaction, mesaj_id: str, kazanan: int = 1):
    await interaction.response.defer(ephemeral=True)
    giveaways = load_giveaways()
    gw = giveaways.get(mesaj_id)
    if not gw:
        await interaction.followup.send("Bu ID'ye ait bir çekiliş kaydı bulunamadı!", ephemeral=True)
        return

    participants = gw.get("participants", [])
    unique_participants = list(set(participants))
    if not unique_participants:
        await interaction.followup.send("Bu çekilişte katılımcı bulunmuyor!", ephemeral=True)
        return

    guild = interaction.guild
    channel_id = gw.get("channel_id")
    channel = bot.get_channel(channel_id) or await bot.fetch_channel(channel_id)
    vip_multiplier = gw.get("vip_multiplier", True)
    vip_role_id = config.get("vip_rol_id", 0)
    prize = gw.get("prize", "Ödül")

    pool = []
    for uid in unique_participants:
        weight = 1
        if vip_multiplier and vip_role_id:
            m = guild.get_member(uid)
            if m and any(r.id == int(vip_role_id) for r in m.roles):
                weight = config.get("giveaway_vip_carpan", 2)
        pool.extend([uid] * weight)

    needed = min(kazanan, len(unique_participants))
    chosen_set = set()
    while len(chosen_set) < needed and pool:
        pick = random.choice(pool)
        chosen_set.add(pick)
        pool = [x for x in pool if x != pick]
    new_winners = list(chosen_set)

    # Otomatik VIP Verme
    is_vip_reward = gw.get("auto_give_vip", False) or ("vip" in prize.lower())
    if is_vip_reward and new_winners:
        await grant_vip_to_winners(guild, new_winners, prize)

    winner_mentions = ", ".join(f"<@{w}>" for w in new_winners)
    extra_msg = "\nVIP rolü yeni kazanan üyeye otomatik olarak tanımlandı." if is_vip_reward else ""

    if channel:
        await channel.send(f"🎉 **YENİDEN ÇEKİLİŞ!**\n🎉 Tebrikler {winner_mentions}! **{prize}** çekilişinin yeni kazananı oldunuz! 🎉{extra_msg}")

    await interaction.followup.send(f"Yeni kazananlar belirlendi: {winner_mentions}", ephemeral=True)

# 12. /cekilis-iptal (Yönetici)
@bot.tree.command(name="cekilis-iptal", description="Devam eden bir çekilişi iptal eder.")
@app_commands.default_permissions(manage_guild=True)
@app_commands.describe(mesaj_id="İptal edilecek çekiliş mesaj ID'si")
async def slash_cekilis_iptal(interaction: discord.Interaction, mesaj_id: str):
    giveaways = load_giveaways()
    if mesaj_id not in giveaways:
        await interaction.response.send_message("Bu ID'ye ait çekiliş bulunamadı!", ephemeral=True)
        return

    del giveaways[mesaj_id]
    save_giveaways(giveaways)
    await interaction.response.send_message(f"`{mesaj_id}` ID'li çekiliş iptal edildi ve silindi.", ephemeral=True)

# ─────────────────────────────────────────────
# GÖRSEL PROFİL KARTI MOTORU (PILLOW)
# ─────────────────────────────────────────────
def render_profile_card(name: str, username: str, user_id: int, status_str: str,
                        voice_str: str, voice_rank: int, level: int, xp_rank: int,
                        xp: int, next_xp: int, lvl_progress: int, lvl_needed: int,
                        messages: int, avatar_bytes: bytes = None) -> io.BytesIO:
    W, H = 900, 360
    img = Image.new('RGBA', (W, H), (12, 13, 17, 255))
    draw = ImageDraw.Draw(img)

    # Dış kart çerçevesi ve arka plan
    draw.rounded_rectangle([(10, 10), (W - 10, H - 10)], radius=20, fill=(18, 19, 26, 255), outline=(36, 38, 50, 255), width=2)
    # Üst aydınlatma çizgisi
    draw.line([(35, 12), (W - 35, 12)], fill=(50, 54, 72, 180), width=1)

    # Fontlar
    font_name = get_card_font(bold=True, size=28)
    font_sub = get_card_font(bold=False, size=15)
    font_badge = get_card_font(bold=True, size=13)
    font_stat_val = get_card_font(bold=True, size=23)
    font_stat_lbl = get_card_font(bold=True, size=13)
    font_stat_sub = get_card_font(bold=False, size=13)
    font_watermark = get_card_font(bold=True, size=12)

    # Avatar hazırlama
    av_size = 102
    av_x, av_y = 35, 34
    ring_color = (88, 101, 242, 255)
    if 'BOOSTER' in status_str.upper():
        ring_color = (244, 127, 255, 255)
    elif 'VIP' in status_str.upper():
        ring_color = (241, 196, 15, 255)

    mask = Image.new('L', (av_size, av_size), 0)
    mask_draw = ImageDraw.Draw(mask)
    mask_draw.ellipse((0, 0, av_size, av_size), fill=255)

    if avatar_bytes:
        try:
            av_raw = Image.open(io.BytesIO(avatar_bytes)).convert('RGBA')
            av_raw = av_raw.resize((av_size, av_size), Image.Resampling.LANCZOS)
            av_raw.putalpha(mask)
            img.paste(av_raw, (av_x, av_y), av_raw)
        except Exception:
            avatar_bytes = None

    if not avatar_bytes:
        fallback = Image.new('RGBA', (av_size, av_size), (32, 36, 48, 255))
        fb_draw = ImageDraw.Draw(fallback)
        initials = name[:2].upper() if len(name) >= 2 else name[:1].upper()
        fb_draw.text((32, 30), initials, fill=(255, 255, 255, 255), font=font_name)
        fallback.putalpha(mask)
        img.paste(fallback, (av_x, av_y), fallback)

    # Avatar halkası
    draw.ellipse([(av_x - 3, av_y - 3), (av_x + av_size + 3, av_y + av_size + 3)], outline=ring_color, width=3)

    # İsim & ID
    name_x = av_x + av_size + 24
    draw.text((name_x, 38), name, fill=(255, 255, 255, 255), font=font_name)
    sub_text = f'@{username}  •  ID: {user_id}'
    draw.text((name_x, 75), sub_text, fill=(145, 152, 172, 255), font=font_sub)

    # Rozet (Badge Pill)
    badge_bg = (32, 35, 46, 255)
    badge_border = (60, 65, 82, 255)
    badge_fg = (180, 185, 200, 255)
    if 'VIP & BOOSTER' in status_str.upper():
        badge_bg = (48, 26, 45, 255)
        badge_border = (244, 127, 255, 220)
        badge_fg = (244, 127, 255, 255)
    elif 'BOOSTER' in status_str.upper():
        badge_bg = (45, 25, 50, 255)
        badge_border = (244, 127, 255, 220)
        badge_fg = (244, 127, 255, 255)
    elif 'VIP' in status_str.upper():
        badge_bg = (48, 40, 20, 255)
        badge_border = (241, 196, 15, 220)
        badge_fg = (241, 196, 15, 255)

    badge_w = int(draw.textlength(status_str, font=font_badge)) + 30
    pill_x = W - 35 - badge_w
    pill_y = 42
    draw.rounded_rectangle([(pill_x, pill_y), (pill_x + badge_w, pill_y + 32)], radius=16, fill=badge_bg, outline=badge_border, width=1)
    draw.text((pill_x + 15, pill_y + 6), status_str, fill=badge_fg, font=font_badge)

    # 4 Stat Kutucuğu
    box_y = 155
    box_h = 95
    box_w = 195
    spacing = 15
    start_x = 35

    boxes = [
        ('SES SÜRESİ', voice_str, f'Sıralama: #{voice_rank}', (88, 101, 242, 255)),
        ('SEVİYE', f'Level {level}', f'Sıralama: #{xp_rank}', (235, 69, 158, 255)),
        ('TOPLAM XP', f'{xp:,} XP', f'Hedef: {next_xp:,} XP', (46, 204, 113, 255)),
        ('MESAJ SAYISI', f'{messages:,} Mesaj', 'Aktif Sohbet', (241, 196, 15, 255))
    ]

    for i, (label, val, sub, accent) in enumerate(boxes):
        bx = start_x + i * (box_w + spacing)
        draw.rounded_rectangle([(bx, box_y), (bx + box_w, box_y + box_h)], radius=12, fill=(25, 27, 36, 255), outline=(42, 45, 60, 255), width=1)
        # Accent vurgusu
        draw.rounded_rectangle([(bx + 14, box_y + 14), (bx + 19, box_y + 26)], radius=2, fill=accent)
        draw.text((bx + 26, box_y + 13), label, fill=(135, 142, 160, 255), font=font_stat_lbl)
        draw.text((bx + 14, box_y + 38), val, fill=(255, 255, 255, 255), font=font_stat_val)
        draw.text((bx + 14, box_y + 70), sub, fill=(115, 122, 142, 255), font=font_stat_sub)

    # Seviye İlerleme Çubuğu
    bar_x = 35
    bar_y = 282
    bar_w = W - 70
    bar_h = 16

    draw.text((bar_x, bar_y - 22), 'SEVİYE İLERLEMESİ', fill=(140, 146, 166, 255), font=font_stat_lbl)
    percent = int((lvl_progress / lvl_needed) * 100) if lvl_needed > 0 else 100
    prog_str = f'{lvl_progress:,} / {lvl_needed:,} XP  (%{percent})'
    prog_text_w = int(draw.textlength(prog_str, font=font_stat_lbl))
    draw.text((bar_x + bar_w - prog_text_w, bar_y - 22), prog_str, fill=(200, 205, 225, 255), font=font_stat_lbl)

    draw.rounded_rectangle([(bar_x, bar_y), (bar_x + bar_w, bar_y + bar_h)], radius=8, fill=(28, 30, 42, 255), outline=(45, 48, 65, 255), width=1)
    fraction = min(1.0, max(0.0, lvl_progress / lvl_needed)) if lvl_needed > 0 else 1.0
    fill_w = max(16, int(bar_w * fraction))
    draw.rounded_rectangle([(bar_x, bar_y), (bar_x + fill_w, bar_y + bar_h)], radius=8, fill=(88, 101, 242, 255))

    # Filigran / Priv Marka
    draw.text((W - 195, H - 32), 'ɨ̇ ʍ ʐ ǟ  •  PRİV STATS', fill=(75, 80, 100, 255), font=font_watermark)

    out = io.BytesIO()
    img.save(out, format='PNG')
    out.seek(0)
    return out

# 13. /profil
@bot.tree.command(name="profil", description="Kullanıcının görsel Priv profil kartını, ses süresini ve seviyesini gösterir.")
@app_commands.describe(kullanıcı="Profiline bakılacak üye (Varsayılan: Kendin)")
async def slash_profil(interaction: discord.Interaction, kullanıcı: discord.Member = None):
    await interaction.response.defer()
    target = kullanıcı or interaction.user
    guild = interaction.guild

    stats = load_stats()
    u_stats = stats.get(str(target.id), {})

    voice_secs = u_stats.get("voice_seconds", 0)
    messages = u_stats.get("messages", 0)
    xp = u_stats.get("xp", 0)
    level = get_level_from_xp(xp)

    # İlerleme hesabı
    curr_lvl_base_xp = get_xp_for_level(level)
    next_lvl_xp = get_xp_for_level(level + 1)
    lvl_progress = max(0, xp - curr_lvl_base_xp)
    lvl_needed = max(1, next_lvl_xp - curr_lvl_base_xp)

    # VIP & Booster kontrolü
    vip_role_id = config.get("vip_rol_id", 0)
    booster_role_id = config.get("booster_rol_id", 0)
    is_vip = False
    is_booster = False
    if isinstance(target, discord.Member):
        if vip_role_id:
            is_vip = any(r.id == int(vip_role_id) for r in target.roles)
        if booster_role_id:
            is_booster = any(r.id == int(booster_role_id) for r in target.roles) or (target.premium_since is not None)

    if is_vip and is_booster:
        status_str = "VIP & BOOSTER"
    elif is_vip:
        status_str = "VIP ÜYE"
    elif is_booster:
        status_str = "SERVER BOOSTER"
    else:
        status_str = "STANDART ÜYE"

    # Sıralama hesabı
    all_users = list(stats.values())
    voice_rank = sum(1 for s in all_users if s.get("voice_seconds", 0) > voice_secs) + 1
    xp_rank = sum(1 for s in all_users if s.get("xp", 0) > xp) + 1
    voice_str = format_seconds(voice_secs)

    # Avatar bytes çekme
    avatar_bytes = None
    try:
        if target.display_avatar:
            avatar_bytes = await target.display_avatar.with_format("png").with_size(128).read()
    except Exception as e:
        print(f"[Profil Avatar Hatası]: {e}", flush=True)

    # Görsel profil kartını oluştur
    card_buf = await asyncio.to_thread(
        render_profile_card,
        target.display_name,
        target.name,
        target.id,
        status_str,
        voice_str,
        voice_rank,
        level,
        xp_rank,
        xp,
        next_lvl_xp,
        lvl_progress,
        lvl_needed,
        messages,
        avatar_bytes
    )

    file = discord.File(fp=card_buf, filename=f"profil_{target.id}.png")
    content = target.mention if target != interaction.user else None
    await interaction.followup.send(content=content, file=file)


def format_seconds_card(secs: int) -> str:
    days = secs // 86400
    hours = (secs % 86400) // 3600
    minutes = (secs % 3600) // 60
    if days > 0:
        return f"{days} gün {hours} sa"
    elif hours > 0:
        return f"{hours} sa {minutes} dk"
    else:
        return f"{max(1, minutes)} dakika"

def render_leaderboard_card(
    category_title: str,
    category_type: str,
    theme_color: tuple,
    items: list,
    guild_name: str = "Sunucu"
) -> io.BytesIO:
    W, H = 950, 560
    img = Image.new('RGBA', (W, H), (10, 11, 15, 255))
    draw = ImageDraw.Draw(img)

    # Dış kart çerçevesi ve koyu priv arka plan
    draw.rounded_rectangle([(10, 10), (W - 10, H - 10)], radius=20, fill=(16, 17, 23, 255), outline=(32, 35, 48, 255), width=2)
    # Üst aydınlatma çizgisi (Tema rengi ışıltısı)
    draw.line([(35, 12), (W - 35, 12)], fill=(theme_color[0], theme_color[1], theme_color[2], 160), width=1)

    # Fontlar
    font_tag = get_card_font(bold=True, size=13)
    font_title = get_card_font(bold=True, size=26)
    font_sub = get_card_font(bold=False, size=14)
    font_pill = get_card_font(bold=True, size=13)
    font_rank = get_card_font(bold=True, size=16)
    font_row_name = get_card_font(bold=True, size=15)
    font_row_tag = get_card_font(bold=False, size=12)
    font_row_stat = get_card_font(bold=True, size=15)
    font_row_sub = get_card_font(bold=False, size=11)
    font_note = get_card_font(bold=False, size=12)
    font_watermark = get_card_font(bold=True, size=12)

    # Başlık Alanı
    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    draw.text((40, 28), f'{bot_name}  •  LİDERLİK TABLOSU', fill=(130, 137, 155, 255), font=font_tag)
    draw.text((40, 48), category_title, fill=(255, 255, 255, 255), font=font_title)
    draw.text((40, 84), f'{guild_name} • En Aktif İlk 10 Üye Sıralaması', fill=(150, 156, 175, 255), font=font_sub)

    # Sağ Üst Rozet
    pill_text = f'{category_type.upper()} SIRALAMASI'
    pill_w = int(draw.textlength(pill_text, font=font_pill)) + 30
    pill_x = W - 40 - pill_w
    pill_y = 42
    draw.rounded_rectangle([(pill_x, pill_y), (pill_x + pill_w, pill_y + 34)], radius=17, fill=(22, 26, 38, 255), outline=(theme_color[0], theme_color[1], theme_color[2], 200), width=1)
    draw.text((pill_x + 15, pill_y + 8), pill_text, fill=(theme_color[0], theme_color[1], theme_color[2], 255), font=font_pill)

    # Ayırıcı çizgi
    draw.line([(40, 118), (W - 40, 118)], fill=(32, 35, 48, 200), width=1)

    # Sıralama Satırları (2 Kolon x 5 Satır = 10 Sıra)
    col_w = 425
    col_gap = 20
    row_h = 58
    row_gap = 12
    start_y = 132

    if not items:
        draw.rounded_rectangle([(40, start_y + 40), (W - 40, start_y + 180)], radius=14, fill=(20, 22, 30, 255), outline=(35, 38, 50, 255), width=1)
        empty_text = "Henüz bu kategoride kayıtlı aktiflik verisi bulunmuyor."
        ew = int(draw.textlength(empty_text, font=font_row_name))
        draw.text((W // 2 - ew // 2, start_y + 95), empty_text, fill=(150, 155, 170, 255), font=font_row_name)
    else:
        for idx in range(10):
            col = 0 if idx < 5 else 1
            row = idx if idx < 5 else idx - 5

            rx = 40 + col * (col_w + col_gap)
            ry = start_y + row * (row_h + row_gap)
            badge_r = 17
            bx = rx + 14 + badge_r
            by = ry + row_h // 2

            if idx < len(items):
                item = items[idx]
                rank = idx + 1
                name = item.get('name', 'Bilinmiyor')
                tag = item.get('tag', '')
                stat = item.get('stat', '-')
                sub = item.get('sub', '')

                if rank == 1:
                    badge_bg = (241, 196, 15, 255)
                    badge_fg = (20, 20, 20, 255)
                    row_outline = (241, 196, 15, 140)
                    row_bg = (28, 27, 24, 255)
                elif rank == 2:
                    badge_bg = (189, 195, 199, 255)
                    badge_fg = (20, 20, 20, 255)
                    row_outline = (189, 195, 199, 120)
                    row_bg = (24, 26, 30, 255)
                elif rank == 3:
                    badge_bg = (205, 127, 50, 255)
                    badge_fg = (20, 20, 20, 255)
                    row_outline = (205, 127, 50, 120)
                    row_bg = (26, 23, 22, 255)
                else:
                    badge_bg = (32, 36, 48, 255)
                    badge_fg = (160, 168, 190, 255)
                    row_outline = (32, 35, 48, 255)
                    row_bg = (20, 22, 30, 255)

                draw.rounded_rectangle([(rx, ry), (rx + col_w, ry + row_h)], radius=12, fill=row_bg, outline=row_outline, width=1)
                draw.ellipse([(bx - badge_r, by - badge_r), (bx + badge_r, by + badge_r)], fill=badge_bg)
                rank_str = str(rank)
                rw = int(draw.textlength(rank_str, font=font_rank))
                draw.text((bx - rw // 2, by - 11), rank_str, fill=badge_fg, font=font_rank)

                text_x = bx + badge_r + 14
                if len(name) > 13:
                    name = name[:12] + "…"
                draw.text((text_x, ry + 10), name, fill=(255, 255, 255, 255), font=font_row_name)
                draw.text((text_x, ry + 32), tag, fill=(130, 137, 155, 255), font=font_row_tag)

                stat_w = int(draw.textlength(stat, font=font_row_stat))
                sub_w = int(draw.textlength(sub, font=font_row_sub))
                val_x = rx + col_w - 16

                draw.text((val_x - stat_w, ry + 10), stat, fill=(theme_color[0], theme_color[1], theme_color[2], 255), font=font_row_stat)
                draw.text((val_x - sub_w, ry + 32), sub, fill=(110, 116, 135, 255), font=font_row_sub)
            else:
                draw.rounded_rectangle([(rx, ry), (rx + col_w, ry + row_h)], radius=12, fill=(13, 14, 19, 255), outline=(24, 26, 36, 255), width=1)
                draw.ellipse([(bx - badge_r, by - badge_r), (bx + badge_r, by + badge_r)], fill=(18, 20, 27, 255), outline=(28, 32, 44, 255), width=1)
                empty_rank = str(idx + 1)
                rw = int(draw.textlength(empty_rank, font=font_rank))
                draw.text((bx - rw // 2, by - 11), empty_rank, fill=(55, 60, 75, 255), font=font_rank)
                draw.text((bx + badge_r + 14, ry + 20), "Müsait Yuva", fill=(55, 60, 75, 255), font=font_row_name)

    footer_y = H - 54
    draw.line([(40, footer_y - 8), (W - 40, footer_y - 8)], fill=(28, 31, 42, 200), width=1)
    draw.text((42, footer_y + 4), "Veriler sunucu genelinde gerçek zamanlı kaydedilir • Sıralama otomatik güncellenir", fill=(120, 126, 145, 255), font=font_note)
    draw.text((W - 240, footer_y + 4), f"{bot_name}  •  PRIV LEADERBOARD", fill=(75, 80, 100, 255), font=font_watermark)

    out = io.BytesIO()
    img.save(out, format='PNG')
    out.seek(0)
    return out

async def get_leaderboard_card_file(
    guild: discord.Guild,
    category_title: str,
    category_type: str,
    theme_color: tuple,
    raw_items: list,
) -> discord.File:
    resolved_items = []
    for rank, (uid_str, stat_val, sub_val) in enumerate(raw_items, start=1):
        try:
            uid_int = int(uid_str)
        except Exception:
            continue

        member = guild.get_member(uid_int) if guild else None
        if member:
            display_name = member.display_name
            username = f"@{member.name}"
        else:
            try:
                user = await bot.fetch_user(uid_int)
                display_name = user.display_name
                username = f"@{user.name}"
            except Exception:
                display_name = "Kullanıcı"
                username = f"ID: {uid_str}"

        resolved_items.append({
            'rank': rank,
            'name': display_name,
            'tag': username,
            'stat': stat_val,
            'sub': sub_val
        })

    guild_name = guild.name if guild else config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    img_buf = await asyncio.to_thread(
        render_leaderboard_card,
        category_title,
        category_type,
        theme_color,
        resolved_items,
        guild_name
    )
    return discord.File(fp=img_buf, filename=f"top_{category_type.lower()}.png")

# 14. /top-ses
@bot.tree.command(name="top-ses", description="Sunucuda seste en çok vakit geçiren ilk 10 üyeyi listeler.")
async def slash_top_ses(interaction: discord.Interaction):
    await interaction.response.defer()
    stats = load_stats()
    sorted_users = sorted(stats.items(), key=lambda item: item[1].get("voice_seconds", 0), reverse=True)
    top_10 = [item for item in sorted_users if item[1].get("voice_seconds", 0) > 0][:10]

    raw_items = []
    for uid, data in top_10:
        secs = data.get("voice_seconds", 0)
        time_str = format_seconds_card(secs)
        lvl = data.get("level", 1)
        raw_items.append((uid, time_str, f"Seviye {lvl}"))

    card_file = await get_leaderboard_card_file(
        guild=interaction.guild,
        category_title="SES AKTİFLİK SIRALAMASI",
        category_type="Ses",
        theme_color=(52, 152, 219),
        raw_items=raw_items
    )
    await interaction.followup.send(file=card_file)

# 15. /top-chat
@bot.tree.command(name="top-chat", description="Sunucuda en çok mesaj atan ilk 10 üyeyi listeler.")
async def slash_top_chat(interaction: discord.Interaction):
    await interaction.response.defer()
    stats = load_stats()
    sorted_users = sorted(stats.items(), key=lambda item: item[1].get("messages", 0), reverse=True)
    top_10 = [item for item in sorted_users if item[1].get("messages", 0) > 0][:10]

    raw_items = []
    for uid, data in top_10:
        msgs = data.get("messages", 0)
        lvl = data.get("level", 1)
        raw_items.append((uid, f"{msgs:,} Mesaj", f"Seviye {lvl}"))

    card_file = await get_leaderboard_card_file(
        guild=interaction.guild,
        category_title="SOHBET (MESAJ) SIRALAMASI",
        category_type="Chat",
        theme_color=(155, 89, 182),
        raw_items=raw_items
    )
    await interaction.followup.send(file=card_file)

# 16. /top-seviye
@bot.tree.command(name="top-seviye", description="Sunucuda en yüksek seviye ve XP'ye sahip ilk 10 üyeyi listeler.")
async def slash_top_seviye(interaction: discord.Interaction):
    await interaction.response.defer()
    stats = load_stats()
    sorted_users = sorted(stats.items(), key=lambda item: item[1].get("xp", 0), reverse=True)
    top_10 = [item for item in sorted_users if item[1].get("xp", 0) > 0][:10]

    raw_items = []
    for uid, data in top_10:
        xp = data.get("xp", 0)
        lvl = data.get("level", 1)
        raw_items.append((uid, f"Seviye {lvl}", f"{xp:,} XP"))

    card_file = await get_leaderboard_card_file(
        guild=interaction.guild,
        category_title="SEVİYE & XP SIRALAMASI",
        category_type="Seviye",
        theme_color=(241, 196, 15),
        raw_items=raw_items
    )
    await interaction.followup.send(file=card_file)

# 17. /xp-ver (Yönetici)
@bot.tree.command(name="xp-ver", description="Belirtilen üyeye XP ödülü verir.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kullanıcı="XP verilecek üye", miktar="Eklenecek XP miktarı")
async def slash_xp_ver(interaction: discord.Interaction, kullanıcı: discord.Member, miktar: int):
    if miktar <= 0:
        await interaction.response.send_message("Eklenecek XP 0'dan büyük olmalıdır.", ephemeral=True)
        return

    stats = load_stats()
    u_id = str(kullanıcı.id)
    if u_id not in stats:
        stats[u_id] = {"voice_seconds": 0, "messages": 0, "xp": 0, "level": 1, "last_xp_time": 0}

    old_xp = stats[u_id].get("xp", 0)
    new_xp = old_xp + miktar
    stats[u_id]["xp"] = new_xp
    old_lvl = stats[u_id].get("level", 1)
    new_lvl = get_level_from_xp(new_xp)
    stats[u_id]["level"] = new_lvl
    save_stats(stats)

    await interaction.response.send_message(
        f"{kullanıcı.mention} üyesine **+{miktar:,} XP** verildi!\n"
        f"Yeni Durum: **Seviye {new_lvl}** `({new_xp:,} XP)`",
        ephemeral=True
    )

# 18. /xp-al (Yönetici)
@bot.tree.command(name="xp-al", description="Belirtilen üyeden XP siler.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kullanıcı="XP silinecek üye", miktar="Silinecek XP miktarı")
async def slash_xp_al(interaction: discord.Interaction, kullanıcı: discord.Member, miktar: int):
    if miktar <= 0:
        await interaction.response.send_message("Silinecek XP 0'dan büyük olmalıdır.", ephemeral=True)
        return

    stats = load_stats()
    u_id = str(kullanıcı.id)
    if u_id not in stats:
        await interaction.response.send_message("Bu üyenin kayıtlı XP verisi yok.", ephemeral=True)
        return

    old_xp = stats[u_id].get("xp", 0)
    new_xp = max(0, old_xp - miktar)
    stats[u_id]["xp"] = new_xp
    new_lvl = get_level_from_xp(new_xp)
    stats[u_id]["level"] = new_lvl
    save_stats(stats)

    await interaction.response.send_message(
        f"{kullanıcı.mention} üyesinden **-{miktar:,} XP** silindi.\n"
        f"Yeni Durum: **Seviye {new_lvl}** `({new_xp:,} XP)`",
        ephemeral=True
    )

# 19. /istatistik-sifirla (Yönetici)
@bot.tree.command(name="istatistik-sifirla", description="Belirtilen üyenin tüm ses, mesaj ve XP istatistiklerini sıfırlar.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kullanıcı="İstatistikleri sıfırlanacak üye")
async def slash_istatistik_sifirla(interaction: discord.Interaction, kullanıcı: discord.Member):
    stats = load_stats()
    u_id = str(kullanıcı.id)
    if u_id in stats:
        del stats[u_id]
        save_stats(stats)
        await interaction.response.send_message(f"{kullanıcı.mention} kullanıcısının tüm aktiflik istatistikleri sıfırlandı.", ephemeral=True)
    else:
        await interaction.response.send_message(f"{kullanıcı.mention} kullanıcısına ait kayıt bulunamadı.", ephemeral=True)

# 20. /kufur-engel (Yönetici)
@bot.tree.command(name="kufur-engel", description="Küfür ve argo engelleme korumasını açar veya kapatır.")
@app_commands.default_permissions(administrator=True)
@app_commands.choices(durum=[
    app_commands.Choice(name="Açık (Aktif)", value="acik"),
    app_commands.Choice(name="Kapalı (Devre Dışı)", value="kapali")
])
async def slash_kufur_engel(interaction: discord.Interaction, durum: app_commands.Choice[str]):
    is_active = (durum.value == "acik")
    config["kufur_engel"] = is_active
    save_config(config)
    durum_str = "aktif" if is_active else "devre dışı"
    await interaction.response.send_message(f"Küfür engelleme sistemi **{durum_str}** bırakıldı.", ephemeral=True)

# 21. /spam-engel (Yönetici)
@bot.tree.command(name="spam-engel", description="Spam ve flood engelleme korumasını açar veya kapatır.")
@app_commands.default_permissions(administrator=True)
@app_commands.choices(durum=[
    app_commands.Choice(name="Açık (Aktif)", value="acik"),
    app_commands.Choice(name="Kapalı (Devre Dışı)", value="kapali")
])
async def slash_spam_engel(interaction: discord.Interaction, durum: app_commands.Choice[str]):
    is_active = (durum.value == "acik")
    config["spam_engel"] = is_active
    save_config(config)
    durum_str = "aktif" if is_active else "devre dışı"
    await interaction.response.send_message(f"Spam engelleme sistemi **{durum_str}** bırakıldı.", ephemeral=True)

# 22. /koruma-durum
@bot.tree.command(name="koruma-durum", description="Sunucu koruma ve güvenlik sistemlerinin durumunu gösterir.")
async def slash_koruma_durum(interaction: discord.Interaction):
    kufur = "Aktif" if config.get("kufur_engel", True) else "Devre Dışı"
    spam = "Aktif" if config.get("spam_engel", True) else "Devre Dışı"
    reklam = "Aktif (GIF Hariç)" if config.get("reklam_engel", True) else "Devre Dışı"
    timeout_m = config.get("spam_timeout_dakika", 2)
    custom_swears = len(config.get("ozel_kufurler", []))
    log_ch_id = config.get("mod_log_kanal_id")
    log_ch_str = f"<#{log_ch_id}>" if log_ch_id else "Ayarlanmadı"
    staff_role_id = config.get("staff_dm_log_role_id", 0)

    bot_name = config.get("bot_adi", "ɨ̇ ʍ ʐ ǟ")
    embed = discord.Embed(
        title=f"{bot_name}  |  Sunucu Koruma & Güvenlik Durumu",
        description="Sunucuda devrede olan otomatik güvenlik filtreleri ve yetkili denetim sistemi:\n",
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    embed.add_field(name="Küfür Koruması", value=f"`{kufur}` *(Akıllı normalizasyon)*", inline=True)
    embed.add_field(name="Spam Koruması", value=f"`{spam}` *(Flood / Tekrar / Etiket)*", inline=True)
    embed.add_field(name="Reklam Koruması", value=f"`{reklam}` *(Discord GIF Serbest)*", inline=True)
    embed.add_field(name="Spam Cezası", value=f"`{timeout_m} Dakika Timeout`", inline=True)
    embed.add_field(name="Güvenlik Log Kanalı", value=log_ch_str, inline=True)
    embed.add_field(name="Yetkili DM Log Rolü", value=f"<@&{staff_role_id}>", inline=True)
    embed.add_field(name="Muafiyet", value="`Yöneticiler ve Yetkililer`", inline=True)

    logo = get_brand_logo_url(interaction.guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_footer(text=f"{bot_name} • Güvenlik Sistemi")
    await interaction.response.send_message(embed=embed, ephemeral=True)

# 23. /kufur-ekle [kelime] (Yönetici)
@bot.tree.command(name="kufur-ekle", description="Küfür filtresine özel yasaklı kelime ekler.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kelime="Yasaklanacak kelime veya ifade")
async def slash_kufur_ekle(interaction: discord.Interaction, kelime: str):
    clean = kelime.strip().lower()
    if len(clean) < 2:
        await interaction.response.send_message("Yasaklanacak kelime en az 2 karakter olmalıdır.", ephemeral=True)
        return
    swears = config.get("ozel_kufurler", [])
    if clean in swears:
        await interaction.response.send_message(f"`{clean}` zaten yasaklı kelimeler listesinde mevcut.", ephemeral=True)
        return
    swears.append(clean)
    config["ozel_kufurler"] = swears
    save_config(config)
    await interaction.response.send_message(f"`{clean}` kelimesi yasaklı kelimeler listesine eklendi.", ephemeral=True)

# 24. /kufur-sil [kelime] (Yönetici)
@bot.tree.command(name="kufur-sil", description="Küfür filtresinden özel bir kelimeyi kaldırır.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kelime="Listeden çıkarılacak kelime")
async def slash_kufur_sil(interaction: discord.Interaction, kelime: str):
    clean = kelime.strip().lower()
    swears = config.get("ozel_kufurler", [])
    if clean not in swears:
        await interaction.response.send_message(f"`{clean}` özel yasaklı kelimeler listesinde bulunamadı.", ephemeral=True)
        return
    swears.remove(clean)
    config["ozel_kufurler"] = swears
    save_config(config)
    await interaction.response.send_message(f"`{clean}` kelimesi özel listeden silindi.", ephemeral=True)

# 25. /kufur-liste (Yönetici)
@bot.tree.command(name="kufur-liste", description="Özel eklenmiş yasaklı kelimelerin listesini gösterir.")
@app_commands.default_permissions(administrator=True)
async def slash_kufur_liste(interaction: discord.Interaction):
    swears = config.get("ozel_kufurler", [])
    if not swears:
        await interaction.response.send_message("Özel eklenmiş herhangi bir yasaklı kelime bulunmuyor. (Varsayılan koruma devrededir)", ephemeral=True)
        return
    words_str = ", ".join(f"`{w}`" for w in swears[:50])
    await interaction.response.send_message(f"**Özel Yasaklı Kelimeler ({len(swears)}):**\n{words_str}", ephemeral=True)

# 26. /mod-log-ayarla [kanal] (Yönetici)
@bot.tree.command(name="mod-log-ayarla", description="Küfür ve spam koruma loglarının gönderileceği kanalı ayarlar.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kanal="Güvenlik log kanalı")
async def slash_mod_log_ayarla(interaction: discord.Interaction, kanal: discord.TextChannel):
    config["mod_log_kanal_id"] = kanal.id
    save_config(config)
    await interaction.response.send_message(f"Güvenlik log kanalı {kanal.mention} olarak ayarlandı.", ephemeral=True)

# 26.1 /rol-log-ayarla [kanal] (Yönetici)
@bot.tree.command(name="rol-log-ayarla", description="Sağ tık ve yönetimsel rol değişikliklerinin loglanacağı kanalı ayarlar.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kanal="Rol denetim log kanalı")
async def slash_rol_log_ayarla(interaction: discord.Interaction, kanal: discord.TextChannel):
    config["rol_log_kanal_id"] = kanal.id
    save_config(config)
    await interaction.response.send_message(f"Rol değişiklik denetim log kanalı {kanal.mention} olarak ayarlandı.", ephemeral=True)

# 27. /mute [kullanici] [dakika] (sebep) (Yetkili)
@bot.tree.command(name="mute", description="Belirtilen üyeyi zaman aşımına (timeout) sokar.")
@app_commands.describe(kullanıcı="Susturulacak üye", dakika="Süre (dakika)", sebep="Susturma sebebi")
async def slash_mute(interaction: discord.Interaction, kullanıcı: discord.Member, dakika: int, sebep: str = "Yetkili tarafından susturuldu"):
    if not is_moderation_immune(interaction.user):
        await interaction.response.send_message("Bu komutu kullanmak için yetkiniz bulunmuyor.", ephemeral=True)
        return
    if is_moderation_immune(kullanıcı):
        await interaction.response.send_message("Yetkilileri veya yöneticileri susturamazsınız.", ephemeral=True)
        return
    if dakika <= 0 or dakika > 40320:
        await interaction.response.send_message("Süre 1 ile 40320 dakika (28 gün) arasında olmalıdır.", ephemeral=True)
        return
    try:
        await kullanıcı.timeout(timedelta(minutes=dakika), reason=f"{interaction.user.name}: {sebep}")
        await interaction.response.send_message(f"{kullanıcı.mention} üyesi **{dakika} dakika** susturuldu.\n• **Sebep:** `{sebep}`")
    except Exception as e:
        await interaction.response.send_message(f"Susturma uygulanamadı: {e}", ephemeral=True)

# 28. /unmute [kullanici] (Yetkili)
@bot.tree.command(name="unmute", description="Belirtilen üyenin susturmasını (timeout) kaldırır.")
@app_commands.describe(kullanıcı="Susturması kaldırılacak üye")
async def slash_unmute(interaction: discord.Interaction, kullanıcı: discord.Member):
    if not is_moderation_immune(interaction.user):
        await interaction.response.send_message("Bu komutu kullanmak için yetkiniz bulunmuyor.", ephemeral=True)
        return
    try:
        await kullanıcı.timeout(None, reason=f"Susturma {interaction.user.name} tarafından kaldırıldı")
        await interaction.response.send_message(f"{kullanıcı.mention} kullanıcısının susturması kaldırıldı.")
    except Exception as e:
        await interaction.response.send_message(f"İşlem uygulanamadı: {e}", ephemeral=True)

# 29. /guard-kanal [durum] (Yönetici)
@bot.tree.command(name="guard-kanal", description="Kanal açma ve silme guard korumasını açar veya kapatır.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(durum="Kanal koruma durumu")
@app_commands.choices(durum=[
    app_commands.Choice(name="Açık (Aktif)", value="acik"),
    app_commands.Choice(name="Kapalı (Devre Dışı)", value="kapali")
])
async def slash_guard_kanal(interaction: discord.Interaction, durum: app_commands.Choice[str]):
    if interaction.user.id != interaction.guild.owner_id and not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("Bu komutu yalnızca sunucu sahibi veya yöneticiler kullanabilir.", ephemeral=True)
        return
    aktif = (durum.value == "acik")
    config["guard_kanal_koruma"] = aktif
    save_config(config)
    durum_str = "AÇIK (Yetkisiz kanal açma/silme engellenir)" if aktif else "KAPALI (Kanal koruması devre dışı)"
    await interaction.response.send_message(f"Kanal Guard Koruması: **{durum_str}**", ephemeral=True)

# 30. /guard-ekle (kullanıcı) (rol) (Yönetici)
@bot.tree.command(name="guard-ekle", description="Guard güvenli listesine (whitelist) kullanıcı veya rol ekler.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kullanıcı="Güvenli listeye eklenecek kullanıcı", rol="Güvenli listeye eklenecek rol")
async def slash_guard_ekle(interaction: discord.Interaction, kullanıcı: Optional[discord.Member] = None, rol: Optional[discord.Role] = None):
    if interaction.user.id != interaction.guild.owner_id and not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("Bu komutu yalnızca sunucu sahibi veya yöneticiler kullanabilir.", ephemeral=True)
        return
    if not kullanıcı and not rol:
        await interaction.response.send_message("Lütfen güvenli listeye eklemek için bir kullanıcı veya bir rol belirtin.", ephemeral=True)
        return

    eklenenler = []
    if kullanıcı:
        wl_users = config.setdefault("guard_whitelist_kullanicilar", [])
        if kullanıcı.id not in wl_users:
            wl_users.append(kullanıcı.id)
            eklenenler.append(f"Kullanıcı: {kullanıcı.mention}")
        else:
            eklenenler.append(f"Kullanıcı {kullanıcı.mention} zaten güvenli listede.")
    if rol:
        wl_roles = config.setdefault("guard_whitelist_roller", [])
        if rol.id not in wl_roles:
            wl_roles.append(rol.id)
            eklenenler.append(f"Rol: {rol.mention}")
        else:
            eklenenler.append(f"Rol {rol.mention} zaten güvenli listede.")

    save_config(config)
    await interaction.response.send_message("Guard Güvenli Liste Güncellendi:\n" + "\n".join(f"• {e}" for e in eklenenler), ephemeral=True)

# 31. /guard-cikar (kullanıcı) (rol) (Yönetici)
@bot.tree.command(name="guard-cikar", description="Guard güvenli listesinden kullanıcı veya rolü kaldırır.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kullanıcı="Güvenli listeden çıkarılacak kullanıcı", rol="Güvenli listeden çıkarılacak rol")
async def slash_guard_cikar(interaction: discord.Interaction, kullanıcı: Optional[discord.Member] = None, rol: Optional[discord.Role] = None):
    if interaction.user.id != interaction.guild.owner_id and not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("Bu komutu yalnızca sunucu sahibi veya yöneticiler kullanabilir.", ephemeral=True)
        return
    if not kullanıcı and not rol:
        await interaction.response.send_message("Lütfen güvenli listeden çıkarmak için bir kullanıcı veya bir rol belirtin.", ephemeral=True)
        return

    cikarilanlar = []
    if kullanıcı:
        wl_users = config.get("guard_whitelist_kullanicilar", [])
        if kullanıcı.id in wl_users:
            wl_users.remove(kullanıcı.id)
            config["guard_whitelist_kullanicilar"] = wl_users
            cikarilanlar.append(f"Kullanıcı: {kullanıcı.mention}")
        else:
            cikarilanlar.append(f"Kullanıcı {kullanıcı.mention} güvenli listede kayıtlı değil.")
    if rol:
        wl_roles = config.get("guard_whitelist_roller", [])
        if rol.id in wl_roles:
            wl_roles.remove(rol.id)
            config["guard_whitelist_roller"] = wl_roles
            cikarilanlar.append(f"Rol: {rol.mention}")
        else:
            cikarilanlar.append(f"Rol {rol.mention} güvenli listede kayıtlı değil.")

    save_config(config)
    await interaction.response.send_message("Guard Güvenli Listeden Çıkarıldı:\n" + "\n".join(f"• {c}" for c in cikarilanlar), ephemeral=True)

# 32. /guard-liste (Yönetici)
@bot.tree.command(name="guard-liste", description="Guard güvenli listesindeki yetkilileri, rolleri ve aktif uyarıları gösterir.")
@app_commands.default_permissions(administrator=True)
async def slash_guard_liste(interaction: discord.Interaction):
    if interaction.user.id != interaction.guild.owner_id and not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("Bu komutu yalnızca sunucu sahibi veya yöneticiler kullanabilir.", ephemeral=True)
        return

    wl_users = config.get("guard_whitelist_kullanicilar", [])
    wl_roles = config.get("guard_whitelist_roller", [])
    safe_bots = config.get("guard_guvenli_botlar", [0, 0])
    uyarilar = config.get("guard_uyarilar", {})
    limit = config.get("guard_uyari_limiti", 3)

    user_strs = [f"<@{uid}> (`{uid}`)" for uid in wl_users] if wl_users else ["*(Kayıtlı kullanıcı yok)*"]
    role_strs = [f"<@&{rid}> (`{rid}`)" for rid in wl_roles] if wl_roles else ["*(Kayıtlı rol yok)*"]
    bot_strs = [f"<@{bid}> (`{bid}`)" for bid in safe_bots] if safe_bots else ["*(Kayıtlı bot yok)*"]

    active_warns = []
    for uid, count in uyarilar.items():
        if count > 0:
            active_warns.append(f"<@{uid}>: `{count} / {limit}` İhlal")
    warn_strs = active_warns if active_warns else ["*(Aktif uyarısı olan yetkili yok)*"]

    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Guard Güvenli Liste & Uyarılar",
        description="Sunucuda kanal açma ve silme yetkisine sahip güvenli kişi ve roller:\n",
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    embed.add_field(name="Sunucu Sahibi (Tam Muaf)", value=f"<@{interaction.guild.owner_id}>", inline=False)
    embed.add_field(name=f"Güvenli Kullanıcılar ({len(wl_users)})", value="\n".join(user_strs[:15]), inline=False)
    embed.add_field(name=f"Güvenli Roller ({len(wl_roles)})", value="\n".join(role_strs[:15]), inline=False)
    embed.add_field(name="Güvenli Entegre Botlar", value="\n".join(bot_strs[:10]), inline=False)
    embed.add_field(name="Aktif Uyarısı Bulunanlar", value="\n".join(warn_strs[:15]), inline=False)

    logo = get_brand_logo_url(interaction.guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Guard Denetim")
    await interaction.response.send_message(embed=embed, ephemeral=True)

# 33. /guard-uyari-sifirla [kullanıcı] (Yönetici)
@bot.tree.command(name="guard-uyari-sifirla", description="Bir yetkilinin guard kanal ihlal sayacını sıfırlar.")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(kullanıcı="Uyarısı sıfırlanacak üye")
async def slash_guard_uyari_sifirla(interaction: discord.Interaction, kullanıcı: discord.Member):
    if interaction.user.id != interaction.guild.owner_id and not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("Bu komutu yalnızca sunucu sahibi veya yöneticiler kullanabilir.", ephemeral=True)
        return
    u_id_str = str(kullanıcı.id)
    uyarilar = config.setdefault("guard_uyarilar", {})
    if u_id_str in uyarilar:
        del uyarilar[u_id_str]
        save_config(config)
        await interaction.response.send_message(f"{kullanıcı.mention} kullanıcısının tüm guard uyarıları sıfırlandı.", ephemeral=True)
    else:
        await interaction.response.send_message(f"{kullanıcı.mention} kullanıcısının aktif bir guard uyarısı bulunmuyor.", ephemeral=True)

# 34. /guard-durum (Yönetici)
@bot.tree.command(name="guard-durum", description="Guard sisteminin aktif durumunu ve ayarlarını gösterir.")
@app_commands.default_permissions(administrator=True)
async def slash_guard_durum(interaction: discord.Interaction):
    if interaction.user.id != interaction.guild.owner_id and not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("Bu komutu yalnızca sunucu sahibi veya yöneticiler kullanabilir.", ephemeral=True)
        return

    koruma = "Aktif" if config.get("guard_kanal_koruma", True) else "Devre Dışı"
    limit = config.get("guard_uyari_limiti", 3)
    wl_user_count = len(config.get("guard_whitelist_kullanicilar", []))
    wl_role_count = len(config.get("guard_whitelist_roller", []))
    log_ch_id = config.get("mod_log_kanal_id")
    log_ch_str = f"<#{log_ch_id}>" if log_ch_id else "Ayarlanmadı (`/mod-log-ayarla`)"

    embed = discord.Embed(
        title=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')}  |  Guard Güvenlik Paneli",
        description="Sunucu kanal koruma ve otomatik yetki sıyırma yapılandırması:\n",
        color=get_embed_color(),
        timestamp=datetime.now(timezone.utc)
    )
    embed.add_field(name="• Kanal Açma & Silme Koruması", value=f"`{koruma}`", inline=True)
    embed.add_field(name="• Uyarı Limiti (Yetki Çekme)", value=f"`{limit} İhlal`", inline=True)
    embed.add_field(name="• Güvenlik Log Kanalı", value=log_ch_str, inline=True)
    embed.add_field(name="• Whitelist Kullanıcı Sayısı", value=f"`{wl_user_count}` Kişi", inline=True)
    embed.add_field(name="• Whitelist Rol Sayısı", value=f"`{wl_role_count}` Rol", inline=True)
    embed.add_field(name="• Koruma Protokolü", value="`Kanal Silme -> Otomatik Kurtar`\n`Kanal Açma -> Otomatik Sil`\n`3 İhlal -> Yetkileri Çek + 1s Mute`", inline=False)

    logo = get_brand_logo_url(interaction.guild)
    if logo:
        embed.set_thumbnail(url=logo)
    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Güvenlik Sistemi")
    await interaction.response.send_message(embed=embed, ephemeral=True)

# 35. /ban [kullanıcı] (sebep) (Yetkili)
@bot.tree.command(name="ban", description="Belirtilen kullanıcıyı sunucudan yasaklar (ban).")
@app_commands.describe(kullanıcı="Yasaklanacak üye veya kullanıcı ID", sebep="Yasaklama gerekçesi", mesaj_silme_gunu="Geçmiş mesajları silme süresi (0-7 gün)")
async def slash_ban(interaction: discord.Interaction, kullanıcı: discord.User, sebep: str = "Yetkili tarafından yasaklandı", mesaj_silme_gunu: int = 0):
    if not is_moderation_immune(interaction.user):
        await interaction.response.send_message("Bu komutu kullanmak için yetkiniz bulunmuyor.", ephemeral=True)
        return

    guild = interaction.guild
    if not guild:
        await interaction.response.send_message("Bu komut yalnızca sunucularda kullanılabilir.", ephemeral=True)
        return

    member = guild.get_member(kullanıcı.id)
    if member and is_moderation_immune(member):
        await interaction.response.send_message("Yetkilileri veya yöneticileri sunucudan yasaklayamazsınız.", ephemeral=True)
        return

    try:
        delete_days = max(0, min(7, mesaj_silme_gunu))
        await guild.ban(kullanıcı, reason=f"{interaction.user.name} ({interaction.user.id}): {sebep}", delete_message_days=delete_days)
        await interaction.response.send_message(
            f"🔨 **{kullanıcı.name}** (`{kullanıcı.id}`) sunucudan yasaklandı.\n• **Yetkili:** {interaction.user.mention}\n• **Sebep:** `{sebep}`"
        )
    except Exception as e:
        await interaction.response.send_message(f"Yasaklama işlemi başarısız: {e}", ephemeral=True)

# 36. /unban [kullanıcı_id] (sebep) (Yetkili)
@bot.tree.command(name="unban", description="Yasaklı bir kullanıcının yasağını kaldırır (unban).")
@app_commands.describe(kullanıcı_id="Yasağı kaldırılacak kullanıcının ID'si", sebep="Yasak kaldırma gerekçesi")
async def slash_unban(interaction: discord.Interaction, kullanıcı_id: str, sebep: str = "Yetkili tarafından yasak kaldırıldı"):
    if not is_moderation_immune(interaction.user):
        await interaction.response.send_message("Bu komutu kullanmak için yetkiniz bulunmuyor.", ephemeral=True)
        return

    uid_clean = kullanıcı_id.strip()
    if not uid_clean.isdigit():
        await interaction.response.send_message("Lütfen geçerli bir sayısal kullanıcı ID girin.", ephemeral=True)
        return

    guild = interaction.guild
    if not guild:
        await interaction.response.send_message("Bu komut yalnızca sunucularda kullanılabilir.", ephemeral=True)
        return

    try:
        user = await bot.fetch_user(int(uid_clean))
        await guild.unban(user, reason=f"{interaction.user.name} ({interaction.user.id}): {sebep}")
        await interaction.response.send_message(
            f"🔓 **{user.name}** (`{user.id}`) kullanıcısının sunucu yasağı kaldırıldı.\n• **Yetkili:** {interaction.user.mention}\n• **Sebep:** `{sebep}`"
        )
    except discord.NotFound:
        await interaction.response.send_message("Belirtilen kullanıcı bulunamadı veya sunucuda yasaklı değil.", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Yasak kaldırma işlemi başarısız: {e}", ephemeral=True)

# 37. /reklam-engel [durum] (Yönetici)
@bot.tree.command(name="reklam-engel", description="Reklam ve bağlantı (link) korumasını açar veya kapatır (Discord GIF hariç).")
@app_commands.default_permissions(administrator=True)
@app_commands.describe(durum="Reklam koruma durumu")
@app_commands.choices(durum=[
    app_commands.Choice(name="Açık (Aktif - Linkler Yasak, GIF Serbest)", value="acik"),
    app_commands.Choice(name="Kapalı (Devre Dışı)", value="kapali")
])
async def slash_reklam_engel(interaction: discord.Interaction, durum: app_commands.Choice[str]):
    if not is_moderation_immune(interaction.user):
        await interaction.response.send_message("Bu komutu kullanmak için yetkiniz bulunmuyor.", ephemeral=True)
        return

    aktif = (durum.value == "acik")
    config["reklam_engel"] = aktif
    save_config(config)
    durum_str = "AÇIK (Bağlantılar engellenir, GIF serbesttir)" if aktif else "KAPALI (Reklam koruması devre dışı)"
    await interaction.response.send_message(f"Reklam Engelleme Koruması: **{durum_str}**", ephemeral=True)

# 38. /snipe (kullanıcı)
@bot.tree.command(name="snipe", description="Bu kanalda silinen en son mesajı gösterir.")
@app_commands.describe(kullanıcı="Belirli bir üyenin sildiği son mesajı görmek için seçin (isteğe bağlı)")
async def slash_snipe(interaction: discord.Interaction, kullanıcı: Optional[discord.Member] = None):
    ch_id = interaction.channel_id
    records = snipe_cache.get(ch_id, [])

    if not records:
        await interaction.response.send_message("🔍 Bu kanalda henüz yakalanan silinmiş bir mesaj bulunmuyor.", ephemeral=True)
        return

    target_entry = None
    if kullanıcı:
        for r in records:
            if r["author_id"] == kullanıcı.id:
                target_entry = r
                break
        if not target_entry:
            await interaction.response.send_message(f"🔍 {kullanıcı.mention} adlı üyenin bu kanalda silinmiş bir mesajı bulunamadı.", ephemeral=True)
            return
    else:
        target_entry = records[0]

    author_display = target_entry["author_display"]
    author_name = target_entry["author_name"]
    author_id = target_entry["author_id"]
    content = target_entry["content"]
    created_ts = int(target_entry["created_at"].timestamp())
    deleted_ts = int(target_entry["deleted_at"].timestamp())
    attachments = target_entry.get("attachments", [])

    embed = discord.Embed(
        title="🎯  |  Snipe (Silinen Mesaj)",
        description=f"```\n{content}\n```" if content != "(Metin içeriği yok)" else "*[Sadece medya / dosya eklentisi silindi]*",
        color=0x5865f2,
        timestamp=target_entry["deleted_at"]
    )

    if target_entry.get("author_avatar"):
        embed.set_author(name=f"{author_display} (@{author_name})", icon_url=target_entry["author_avatar"])
        embed.set_thumbnail(url=target_entry["author_avatar"])

    embed.add_field(name="👤 Mesaj Sahibi", value=f"<@{author_id}> (`{author_id}`)", inline=True)
    embed.add_field(name="🕒 Gönderilme", value=f"<t:{created_ts}:R>", inline=True)
    embed.add_field(name="🗑️ Silinme", value=f"<t:{deleted_ts}:R>", inline=True)

    # Eğer resim veya ek varsa
    image_exts = ('.png', '.jpg', '.jpeg', '.gif', '.webp')
    img_set = False
    if attachments:
        att_links = []
        for att in attachments:
            att_links.append(f"• [Dosyayı Görüntüle]({att})")
            if not img_set and any(att.lower().endswith(ext) or ext in att.lower() for ext in image_exts):
                embed.set_image(url=att)
                img_set = True
        embed.add_field(name="📎 Ekler", value="\n".join(att_links[:5]), inline=False)

    embed.set_footer(text=f"{config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} • Snipe Sistemi")
    await interaction.response.send_message(embed=embed)


# ─────────────────────────────────────────────
# BAŞLATMA FONKSİYONU
# ─────────────────────────────────────────────
def main():
    token = config.get("bot_token", "").strip()
    if not token or token == "BOT_TOKENINI_BURAYA_YAZIN":
        print("\n" + "═"*60, flush=True)
        print(f" [!] DİKKAT: {config.get('bot_adi', 'ɨ̇ ʍ ʐ ǟ')} Hoşgeldin Botu için henüz Bot Token girilmedi!", flush=True)
        print(" Lütfen config.json dosyasını açıp 'bot_token' alanına", flush=True)
        print(" Discord Developer Portal'dan aldığın bot tokenını yapıştır.", flush=True)
        print("═"*60 + "\n", flush=True)
        input("Devam etmek için Enter tuşuna bas...")
        sys.exit(1)

    # ----------------------------------------------------
    # 🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ (Açılış Kilidi)
    # ----------------------------------------------------
    from closy_license_client import verify_license_sync, setup_license_guard
    _lic_key = config.get("lisans_anahtari", "").strip()
    _lic_api = config.get("lisans_api_url", "http://localhost:5050").strip()

    print("\n" + "=" * 60)
    print("  🛡️ CLOSY LİSANS DOĞRULAMA KONTROLÜ")
    print(f"  🔑 Lisans Anahtarı : {_lic_key or 'GİRİLMEDİ'}")
    print(f"  🌐 Lisans Sunucusu : {_lic_api}")
    print("=" * 60)

    _lic_res = verify_license_sync(_lic_key, api_url=_lic_api)
    if not _lic_res.get("valid"):
        print("\n" + "!" * 65)
        print("  [LİSANS HATASI] ⛔ BOT BAŞLATILAMADI!")
        print(f"  Sebep: {_lic_res.get('reason', 'Geçersiz Lisans')}")
        print("  Lütfen config.json dosyasındaki 'lisans_anahtari' alanına")
        print("  satın aldığınız geçerli lisansı giriniz.")
        print("  Lisans Satın Almak veya Yenilemek İçin: https://discord.gg/imzapriw")
        print("!" * 65 + "\n")
        try:
            input("Kapatmak için Enter tuşuna basınız...")
        except Exception:
            pass
        sys.exit(1)

    print(f"  [LİSANS ONAYLANDI] 🟢 {_lic_res.get('message', 'Lisans aktif.')}")
    print(f"  [BİLGİ] Lisans Sahibi: {_lic_res.get('owner_discord', 'Müşteri')} | Kalan: {_lic_res.get('days_left')} Gün")
    print("=" * 60 + "\n")
    setup_license_guard(bot, license_key=_lic_key, api_url=_lic_api)

    try:
        bot.run(token)
    except discord.LoginFailure:
        print("\n[HATA] Girdiğin Bot Token geçersiz! Lütfen config.json dosyasını kontrol et.\n", flush=True)
        input("Çıkmak için Enter tuşuna bas...")
    except Exception as e:
        print(f"\n[HATA] Bot başlatılırken bir sorun oluştu: {e}\n", flush=True)
        input("Çıkmak için Enter tuşuna bas...")

if __name__ == "__main__":
    main()
