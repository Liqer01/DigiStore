// Closy Bot Manager - Frontend Renderer Logic (Gelismis Versiyon)
document.addEventListener('DOMContentLoaded', async () => {
  // State
  let currentLicense = '';
  let currentBotPath = '';
  let activeConfig = null;
  let isBotRunning = false;
  let botStartTime = null;
  let uptimeInterval = null;
  let logsList = [];
  let currentFilter = 'all';
  let searchQuery = '';

  // DOM Elements - Titlebar
  const btnWinMin = document.getElementById('btn-win-minimize');
  const btnWinMax = document.getElementById('btn-win-maximize');
  const btnWinClose = document.getElementById('btn-win-close');
  const titlebarStatusBadge = document.getElementById('titlebar-status-badge');
  const titlebarUptimeBadge = document.getElementById('titlebar-uptime-badge');

  // DOM Elements - Views
  const loginView = document.getElementById('login-view');
  const dashboardView = document.getElementById('dashboard-view');
  const licenseForm = document.getElementById('license-form');
  const licenseInput = document.getElementById('license-input');
  const loginAlert = document.getElementById('login-alert');
  const btnLogin = document.getElementById('btn-login');

  // Sidebar & Badges
  const sidebarLicenseKey = document.getElementById('sidebar-license-key');
  const sidebarBotPath = document.getElementById('sidebar-bot-path');
  const sidebarBotProfile = document.getElementById('sidebar-bot-profile');
  const sidebarBotAvatar = document.getElementById('sidebar-bot-avatar');
  const sidebarBotName = document.getElementById('sidebar-bot-name');
  const sidebarBotTag = document.getElementById('sidebar-bot-tag');

  // Overview Stats
  const overviewStatusText = document.getElementById('overview-status-text');
  const overviewPidText = document.getElementById('overview-pid-text');
  const overviewUptimeText = document.getElementById('overview-uptime-text');
  const overviewStartTime = document.getElementById('overview-start-time');
  const overviewLicenseSub = document.getElementById('overview-license-sub');

  // Actions & Tools
  const btnQuickStart = document.getElementById('btn-quick-start');
  const btnQuickStop = document.getElementById('btn-quick-stop');
  const btnQuickRestart = document.getElementById('btn-quick-restart');
  const btnChangeFolder = document.getElementById('btn-change-folder');
  const btnLogout = document.getElementById('btn-logout');
  const chkAutoRestart = document.getElementById('chk-auto-restart');

  const btnToolInstallReq = document.getElementById('btn-tool-install-req');
  const btnToolOpenFolder = document.getElementById('btn-tool-open-folder');
  const btnToolOpenTranscripts = document.getElementById('btn-tool-open-transcripts');
  const btnToolOpenWeb = document.getElementById('btn-tool-open-web');

  // Terminal Controls
  const previewTerminal = document.getElementById('preview-terminal');
  const fullTerminal = document.getElementById('full-terminal');
  const btnClearTerminal = document.getElementById('btn-clear-terminal');
  const btnCopyTerminal = document.getElementById('btn-copy-terminal');
  const btnExportTerminal = document.getElementById('btn-export-terminal');
  const btnGoToConsole = document.getElementById('btn-go-to-console');
  const chkAutoscroll = document.getElementById('chk-autoscroll');
  const chkTimestamps = document.getElementById('chk-timestamps');
  const terminalSearchInput = document.getElementById('terminal-search-input');
  const terminalLineCount = document.getElementById('terminal-line-count');
  const filterPills = document.querySelectorAll('.filter-pill');

  // Config Inputs
  const cfgBotToken = document.getElementById('cfg-bot-token');
  const btnToggleToken = document.getElementById('btn-toggle-token');
  const btnVerifyToken = document.getElementById('btn-verify-token');
  const tokenBotPreview = document.getElementById('token-bot-preview');
  const tokenBotAvatar = document.getElementById('token-bot-avatar');
  const tokenBotName = document.getElementById('token-bot-name');
  const tokenBotId = document.getElementById('token-bot-id');

  const cfgBotName = document.getElementById('cfg-bot-name');
  const cfgStreamUrl = document.getElementById('cfg-stream-url');
  const cfgLicenseKey = document.getElementById('cfg-license-key');
  const cfgPanelChannel = document.getElementById('cfg-panel-channel');
  const cfgTicketCategory = document.getElementById('cfg-ticket-category');
  const cfgLogChannel = document.getElementById('cfg-log-channel');
  const cfgStaffRole = document.getElementById('cfg-staff-role');
  const cfgVoiceChannel = document.getElementById('cfg-voice-channel');
  const cfgEmbedColor = document.getElementById('cfg-embed-color');
  const cfgColorPicker = document.getElementById('cfg-color-picker');
  const cfgWebPort = document.getElementById('cfg-web-port');
  const btnSaveConfig = document.getElementById('btn-save-config');
  const configAlert = document.getElementById('config-alert');

  // External Links
  const linkLoginSupport = document.getElementById('link-login-support');
  const btnSupportDiscord = document.getElementById('btn-support-discord');
  const btnSupportWeb = document.getElementById('btn-support-web');

  // --- CERCEVESIZ PENCERE KONTROLLERI ---
  if (btnWinMin) btnWinMin.addEventListener('click', () => window.closyAPI.windowMinimize());
  if (btnWinMax) btnWinMax.addEventListener('click', () => window.closyAPI.windowMaximize());
  if (btnWinClose) btnWinClose.addEventListener('click', () => window.closyAPI.windowClose());

  if (window.closyAPI.onWindowMaximizedState) {
    window.closyAPI.onWindowMaximizedState((isMaximized) => {
      if (btnWinMax) {
        btnWinMax.title = isMaximized ? 'Geri Yukle' : 'Ekrani Kapla';
      }
    });
  }

  // --- INITIAL SESSION LOAD ---
  try {
    const session = await window.closyAPI.getSavedSession();
    if (session) {
      if (session.licenseKey) {
        licenseInput.value = session.licenseKey;
      }
      if (session.botPath) {
        currentBotPath = session.botPath;
      }
    }
  } catch (err) {
    console.error('Session alinamadi:', err);
  }

  // --- NAVIGATION TABS ---
  const navItems = document.querySelectorAll('.nav-item');
  const tabPanes = document.querySelectorAll('.tab-pane');

  function switchTab(tabId) {
    navItems.forEach(item => {
      if (item.dataset.tab === tabId) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    tabPanes.forEach(pane => {
      if (pane.id === `tab-${tabId}`) {
        pane.classList.add('active');
      } else {
        pane.classList.remove('active');
      }
    });
  }

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      switchTab(item.dataset.tab);
    });
  });

  if (btnGoToConsole) {
    btnGoToConsole.addEventListener('click', () => {
      switchTab('console');
    });
  }

  // --- UPTIME SAYACI ---
  function formatDuration(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    const pad = (n) => String(n).padStart(2, '0');
    return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  }

  function startUptimeCounter(startTime) {
    botStartTime = startTime || Date.now();
    if (uptimeInterval) clearInterval(uptimeInterval);

    titlebarUptimeBadge.style.display = 'inline-block';
    overviewStartTime.textContent = new Date(botStartTime).toLocaleTimeString();

    uptimeInterval = setInterval(() => {
      const elapsed = Date.now() - botStartTime;
      const formatted = formatDuration(elapsed);
      overviewUptimeText.textContent = formatted;
      titlebarUptimeBadge.textContent = formatted;
    }, 1000);
  }

  function stopUptimeCounter() {
    if (uptimeInterval) {
      clearInterval(uptimeInterval);
      uptimeInterval = null;
    }
    titlebarUptimeBadge.style.display = 'none';
    overviewUptimeText.textContent = '00:00:00';
    overviewStartTime.textContent = 'Durduruldu';
  }

  // --- STATUS UPDATES ---
  function updateBotStatus(running, pid = null, startTime = null) {
    isBotRunning = running;
    if (running) {
      titlebarStatusBadge.textContent = 'Calisiyor';
      titlebarStatusBadge.className = 'badge badge-online';
      overviewStatusText.textContent = 'Calisiyor';
      overviewStatusText.style.color = 'var(--success)';
      overviewPidText.textContent = pid ? `PID: ${pid}` : 'PID: Aktif';
      btnQuickStart.disabled = true;
      btnQuickStop.disabled = false;
      btnQuickRestart.disabled = false;
      startUptimeCounter(startTime);
    } else {
      titlebarStatusBadge.textContent = 'Durduruldu';
      titlebarStatusBadge.className = 'badge badge-offline';
      overviewStatusText.textContent = 'Durduruldu';
      overviewStatusText.style.color = '#fff';
      overviewPidText.textContent = 'PID: -';
      btnQuickStart.disabled = false;
      btnQuickStop.disabled = true;
      btnQuickRestart.disabled = true;
      stopUptimeCounter();
    }
  }

  // --- TERMINAL LOGGING VE FILTRELEME ---
  function getTimestampString() {
    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return `[${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}]`;
  }

  function renderTerminal() {
    fullTerminal.innerHTML = '';
    const showTimestamps = chkTimestamps.checked;

    const filtered = logsList.filter(log => {
      if (currentFilter !== 'all' && log.type !== currentFilter) {
        return false;
      }
      if (searchQuery && !log.text.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      return true;
    });

    terminalLineCount.textContent = `${filtered.length} satir`;

    filtered.forEach(log => {
      const lineDiv = document.createElement('div');
      lineDiv.className = `log-line log-${log.type}`;

      if (showTimestamps && log.time) {
        const timeSpan = document.createElement('span');
        timeSpan.className = 'log-time';
        timeSpan.textContent = log.time + ' ';
        lineDiv.appendChild(timeSpan);
      }

      const textSpan = document.createElement('span');
      textSpan.textContent = log.text;
      lineDiv.appendChild(textSpan);

      fullTerminal.appendChild(lineDiv);
    });

    if (chkAutoscroll && chkAutoscroll.checked) {
      fullTerminal.scrollTop = fullTerminal.scrollHeight;
    }
  }

  function appendLog(type, text) {
    const timestamp = getTimestampString();
    logsList.push({ type, text, time: timestamp });

    // Onizleme terminaline son 15 logu ekle
    const previewSpan = document.createElement('span');
    previewSpan.className = `log-${type}`;
    previewSpan.textContent = (chkTimestamps.checked ? timestamp + ' ' : '') + text;
    previewTerminal.appendChild(previewSpan);
    previewTerminal.scrollTop = previewTerminal.scrollHeight;

    // Tam terminali guncelle
    renderTerminal();
  }

  filterPills.forEach(pill => {
    pill.addEventListener('click', () => {
      filterPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentFilter = pill.dataset.filter;
      renderTerminal();
    });
  });

  if (terminalSearchInput) {
    terminalSearchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.trim();
      renderTerminal();
    });
  }

  if (chkTimestamps) {
    chkTimestamps.addEventListener('change', () => {
      renderTerminal();
    });
  }

  window.closyAPI.onBotLog(({ type, text }) => {
    appendLog(type, text);
  });

  window.closyAPI.onBotStatus(({ running, code, pid, startTime, error }) => {
    updateBotStatus(running, pid, startTime);
    if (error) {
      appendLog('error', `\n[HATA] ${error}\n`);
    }
  });

  // --- DISCORD BOT TOKEN DOGRULAMA ---
  async function testBotToken(token) {
    if (!token) return;
    btnVerifyToken.disabled = true;
    btnVerifyToken.textContent = 'Test Ediliyor...';

    try {
      const res = await window.closyAPI.verifyBotToken(token);
      if (res.success) {
        // Formdaki bot onizlemesini guncelle
        tokenBotPreview.style.display = 'flex';
        tokenBotName.textContent = res.globalName || res.username;
        tokenBotId.textContent = `ID: ${res.botId}`;
        if (res.avatar) {
          tokenBotAvatar.src = res.avatar;
          tokenBotAvatar.style.display = 'block';
        } else {
          tokenBotAvatar.style.display = 'none';
        }

        // Yan menudeki mini bot profilini guncelle
        sidebarBotProfile.style.display = 'flex';
        sidebarBotName.textContent = res.globalName || res.username;
        sidebarBotTag.textContent = res.discriminator !== '0' ? `#${res.discriminator}` : `@${res.username}`;
        if (res.avatar) {
          sidebarBotAvatar.src = res.avatar;
          sidebarBotAvatar.style.display = 'block';
        } else {
          sidebarBotAvatar.style.display = 'none';
        }
      } else {
        alert(res.message);
        tokenBotPreview.style.display = 'none';
      }
    } catch (err) {
      alert('Token dogrulama hatasi: ' + err.message);
    } finally {
      btnVerifyToken.disabled = false;
      btnVerifyToken.textContent = 'Tokeni Test Et';
    }
  }

  if (btnVerifyToken) {
    btnVerifyToken.addEventListener('click', () => {
      testBotToken(cfgBotToken.value.trim());
    });
  }

  if (btnToggleToken) {
    btnToggleToken.addEventListener('click', () => {
      if (cfgBotToken.type === 'password') {
        cfgBotToken.type = 'text';
        btnToggleToken.textContent = 'Gizle';
      } else {
        cfgBotToken.type = 'password';
        btnToggleToken.textContent = 'Goster';
      }
    });
  }

  // --- EMBED RENK SECICI SYNC ---
  function hexTo0x(hex) {
    return '0x' + hex.replace('#', '').toUpperCase();
  }

  function oxToHex(ox) {
    return '#' + ox.replace('0x', '').replace('0X', '');
  }

  if (cfgColorPicker && cfgEmbedColor) {
    cfgColorPicker.addEventListener('input', (e) => {
      cfgEmbedColor.value = hexTo0x(e.target.value);
    });

    cfgEmbedColor.addEventListener('input', (e) => {
      const val = e.target.value.trim();
      if (/^(0x|0X|#)?[0-9A-Fa-f]{6}$/.test(val)) {
        cfgColorPicker.value = oxToHex(val);
      }
    });
  }

  // --- CONFIG LOADING & SAVING ---
  async function loadConfig() {
    if (!currentBotPath) {
      sidebarBotPath.textContent = 'Secili Dizin Yok';
      sidebarBotPath.title = 'Secili Dizin Yok';
      return;
    }

    sidebarBotPath.textContent = currentBotPath;
    sidebarBotPath.title = currentBotPath;

    const res = await window.closyAPI.readBotConfig(currentBotPath);
    if (res.success && res.config) {
      activeConfig = res.config;
      cfgBotToken.value = activeConfig.bot_token || '';
      cfgBotName.value = activeConfig.bot_adi || 'Closy Ticket';
      cfgStreamUrl.value = activeConfig.stream_url || 'https://twitch.tv/closydev';
      cfgLicenseKey.value = currentLicense || activeConfig.lisans_anahtari || '';
      cfgPanelChannel.value = activeConfig.ticket_panel_kanal_id ? String(activeConfig.ticket_panel_kanal_id) : '0';
      cfgTicketCategory.value = activeConfig.ticket_kategori_id ? String(activeConfig.ticket_kategori_id) : '0';
      cfgLogChannel.value = activeConfig.ticket_log_kanal_id ? String(activeConfig.ticket_log_kanal_id) : '0';
      cfgStaffRole.value = activeConfig.ticket_yetkili_rol_id ? String(activeConfig.ticket_yetkili_rol_id) : '0';
      cfgVoiceChannel.value = activeConfig.sabit_ses_kanal_id ? String(activeConfig.sabit_ses_kanal_id) : '0';
      
      const embedCol = activeConfig.embed_renk || '0x111216';
      cfgEmbedColor.value = embedCol;
      if (cfgColorPicker) {
        cfgColorPicker.value = oxToHex(embedCol);
      }

      cfgWebPort.value = activeConfig.web_port || 8080;

      // Token varsa bot profilini otomatik cek
      if (activeConfig.bot_token) {
        testBotToken(activeConfig.bot_token);
      }
    } else {
      console.warn('Config okunamadi:', res.message);
    }
  }

  // --- LOGIN SUBMIT ---
  licenseForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginAlert.style.display = 'none';
    btnLogin.disabled = true;
    btnLogin.textContent = 'Dogrulaniyor...';

    const rawKey = licenseInput.value.trim();
    try {
      const result = await window.closyAPI.verifyLicense(rawKey);
      if (result.success) {
        currentLicense = result.licenseKey;
        sidebarLicenseKey.textContent = currentLicense;
        overviewLicenseSub.textContent = currentLicense;
        cfgLicenseKey.value = currentLicense;

        loginView.style.display = 'none';
        dashboardView.style.display = 'flex';

        // Bot durumunu kontrol et
        const status = await window.closyAPI.getBotStatus();
        updateBotStatus(status.running, status.pid);

        // Config yukle
        await loadConfig();
      } else {
        loginAlert.textContent = result.message || 'Lisans dogrulanamadi.';
        loginAlert.style.display = 'block';
      }
    } catch (err) {
      loginAlert.textContent = 'Baglanti hatasi: ' + err.message;
      loginAlert.style.display = 'block';
    } finally {
      btnLogin.disabled = false;
      btnLogin.textContent = 'Giris Yap ve Kokpiti Ac';
    }
  });

  // --- BOT ISLEMLERI ---
  btnQuickStart.addEventListener('click', async () => {
    if (!currentBotPath) {
      alert('Lutfen once bot dizinini secin.');
      return;
    }
    btnQuickStart.disabled = true;
    const res = await window.closyAPI.startBot(currentBotPath);
    if (!res.success) {
      alert(res.message);
      btnQuickStart.disabled = false;
    } else {
      updateBotStatus(true, res.pid, res.startTime);
    }
  });

  btnQuickStop.addEventListener('click', async () => {
    btnQuickStop.disabled = true;
    const res = await window.closyAPI.stopBot();
    if (!res.success) {
      alert(res.message);
      btnQuickStop.disabled = false;
    } else {
      updateBotStatus(false);
    }
  });

  if (btnQuickRestart) {
    btnQuickRestart.addEventListener('click', async () => {
      if (!currentBotPath) {
        alert('Lutfen once bot dizinini secin.');
        return;
      }
      btnQuickRestart.disabled = true;
      btnQuickStop.disabled = true;
      appendLog('system', '[SISTEM] Bot yeniden baslatma komutu gonderildi...\n');
      const res = await window.closyAPI.restartBot(currentBotPath);
      if (!res.success) {
        alert(res.message);
        btnQuickRestart.disabled = false;
      } else {
        updateBotStatus(true, res.pid, res.startTime);
      }
      setTimeout(() => {
        btnQuickRestart.disabled = false;
      }, 1500);
    });
  }

  // --- OTOMATIK KURTARMA SWITCH ---
  if (chkAutoRestart) {
    chkAutoRestart.addEventListener('change', (e) => {
      window.closyAPI.setAutoRestart(e.target.checked);
      appendLog('system', `[AYAR] Cokerse otomatik yeniden baslat: ${e.target.checked ? 'AKTIF' : 'PASIF'}\n`);
    });
  }

  // --- HIZLI ARACLAR ---
  if (btnToolInstallReq) {
    btnToolInstallReq.addEventListener('click', async () => {
      if (!currentBotPath) {
        alert('Lutfen once bot klasorunu secin.');
        return;
      }
      switchTab('console');
      btnToolInstallReq.disabled = true;
      appendLog('system', '[PAKET KURUCU] requirements.txt kutuphaneleri indiriliyor...\n');
      const res = await window.closyAPI.installRequirements(currentBotPath);
      if (!res.success) {
        alert(res.message);
      }
      btnToolInstallReq.disabled = false;
    });
  }

  if (btnToolOpenFolder) {
    btnToolOpenFolder.addEventListener('click', () => {
      window.closyAPI.openFolder();
    });
  }

  if (btnToolOpenTranscripts) {
    btnToolOpenTranscripts.addEventListener('click', () => {
      window.closyAPI.openFolder('transcripts');
    });
  }

  if (btnToolOpenWeb) {
    btnToolOpenWeb.addEventListener('click', () => {
      const port = activeConfig?.web_port || 8080;
      window.closyAPI.openExternal(`http://localhost:${port}`);
    });
  }

  // --- DIZIN DEGISTIRME ---
  btnChangeFolder.addEventListener('click', async () => {
    const res = await window.closyAPI.selectBotFolder();
    if (res.success) {
      currentBotPath = res.botPath;
      sidebarBotPath.textContent = currentBotPath;
      sidebarBotPath.title = currentBotPath;
      await loadConfig();
      appendLog('system', `[SISTEM] Bot dizini guncellendi: ${currentBotPath}\n`);
    } else if (res.message) {
      alert(res.message);
    }
  });

  // --- CONFIG KAYDET ---
  btnSaveConfig.addEventListener('click', async (e) => {
    e.preventDefault();
    if (!activeConfig) activeConfig = {};

    const updatedConfig = {
      ...activeConfig,
      bot_token: cfgBotToken.value.trim(),
      bot_adi: cfgBotName.value.trim() || 'Closy Ticket',
      stream_url: cfgStreamUrl.value.trim() || 'https://twitch.tv/closydev',
      lisans_anahtari: currentLicense || cfgLicenseKey.value.trim(),
      ticket_panel_kanal_id: cfgPanelChannel.value.trim() || "0",
      ticket_kategori_id: cfgTicketCategory.value.trim() || "0",
      ticket_log_kanal_id: cfgLogChannel.value.trim() || "0",
      ticket_yetkili_rol_id: cfgStaffRole.value.trim() || "0",
      sabit_ses_kanal_id: cfgVoiceChannel.value.trim() || "0",
      embed_renk: cfgEmbedColor.value.trim() || '0x111216',
      web_port: parseInt(cfgWebPort.value.trim(), 10) || 8080,
      dm_bildirim: activeConfig.dm_bildirim !== undefined ? activeConfig.dm_bildirim : false,
      web_host: activeConfig.web_host || '0.0.0.0',
      web_base_url: activeConfig.web_base_url || 'auto',
      lisans_api_url: activeConfig.lisans_api_url || 'https://closydev.vercel.app'
    };

    btnSaveConfig.disabled = true;
    configAlert.style.display = 'none';

    try {
      const res = await window.closyAPI.saveBotConfig(updatedConfig, currentBotPath);
      if (res.success) {
        activeConfig = updatedConfig;
        configAlert.textContent = 'Yapilandirma (config.json) basariyla kaydedildi.';
        configAlert.className = 'alert alert-success';
        configAlert.style.display = 'block';
        appendLog('system', '[SISTEM] config.json degisiklikleri kaydedildi.\n');
        setTimeout(() => {
          configAlert.style.display = 'none';
        }, 4000);
      } else {
        configAlert.textContent = res.message;
        configAlert.className = 'alert alert-danger';
        configAlert.style.display = 'block';
      }
    } catch (err) {
      configAlert.textContent = 'Kaydetme hatasi: ' + err.message;
      configAlert.className = 'alert alert-danger';
      configAlert.style.display = 'block';
    } finally {
      btnSaveConfig.disabled = false;
    }
  });

  // --- TERMINAL BUTONLARI ---
  btnClearTerminal.addEventListener('click', () => {
    logsList = [];
    fullTerminal.innerHTML = '';
    previewTerminal.innerHTML = '';
    terminalLineCount.textContent = '0 satir';
  });

  btnCopyTerminal.addEventListener('click', async () => {
    const text = logsList.map(l => `${l.time ? l.time + ' ' : ''}${l.text}`).join('');
    if (text) {
      await navigator.clipboard.writeText(text);
      const orig = btnCopyTerminal.textContent;
      btnCopyTerminal.textContent = 'Kopyalandi!';
      setTimeout(() => btnCopyTerminal.textContent = orig, 2000);
    }
  });

  if (btnExportTerminal) {
    btnExportTerminal.addEventListener('click', () => {
      const fullText = logsList.map(l => `${l.time ? l.time + ' ' : ''}[${l.type.toUpperCase()}] ${l.text}`).join('');
      if (!fullText) {
        alert('Kaydedilecek log bulunmuyor.');
        return;
      }
      const blob = new Blob([fullText], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `closy-bot-log-${Date.now()}.txt`;
      a.click();
      URL.revokeObjectURL(url);
    });
  }

  // --- LOGOUT ---
  btnLogout.addEventListener('click', () => {
    if (isBotRunning) {
      if (!confirm('Bot su anda calisiyor. Oturumu kapatirsaniz bot durdurulacaktir. Devam etmek istiyor musunuz?')) {
        return;
      }
      window.closyAPI.stopBot();
    }
    dashboardView.style.display = 'none';
    loginView.style.display = 'flex';
    updateBotStatus(false);
  });

  // --- EXTERNAL LINKS ---
  function openLink(url) {
    if (window.closyAPI && window.closyAPI.openExternal) {
      window.closyAPI.openExternal(url);
    }
  }

  if (linkLoginSupport) linkLoginSupport.addEventListener('click', (e) => { e.preventDefault(); openLink('https://discord.gg/vqYZgAyP8v'); });
  if (btnSupportDiscord) btnSupportDiscord.addEventListener('click', () => openLink('https://discord.gg/vqYZgAyP8v'));
  if (btnSupportWeb) btnSupportWeb.addEventListener('click', () => openLink('https://closydev.vercel.app'));
});
