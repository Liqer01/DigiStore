const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('closyAPI', {
  // Pencere kontrolleri
  windowMinimize: () => ipcRenderer.invoke('window-minimize'),
  windowMaximize: () => ipcRenderer.invoke('window-maximize'),
  windowClose: () => ipcRenderer.invoke('window-close'),
  windowIsMaximized: () => ipcRenderer.invoke('window-is-maximized'),
  onWindowMaximizedState: (callback) => {
    const subscription = (event, val) => callback(val);
    ipcRenderer.on('window-maximized-state', subscription);
    return () => ipcRenderer.removeListener('window-maximized-state', subscription);
  },

  // Lisans & Oturum
  verifyLicense: (licenseKey) => ipcRenderer.invoke('verify-license', licenseKey),
  getSavedSession: () => ipcRenderer.invoke('get-saved-session'),
  selectBotFolder: () => ipcRenderer.invoke('select-bot-folder'),

  // Config & Token
  readBotConfig: (botPath) => ipcRenderer.invoke('read-bot-config', botPath),
  saveBotConfig: (newConfig, botPath) => ipcRenderer.invoke('save-bot-config', newConfig, botPath),
  verifyBotToken: (token) => ipcRenderer.invoke('verify-bot-token', token),

  // Bot Calistirma & Paket Kurulumu
  startBot: (botPath) => ipcRenderer.invoke('start-bot', botPath),
  stopBot: () => ipcRenderer.invoke('stop-bot'),
  restartBot: (botPath) => ipcRenderer.invoke('restart-bot', botPath),
  setAutoRestart: (enabled) => ipcRenderer.invoke('set-auto-restart', enabled),
  getBotStatus: () => ipcRenderer.invoke('get-bot-status'),
  installRequirements: (botPath) => ipcRenderer.invoke('install-requirements', botPath),

  // Dosya & Linkler
  openFolder: (subPath) => ipcRenderer.invoke('open-folder', subPath),
  openExternal: (url) => ipcRenderer.invoke('open-external', url),

  // Olay Dinleyicileri
  onBotLog: (callback) => {
    const subscription = (event, val) => callback(val);
    ipcRenderer.on('bot-log', subscription);
    return () => ipcRenderer.removeListener('bot-log', subscription);
  },
  onBotStatus: (callback) => {
    const subscription = (event, val) => callback(val);
    ipcRenderer.on('bot-status', subscription);
    return () => ipcRenderer.removeListener('bot-status', subscription);
  }
});
