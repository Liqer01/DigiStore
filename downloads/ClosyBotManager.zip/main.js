const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const { spawn, execSync } = require('child_process');

let mainWindow = null;
let botProcess = null;
let pipProcess = null;
let currentBotPath = '';
let intentionalStop = false;
let autoRestart = false;

const sessionFilePath = path.join(app.getPath('userData'), 'closy_manager_session.json');

function loadSession() {
  try {
    if (fs.existsSync(sessionFilePath)) {
      return JSON.parse(fs.readFileSync(sessionFilePath, 'utf8'));
    }
  } catch (e) {
    console.error('Session yukleme hatasi:', e);
  }
  return {};
}

function saveSession(data) {
  try {
    const current = loadSession();
    const merged = { ...current, ...data };
    fs.writeFileSync(sessionFilePath, JSON.stringify(merged, null, 2), 'utf8');
  } catch (e) {
    console.error('Session kaydetme hatasi:', e);
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 820,
    minWidth: 1020,
    minHeight: 700,
    frame: false,
    titleBarStyle: 'hidden',
    backgroundColor: '#0c0d12',
    title: 'Closy Bot Manager',
    icon: path.join(__dirname, 'assets', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  mainWindow.on('maximize', () => {
    mainWindow.webContents.send('window-maximized-state', true);
  });

  mainWindow.on('unmaximize', () => {
    mainWindow.webContents.send('window-maximized-state', false);
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  stopBotProcess();
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// PENCERE KONTROLLERI (FRAMELESS)
ipcMain.handle('window-minimize', () => {
  if (mainWindow) mainWindow.minimize();
});

ipcMain.handle('window-maximize', () => {
  if (!mainWindow) return false;
  if (mainWindow.isMaximized()) {
    mainWindow.unmaximize();
    return false;
  } else {
    mainWindow.maximize();
    return true;
  }
});

ipcMain.handle('window-close', () => {
  if (mainWindow) mainWindow.close();
});

ipcMain.handle('window-is-maximized', () => {
  return mainWindow ? mainWindow.isMaximized() : false;
});

function checkRemoteLicense(cleanKey) {
  return new Promise((resolve) => {
    // Sabit onayli lisanslar
    if (cleanKey === 'DS-TG7R-IRZG-VXZN-9SD2' || cleanKey === 'CLOSY-TK84-9921-X48A-9921') {
      return resolve({
        valid: true,
        active: true,
        licenseKey: cleanKey,
        productName: 'Closy Ticket Botu v14',
        productVersion: '14.0.2',
        plan: 'Omur Boyu Lisans',
        customer: 'Closy Kurucu & Yonetici',
        expiresAt: 'Sinirsiz'
      });
    }

    const payload = JSON.stringify({ license_key: cleanKey });
    const urls = [
      'https://closydev.site/api/license/verify',
      'https://closydev.vercel.app/api/license/verify',
      'http://localhost:3000/api/license/verify'
    ];

    let tried = 0;
    function tryNext() {
      if (tried >= urls.length) {
        return resolve({
          valid: false,
          active: false,
          reason: 'Lisans aktif degildir veya onaylanmamistir!'
        });
      }
      const targetUrl = urls[tried++];
      try {
        const urlObj = new URL(targetUrl);
        const isHttps = urlObj.protocol === 'https:';
        const client = isHttps ? require('https') : require('http');

        const req = client.request({
          hostname: urlObj.hostname,
          port: urlObj.port || (isHttps ? 443 : 80),
          path: urlObj.pathname,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(payload),
            'User-Agent': 'ClosyBotManager/1.0.0'
          },
          timeout: 4000
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => {
            try {
              const parsed = JSON.parse(data);
              if (parsed.valid && parsed.active !== false) {
                return resolve({
                  valid: true,
                  active: true,
                  licenseKey: cleanKey,
                  productName: parsed.product || 'Closy Ticket Botu v14',
                  productVersion: '14.0.2',
                  plan: parsed.plan || 'Omur Boyu Lisans',
                  customer: parsed.customer || 'Closy Lisansli Musteri',
                  expiresAt: 'Sinirsiz'
                });
              } else {
                return resolve({
                  valid: false,
                  active: false,
                  reason: parsed.reason || 'Bu lisans aktif degildir veya onay beklemektedir!'
                });
              }
            } catch (e) {
              tryNext();
            }
          });
        });

        req.on('error', () => tryNext());
        req.on('timeout', () => { req.destroy(); tryNext(); });
        req.write(payload);
        req.end();
      } catch (err) {
        tryNext();
      }
    }

    tryNext();
  });
}

// LISANS DOGRULAMA
ipcMain.handle('verify-license', async (event, licenseKey) => {
  if (!licenseKey || typeof licenseKey !== 'string') {
    return { success: false, message: 'Gecersiz lisans anahtari formati.' };
  }
  const cleanKey = licenseKey.trim().toUpperCase();
  const pattern = /^(CLOSY|DS)-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}(-[A-Z0-9]{4})?$/;
  if (!pattern.test(cleanKey)) {
    return { 
      success: false, 
      message: 'Lisans anahtari formati gecersiz. Ornek: CLOSY-XXXX-XXXX-XXXX veya DS-XXXX-XXXX-XXXX-XXXX' 
    };
  }

  const check = await checkRemoteLicense(cleanKey);
  if (!check.valid || check.active === false) {
    return {
      success: false,
      message: check.reason || 'Gecersiz veya aktif olmayan lisans anahtari! Lutfen satin aldiginiz onayli lisansi giriniz.'
    };
  }

  saveSession({ licenseKey: cleanKey });

  return {
    success: true,
    ...check
  };
});

// KAYITLI OTURUMU GETIR
ipcMain.handle('get-saved-session', async () => {
  const session = loadSession();
  if (session.licenseKey) {
    const check = await checkRemoteLicense(session.licenseKey);
    if (!check.valid || check.active === false) {
      session.invalidLicenseMessage = check.reason || 'Kayitli lisansiniz aktif degildir veya onay beklemektedir.';
      session.licenseKey = null;
      saveSession({ licenseKey: null });
    }
  }

  if (!session.botPath) {
    const candidatePaths = [
      path.join(app.getPath('home'), 'OneDrive', 'Desktop', 'bot 2'),
      path.join(app.getPath('desktop'), 'bot 2'),
      path.join(app.getPath('home'), 'Desktop', 'bot 2')
    ];
    for (const p of candidatePaths) {
      if (fs.existsSync(p) && fs.existsSync(path.join(p, 'main.py'))) {
        session.botPath = p;
        break;
      }
    }
  }
  return session;
});

// BOT KLASORU SECME
ipcMain.handle('select-bot-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Discord Bot Klasorunu Secin',
    properties: ['openDirectory']
  });

  if (result.canceled || !result.filePaths.length) {
    return { success: false };
  }

  const selectedPath = result.filePaths[0];
  const hasMainPy = fs.existsSync(path.join(selectedPath, 'main.py'));
  const hasConfig = fs.existsSync(path.join(selectedPath, 'config.json'));
  const hasRequirements = fs.existsSync(path.join(selectedPath, 'requirements.txt'));

  if (!hasMainPy) {
    return {
      success: false,
      message: 'Secilen klasorde main.py dosyasi bulunamadi. Lutfen bot kaynak kodlarinin bulundugu klasoru secin.'
    };
  }

  currentBotPath = selectedPath;
  saveSession({ botPath: selectedPath });

  return {
    success: true,
    botPath: selectedPath,
    hasConfig,
    hasRequirements
  };
});

// CONFIG OKU
ipcMain.handle('read-bot-config', async (event, customPath) => {
  const targetDir = customPath || currentBotPath || loadSession().botPath;
  if (!targetDir) {
    return { success: false, message: 'Bot klasoru secilmedi.' };
  }
  const configPath = path.join(targetDir, 'config.json');
  if (!fs.existsSync(configPath)) {
    return { success: false, message: 'Secilen klasorde config.json bulunamadi.' };
  }
  try {
    const content = fs.readFileSync(configPath, 'utf8');
    const parsed = JSON.parse(content);
    return { success: true, config: parsed, path: configPath };
  } catch (err) {
    return { success: false, message: 'config.json okunurken hata: ' + err.message };
  }
});

// CONFIG KAYDET
ipcMain.handle('save-bot-config', async (event, newConfig, customPath) => {
  const targetDir = customPath || currentBotPath || loadSession().botPath;
  if (!targetDir) {
    return { success: false, message: 'Bot klasoru secilmedi.' };
  }
  const configPath = path.join(targetDir, 'config.json');
  try {
    fs.writeFileSync(configPath, JSON.stringify(newConfig, null, 4), 'utf8');
    return { success: true, message: 'Yapilandirma (config.json) basariyla kaydedildi.' };
  } catch (err) {
    return { success: false, message: 'Yapilandirma kaydedilemedi: ' + err.message };
  }
});

// DISCORD BOT TOKENINI TEST ET VE BILGILERINI AL
ipcMain.handle('verify-bot-token', async (event, token) => {
  if (!token || typeof token !== 'string') {
    return { success: false, message: 'Lutfen bir bot tokeni girin.' };
  }

  const cleanToken = token.trim();
  return new Promise((resolve) => {
    const options = {
      hostname: 'discord.com',
      port: 443,
      path: '/api/v10/users/@me',
      method: 'GET',
      headers: {
        'Authorization': `Bot ${cleanToken}`,
        'User-Agent': 'ClosyBotManager/1.0.0'
      }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const data = JSON.parse(body);
          if (res.statusCode === 200 && data.id) {
            resolve({
              success: true,
              botId: data.id,
              username: data.username,
              globalName: data.global_name || data.username,
              discriminator: data.discriminator,
              avatar: data.avatar 
                ? `https://cdn.discordapp.com/avatars/${data.id}/${data.avatar}.png`
                : null
            });
          } else {
            resolve({
              success: false,
              message: data.message || 'Gecersiz bot tokeni. Lutfen Discord Developer Portal kontrol edin.'
            });
          }
        } catch (e) {
          resolve({ success: false, message: 'Discord yaniti cozumlenemedi.' });
        }
      });
    });

    req.on('error', (err) => {
      resolve({ success: false, message: 'Discord API baglanti hatasi: ' + err.message });
    });

    req.setTimeout(8000, () => {
      req.destroy();
      resolve({ success: false, message: 'Baglanti zaman asimina ugradi.' });
    });

    req.end();
  });
});

// PIP GEREKSINIMLERINI KUR
ipcMain.handle('install-requirements', async (event, customPath) => {
  if (pipProcess) {
    return { success: false, message: 'Paket yukleme islemi su anda zaten calisiyor.' };
  }

  const targetDir = customPath || currentBotPath || loadSession().botPath;
  if (!targetDir) {
    return { success: false, message: 'Bot klasoru secilmedi.' };
  }

  const reqPath = path.join(targetDir, 'requirements.txt');
  if (!fs.existsSync(reqPath)) {
    return { success: false, message: 'Secili klasorde requirements.txt bulunamadi.' };
  }

  try {
    if (mainWindow) {
      mainWindow.webContents.send('bot-log', {
        type: 'system',
        text: `\n[PAKET KURULUMU] requirements.txt paketleri yukleniyor...\n`
      });
    }

    pipProcess = spawn('python', ['-m', 'pip', 'install', '-r', 'requirements.txt'], {
      cwd: targetDir,
      env: {
        ...process.env,
        PYTHONIOENCODING: 'utf-8',
        PYTHONUNBUFFERED: '1'
      }
    });

    pipProcess.stdout.on('data', (data) => {
      if (mainWindow) {
        mainWindow.webContents.send('bot-log', {
          type: 'stdout',
          text: data.toString('utf8')
        });
      }
    });

    pipProcess.stderr.on('data', (data) => {
      if (mainWindow) {
        mainWindow.webContents.send('bot-log', {
          type: 'stderr',
          text: data.toString('utf8')
        });
      }
    });

    pipProcess.on('close', (code) => {
      pipProcess = null;
      if (mainWindow) {
        if (code === 0) {
          mainWindow.webContents.send('bot-log', {
            type: 'system',
            text: `[PAKET KURULUMU] Tum gereksinimler basariyla kuruldu.\n\n`
          });
        } else {
          mainWindow.webContents.send('bot-log', {
            type: 'error',
            text: `[PAKET KURULUMU] Kurulum sirasinda hata olustu (Kod: ${code}).\n\n`
          });
        }
      }
    });

    return { success: true, message: 'Paket yukleme islemi baslatildi.' };
  } catch (err) {
    pipProcess = null;
    return { success: false, message: 'Kurulum baslatilamadi: ' + err.message };
  }
});

// OTOMATIK YENIDEN BASLATMA AYARI
ipcMain.handle('set-auto-restart', (event, enabled) => {
  autoRestart = !!enabled;
  return { success: true, autoRestart };
});

// YARDIMCI: BOTU BASLATMA FONKSIYONU
async function startBotProcess(customPath) {
  const targetDir = customPath || currentBotPath || loadSession().botPath;
  if (!targetDir || !fs.existsSync(path.join(targetDir, 'main.py'))) {
    return { success: false, message: 'Gecerli bir bot klasoru bulunamadi (main.py eksik).' };
  }

  if (botProcess && botProcess.pid) {
    return { success: false, message: 'Bot su anda zaten calisiyor.' };
  }

  const session = loadSession();
  const licKey = session.licenseKey;
  if (!licKey) {
    return { success: false, message: 'Aktif bir lisans anahtari bulunamadi. Lutfen once lisans girisi yapiniz.' };
  }
  const licCheck = await checkRemoteLicense(licKey);
  if (!licCheck.valid || licCheck.active === false) {
    return { success: false, message: licCheck.reason || 'Bot baslatilamadi: Lisans aktif durumda degildir!' };
  }

  currentBotPath = targetDir;
  intentionalStop = false;

  try {
    botProcess = spawn('python', ['main.py'], {
      cwd: targetDir,
      env: {
        ...process.env,
        PYTHONIOENCODING: 'utf-8',
        PYTHONUNBUFFERED: '1'
      }
    });

    const startTime = Date.now();
    const pid = botProcess.pid;

    if (mainWindow) {
      mainWindow.webContents.send('bot-status', { 
        running: true, 
        pid: pid,
        startTime 
      });
      mainWindow.webContents.send('bot-log', {
        type: 'system',
        text: `[SISTEM] Bot calistirildi (PID: ${pid}, Dizin: ${targetDir})\n`
      });
    }

    botProcess.stdout.on('data', (data) => {
      if (mainWindow) {
        mainWindow.webContents.send('bot-log', {
          type: 'stdout',
          text: data.toString('utf8')
        });
      }
    });

    botProcess.stderr.on('data', (data) => {
      if (mainWindow) {
        mainWindow.webContents.send('bot-log', {
          type: 'stderr',
          text: data.toString('utf8')
        });
      }
    });

    botProcess.on('close', (code) => {
      botProcess = null;
      
      if (mainWindow) {
        mainWindow.webContents.send('bot-status', {
          running: false,
          code
        });
        mainWindow.webContents.send('bot-log', {
          type: 'system',
          text: `\n[SISTEM] Bot calismasi sonlandi (Cikis kodu: ${code})\n`
        });
      }

      // Otomatik kurtarma
      if (!intentionalStop && autoRestart && code !== 0) {
        if (mainWindow) {
          mainWindow.webContents.send('bot-log', {
            type: 'system',
            text: `[OTOMATIK KURTARMA] Bot beklenmedik sekilde durdu. 3 saniye icinde tekrar baslatiliyor...\n`
          });
        }
        setTimeout(() => {
          if (!botProcess && autoRestart) {
            startBotProcess(targetDir);
          }
        }, 3000);
      }
    });

    botProcess.on('error', (err) => {
      botProcess = null;
      if (mainWindow) {
        mainWindow.webContents.send('bot-status', {
          running: false,
          error: err.message
        });
        mainWindow.webContents.send('bot-log', {
          type: 'error',
          text: `\n[HATA] Bot baslatilamadi: ${err.message}\n`
        });
      }
    });

    return { success: true, message: 'Bot basariyla baslatildi.', pid, startTime };
  } catch (err) {
    botProcess = null;
    return { success: false, message: 'Bot baslatilirken hata olustu: ' + err.message };
  }
}

// YARDIMCI: BOTU DURDURMA FONKSIYONU
async function stopBotProcess() {
  intentionalStop = true;

  // 1. Temiz Discord cikis sinyali gonder (Discord'da botun aninda cevrimdisi olmasi icin)
  try {
    const http = require('http');
    const req = http.request({
      hostname: '127.0.0.1',
      port: 8080,
      path: '/api/shutdown',
      method: 'POST',
      timeout: 800
    });
    req.on('error', () => {});
    req.end();
    await new Promise(r => setTimeout(r, 600));
  } catch (e) {}

  if (botProcess && botProcess.pid) {
    const pid = botProcess.pid;
    try {
      if (process.platform === 'win32') {
        execSync(`taskkill /pid ${pid} /f /t`, { windowsHide: true, stdio: 'ignore' });
      } else {
        botProcess.kill('SIGKILL');
      }
    } catch (e) {}
    botProcess = null;
  }

  // Windows'ta python.exe arkada kalmissa kesin olarak temizle
  if (process.platform === 'win32') {
    try {
      const out = execSync('tasklist /FI "IMAGENAME eq python.exe" /FO CSV /NH', { windowsHide: true }).toString();
      if (out.includes('python.exe')) {
        execSync('taskkill /im python.exe /f', { windowsHide: true, stdio: 'ignore' });
      }
    } catch (e) {}
  }

  if (mainWindow) {
    mainWindow.webContents.send('bot-status', { running: false });
    mainWindow.webContents.send('bot-log', {
      type: 'system',
      text: `[SISTEM] Bot basariyla durduruldu.\n`
    });
  }

  return { success: true, message: 'Bot basariyla durduruldu.' };
}

// YARDIMCI: BOTU YENIDEN BASLATMA FONKSIYONU
async function restartBotProcess(customPath) {
  intentionalStop = true;

  // Once calisan bot sureclerini kapat
  await stopBotProcess();

  if (mainWindow) {
    mainWindow.webContents.send('bot-log', {
      type: 'system',
      text: `[SISTEM] Bot yeniden baslatiliyor...\n`
    });
  }

  // Portun ve socketlerin serbest kalmasi icin 1.5 saniye bekle
  await new Promise(r => setTimeout(r, 1500));

  const targetDir = customPath || currentBotPath || loadSession().botPath;
  return await startBotProcess(targetDir);
}

// IPC ISLEYICILERI
ipcMain.handle('start-bot', async (event, customPath) => {
  return await startBotProcess(customPath);
});

ipcMain.handle('stop-bot', async () => {
  return await stopBotProcess();
});

ipcMain.handle('restart-bot', async (event, customPath) => {
  return await restartBotProcess(customPath);
});

// BOT DURUMU AL
ipcMain.handle('get-bot-status', async () => {
  let isRunning = !!botProcess;
  if (!isRunning && process.platform === 'win32') {
    try {
      const out = execSync('tasklist /FI "IMAGENAME eq python.exe" /FO CSV /NH', { windowsHide: true }).toString();
      if (out.includes('python.exe')) {
        isRunning = true;
      }
    } catch (e) {}
  }
  return { running: isRunning, pid: botProcess ? botProcess.pid : null };
});

// KLASOR AC (WINDOWS GEZGINI)
ipcMain.handle('open-folder', async (event, subPath = '') => {
  const targetDir = currentBotPath || loadSession().botPath;
  if (!targetDir) {
    return { success: false, message: 'Bot klasoru secilmedi.' };
  }
  const fullPath = subPath ? path.join(targetDir, subPath) : targetDir;
  if (!fs.existsSync(fullPath)) {
    if (subPath) {
      fs.mkdirSync(fullPath, { recursive: true });
    } else {
      return { success: false, message: 'Klasor bulunamadi.' };
    }
  }
  shell.openPath(fullPath);
  return { success: true };
});

// HARICI LINK AC
ipcMain.handle('open-external', async (event, url) => {
  if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
    shell.openExternal(url);
  }
});
