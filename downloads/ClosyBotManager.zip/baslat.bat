@echo off
title Closy Bot Manager
cd /d "%~dp0"

echo ========================================================
echo               CLOSY BOT MANAGER BASLATILIYOR
echo ========================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [HATA] Node.js sisteminizde kurulu bulunamadi.
    echo Lutfen https://nodejs.org adresinden Node.js kurun.
    pause
    exit /b
)

if not exist node_modules (
    echo [BILGI] Ilk calistirma icin paketler yukleniyor...
    call npm install
)

echo [BILGI] Closy Bot Manager aciliyor...
call npm start

if %errorlevel% neq 0 (
    echo.
    echo [BILGI] Uygulama sonlandi.
)
